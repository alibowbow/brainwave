(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const o of document.querySelectorAll('link[rel="modulepreload"]'))a(o);new MutationObserver(o=>{for(const c of o)if(c.type==="childList")for(const u of c.addedNodes)u.tagName==="LINK"&&u.rel==="modulepreload"&&a(u)}).observe(document,{childList:!0,subtree:!0});function n(o){const c={};return o.integrity&&(c.integrity=o.integrity),o.referrerPolicy&&(c.referrerPolicy=o.referrerPolicy),o.crossOrigin==="use-credentials"?c.credentials="include":o.crossOrigin==="anonymous"?c.credentials="omit":c.credentials="same-origin",c}function a(o){if(o.ep)return;o.ep=!0;const c=n(o);fetch(o.href,c)}})();var nd={exports:{}},ol={};/**
 * @license React
 * react-jsx-runtime.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var jv;function US(){if(jv)return ol;jv=1;var s=Symbol.for("react.transitional.element"),t=Symbol.for("react.fragment");function n(a,o,c){var u=null;if(c!==void 0&&(u=""+c),o.key!==void 0&&(u=""+o.key),"key"in o){c={};for(var h in o)h!=="key"&&(c[h]=o[h])}else c=o;return o=c.ref,{$$typeof:s,type:a,key:u,ref:o!==void 0?o:null,props:c}}return ol.Fragment=t,ol.jsx=n,ol.jsxs=n,ol}var $v;function LS(){return $v||($v=1,nd.exports=US()),nd.exports}var nn=LS();/**
 * @license
 * Copyright 2010-2026 Three.js Authors
 * SPDX-License-Identifier: MIT
 */const Xp="186",NS=0,t_=1,OS=2,yl=1,Wp=2,_l=3,er=0,vi=1,vn=2,Ya=0,Sl=1,e_=2,n_=3,i_=4,PS=5,ro=100,zS=101,IS=102,BS=103,FS=104,HS=200,GS=201,VS=202,kS=203,Dx=204,Ux=205,XS=206,WS=207,qS=208,YS=209,ZS=210,KS=211,JS=212,QS=213,jS=214,Yd=0,Zd=1,Kd=2,Rl=3,Jd=4,Qd=5,jd=6,$d=7,Lx=0,$S=1,t1=2,xa=0,Nx=1,Ox=2,Px=3,qp=4,zx=5,Ix=6,Bx=7,Fx=300,nr=301,ho=302,id=303,ad=304,Hu=306,Ka=1e3,Wa=1001,tp=1002,ri=1003,e1=1004,Kc=1005,Wn=1006,sd=1007,Qs=1008,Ti=1009,Hx=1010,Gx=1011,Cl=1012,Yp=1013,la=1014,oa=1015,ji=1016,Zp=1017,Kp=1018,Dl=1020,Vx=35902,kx=35899,Xx=1021,Wx=1022,Qi=1023,Ma=1026,js=1027,Jp=1028,Qp=1029,ir=1030,jp=1031,$p=1033,Eu=33776,Tu=33777,Au=33778,wu=33779,ep=35840,np=35841,ip=35842,ap=35843,sp=36196,rp=37492,op=37496,lp=37488,cp=37489,Du=37490,up=37491,fp=37808,hp=37809,dp=37810,pp=37811,mp=37812,gp=37813,vp=37814,_p=37815,xp=37816,Mp=37817,yp=37818,Sp=37819,bp=37820,Ep=37821,Tp=36492,Ap=36494,wp=36495,Rp=36283,Cp=36284,Uu=36285,Dp=36286,n1=3200,Up=0,i1=1,Xa="",Ln="srgb",Lu="srgb-linear",Nu="linear",on="srgb",rd=7680,a1=519,s1=512,r1=513,o1=514,Gu=515,l1=516,c1=517,Vu=518,u1=519,qx=35044,a_="300 es",_a=2e3,Ul=2001;function f1(s){for(let t=s.length-1;t>=0;--t)if(s[t]>=65535)return!0;return!1}function Ou(s){return document.createElementNS("http://www.w3.org/1999/xhtml",s)}function h1(){const s=Ou("canvas");return s.style.display="block",s}const s_={};function r_(...s){const t="THREE."+s.shift();console.log(t,...s)}function Yx(s){const t=s[0];if(typeof t=="string"&&t.startsWith("TSL:")){const n=s[1];n&&n.isStackTrace?s[0]+=" "+n.getLocation():s[1]='Stack trace not available. Enable "THREE.Node.captureStackTrace" to capture stack traces.'}return s}function ye(...s){s=Yx(s);const t="THREE."+s.shift();{const n=s[0];n&&n.isStackTrace?console.warn(n.getError(t)):console.warn(t,...s)}}function Je(...s){s=Yx(s);const t="THREE."+s.shift();{const n=s[0];n&&n.isStackTrace?console.error(n.getError(t)):console.error(t,...s)}}function uo(...s){const t=s.join(" ");t in s_||(s_[t]=!0,ye(...s))}function d1(s,t,n){return new Promise(function(a,o){function c(){switch(s.clientWaitSync(t,s.SYNC_FLUSH_COMMANDS_BIT,0)){case s.WAIT_FAILED:o();break;case s.TIMEOUT_EXPIRED:setTimeout(c,n);break;default:a()}}setTimeout(c,n)})}const p1={[Yd]:Zd,[Kd]:jd,[Jd]:$d,[Rl]:Qd,[Zd]:Yd,[jd]:Kd,[$d]:Jd,[Qd]:Rl};class lr{addEventListener(t,n){this._listeners===void 0&&(this._listeners={});const a=this._listeners;a[t]===void 0&&(a[t]=[]),a[t].indexOf(n)===-1&&a[t].push(n)}hasEventListener(t,n){const a=this._listeners;return a===void 0?!1:a[t]!==void 0&&a[t].indexOf(n)!==-1}removeEventListener(t,n){const a=this._listeners;if(a===void 0)return;const o=a[t];if(o!==void 0){const c=o.indexOf(n);c!==-1&&o.splice(c,1)}}dispatchEvent(t){const n=this._listeners;if(n===void 0)return;const a=n[t.type];if(a!==void 0){t.target=this;const o=a.slice(0);for(let c=0,u=o.length;c<u;c++)o[c].call(this,t);t.target=null}}}const oi=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"];let o_=1234567;const bl=Math.PI/180,Ll=180/Math.PI;function cr(){const s=Math.random()*4294967295|0,t=Math.random()*4294967295|0,n=Math.random()*4294967295|0,a=Math.random()*4294967295|0;return(oi[s&255]+oi[s>>8&255]+oi[s>>16&255]+oi[s>>24&255]+"-"+oi[t&255]+oi[t>>8&255]+"-"+oi[t>>16&15|64]+oi[t>>24&255]+"-"+oi[n&63|128]+oi[n>>8&255]+"-"+oi[n>>16&255]+oi[n>>24&255]+oi[a&255]+oi[a>>8&255]+oi[a>>16&255]+oi[a>>24&255]).toLowerCase()}function ze(s,t,n){return Math.max(t,Math.min(n,s))}function tm(s,t){return(s%t+t)%t}function m1(s,t,n,a,o){return a+(s-t)*(o-a)/(n-t)}function g1(s,t,n){return s!==t?(n-s)/(t-s):0}function El(s,t,n){return(1-n)*s+n*t}function v1(s,t,n,a){return El(s,t,1-Math.exp(-n*a))}function _1(s,t=1){return t-Math.abs(tm(s,t*2)-t)}function x1(s,t,n){return s<=t?0:s>=n?1:(s=(s-t)/(n-t),s*s*(3-2*s))}function M1(s,t,n){return s<=t?0:s>=n?1:(s=(s-t)/(n-t),s*s*s*(s*(s*6-15)+10))}function y1(s,t){return s+Math.floor(Math.random()*(t-s+1))}function S1(s,t){return s+Math.random()*(t-s)}function b1(s){return s*(.5-Math.random())}function E1(s){s!==void 0&&(o_=s);let t=o_+=1831565813;return t=Math.imul(t^t>>>15,t|1),t^=t+Math.imul(t^t>>>7,t|61),((t^t>>>14)>>>0)/4294967296}function T1(s){return s*bl}function A1(s){return s*Ll}function w1(s){return s>0&&Number.isInteger(s)&&2**Math.round(Math.log2(s))===s}function R1(s){return Math.pow(2,Math.ceil(Math.log(s)/Math.LN2))}function C1(s){return Math.pow(2,Math.floor(Math.log(s)/Math.LN2))}function D1(s,t,n,a,o){const c=Math.cos,u=Math.sin,h=c(n/2),p=u(n/2),d=c((t+a)/2),g=u((t+a)/2),v=c((t-a)/2),_=u((t-a)/2),x=c((a-t)/2),b=u((a-t)/2);switch(o){case"XYX":s.set(h*g,p*v,p*_,h*d);break;case"YZY":s.set(p*_,h*g,p*v,h*d);break;case"ZXZ":s.set(p*v,p*_,h*g,h*d);break;case"XZX":s.set(h*g,p*b,p*x,h*d);break;case"YXY":s.set(p*x,h*g,p*b,h*d);break;case"ZYZ":s.set(p*b,p*x,h*g,h*d);break;default:ye("MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: "+o)}}function oo(s,t){switch(t.constructor){case Float32Array:return s;case Uint32Array:return s/4294967295;case Uint16Array:return s/65535;case Uint8Array:case Uint8ClampedArray:return s/255;case Int32Array:return Math.max(s/2147483647,-1);case Int16Array:return Math.max(s/32767,-1);case Int8Array:return Math.max(s/127,-1);default:throw new Error("THREE.MathUtils: Invalid component type.")}}function mi(s,t){switch(t.constructor){case Float32Array:return s;case Uint32Array:return Math.round(s*4294967295);case Uint16Array:return Math.round(s*65535);case Uint8Array:case Uint8ClampedArray:return Math.round(s*255);case Int32Array:return Math.round(s*2147483647);case Int16Array:return Math.round(s*32767);case Int8Array:return Math.round(s*127);default:throw new Error("THREE.MathUtils: Invalid component type.")}}const $s={DEG2RAD:bl,RAD2DEG:Ll,generateUUID:cr,clamp:ze,euclideanModulo:tm,mapLinear:m1,inverseLerp:g1,lerp:El,damp:v1,pingpong:_1,smoothstep:x1,smootherstep:M1,randInt:y1,randFloat:S1,randFloatSpread:b1,seededRandom:E1,degToRad:T1,radToDeg:A1,isPowerOfTwo:w1,ceilPowerOfTwo:R1,floorPowerOfTwo:C1,setQuaternionFromProperEuler:D1,normalize:mi,denormalize:oo},mm=class mm{constructor(t=0,n=0){this.x=t,this.y=n}get width(){return this.x}set width(t){this.x=t}get height(){return this.y}set height(t){this.y=t}set(t,n){return this.x=t,this.y=n,this}setScalar(t){return this.x=t,this.y=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setComponent(t,n){switch(t){case 0:this.x=n;break;case 1:this.y=n;break;default:throw new Error("THREE.Vector2: index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;default:throw new Error("THREE.Vector2: index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y)}copy(t){return this.x=t.x,this.y=t.y,this}add(t){return this.x+=t.x,this.y+=t.y,this}addScalar(t){return this.x+=t,this.y+=t,this}addVectors(t,n){return this.x=t.x+n.x,this.y=t.y+n.y,this}addScaledVector(t,n){return this.x+=t.x*n,this.y+=t.y*n,this}sub(t){return this.x-=t.x,this.y-=t.y,this}subScalar(t){return this.x-=t,this.y-=t,this}subVectors(t,n){return this.x=t.x-n.x,this.y=t.y-n.y,this}multiply(t){return this.x*=t.x,this.y*=t.y,this}multiplyScalar(t){return this.x*=t,this.y*=t,this}divide(t){return this.x/=t.x,this.y/=t.y,this}divideScalar(t){return this.multiplyScalar(1/t)}applyMatrix3(t){const n=this.x,a=this.y,o=t.elements;return this.x=o[0]*n+o[3]*a+o[6],this.y=o[1]*n+o[4]*a+o[7],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this}clamp(t,n){return this.x=ze(this.x,t.x,n.x),this.y=ze(this.y,t.y,n.y),this}clampScalar(t,n){return this.x=ze(this.x,t,n),this.y=ze(this.y,t,n),this}clampLength(t,n){const a=this.length();return this.divideScalar(a||1).multiplyScalar(ze(a,t,n))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(t){return this.x*t.x+this.y*t.y}cross(t){return this.x*t.y-this.y*t.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(t){const n=Math.sqrt(this.lengthSq()*t.lengthSq());if(n===0)return Math.PI/2;const a=this.dot(t)/n;return Math.acos(ze(a,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){const n=this.x-t.x,a=this.y-t.y;return n*n+a*a}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,n){return this.x+=(t.x-this.x)*n,this.y+=(t.y-this.y)*n,this}lerpVectors(t,n,a){return this.x=t.x+(n.x-t.x)*a,this.y=t.y+(n.y-t.y)*a,this}equals(t){return t.x===this.x&&t.y===this.y}fromArray(t,n=0){return this.x=t[n],this.y=t[n+1],this}toArray(t=[],n=0){return t[n]=this.x,t[n+1]=this.y,t}fromBufferAttribute(t,n){return this.x=t.getX(n),this.y=t.getY(n),this}rotateAround(t,n){const a=Math.cos(n),o=Math.sin(n),c=this.x-t.x,u=this.y-t.y;return this.x=c*a-u*o+t.x,this.y=c*o+u*a+t.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}};mm.prototype.isVector2=!0;let Ot=mm;class Ei{constructor(t=0,n=0,a=0,o=1){this.isQuaternion=!0,this._x=t,this._y=n,this._z=a,this._w=o}static slerpFlat(t,n,a,o,c,u,h){let p=a[o+0],d=a[o+1],g=a[o+2],v=a[o+3],_=c[u+0],x=c[u+1],b=c[u+2],R=c[u+3];if(v!==R||p!==_||d!==x||g!==b){let y=p*_+d*x+g*b+v*R;y<0&&(_=-_,x=-x,b=-b,R=-R,y=-y);let M=1-h;if(y<.9995){const C=Math.acos(y),P=Math.sin(C);M=Math.sin(M*C)/P,h=Math.sin(h*C)/P,p=p*M+_*h,d=d*M+x*h,g=g*M+b*h,v=v*M+R*h}else{p=p*M+_*h,d=d*M+x*h,g=g*M+b*h,v=v*M+R*h;const C=1/Math.sqrt(p*p+d*d+g*g+v*v);p*=C,d*=C,g*=C,v*=C}}t[n]=p,t[n+1]=d,t[n+2]=g,t[n+3]=v}static multiplyQuaternionsFlat(t,n,a,o,c,u){const h=a[o],p=a[o+1],d=a[o+2],g=a[o+3],v=c[u],_=c[u+1],x=c[u+2],b=c[u+3];return t[n]=h*b+g*v+p*x-d*_,t[n+1]=p*b+g*_+d*v-h*x,t[n+2]=d*b+g*x+h*_-p*v,t[n+3]=g*b-h*v-p*_-d*x,t}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get w(){return this._w}set w(t){this._w=t,this._onChangeCallback()}set(t,n,a,o){return this._x=t,this._y=n,this._z=a,this._w=o,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(t){return this._x=t.x,this._y=t.y,this._z=t.z,this._w=t.w,this._onChangeCallback(),this}setFromEuler(t,n=!0){const a=t._x,o=t._y,c=t._z,u=t._order,h=Math.cos,p=Math.sin,d=h(a/2),g=h(o/2),v=h(c/2),_=p(a/2),x=p(o/2),b=p(c/2);switch(u){case"XYZ":this._x=_*g*v+d*x*b,this._y=d*x*v-_*g*b,this._z=d*g*b+_*x*v,this._w=d*g*v-_*x*b;break;case"YXZ":this._x=_*g*v+d*x*b,this._y=d*x*v-_*g*b,this._z=d*g*b-_*x*v,this._w=d*g*v+_*x*b;break;case"ZXY":this._x=_*g*v-d*x*b,this._y=d*x*v+_*g*b,this._z=d*g*b+_*x*v,this._w=d*g*v-_*x*b;break;case"ZYX":this._x=_*g*v-d*x*b,this._y=d*x*v+_*g*b,this._z=d*g*b-_*x*v,this._w=d*g*v+_*x*b;break;case"YZX":this._x=_*g*v+d*x*b,this._y=d*x*v+_*g*b,this._z=d*g*b-_*x*v,this._w=d*g*v-_*x*b;break;case"XZY":this._x=_*g*v-d*x*b,this._y=d*x*v-_*g*b,this._z=d*g*b+_*x*v,this._w=d*g*v+_*x*b;break;default:ye("Quaternion: .setFromEuler() encountered an unknown order: "+u)}return n===!0&&this._onChangeCallback(),this}setFromAxisAngle(t,n){const a=n/2,o=Math.sin(a);return this._x=t.x*o,this._y=t.y*o,this._z=t.z*o,this._w=Math.cos(a),this._onChangeCallback(),this}setFromRotationMatrix(t){const n=t.elements,a=n[0],o=n[4],c=n[8],u=n[1],h=n[5],p=n[9],d=n[2],g=n[6],v=n[10],_=a+h+v;if(_>0){const x=.5/Math.sqrt(_+1);this._w=.25/x,this._x=(g-p)*x,this._y=(c-d)*x,this._z=(u-o)*x}else if(a>h&&a>v){const x=2*Math.sqrt(1+a-h-v);this._w=(g-p)/x,this._x=.25*x,this._y=(o+u)/x,this._z=(c+d)/x}else if(h>v){const x=2*Math.sqrt(1+h-a-v);this._w=(c-d)/x,this._x=(o+u)/x,this._y=.25*x,this._z=(p+g)/x}else{const x=2*Math.sqrt(1+v-a-h);this._w=(u-o)/x,this._x=(c+d)/x,this._y=(p+g)/x,this._z=.25*x}return this._onChangeCallback(),this}setFromUnitVectors(t,n){let a=t.dot(n)+1;return a<1e-8?(a=0,Math.abs(t.x)>Math.abs(t.z)?(this._x=-t.y,this._y=t.x,this._z=0,this._w=a):(this._x=0,this._y=-t.z,this._z=t.y,this._w=a)):(this._x=t.y*n.z-t.z*n.y,this._y=t.z*n.x-t.x*n.z,this._z=t.x*n.y-t.y*n.x,this._w=a),this.normalize()}angleTo(t){return 2*Math.acos(Math.abs(ze(this.dot(t),-1,1)))}rotateTowards(t,n){const a=this.angleTo(t);if(a===0)return this;const o=Math.min(1,n/a);return this.slerp(t,o),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(t){return this._x*t._x+this._y*t._y+this._z*t._z+this._w*t._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let t=this.length();return t===0?(this._x=0,this._y=0,this._z=0,this._w=1):(t=1/t,this._x=this._x*t,this._y=this._y*t,this._z=this._z*t,this._w=this._w*t),this._onChangeCallback(),this}multiply(t){return this.multiplyQuaternions(this,t)}premultiply(t){return this.multiplyQuaternions(t,this)}multiplyQuaternions(t,n){const a=t._x,o=t._y,c=t._z,u=t._w,h=n._x,p=n._y,d=n._z,g=n._w;return this._x=a*g+u*h+o*d-c*p,this._y=o*g+u*p+c*h-a*d,this._z=c*g+u*d+a*p-o*h,this._w=u*g-a*h-o*p-c*d,this._onChangeCallback(),this}slerp(t,n){let a=t._x,o=t._y,c=t._z,u=t._w,h=this.dot(t);h<0&&(a=-a,o=-o,c=-c,u=-u,h=-h);let p=1-n;if(h<.9995){const d=Math.acos(h),g=Math.sin(d);p=Math.sin(p*d)/g,n=Math.sin(n*d)/g,this._x=this._x*p+a*n,this._y=this._y*p+o*n,this._z=this._z*p+c*n,this._w=this._w*p+u*n,this._onChangeCallback()}else this._x=this._x*p+a*n,this._y=this._y*p+o*n,this._z=this._z*p+c*n,this._w=this._w*p+u*n,this.normalize();return this}slerpQuaternions(t,n,a){return this.copy(t).slerp(n,a)}random(){const t=2*Math.PI*Math.random(),n=2*Math.PI*Math.random(),a=Math.random(),o=Math.sqrt(1-a),c=Math.sqrt(a);return this.set(o*Math.sin(t),o*Math.cos(t),c*Math.sin(n),c*Math.cos(n))}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._w===this._w}fromArray(t,n=0){return this._x=t[n],this._y=t[n+1],this._z=t[n+2],this._w=t[n+3],this._onChangeCallback(),this}toArray(t=[],n=0){return t[n]=this._x,t[n+1]=this._y,t[n+2]=this._z,t[n+3]=this._w,t}fromBufferAttribute(t,n){return this._x=t.getX(n),this._y=t.getY(n),this._z=t.getZ(n),this._w=t.getW(n),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}const gm=class gm{constructor(t=0,n=0,a=0){this.x=t,this.y=n,this.z=a}set(t,n,a){return a===void 0&&(a=this.z),this.x=t,this.y=n,this.z=a,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setComponent(t,n){switch(t){case 0:this.x=n;break;case 1:this.y=n;break;case 2:this.z=n;break;default:throw new Error("THREE.Vector3: index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("THREE.Vector3: index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this}addVectors(t,n){return this.x=t.x+n.x,this.y=t.y+n.y,this.z=t.z+n.z,this}addScaledVector(t,n){return this.x+=t.x*n,this.y+=t.y*n,this.z+=t.z*n,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this}subVectors(t,n){return this.x=t.x-n.x,this.y=t.y-n.y,this.z=t.z-n.z,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this}multiplyVectors(t,n){return this.x=t.x*n.x,this.y=t.y*n.y,this.z=t.z*n.z,this}applyEuler(t){return this.applyQuaternion(l_.setFromEuler(t))}applyAxisAngle(t,n){return this.applyQuaternion(l_.setFromAxisAngle(t,n))}applyMatrix3(t){const n=this.x,a=this.y,o=this.z,c=t.elements;return this.x=c[0]*n+c[3]*a+c[6]*o,this.y=c[1]*n+c[4]*a+c[7]*o,this.z=c[2]*n+c[5]*a+c[8]*o,this}applyNormalMatrix(t){return this.applyMatrix3(t).normalize()}applyMatrix4(t){const n=this.x,a=this.y,o=this.z,c=t.elements,u=1/(c[3]*n+c[7]*a+c[11]*o+c[15]);return this.x=(c[0]*n+c[4]*a+c[8]*o+c[12])*u,this.y=(c[1]*n+c[5]*a+c[9]*o+c[13])*u,this.z=(c[2]*n+c[6]*a+c[10]*o+c[14])*u,this}applyQuaternion(t){const n=this.x,a=this.y,o=this.z,c=t.x,u=t.y,h=t.z,p=t.w,d=2*(u*o-h*a),g=2*(h*n-c*o),v=2*(c*a-u*n);return this.x=n+p*d+u*v-h*g,this.y=a+p*g+h*d-c*v,this.z=o+p*v+c*g-u*d,this}project(t){return this.applyMatrix4(t.matrixWorldInverse).applyMatrix4(t.projectionMatrix)}unproject(t){return this.applyMatrix4(t.projectionMatrixInverse).applyMatrix4(t.matrixWorld)}transformDirection(t){const n=this.x,a=this.y,o=this.z,c=t.elements;return this.x=c[0]*n+c[4]*a+c[8]*o,this.y=c[1]*n+c[5]*a+c[9]*o,this.z=c[2]*n+c[6]*a+c[10]*o,this.normalize()}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this}divideScalar(t){return this.multiplyScalar(1/t)}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this}clamp(t,n){return this.x=ze(this.x,t.x,n.x),this.y=ze(this.y,t.y,n.y),this.z=ze(this.z,t.z,n.z),this}clampScalar(t,n){return this.x=ze(this.x,t,n),this.y=ze(this.y,t,n),this.z=ze(this.z,t,n),this}clampLength(t,n){const a=this.length();return this.divideScalar(a||1).multiplyScalar(ze(a,t,n))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,n){return this.x+=(t.x-this.x)*n,this.y+=(t.y-this.y)*n,this.z+=(t.z-this.z)*n,this}lerpVectors(t,n,a){return this.x=t.x+(n.x-t.x)*a,this.y=t.y+(n.y-t.y)*a,this.z=t.z+(n.z-t.z)*a,this}cross(t){return this.crossVectors(this,t)}crossVectors(t,n){const a=t.x,o=t.y,c=t.z,u=n.x,h=n.y,p=n.z;return this.x=o*p-c*h,this.y=c*u-a*p,this.z=a*h-o*u,this}projectOnVector(t){const n=t.lengthSq();if(n===0)return this.set(0,0,0);const a=t.dot(this)/n;return this.copy(t).multiplyScalar(a)}projectOnPlane(t){return od.copy(this).projectOnVector(t),this.sub(od)}reflect(t){return this.sub(od.copy(t).multiplyScalar(2*this.dot(t)))}angleTo(t){const n=Math.sqrt(this.lengthSq()*t.lengthSq());if(n===0)return Math.PI/2;const a=this.dot(t)/n;return Math.acos(ze(a,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){const n=this.x-t.x,a=this.y-t.y,o=this.z-t.z;return n*n+a*a+o*o}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)+Math.abs(this.z-t.z)}setFromSpherical(t){return this.setFromSphericalCoords(t.radius,t.phi,t.theta)}setFromSphericalCoords(t,n,a){const o=Math.sin(n)*t;return this.x=o*Math.sin(a),this.y=Math.cos(n)*t,this.z=o*Math.cos(a),this}setFromCylindrical(t){return this.setFromCylindricalCoords(t.radius,t.theta,t.y)}setFromCylindricalCoords(t,n,a){return this.x=t*Math.sin(n),this.y=a,this.z=t*Math.cos(n),this}setFromMatrixPosition(t){const n=t.elements;return this.x=n[12],this.y=n[13],this.z=n[14],this}setFromMatrixScale(t){const n=this.setFromMatrixColumn(t,0).length(),a=this.setFromMatrixColumn(t,1).length(),o=this.setFromMatrixColumn(t,2).length();return this.x=n,this.y=a,this.z=o,this}setFromMatrixColumn(t,n){return this.fromArray(t.elements,n*4)}setFromMatrix3Column(t,n){return this.fromArray(t.elements,n*3)}setFromEuler(t){return this.x=t._x,this.y=t._y,this.z=t._z,this}setFromColor(t){return this.x=t.r,this.y=t.g,this.z=t.b,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z}fromArray(t,n=0){return this.x=t[n],this.y=t[n+1],this.z=t[n+2],this}toArray(t=[],n=0){return t[n]=this.x,t[n+1]=this.y,t[n+2]=this.z,t}fromBufferAttribute(t,n){return this.x=t.getX(n),this.y=t.getY(n),this.z=t.getZ(n),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const t=Math.random()*Math.PI*2,n=Math.random()*2-1,a=Math.sqrt(1-n*n);return this.x=a*Math.cos(t),this.y=n,this.z=a*Math.sin(t),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}};gm.prototype.isVector3=!0;let B=gm;const od=new B,l_=new Ei,vm=class vm{constructor(t,n,a,o,c,u,h,p,d){this.elements=[1,0,0,0,1,0,0,0,1],t!==void 0&&this.set(t,n,a,o,c,u,h,p,d)}set(t,n,a,o,c,u,h,p,d){const g=this.elements;return g[0]=t,g[1]=o,g[2]=h,g[3]=n,g[4]=c,g[5]=p,g[6]=a,g[7]=u,g[8]=d,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(t){const n=this.elements,a=t.elements;return n[0]=a[0],n[1]=a[1],n[2]=a[2],n[3]=a[3],n[4]=a[4],n[5]=a[5],n[6]=a[6],n[7]=a[7],n[8]=a[8],this}extractBasis(t,n,a){return t.setFromMatrix3Column(this,0),n.setFromMatrix3Column(this,1),a.setFromMatrix3Column(this,2),this}setFromMatrix4(t){const n=t.elements;return this.set(n[0],n[4],n[8],n[1],n[5],n[9],n[2],n[6],n[10]),this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,n){const a=t.elements,o=n.elements,c=this.elements,u=a[0],h=a[3],p=a[6],d=a[1],g=a[4],v=a[7],_=a[2],x=a[5],b=a[8],R=o[0],y=o[3],M=o[6],C=o[1],P=o[4],E=o[7],U=o[2],L=o[5],N=o[8];return c[0]=u*R+h*C+p*U,c[3]=u*y+h*P+p*L,c[6]=u*M+h*E+p*N,c[1]=d*R+g*C+v*U,c[4]=d*y+g*P+v*L,c[7]=d*M+g*E+v*N,c[2]=_*R+x*C+b*U,c[5]=_*y+x*P+b*L,c[8]=_*M+x*E+b*N,this}multiplyScalar(t){const n=this.elements;return n[0]*=t,n[3]*=t,n[6]*=t,n[1]*=t,n[4]*=t,n[7]*=t,n[2]*=t,n[5]*=t,n[8]*=t,this}determinant(){const t=this.elements,n=t[0],a=t[1],o=t[2],c=t[3],u=t[4],h=t[5],p=t[6],d=t[7],g=t[8];return n*u*g-n*h*d-a*c*g+a*h*p+o*c*d-o*u*p}invert(){const t=this.elements,n=t[0],a=t[1],o=t[2],c=t[3],u=t[4],h=t[5],p=t[6],d=t[7],g=t[8],v=g*u-h*d,_=h*p-g*c,x=d*c-u*p,b=n*v+a*_+o*x;if(b===0)return this.set(0,0,0,0,0,0,0,0,0);const R=1/b;return t[0]=v*R,t[1]=(o*d-g*a)*R,t[2]=(h*a-o*u)*R,t[3]=_*R,t[4]=(g*n-o*p)*R,t[5]=(o*c-h*n)*R,t[6]=x*R,t[7]=(a*p-d*n)*R,t[8]=(u*n-a*c)*R,this}transpose(){let t;const n=this.elements;return t=n[1],n[1]=n[3],n[3]=t,t=n[2],n[2]=n[6],n[6]=t,t=n[5],n[5]=n[7],n[7]=t,this}getNormalMatrix(t){return this.setFromMatrix4(t).invert().transpose()}transposeIntoArray(t){const n=this.elements;return t[0]=n[0],t[1]=n[3],t[2]=n[6],t[3]=n[1],t[4]=n[4],t[5]=n[7],t[6]=n[2],t[7]=n[5],t[8]=n[8],this}setUvTransform(t,n,a,o,c,u,h){const p=Math.cos(c),d=Math.sin(c);return this.set(a*p,a*d,-a*(p*u+d*h)+u+t,-o*d,o*p,-o*(-d*u+p*h)+h+n,0,0,1),this}scale(t,n){return uo("Matrix3: .scale() is deprecated. Use .makeScale() instead."),this.premultiply(ld.makeScale(t,n)),this}rotate(t){return uo("Matrix3: .rotate() is deprecated. Use .makeRotation() instead."),this.premultiply(ld.makeRotation(-t)),this}translate(t,n){return uo("Matrix3: .translate() is deprecated. Use .makeTranslation() instead."),this.premultiply(ld.makeTranslation(t,n)),this}makeTranslation(t,n){return t.isVector2?this.set(1,0,t.x,0,1,t.y,0,0,1):this.set(1,0,t,0,1,n,0,0,1),this}makeRotation(t){const n=Math.cos(t),a=Math.sin(t);return this.set(n,-a,0,a,n,0,0,0,1),this}makeScale(t,n){return this.set(t,0,0,0,n,0,0,0,1),this}equals(t){const n=this.elements,a=t.elements;for(let o=0;o<9;o++)if(n[o]!==a[o])return!1;return!0}fromArray(t,n=0){for(let a=0;a<9;a++)this.elements[a]=t[a+n];return this}toArray(t=[],n=0){const a=this.elements;return t[n]=a[0],t[n+1]=a[1],t[n+2]=a[2],t[n+3]=a[3],t[n+4]=a[4],t[n+5]=a[5],t[n+6]=a[6],t[n+7]=a[7],t[n+8]=a[8],t}clone(){return new this.constructor().fromArray(this.elements)}};vm.prototype.isMatrix3=!0;let we=vm;const ld=new we,c_=new we().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),u_=new we().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function U1(){const s={enabled:!0,workingColorSpace:Lu,spaces:{},convert:function(o,c,u){return this.enabled===!1||c===u||!c||!u||(this.spaces[c].transfer===on&&(o.r=Za(o.r),o.g=Za(o.g),o.b=Za(o.b)),this.spaces[c].primaries!==this.spaces[u].primaries&&(o.applyMatrix3(this.spaces[c].toXYZ),o.applyMatrix3(this.spaces[u].fromXYZ)),this.spaces[u].transfer===on&&(o.r=fo(o.r),o.g=fo(o.g),o.b=fo(o.b))),o},workingToColorSpace:function(o,c){return this.convert(o,this.workingColorSpace,c)},colorSpaceToWorking:function(o,c){return this.convert(o,c,this.workingColorSpace)},getPrimaries:function(o){return this.spaces[o].primaries},getTransfer:function(o){return o===Xa?Nu:this.spaces[o].transfer},getToneMappingMode:function(o){return this.spaces[o].outputColorSpaceConfig.toneMappingMode||"standard"},getLuminanceCoefficients:function(o,c=this.workingColorSpace){return o.fromArray(this.spaces[c].luminanceCoefficients)},define:function(o){Object.assign(this.spaces,o)},_getMatrix:function(o,c,u){return o.copy(this.spaces[c].toXYZ).multiply(this.spaces[u].fromXYZ)},_getDrawingBufferColorSpace:function(o){return this.spaces[o].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(o=this.workingColorSpace){return this.spaces[o].workingColorSpaceConfig.unpackColorSpace},fromWorkingColorSpace:function(o,c){return uo("ColorManagement: .fromWorkingColorSpace() has been renamed to .workingToColorSpace()."),s.workingToColorSpace(o,c)},toWorkingColorSpace:function(o,c){return uo("ColorManagement: .toWorkingColorSpace() has been renamed to .colorSpaceToWorking()."),s.colorSpaceToWorking(o,c)}},t=[.64,.33,.3,.6,.15,.06],n=[.2126,.7152,.0722],a=[.3127,.329];return s.define({[Lu]:{primaries:t,whitePoint:a,transfer:Nu,toXYZ:c_,fromXYZ:u_,luminanceCoefficients:n,workingColorSpaceConfig:{unpackColorSpace:Ln},outputColorSpaceConfig:{drawingBufferColorSpace:Ln}},[Ln]:{primaries:t,whitePoint:a,transfer:on,toXYZ:c_,fromXYZ:u_,luminanceCoefficients:n,outputColorSpaceConfig:{drawingBufferColorSpace:Ln}}}),s}const qe=U1();function Za(s){return s<.04045?s*.0773993808:Math.pow(s*.9478672986+.0521327014,2.4)}function fo(s){return s<.0031308?s*12.92:1.055*Math.pow(s,.41666)-.055}let Wr;class L1{static getDataURL(t,n="image/png"){if(/^data:/i.test(t.src)||typeof HTMLCanvasElement>"u")return t.src;let a;if(t instanceof HTMLCanvasElement)a=t;else{Wr===void 0&&(Wr=Ou("canvas")),Wr.width=t.width,Wr.height=t.height;const o=Wr.getContext("2d");t instanceof ImageData?o.putImageData(t,0,0):o.drawImage(t,0,0,t.width,t.height),a=Wr}return a.toDataURL(n)}static sRGBToLinear(t){if(typeof HTMLImageElement<"u"&&t instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&t instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&t instanceof ImageBitmap){const n=Ou("canvas");n.width=t.width,n.height=t.height;const a=n.getContext("2d");a.drawImage(t,0,0,t.width,t.height);const o=a.getImageData(0,0,t.width,t.height),c=o.data;for(let u=0;u<c.length;u++)c[u]=Za(c[u]/255)*255;return a.putImageData(o,0,0),n}else if(t.data){const n=t.data.slice(0);for(let a=0;a<n.length;a++)n instanceof Uint8Array||n instanceof Uint8ClampedArray?n[a]=Math.floor(Za(n[a]/255)*255):n[a]=Za(n[a]);return{data:n,width:t.width,height:t.height}}else return ye("ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),t}}let N1=0;class em{constructor(t=null){this.isTextureSource=!0,Object.defineProperty(this,"id",{value:N1++}),this.uuid=cr(),this.data=t,this.dataReady=!0,this.version=0}getSize(t){const n=this.data;return typeof HTMLVideoElement<"u"&&n instanceof HTMLVideoElement?t.set(n.videoWidth,n.videoHeight,0):typeof VideoFrame<"u"&&n instanceof VideoFrame?t.set(n.displayWidth,n.displayHeight,0):n!==null?t.set(n.width,n.height,n.depth||0):t.set(0,0,0),t}set needsUpdate(t){t===!0&&this.version++}toJSON(t){const n=t===void 0||typeof t=="string";if(!n&&t.images[this.uuid]!==void 0)return t.images[this.uuid];const a={uuid:this.uuid,url:""},o=this.data;if(o!==null){let c;if(Array.isArray(o)){c=[];for(let u=0,h=o.length;u<h;u++)o[u].isDataTexture?c.push(cd(o[u].image)):c.push(cd(o[u]))}else c=cd(o);a.url=c}return n||(t.images[this.uuid]=a),a}}function cd(s){return typeof HTMLImageElement<"u"&&s instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&s instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&s instanceof ImageBitmap?L1.getDataURL(s):s.data?{data:Array.from(s.data),width:s.width,height:s.height,type:s.data.constructor.name}:(ye("Texture: Unable to serialize Texture."),{})}let O1=0;const ud=new B;class $n extends lr{constructor(t=$n.DEFAULT_IMAGE,n=$n.DEFAULT_MAPPING,a=Wa,o=Wa,c=Wn,u=Qs,h=Qi,p=Ti,d=$n.DEFAULT_ANISOTROPY,g=Xa){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:O1++}),this.uuid=cr(),this.name="",this.source=new em(t),this.mipmaps=[],this.mapping=n,this.channel=0,this.wrapS=a,this.wrapT=o,this.magFilter=c,this.minFilter=u,this.anisotropy=d,this.format=h,this.internalFormat=null,this.type=p,this.offset=new Ot(0,0),this.repeat=new Ot(1,1),this.center=new Ot(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new we,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=g,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=!!(t&&t.depth&&t.depth>1),this.pmremVersion=0,this.normalized=!1}get width(){return this.source.getSize(ud).x}get height(){return this.source.getSize(ud).y}get depth(){return this.source.getSize(ud).z}get image(){return this.source.data}set image(t){this.source.data=t}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}addUpdateRange(t,n){this.updateRanges.push({start:t,count:n})}clearUpdateRanges(){this.updateRanges.length=0}clone(){return new this.constructor().copy(this)}copy(t){return this.name=t.name,this.source=t.source,this.mipmaps=t.mipmaps.slice(0),this.mapping=t.mapping,this.channel=t.channel,this.wrapS=t.wrapS,this.wrapT=t.wrapT,this.magFilter=t.magFilter,this.minFilter=t.minFilter,this.anisotropy=t.anisotropy,this.format=t.format,this.internalFormat=t.internalFormat,this.type=t.type,this.normalized=t.normalized,this.offset.copy(t.offset),this.repeat.copy(t.repeat),this.center.copy(t.center),this.rotation=t.rotation,this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrix.copy(t.matrix),this.generateMipmaps=t.generateMipmaps,this.premultiplyAlpha=t.premultiplyAlpha,this.flipY=t.flipY,this.unpackAlignment=t.unpackAlignment,this.colorSpace=t.colorSpace,this.renderTarget=t.renderTarget,this.isRenderTargetTexture=t.isRenderTargetTexture,this.isArrayTexture=t.isArrayTexture,this.userData=JSON.parse(JSON.stringify(t.userData)),this.needsUpdate=!0,this}setValues(t){for(const n in t){const a=t[n];if(a===void 0){ye(`Texture.setValues(): parameter '${n}' has value of undefined.`);continue}const o=this[n];if(o===void 0){ye(`Texture.setValues(): property '${n}' does not exist.`);continue}o&&a&&o.isVector2&&a.isVector2||o&&a&&o.isVector3&&a.isVector3||o&&a&&o.isMatrix3&&a.isMatrix3?o.copy(a):this[n]=a}}toJSON(t){const n=t===void 0||typeof t=="string";if(!n&&t.textures[this.uuid]!==void 0)return t.textures[this.uuid];const a={metadata:{version:4.7,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(t).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,normalized:this.normalized,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(a.userData=this.userData),n||(t.textures[this.uuid]=a),a}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(t){if(this.mapping!==Fx)return t;if(t.applyMatrix3(this.matrix),t.x<0||t.x>1)switch(this.wrapS){case Ka:t.x=t.x-Math.floor(t.x);break;case Wa:t.x=t.x<0?0:1;break;case tp:Math.abs(Math.floor(t.x)%2)===1?t.x=Math.ceil(t.x)-t.x:t.x=t.x-Math.floor(t.x);break}if(t.y<0||t.y>1)switch(this.wrapT){case Ka:t.y=t.y-Math.floor(t.y);break;case Wa:t.y=t.y<0?0:1;break;case tp:Math.abs(Math.floor(t.y)%2)===1?t.y=Math.ceil(t.y)-t.y:t.y=t.y-Math.floor(t.y);break}return this.flipY&&(t.y=1-t.y),t}set needsUpdate(t){t===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(t){t===!0&&this.pmremVersion++}}$n.DEFAULT_IMAGE=null;$n.DEFAULT_MAPPING=Fx;$n.DEFAULT_ANISOTROPY=1;const _m=class _m{constructor(t=0,n=0,a=0,o=1){this.x=t,this.y=n,this.z=a,this.w=o}get width(){return this.z}set width(t){this.z=t}get height(){return this.w}set height(t){this.w=t}set(t,n,a,o){return this.x=t,this.y=n,this.z=a,this.w=o,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this.w=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setW(t){return this.w=t,this}setComponent(t,n){switch(t){case 0:this.x=n;break;case 1:this.y=n;break;case 2:this.z=n;break;case 3:this.w=n;break;default:throw new Error("THREE.Vector4: index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("THREE.Vector4: index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this.w=t.w!==void 0?t.w:1,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this.w+=t.w,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this.w+=t,this}addVectors(t,n){return this.x=t.x+n.x,this.y=t.y+n.y,this.z=t.z+n.z,this.w=t.w+n.w,this}addScaledVector(t,n){return this.x+=t.x*n,this.y+=t.y*n,this.z+=t.z*n,this.w+=t.w*n,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this.w-=t.w,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this.w-=t,this}subVectors(t,n){return this.x=t.x-n.x,this.y=t.y-n.y,this.z=t.z-n.z,this.w=t.w-n.w,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this.w*=t.w,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this.w*=t,this}applyMatrix4(t){const n=this.x,a=this.y,o=this.z,c=this.w,u=t.elements;return this.x=u[0]*n+u[4]*a+u[8]*o+u[12]*c,this.y=u[1]*n+u[5]*a+u[9]*o+u[13]*c,this.z=u[2]*n+u[6]*a+u[10]*o+u[14]*c,this.w=u[3]*n+u[7]*a+u[11]*o+u[15]*c,this}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this.w/=t.w,this}divideScalar(t){return this.multiplyScalar(1/t)}setAxisAngleFromQuaternion(t){this.w=2*Math.acos(t.w);const n=Math.sqrt(1-t.w*t.w);return n<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=t.x/n,this.y=t.y/n,this.z=t.z/n),this}setAxisAngleFromRotationMatrix(t){let n,a,o,c;const p=t.elements,d=p[0],g=p[4],v=p[8],_=p[1],x=p[5],b=p[9],R=p[2],y=p[6],M=p[10];if(Math.abs(g-_)<.01&&Math.abs(v-R)<.01&&Math.abs(b-y)<.01){if(Math.abs(g+_)<.1&&Math.abs(v+R)<.1&&Math.abs(b+y)<.1&&Math.abs(d+x+M-3)<.1)return this.set(1,0,0,0),this;n=Math.PI;const P=(d+1)/2,E=(x+1)/2,U=(M+1)/2,L=(g+_)/4,N=(v+R)/4,T=(b+y)/4;return P>E&&P>U?P<.01?(a=0,o=.707106781,c=.707106781):(a=Math.sqrt(P),o=L/a,c=N/a):E>U?E<.01?(a=.707106781,o=0,c=.707106781):(o=Math.sqrt(E),a=L/o,c=T/o):U<.01?(a=.707106781,o=.707106781,c=0):(c=Math.sqrt(U),a=N/c,o=T/c),this.set(a,o,c,n),this}let C=Math.sqrt((y-b)*(y-b)+(v-R)*(v-R)+(_-g)*(_-g));return Math.abs(C)<.001&&(C=1),this.x=(y-b)/C,this.y=(v-R)/C,this.z=(_-g)/C,this.w=Math.acos((d+x+M-1)/2),this}setFromMatrixPosition(t){const n=t.elements;return this.x=n[12],this.y=n[13],this.z=n[14],this.w=n[15],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this.w=Math.min(this.w,t.w),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this.w=Math.max(this.w,t.w),this}clamp(t,n){return this.x=ze(this.x,t.x,n.x),this.y=ze(this.y,t.y,n.y),this.z=ze(this.z,t.z,n.z),this.w=ze(this.w,t.w,n.w),this}clampScalar(t,n){return this.x=ze(this.x,t,n),this.y=ze(this.y,t,n),this.z=ze(this.z,t,n),this.w=ze(this.w,t,n),this}clampLength(t,n){const a=this.length();return this.divideScalar(a||1).multiplyScalar(ze(a,t,n))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z+this.w*t.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,n){return this.x+=(t.x-this.x)*n,this.y+=(t.y-this.y)*n,this.z+=(t.z-this.z)*n,this.w+=(t.w-this.w)*n,this}lerpVectors(t,n,a){return this.x=t.x+(n.x-t.x)*a,this.y=t.y+(n.y-t.y)*a,this.z=t.z+(n.z-t.z)*a,this.w=t.w+(n.w-t.w)*a,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z&&t.w===this.w}fromArray(t,n=0){return this.x=t[n],this.y=t[n+1],this.z=t[n+2],this.w=t[n+3],this}toArray(t=[],n=0){return t[n]=this.x,t[n+1]=this.y,t[n+2]=this.z,t[n+3]=this.w,t}fromBufferAttribute(t,n){return this.x=t.getX(n),this.y=t.getY(n),this.z=t.getZ(n),this.w=t.getW(n),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}};_m.prototype.isVector4=!0;let _n=_m;class P1 extends lr{constructor(t=1,n=1,a={}){super(),a=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:Wn,depthBuffer:!0,stencilBuffer:!1,resolveColorBuffer:!0,resolveDepthBuffer:!0,resolveStencilBuffer:!0,storeMultisampledColorBuffer:!0,storeMultisampledDepthBuffer:!0,storeMultisampledStencilBuffer:!0,depthTexture:null,samples:0,count:1,depth:1,multiview:!1,useArrayDepthTexture:!1},a),this.isRenderTarget=!0,this.width=t,this.height=n,this.depth=a.depth,this.scissor=new _n(0,0,t,n),this.scissorTest=!1,this.viewport=new _n(0,0,t,n),this.textures=[];const o={width:t,height:n,depth:a.depth},c=new $n(o),u=a.count;for(let h=0;h<u;h++)this.textures[h]=c.clone(),this.textures[h].isRenderTargetTexture=!0,this.textures[h].renderTarget=this;this._setTextureOptions(a),this.depthBuffer=a.depthBuffer,this.stencilBuffer=a.stencilBuffer,this.resolveColorBuffer=a.resolveColorBuffer,this.resolveDepthBuffer=a.resolveDepthBuffer,this.resolveStencilBuffer=a.resolveStencilBuffer,this.storeMultisampledColorBuffer=a.storeMultisampledColorBuffer,this.storeMultisampledDepthBuffer=a.storeMultisampledDepthBuffer,this.storeMultisampledStencilBuffer=a.storeMultisampledStencilBuffer,this._depthTexture=null,this.depthTexture=a.depthTexture,this.samples=a.samples,this.multiview=a.multiview,this.useArrayDepthTexture=a.useArrayDepthTexture}_setTextureOptions(t={}){const n={minFilter:Wn,generateMipmaps:!1,flipY:!1,internalFormat:null};t.mapping!==void 0&&(n.mapping=t.mapping),t.wrapS!==void 0&&(n.wrapS=t.wrapS),t.wrapT!==void 0&&(n.wrapT=t.wrapT),t.wrapR!==void 0&&(n.wrapR=t.wrapR),t.magFilter!==void 0&&(n.magFilter=t.magFilter),t.minFilter!==void 0&&(n.minFilter=t.minFilter),t.format!==void 0&&(n.format=t.format),t.type!==void 0&&(n.type=t.type),t.anisotropy!==void 0&&(n.anisotropy=t.anisotropy),t.colorSpace!==void 0&&(n.colorSpace=t.colorSpace),t.flipY!==void 0&&(n.flipY=t.flipY),t.generateMipmaps!==void 0&&(n.generateMipmaps=t.generateMipmaps),t.internalFormat!==void 0&&(n.internalFormat=t.internalFormat);for(let a=0;a<this.textures.length;a++)this.textures[a].setValues(n)}get texture(){return this.textures[0]}set texture(t){this.textures[0]=t}set depthTexture(t){this._depthTexture!==null&&this._depthTexture.renderTarget===this&&(this._depthTexture.renderTarget=null),t!==null&&t.renderTarget===null&&(t.renderTarget=this),this._depthTexture=t}get depthTexture(){return this._depthTexture}setSize(t,n,a=1){if(this.width!==t||this.height!==n||this.depth!==a){this.width=t,this.height=n,this.depth=a;for(let o=0,c=this.textures.length;o<c;o++)this.textures[o].image.width=t,this.textures[o].image.height=n,this.textures[o].image.depth=a,this.textures[o].isData3DTexture!==!0&&(this.textures[o].isArrayTexture=this.textures[o].image.depth>1);this.dispose()}this.viewport.set(0,0,t,n),this.scissor.set(0,0,t,n)}clone(){return new this.constructor().copy(this)}copy(t){this.width=t.width,this.height=t.height,this.depth=t.depth,this.scissor.copy(t.scissor),this.scissorTest=t.scissorTest,this.viewport.copy(t.viewport),this.textures.length=0;for(let n=0,a=t.textures.length;n<a;n++){this.textures[n]=t.textures[n].clone(),this.textures[n].isRenderTargetTexture=!0,this.textures[n].renderTarget=this;const o=Object.assign({},t.textures[n].image);this.textures[n].source=new em(o)}if(this.depthBuffer=t.depthBuffer,this.stencilBuffer=t.stencilBuffer,this.resolveColorBuffer=t.resolveColorBuffer,this.resolveDepthBuffer=t.resolveDepthBuffer,this.resolveStencilBuffer=t.resolveStencilBuffer,this.storeMultisampledColorBuffer=t.storeMultisampledColorBuffer,this.storeMultisampledDepthBuffer=t.storeMultisampledDepthBuffer,this.storeMultisampledStencilBuffer=t.storeMultisampledStencilBuffer,t.depthTexture!==null)if(t.depthTexture.renderTarget===t){const n=t.depthTexture.clone();n.renderTarget=null,this.depthTexture=n}else this.depthTexture=t.depthTexture;return this.samples=t.samples,this.multiview=t.multiview,this.useArrayDepthTexture=t.useArrayDepthTexture,this}dispose(){this.dispatchEvent({type:"dispose"})}}class Bi extends P1{constructor(t=1,n=1,a={}){super(t,n,a),this.isWebGLRenderTarget=!0}}class Zx extends $n{constructor(t=null,n=1,a=1,o=1){super(null),this.isDataArrayTexture=!0,this.image={data:t,width:n,height:a,depth:o},this.magFilter=ri,this.minFilter=ri,this.wrapR=Wa,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}copy(t){return super.copy(t),this.wrapR=t.wrapR,this}addLayerUpdate(t){this.layerUpdates.add(t)}clearLayerUpdates(){this.layerUpdates.clear()}}class z1 extends $n{constructor(t=null,n=1,a=1,o=1){super(null),this.isData3DTexture=!0,this.image={data:t,width:n,height:a,depth:o},this.magFilter=ri,this.minFilter=ri,this.wrapR=Wa,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}copy(t){return super.copy(t),this.wrapR=t.wrapR,this}}const Fu=class Fu{constructor(t,n,a,o,c,u,h,p,d,g,v,_,x,b,R,y){this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],t!==void 0&&this.set(t,n,a,o,c,u,h,p,d,g,v,_,x,b,R,y)}set(t,n,a,o,c,u,h,p,d,g,v,_,x,b,R,y){const M=this.elements;return M[0]=t,M[4]=n,M[8]=a,M[12]=o,M[1]=c,M[5]=u,M[9]=h,M[13]=p,M[2]=d,M[6]=g,M[10]=v,M[14]=_,M[3]=x,M[7]=b,M[11]=R,M[15]=y,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new Fu().fromArray(this.elements)}copy(t){const n=this.elements,a=t.elements;return n[0]=a[0],n[1]=a[1],n[2]=a[2],n[3]=a[3],n[4]=a[4],n[5]=a[5],n[6]=a[6],n[7]=a[7],n[8]=a[8],n[9]=a[9],n[10]=a[10],n[11]=a[11],n[12]=a[12],n[13]=a[13],n[14]=a[14],n[15]=a[15],this}copyPosition(t){const n=this.elements,a=t.elements;return n[12]=a[12],n[13]=a[13],n[14]=a[14],this}setFromMatrix3(t){const n=t.elements;return this.set(n[0],n[3],n[6],0,n[1],n[4],n[7],0,n[2],n[5],n[8],0,0,0,0,1),this}extractBasis(t,n,a){return this.determinantAffine()===0?(t.set(1,0,0),n.set(0,1,0),a.set(0,0,1),this):(t.setFromMatrixColumn(this,0),n.setFromMatrixColumn(this,1),a.setFromMatrixColumn(this,2),this)}makeBasis(t,n,a){return this.set(t.x,n.x,a.x,0,t.y,n.y,a.y,0,t.z,n.z,a.z,0,0,0,0,1),this}extractRotation(t){if(t.determinantAffine()===0)return this.identity();const n=this.elements,a=t.elements,o=1/qr.setFromMatrixColumn(t,0).length(),c=1/qr.setFromMatrixColumn(t,1).length(),u=1/qr.setFromMatrixColumn(t,2).length();return n[0]=a[0]*o,n[1]=a[1]*o,n[2]=a[2]*o,n[3]=0,n[4]=a[4]*c,n[5]=a[5]*c,n[6]=a[6]*c,n[7]=0,n[8]=a[8]*u,n[9]=a[9]*u,n[10]=a[10]*u,n[11]=0,n[12]=0,n[13]=0,n[14]=0,n[15]=1,this}makeRotationFromEuler(t){const n=this.elements,a=t.x,o=t.y,c=t.z,u=Math.cos(a),h=Math.sin(a),p=Math.cos(o),d=Math.sin(o),g=Math.cos(c),v=Math.sin(c);if(t.order==="XYZ"){const _=u*g,x=u*v,b=h*g,R=h*v;n[0]=p*g,n[4]=-p*v,n[8]=d,n[1]=x+b*d,n[5]=_-R*d,n[9]=-h*p,n[2]=R-_*d,n[6]=b+x*d,n[10]=u*p}else if(t.order==="YXZ"){const _=p*g,x=p*v,b=d*g,R=d*v;n[0]=_+R*h,n[4]=b*h-x,n[8]=u*d,n[1]=u*v,n[5]=u*g,n[9]=-h,n[2]=x*h-b,n[6]=R+_*h,n[10]=u*p}else if(t.order==="ZXY"){const _=p*g,x=p*v,b=d*g,R=d*v;n[0]=_-R*h,n[4]=-u*v,n[8]=b+x*h,n[1]=x+b*h,n[5]=u*g,n[9]=R-_*h,n[2]=-u*d,n[6]=h,n[10]=u*p}else if(t.order==="ZYX"){const _=u*g,x=u*v,b=h*g,R=h*v;n[0]=p*g,n[4]=b*d-x,n[8]=_*d+R,n[1]=p*v,n[5]=R*d+_,n[9]=x*d-b,n[2]=-d,n[6]=h*p,n[10]=u*p}else if(t.order==="YZX"){const _=u*p,x=u*d,b=h*p,R=h*d;n[0]=p*g,n[4]=R-_*v,n[8]=b*v+x,n[1]=v,n[5]=u*g,n[9]=-h*g,n[2]=-d*g,n[6]=x*v+b,n[10]=_-R*v}else if(t.order==="XZY"){const _=u*p,x=u*d,b=h*p,R=h*d;n[0]=p*g,n[4]=-v,n[8]=d*g,n[1]=_*v+R,n[5]=u*g,n[9]=x*v-b,n[2]=b*v-x,n[6]=h*g,n[10]=R*v+_}return n[3]=0,n[7]=0,n[11]=0,n[12]=0,n[13]=0,n[14]=0,n[15]=1,this}makeRotationFromQuaternion(t){return this.compose(I1,t,B1)}lookAt(t,n,a){const o=this.elements;return Oi.subVectors(t,n),Oi.lengthSq()===0&&(Oi.z=1),Oi.normalize(),bs.crossVectors(a,Oi),bs.lengthSq()===0&&(Math.abs(a.z)===1?Oi.x+=1e-4:Oi.z+=1e-4,Oi.normalize(),bs.crossVectors(a,Oi)),bs.normalize(),Jc.crossVectors(Oi,bs),o[0]=bs.x,o[4]=Jc.x,o[8]=Oi.x,o[1]=bs.y,o[5]=Jc.y,o[9]=Oi.y,o[2]=bs.z,o[6]=Jc.z,o[10]=Oi.z,this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,n){const a=t.elements,o=n.elements,c=this.elements,u=a[0],h=a[4],p=a[8],d=a[12],g=a[1],v=a[5],_=a[9],x=a[13],b=a[2],R=a[6],y=a[10],M=a[14],C=a[3],P=a[7],E=a[11],U=a[15],L=o[0],N=o[4],T=o[8],z=o[12],W=o[1],J=o[5],$=o[9],lt=o[13],X=o[2],k=o[6],H=o[10],Y=o[14],it=o[3],rt=o[7],ht=o[11],I=o[15];return c[0]=u*L+h*W+p*X+d*it,c[4]=u*N+h*J+p*k+d*rt,c[8]=u*T+h*$+p*H+d*ht,c[12]=u*z+h*lt+p*Y+d*I,c[1]=g*L+v*W+_*X+x*it,c[5]=g*N+v*J+_*k+x*rt,c[9]=g*T+v*$+_*H+x*ht,c[13]=g*z+v*lt+_*Y+x*I,c[2]=b*L+R*W+y*X+M*it,c[6]=b*N+R*J+y*k+M*rt,c[10]=b*T+R*$+y*H+M*ht,c[14]=b*z+R*lt+y*Y+M*I,c[3]=C*L+P*W+E*X+U*it,c[7]=C*N+P*J+E*k+U*rt,c[11]=C*T+P*$+E*H+U*ht,c[15]=C*z+P*lt+E*Y+U*I,this}multiplyScalar(t){const n=this.elements;return n[0]*=t,n[4]*=t,n[8]*=t,n[12]*=t,n[1]*=t,n[5]*=t,n[9]*=t,n[13]*=t,n[2]*=t,n[6]*=t,n[10]*=t,n[14]*=t,n[3]*=t,n[7]*=t,n[11]*=t,n[15]*=t,this}determinant(){const t=this.elements,n=t[0],a=t[4],o=t[8],c=t[12],u=t[1],h=t[5],p=t[9],d=t[13],g=t[2],v=t[6],_=t[10],x=t[14],b=t[3],R=t[7],y=t[11],M=t[15],C=p*x-d*_,P=h*x-d*v,E=h*_-p*v,U=u*x-d*g,L=u*_-p*g,N=u*v-h*g;return n*(R*C-y*P+M*E)-a*(b*C-y*U+M*L)+o*(b*P-R*U+M*N)-c*(b*E-R*L+y*N)}determinantAffine(){const t=this.elements,n=t[0],a=t[4],o=t[8],c=t[1],u=t[5],h=t[9],p=t[2],d=t[6],g=t[10];return n*(u*g-h*d)-a*(c*g-h*p)+o*(c*d-u*p)}transpose(){const t=this.elements;let n;return n=t[1],t[1]=t[4],t[4]=n,n=t[2],t[2]=t[8],t[8]=n,n=t[6],t[6]=t[9],t[9]=n,n=t[3],t[3]=t[12],t[12]=n,n=t[7],t[7]=t[13],t[13]=n,n=t[11],t[11]=t[14],t[14]=n,this}setPosition(t,n,a){const o=this.elements;return t.isVector3?(o[12]=t.x,o[13]=t.y,o[14]=t.z):(o[12]=t,o[13]=n,o[14]=a),this}invert(){const t=this.elements,n=t[0],a=t[1],o=t[2],c=t[3],u=t[4],h=t[5],p=t[6],d=t[7],g=t[8],v=t[9],_=t[10],x=t[11],b=t[12],R=t[13],y=t[14],M=t[15],C=n*h-a*u,P=n*p-o*u,E=n*d-c*u,U=a*p-o*h,L=a*d-c*h,N=o*d-c*p,T=g*R-v*b,z=g*y-_*b,W=g*M-x*b,J=v*y-_*R,$=v*M-x*R,lt=_*M-x*y,X=C*lt-P*$+E*J+U*W-L*z+N*T;if(X===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const k=1/X;return t[0]=(h*lt-p*$+d*J)*k,t[1]=(o*$-a*lt-c*J)*k,t[2]=(R*N-y*L+M*U)*k,t[3]=(_*L-v*N-x*U)*k,t[4]=(p*W-u*lt-d*z)*k,t[5]=(n*lt-o*W+c*z)*k,t[6]=(y*E-b*N-M*P)*k,t[7]=(g*N-_*E+x*P)*k,t[8]=(u*$-h*W+d*T)*k,t[9]=(a*W-n*$-c*T)*k,t[10]=(b*L-R*E+M*C)*k,t[11]=(v*E-g*L-x*C)*k,t[12]=(h*z-u*J-p*T)*k,t[13]=(n*J-a*z+o*T)*k,t[14]=(R*P-b*U-y*C)*k,t[15]=(g*U-v*P+_*C)*k,this}scale(t){const n=this.elements,a=t.x,o=t.y,c=t.z;return n[0]*=a,n[4]*=o,n[8]*=c,n[1]*=a,n[5]*=o,n[9]*=c,n[2]*=a,n[6]*=o,n[10]*=c,n[3]*=a,n[7]*=o,n[11]*=c,this}getMaxScaleOnAxis(){const t=this.elements,n=t[0]*t[0]+t[1]*t[1]+t[2]*t[2],a=t[4]*t[4]+t[5]*t[5]+t[6]*t[6],o=t[8]*t[8]+t[9]*t[9]+t[10]*t[10];return Math.sqrt(Math.max(n,a,o))}makeTranslation(t,n,a){return t.isVector3?this.set(1,0,0,t.x,0,1,0,t.y,0,0,1,t.z,0,0,0,1):this.set(1,0,0,t,0,1,0,n,0,0,1,a,0,0,0,1),this}makeRotationX(t){const n=Math.cos(t),a=Math.sin(t);return this.set(1,0,0,0,0,n,-a,0,0,a,n,0,0,0,0,1),this}makeRotationY(t){const n=Math.cos(t),a=Math.sin(t);return this.set(n,0,a,0,0,1,0,0,-a,0,n,0,0,0,0,1),this}makeRotationZ(t){const n=Math.cos(t),a=Math.sin(t);return this.set(n,-a,0,0,a,n,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(t,n){const a=Math.cos(n),o=Math.sin(n),c=1-a,u=t.x,h=t.y,p=t.z,d=c*u,g=c*h;return this.set(d*u+a,d*h-o*p,d*p+o*h,0,d*h+o*p,g*h+a,g*p-o*u,0,d*p-o*h,g*p+o*u,c*p*p+a,0,0,0,0,1),this}makeScale(t,n,a){return this.set(t,0,0,0,0,n,0,0,0,0,a,0,0,0,0,1),this}makeShear(t,n,a,o,c,u){return this.set(1,a,c,0,t,1,u,0,n,o,1,0,0,0,0,1),this}compose(t,n,a){const o=this.elements,c=n._x,u=n._y,h=n._z,p=n._w,d=c+c,g=u+u,v=h+h,_=c*d,x=c*g,b=c*v,R=u*g,y=u*v,M=h*v,C=p*d,P=p*g,E=p*v,U=a.x,L=a.y,N=a.z;return o[0]=(1-(R+M))*U,o[1]=(x+E)*U,o[2]=(b-P)*U,o[3]=0,o[4]=(x-E)*L,o[5]=(1-(_+M))*L,o[6]=(y+C)*L,o[7]=0,o[8]=(b+P)*N,o[9]=(y-C)*N,o[10]=(1-(_+R))*N,o[11]=0,o[12]=t.x,o[13]=t.y,o[14]=t.z,o[15]=1,this}decompose(t,n,a){const o=this.elements;t.x=o[12],t.y=o[13],t.z=o[14];const c=this.determinantAffine();if(c===0)return a.set(1,1,1),n.identity(),this;let u=qr.set(o[0],o[1],o[2]).length();const h=qr.set(o[4],o[5],o[6]).length(),p=qr.set(o[8],o[9],o[10]).length();c<0&&(u=-u),ia.copy(this);const d=1/u,g=1/h,v=1/p;return ia.elements[0]*=d,ia.elements[1]*=d,ia.elements[2]*=d,ia.elements[4]*=g,ia.elements[5]*=g,ia.elements[6]*=g,ia.elements[8]*=v,ia.elements[9]*=v,ia.elements[10]*=v,n.setFromRotationMatrix(ia),a.x=u,a.y=h,a.z=p,this}makePerspective(t,n,a,o,c,u,h=_a,p=!1){const d=this.elements,g=2*c/(n-t),v=2*c/(a-o),_=(n+t)/(n-t),x=(a+o)/(a-o);let b,R;if(p)b=c/(u-c),R=u*c/(u-c);else if(h===_a)b=-(u+c)/(u-c),R=-2*u*c/(u-c);else if(h===Ul)b=-u/(u-c),R=-u*c/(u-c);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+h);return d[0]=g,d[4]=0,d[8]=_,d[12]=0,d[1]=0,d[5]=v,d[9]=x,d[13]=0,d[2]=0,d[6]=0,d[10]=b,d[14]=R,d[3]=0,d[7]=0,d[11]=-1,d[15]=0,this}makeOrthographic(t,n,a,o,c,u,h=_a,p=!1){const d=this.elements,g=2/(n-t),v=2/(a-o),_=-(n+t)/(n-t),x=-(a+o)/(a-o);let b,R;if(p)b=1/(u-c),R=u/(u-c);else if(h===_a)b=-2/(u-c),R=-(u+c)/(u-c);else if(h===Ul)b=-1/(u-c),R=-c/(u-c);else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+h);return d[0]=g,d[4]=0,d[8]=0,d[12]=_,d[1]=0,d[5]=v,d[9]=0,d[13]=x,d[2]=0,d[6]=0,d[10]=b,d[14]=R,d[3]=0,d[7]=0,d[11]=0,d[15]=1,this}equals(t){const n=this.elements,a=t.elements;for(let o=0;o<16;o++)if(n[o]!==a[o])return!1;return!0}fromArray(t,n=0){for(let a=0;a<16;a++)this.elements[a]=t[a+n];return this}toArray(t=[],n=0){const a=this.elements;return t[n]=a[0],t[n+1]=a[1],t[n+2]=a[2],t[n+3]=a[3],t[n+4]=a[4],t[n+5]=a[5],t[n+6]=a[6],t[n+7]=a[7],t[n+8]=a[8],t[n+9]=a[9],t[n+10]=a[10],t[n+11]=a[11],t[n+12]=a[12],t[n+13]=a[13],t[n+14]=a[14],t[n+15]=a[15],t}};Fu.prototype.isMatrix4=!0;let ln=Fu;const qr=new B,ia=new ln,I1=new B(0,0,0),B1=new B(1,1,1),bs=new B,Jc=new B,Oi=new B,f_=new ln,h_=new Ei;class Ja{constructor(t=0,n=0,a=0,o=Ja.DEFAULT_ORDER){this.isEuler=!0,this._x=t,this._y=n,this._z=a,this._order=o}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get order(){return this._order}set order(t){this._order=t,this._onChangeCallback()}set(t,n,a,o=this._order){return this._x=t,this._y=n,this._z=a,this._order=o,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(t){return this._x=t._x,this._y=t._y,this._z=t._z,this._order=t._order,this._onChangeCallback(),this}setFromRotationMatrix(t,n=this._order,a=!0){const o=t.elements,c=o[0],u=o[4],h=o[8],p=o[1],d=o[5],g=o[9],v=o[2],_=o[6],x=o[10];switch(n){case"XYZ":this._y=Math.asin(ze(h,-1,1)),Math.abs(h)<.9999999?(this._x=Math.atan2(-g,x),this._z=Math.atan2(-u,c)):(this._x=Math.atan2(_,d),this._z=0);break;case"YXZ":this._x=Math.asin(-ze(g,-1,1)),Math.abs(g)<.9999999?(this._y=Math.atan2(h,x),this._z=Math.atan2(p,d)):(this._y=Math.atan2(-v,c),this._z=0);break;case"ZXY":this._x=Math.asin(ze(_,-1,1)),Math.abs(_)<.9999999?(this._y=Math.atan2(-v,x),this._z=Math.atan2(-u,d)):(this._y=0,this._z=Math.atan2(p,c));break;case"ZYX":this._y=Math.asin(-ze(v,-1,1)),Math.abs(v)<.9999999?(this._x=Math.atan2(_,x),this._z=Math.atan2(p,c)):(this._x=0,this._z=Math.atan2(-u,d));break;case"YZX":this._z=Math.asin(ze(p,-1,1)),Math.abs(p)<.9999999?(this._x=Math.atan2(-g,d),this._y=Math.atan2(-v,c)):(this._x=0,this._y=Math.atan2(h,x));break;case"XZY":this._z=Math.asin(-ze(u,-1,1)),Math.abs(u)<.9999999?(this._x=Math.atan2(_,d),this._y=Math.atan2(h,c)):(this._x=Math.atan2(-g,x),this._y=0);break;default:ye("Euler: .setFromRotationMatrix() encountered an unknown order: "+n)}return this._order=n,a===!0&&this._onChangeCallback(),this}setFromQuaternion(t,n,a){return f_.makeRotationFromQuaternion(t),this.setFromRotationMatrix(f_,n,a)}setFromVector3(t,n=this._order){return this.set(t.x,t.y,t.z,n)}reorder(t){return h_.setFromEuler(this),this.setFromQuaternion(h_,t)}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._order===this._order}fromArray(t){return this._x=t[0],this._y=t[1],this._z=t[2],t[3]!==void 0&&(this._order=t[3]),this._onChangeCallback(),this}toArray(t=[],n=0){return t[n]=this._x,t[n+1]=this._y,t[n+2]=this._z,t[n+3]=this._order,t}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}Ja.DEFAULT_ORDER="XYZ";class nm{constructor(){this.mask=1}set(t){this.mask=(1<<t|0)>>>0}enable(t){this.mask|=1<<t|0}enableAll(){this.mask=-1}toggle(t){this.mask^=1<<t|0}disable(t){this.mask&=~(1<<t|0)}disableAll(){this.mask=0}test(t){return(this.mask&t.mask)!==0}isEnabled(t){return(this.mask&(1<<t|0))!==0}}let F1=0;const d_=new B,Yr=new Ei,Ba=new ln,Qc=new B,ll=new B,H1=new B,G1=new Ei,p_=new B(1,0,0),m_=new B(0,1,0),g_=new B(0,0,1),v_={type:"added"},V1={type:"removed"},Zr={type:"childadded",child:null},fd={type:"childremoved",child:null};class An extends lr{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:F1++}),this.uuid=cr(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=An.DEFAULT_UP.clone();const t=new B,n=new Ja,a=new Ei,o=new B(1,1,1);function c(){a.setFromEuler(n,!1)}function u(){n.setFromQuaternion(a,void 0,!1)}n._onChange(c),a._onChange(u),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:t},rotation:{configurable:!0,enumerable:!0,value:n},quaternion:{configurable:!0,enumerable:!0,value:a},scale:{configurable:!0,enumerable:!0,value:o},modelViewMatrix:{value:new ln},normalMatrix:{value:new we}}),this.matrix=new ln,this.matrixWorld=new ln,this.matrixAutoUpdate=An.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=An.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new nm,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.static=!1,this.userData={},this.pivot=null}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(t){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(t),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(t){return this.quaternion.premultiply(t),this}setRotationFromAxisAngle(t,n){this.quaternion.setFromAxisAngle(t,n)}setRotationFromEuler(t){this.quaternion.setFromEuler(t,!0)}setRotationFromMatrix(t){this.quaternion.setFromRotationMatrix(t)}setRotationFromQuaternion(t){this.quaternion.copy(t)}rotateOnAxis(t,n){return Yr.setFromAxisAngle(t,n),this.quaternion.multiply(Yr),this}rotateOnWorldAxis(t,n){return Yr.setFromAxisAngle(t,n),this.quaternion.premultiply(Yr),this}rotateX(t){return this.rotateOnAxis(p_,t)}rotateY(t){return this.rotateOnAxis(m_,t)}rotateZ(t){return this.rotateOnAxis(g_,t)}translateOnAxis(t,n){return d_.copy(t).applyQuaternion(this.quaternion),this.position.add(d_.multiplyScalar(n)),this}translateX(t){return this.translateOnAxis(p_,t)}translateY(t){return this.translateOnAxis(m_,t)}translateZ(t){return this.translateOnAxis(g_,t)}localToWorld(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(this.matrixWorld)}worldToLocal(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(Ba.copy(this.matrixWorld).invert())}lookAt(t,n,a){t.isVector3?Qc.copy(t):Qc.set(t,n,a);const o=this.parent;this.updateWorldMatrix(!0,!1),ll.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?Ba.lookAt(ll,Qc,this.up):Ba.lookAt(Qc,ll,this.up),this.quaternion.setFromRotationMatrix(Ba),o&&(Ba.extractRotation(o.matrixWorld),Yr.setFromRotationMatrix(Ba),this.quaternion.premultiply(Yr.invert()))}add(t){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.add(arguments[n]);return this}return t===this?(Je("Object3D.add: object can't be added as a child of itself.",t),this):(t&&t.isObject3D?(t.removeFromParent(),t.parent=this,this.children.push(t),t.dispatchEvent(v_),Zr.child=t,this.dispatchEvent(Zr),Zr.child=null):Je("Object3D.add: object not an instance of THREE.Object3D.",t),this)}remove(t){if(arguments.length>1){for(let a=0;a<arguments.length;a++)this.remove(arguments[a]);return this}const n=this.children.indexOf(t);return n!==-1&&(t.parent=null,this.children.splice(n,1),t.dispatchEvent(V1),fd.child=t,this.dispatchEvent(fd),fd.child=null),this}removeFromParent(){const t=this.parent;return t!==null&&t.remove(this),this}clear(){return this.remove(...this.children)}attach(t){return this.updateWorldMatrix(!0,!1),Ba.copy(this.matrixWorld).invert(),t.parent!==null&&(t.parent.updateWorldMatrix(!0,!1),Ba.multiply(t.parent.matrixWorld)),t.applyMatrix4(Ba),t.removeFromParent(),t.parent=this,this.children.push(t),t.updateWorldMatrix(!1,!0),t.dispatchEvent(v_),Zr.child=t,this.dispatchEvent(Zr),Zr.child=null,this}getObjectById(t){return this.getObjectByProperty("id",t)}getObjectByName(t){return this.getObjectByProperty("name",t)}getObjectByProperty(t,n){if(this[t]===n)return this;for(let a=0,o=this.children.length;a<o;a++){const u=this.children[a].getObjectByProperty(t,n);if(u!==void 0)return u}}getObjectsByProperty(t,n,a=[]){this[t]===n&&a.push(this);const o=this.children;for(let c=0,u=o.length;c<u;c++)o[c].getObjectsByProperty(t,n,a);return a}getWorldPosition(t){return this.updateWorldMatrix(!0,!1),t.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(ll,t,H1),t}getWorldScale(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(ll,G1,t),t}getWorldDirection(t){this.updateWorldMatrix(!0,!1);const n=this.matrixWorld.elements;return t.set(n[8],n[9],n[10]).normalize()}raycast(){}intersectsFrustum(){}traverse(t){t(this);const n=this.children;for(let a=0,o=n.length;a<o;a++)n[a].traverse(t)}traverseVisible(t){if(this.visible===!1)return;t(this);const n=this.children;for(let a=0,o=n.length;a<o;a++)n[a].traverseVisible(t)}traverseAncestors(t){const n=this.parent;n!==null&&(t(n),n.traverseAncestors(t))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale);const t=this.pivot;if(t!==null){const n=t.x,a=t.y,o=t.z,c=this.matrix.elements;c[12]+=n-c[0]*n-c[4]*a-c[8]*o,c[13]+=a-c[1]*n-c[5]*a-c[9]*o,c[14]+=o-c[2]*n-c[6]*a-c[10]*o}this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(t){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||t)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,t=!0);const n=this.children;for(let a=0,o=n.length;a<o;a++)n[a].updateMatrixWorld(t)}updateWorldMatrix(t,n,a=!1){const o=this.parent;if(t===!0&&o!==null&&o.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||a)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,a=!0),n===!0){const c=this.children;for(let u=0,h=c.length;u<h;u++)c[u].updateWorldMatrix(!1,!0,a)}}toJSON(t){const n=t===void 0||typeof t=="string",a={};n&&(t={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},a.metadata={version:4.7,type:"Object",generator:"Object3D.toJSON"});const o={};o.uuid=this.uuid,o.type=this.type,o.name=this.name,o.castShadow=this.castShadow,o.receiveShadow=this.receiveShadow,o.visible=this.visible,o.frustumCulled=this.frustumCulled,o.renderOrder=this.renderOrder,o.static=this.static,o.matrixAutoUpdate=this.matrixAutoUpdate,Object.keys(this.userData).length>0&&(o.userData=this.userData),o.layers=this.layers.mask,o.matrix=this.matrix.toArray(),o.up=this.up.toArray(),this.pivot!==null&&(o.pivot=this.pivot.toArray()),this.morphTargetDictionary!==void 0&&(o.morphTargetDictionary=Object.assign({},this.morphTargetDictionary)),this.morphTargetInfluences!==void 0&&(o.morphTargetInfluences=this.morphTargetInfluences.slice()),this.isInstancedMesh&&(o.type="InstancedMesh",o.count=this.count,o.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(o.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(o.type="BatchedMesh",o.perObjectFrustumCulled=this.perObjectFrustumCulled,o.sortObjects=this.sortObjects,o.drawRanges=this._drawRanges,o.reservedRanges=this._reservedRanges,o.geometryInfo=this._geometryInfo.map(h=>({...h,boundingBox:h.boundingBox?h.boundingBox.toJSON():void 0,boundingSphere:h.boundingSphere?h.boundingSphere.toJSON():void 0})),o.instanceInfo=this._instanceInfo.map(h=>({...h})),o.availableInstanceIds=this._availableInstanceIds.slice(),o.availableGeometryIds=this._availableGeometryIds.slice(),o.nextIndexStart=this._nextIndexStart,o.nextVertexStart=this._nextVertexStart,o.geometryCount=this._geometryCount,o.maxInstanceCount=this._maxInstanceCount,o.maxVertexCount=this._maxVertexCount,o.maxIndexCount=this._maxIndexCount,o.geometryInitialized=this._geometryInitialized,o.matricesTexture=this._matricesTexture.toJSON(t),o.indirectTexture=this._indirectTexture.toJSON(t),this._colorsTexture!==null&&(o.colorsTexture=this._colorsTexture.toJSON(t)),this.boundingSphere!==null&&(o.boundingSphere=this.boundingSphere.toJSON()),this.boundingBox!==null&&(o.boundingBox=this.boundingBox.toJSON()));function c(h,p){return h[p.uuid]===void 0&&(h[p.uuid]=p.toJSON(t)),p.uuid}if(this.isScene)this.background&&(this.background.isColor?o.background=this.background.toJSON():this.background.isTexture&&(o.background=this.background.toJSON(t).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(o.environment=this.environment.toJSON(t).uuid);else if(this.isMesh||this.isLine||this.isPoints){o.geometry=c(t.geometries,this.geometry);const h=this.geometry.parameters;if(h!==void 0&&h.shapes!==void 0){const p=h.shapes;if(Array.isArray(p))for(let d=0,g=p.length;d<g;d++){const v=p[d];c(t.shapes,v)}else c(t.shapes,p)}}if(this.isSkinnedMesh&&(o.bindMode=this.bindMode,o.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(c(t.skeletons,this.skeleton),o.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const h=[];for(let p=0,d=this.material.length;p<d;p++)h.push(c(t.materials,this.material[p]));o.material=h}else o.material=c(t.materials,this.material);if(this.children.length>0){o.children=[];for(let h=0;h<this.children.length;h++)o.children.push(this.children[h].toJSON(t).object)}if(this.animations.length>0){o.animations=[];for(let h=0;h<this.animations.length;h++){const p=this.animations[h];o.animations.push(c(t.animations,p))}}if(n){const h=u(t.geometries),p=u(t.materials),d=u(t.textures),g=u(t.images),v=u(t.shapes),_=u(t.skeletons),x=u(t.animations),b=u(t.nodes);h.length>0&&(a.geometries=h),p.length>0&&(a.materials=p),d.length>0&&(a.textures=d),g.length>0&&(a.images=g),v.length>0&&(a.shapes=v),_.length>0&&(a.skeletons=_),x.length>0&&(a.animations=x),b.length>0&&(a.nodes=b)}return a.object=o,a;function u(h){const p=[];for(const d in h){const g=h[d];delete g.metadata,p.push(g)}return p}}clone(t){return new this.constructor().copy(this,t)}copy(t,n=!0){if(this.name=t.name,this.up.copy(t.up),this.position.copy(t.position),this.rotation.order=t.rotation.order,this.quaternion.copy(t.quaternion),this.scale.copy(t.scale),this.pivot=t.pivot!==null?t.pivot.clone():null,this.matrix.copy(t.matrix),this.matrixWorld.copy(t.matrixWorld),this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrixWorldAutoUpdate=t.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=t.matrixWorldNeedsUpdate,this.layers.mask=t.layers.mask,this.visible=t.visible,this.castShadow=t.castShadow,this.receiveShadow=t.receiveShadow,this.frustumCulled=t.frustumCulled,this.renderOrder=t.renderOrder,this.static=t.static,this.animations=t.animations.slice(),this.userData=JSON.parse(JSON.stringify(t.userData)),n===!0)for(let a=0;a<t.children.length;a++){const o=t.children[a];this.add(o.clone())}return this}dispose(){this.dispatchEvent({type:"dispose"})}}An.DEFAULT_UP=new B(0,1,0);An.DEFAULT_MATRIX_AUTO_UPDATE=!0;An.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;class Ii extends An{constructor(){super(),this.isGroup=!0,this.type="Group"}}const k1={type:"move"};class hd{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new Ii,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new Ii,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new B,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new B),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new Ii,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new B,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new B,this._grip.eventsEnabled=!1),this._grip}dispatchEvent(t){return this._targetRay!==null&&this._targetRay.dispatchEvent(t),this._grip!==null&&this._grip.dispatchEvent(t),this._hand!==null&&this._hand.dispatchEvent(t),this}connect(t){if(t&&t.hand){const n=this._hand;if(n)for(const a of t.hand.values())this._getHandJoint(n,a)}return this.dispatchEvent({type:"connected",data:t}),this}disconnect(t){return this.dispatchEvent({type:"disconnected",data:t}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(t,n,a){let o=null,c=null,u=null;const h=this._targetRay,p=this._grip,d=this._hand;if(t&&n.session.visibilityState!=="visible-blurred"){if(d&&t.hand){u=!0;for(const R of t.hand.values()){const y=n.getJointPose(R,a),M=this._getHandJoint(d,R);y!==null&&(M.matrix.fromArray(y.transform.matrix),M.matrix.decompose(M.position,M.rotation,M.scale),M.matrixWorldNeedsUpdate=!0,M.jointRadius=y.radius),M.visible=y!==null}const g=d.joints["index-finger-tip"],v=d.joints["thumb-tip"],_=g.position.distanceTo(v.position),x=.02,b=.005;d.inputState.pinching&&_>x+b?(d.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:t.handedness,target:this})):!d.inputState.pinching&&_<=x-b&&(d.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:t.handedness,target:this}))}else p!==null&&t.gripSpace&&(c=n.getPose(t.gripSpace,a),c!==null&&(p.matrix.fromArray(c.transform.matrix),p.matrix.decompose(p.position,p.rotation,p.scale),p.matrixWorldNeedsUpdate=!0,c.linearVelocity?(p.hasLinearVelocity=!0,p.linearVelocity.copy(c.linearVelocity)):p.hasLinearVelocity=!1,c.angularVelocity?(p.hasAngularVelocity=!0,p.angularVelocity.copy(c.angularVelocity)):p.hasAngularVelocity=!1,p.eventsEnabled&&p.dispatchEvent({type:"gripUpdated",data:t,target:this})));h!==null&&(o=n.getPose(t.targetRaySpace,a),o===null&&c!==null&&(o=c),o!==null&&(h.matrix.fromArray(o.transform.matrix),h.matrix.decompose(h.position,h.rotation,h.scale),h.matrixWorldNeedsUpdate=!0,o.linearVelocity?(h.hasLinearVelocity=!0,h.linearVelocity.copy(o.linearVelocity)):h.hasLinearVelocity=!1,o.angularVelocity?(h.hasAngularVelocity=!0,h.angularVelocity.copy(o.angularVelocity)):h.hasAngularVelocity=!1,this.dispatchEvent(k1)))}return h!==null&&(h.visible=o!==null),p!==null&&(p.visible=c!==null),d!==null&&(d.visible=u!==null),this}_getHandJoint(t,n){if(t.joints[n.jointName]===void 0){const a=new Ii;a.matrixAutoUpdate=!1,a.visible=!1,t.joints[n.jointName]=a,t.add(a)}return t.joints[n.jointName]}}const Kx={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},Es={h:0,s:0,l:0},jc={h:0,s:0,l:0};function dd(s,t,n){return n<0&&(n+=1),n>1&&(n-=1),n<1/6?s+(t-s)*6*n:n<1/2?t:n<2/3?s+(t-s)*6*(2/3-n):s}class ce{constructor(t,n,a){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(t,n,a)}set(t,n,a){if(n===void 0&&a===void 0){const o=t;o&&o.isColor?this.copy(o):typeof o=="number"?this.setHex(o):typeof o=="string"&&this.setStyle(o)}else this.setRGB(t,n,a);return this}setScalar(t){return this.r=t,this.g=t,this.b=t,this}setHex(t,n=Ln){return t=Math.floor(t),this.r=(t>>16&255)/255,this.g=(t>>8&255)/255,this.b=(t&255)/255,qe.colorSpaceToWorking(this,n),this}setRGB(t,n,a,o=qe.workingColorSpace){return this.r=t,this.g=n,this.b=a,qe.colorSpaceToWorking(this,o),this}setHSL(t,n,a,o=qe.workingColorSpace){if(t=tm(t,1),n=ze(n,0,1),a=ze(a,0,1),n===0)this.r=this.g=this.b=a;else{const c=a<=.5?a*(1+n):a+n-a*n,u=2*a-c;this.r=dd(u,c,t+1/3),this.g=dd(u,c,t),this.b=dd(u,c,t-1/3)}return qe.colorSpaceToWorking(this,o),this}setStyle(t,n=Ln){function a(c){c!==void 0&&parseFloat(c)<1&&ye("Color: Alpha component of "+t+" will be ignored.")}let o;if(o=/^(\w+)\(([^\)]*)\)/.exec(t)){let c;const u=o[1],h=o[2];switch(u){case"rgb":case"rgba":if(c=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(h))return a(c[4]),this.setRGB(Math.min(255,parseInt(c[1],10))/255,Math.min(255,parseInt(c[2],10))/255,Math.min(255,parseInt(c[3],10))/255,n);if(c=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(h))return a(c[4]),this.setRGB(Math.min(100,parseInt(c[1],10))/100,Math.min(100,parseInt(c[2],10))/100,Math.min(100,parseInt(c[3],10))/100,n);break;case"hsl":case"hsla":if(c=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(h))return a(c[4]),this.setHSL(parseFloat(c[1])/360,parseFloat(c[2])/100,parseFloat(c[3])/100,n);break;default:ye("Color: Unknown color model "+t)}}else if(o=/^\#([A-Fa-f\d]+)$/.exec(t)){const c=o[1],u=c.length;if(u===3)return this.setRGB(parseInt(c.charAt(0),16)/15,parseInt(c.charAt(1),16)/15,parseInt(c.charAt(2),16)/15,n);if(u===6)return this.setHex(parseInt(c,16),n);ye("Color: Invalid hex color "+t)}else if(t&&t.length>0)return this.setColorName(t,n);return this}setColorName(t,n=Ln){const a=Kx[t.toLowerCase()];return a!==void 0?this.setHex(a,n):ye("Color: Unknown color "+t),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(t){return this.r=t.r,this.g=t.g,this.b=t.b,this}copySRGBToLinear(t){return this.r=Za(t.r),this.g=Za(t.g),this.b=Za(t.b),this}copyLinearToSRGB(t){return this.r=fo(t.r),this.g=fo(t.g),this.b=fo(t.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(t=Ln){return qe.workingToColorSpace(li.copy(this),t),Math.round(ze(li.r*255,0,255))*65536+Math.round(ze(li.g*255,0,255))*256+Math.round(ze(li.b*255,0,255))}getHexString(t=Ln){return("000000"+this.getHex(t).toString(16)).slice(-6)}getHSL(t,n=qe.workingColorSpace){qe.workingToColorSpace(li.copy(this),n);const a=li.r,o=li.g,c=li.b,u=Math.max(a,o,c),h=Math.min(a,o,c);let p,d;const g=(h+u)/2;if(h===u)p=0,d=0;else{const v=u-h;switch(d=g<=.5?v/(u+h):v/(2-u-h),u){case a:p=(o-c)/v+(o<c?6:0);break;case o:p=(c-a)/v+2;break;case c:p=(a-o)/v+4;break}p/=6}return t.h=p,t.s=d,t.l=g,t}getRGB(t,n=qe.workingColorSpace){return qe.workingToColorSpace(li.copy(this),n),t.r=li.r,t.g=li.g,t.b=li.b,t}getStyle(t=Ln){qe.workingToColorSpace(li.copy(this),t);const n=li.r,a=li.g,o=li.b;return t!==Ln?`color(${t} ${n.toFixed(3)} ${a.toFixed(3)} ${o.toFixed(3)})`:`rgb(${Math.round(n*255)},${Math.round(a*255)},${Math.round(o*255)})`}offsetHSL(t,n,a){return this.getHSL(Es),this.setHSL(Es.h+t,Es.s+n,Es.l+a)}add(t){return this.r+=t.r,this.g+=t.g,this.b+=t.b,this}addColors(t,n){return this.r=t.r+n.r,this.g=t.g+n.g,this.b=t.b+n.b,this}addScalar(t){return this.r+=t,this.g+=t,this.b+=t,this}sub(t){return this.r=Math.max(0,this.r-t.r),this.g=Math.max(0,this.g-t.g),this.b=Math.max(0,this.b-t.b),this}multiply(t){return this.r*=t.r,this.g*=t.g,this.b*=t.b,this}multiplyScalar(t){return this.r*=t,this.g*=t,this.b*=t,this}lerp(t,n){return this.r+=(t.r-this.r)*n,this.g+=(t.g-this.g)*n,this.b+=(t.b-this.b)*n,this}lerpColors(t,n,a){return this.r=t.r+(n.r-t.r)*a,this.g=t.g+(n.g-t.g)*a,this.b=t.b+(n.b-t.b)*a,this}lerpHSL(t,n){this.getHSL(Es),t.getHSL(jc);const a=El(Es.h,jc.h,n),o=El(Es.s,jc.s,n),c=El(Es.l,jc.l,n);return this.setHSL(a,o,c),this}setFromVector3(t){return this.r=t.x,this.g=t.y,this.b=t.z,this}applyMatrix3(t){const n=this.r,a=this.g,o=this.b,c=t.elements;return this.r=c[0]*n+c[3]*a+c[6]*o,this.g=c[1]*n+c[4]*a+c[7]*o,this.b=c[2]*n+c[5]*a+c[8]*o,this}equals(t){return t.r===this.r&&t.g===this.g&&t.b===this.b}fromArray(t,n=0){return this.r=t[n],this.g=t[n+1],this.b=t[n+2],this}toArray(t=[],n=0){return t[n]=this.r,t[n+1]=this.g,t[n+2]=this.b,t}fromBufferAttribute(t,n){return this.r=t.getX(n),this.g=t.getY(n),this.b=t.getZ(n),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const li=new ce;ce.NAMES=Kx;class vo{constructor(t,n=25e-5){this.isFogExp2=!0,this.name="",this.color=new ce(t),this.density=n}clone(){return new vo(this.color,this.density)}toJSON(){return{type:"FogExp2",name:this.name,color:this.color.getHex(),density:this.density}}}class X1 extends An{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new Ja,this.environmentIntensity=1,this.environmentRotation=new Ja,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(t,n){return super.copy(t,n),t.background!==null&&(this.background=t.background.clone()),t.environment!==null&&(this.environment=t.environment.clone()),t.fog!==null&&(this.fog=t.fog.clone()),this.backgroundBlurriness=t.backgroundBlurriness,this.backgroundIntensity=t.backgroundIntensity,this.backgroundRotation.copy(t.backgroundRotation),this.environmentIntensity=t.environmentIntensity,this.environmentRotation.copy(t.environmentRotation),t.overrideMaterial!==null&&(this.overrideMaterial=t.overrideMaterial.clone()),this.matrixAutoUpdate=t.matrixAutoUpdate,this}toJSON(t){const n=super.toJSON(t);return this.fog!==null&&(n.object.fog=this.fog.toJSON()),n.object.backgroundBlurriness=this.backgroundBlurriness,n.object.backgroundIntensity=this.backgroundIntensity,n.object.backgroundRotation=this.backgroundRotation.toArray(),n.object.environmentIntensity=this.environmentIntensity,n.object.environmentRotation=this.environmentRotation.toArray(),n}}const aa=new B,Fa=new B,pd=new B,Ha=new B,Kr=new B,Jr=new B,__=new B,md=new B,gd=new B,vd=new B,_d=new _n,xd=new _n,Md=new _n;class ra{constructor(t=new B,n=new B,a=new B){this.a=t,this.b=n,this.c=a}static getNormal(t,n,a,o){o.subVectors(a,n),aa.subVectors(t,n),o.cross(aa);const c=o.lengthSq();return c>0?o.multiplyScalar(1/Math.sqrt(c)):o.set(0,0,0)}static getBarycoord(t,n,a,o,c){aa.subVectors(o,n),Fa.subVectors(a,n),pd.subVectors(t,n);const u=aa.dot(aa),h=aa.dot(Fa),p=aa.dot(pd),d=Fa.dot(Fa),g=Fa.dot(pd),v=u*d-h*h;if(v===0)return c.set(0,0,0),null;const _=1/v,x=(d*p-h*g)*_,b=(u*g-h*p)*_;return c.set(1-x-b,b,x)}static containsPoint(t,n,a,o){return this.getBarycoord(t,n,a,o,Ha)===null?!1:Ha.x>=0&&Ha.y>=0&&Ha.x+Ha.y<=1}static getInterpolation(t,n,a,o,c,u,h,p){return this.getBarycoord(t,n,a,o,Ha)===null?(p.x=0,p.y=0,"z"in p&&(p.z=0),"w"in p&&(p.w=0),null):(p.setScalar(0),p.addScaledVector(c,Ha.x),p.addScaledVector(u,Ha.y),p.addScaledVector(h,Ha.z),p)}static getInterpolatedAttribute(t,n,a,o,c,u){return _d.setScalar(0),xd.setScalar(0),Md.setScalar(0),_d.fromBufferAttribute(t,n),xd.fromBufferAttribute(t,a),Md.fromBufferAttribute(t,o),u.setScalar(0),u.addScaledVector(_d,c.x),u.addScaledVector(xd,c.y),u.addScaledVector(Md,c.z),u}static isFrontFacing(t,n,a,o){return aa.subVectors(a,n),Fa.subVectors(t,n),aa.cross(Fa).dot(o)<0}set(t,n,a){return this.a.copy(t),this.b.copy(n),this.c.copy(a),this}setFromPointsAndIndices(t,n,a,o){return this.a.copy(t[n]),this.b.copy(t[a]),this.c.copy(t[o]),this}setFromAttributeAndIndices(t,n,a,o){return this.a.fromBufferAttribute(t,n),this.b.fromBufferAttribute(t,a),this.c.fromBufferAttribute(t,o),this}clone(){return new this.constructor().copy(this)}copy(t){return this.a.copy(t.a),this.b.copy(t.b),this.c.copy(t.c),this}getArea(){return aa.subVectors(this.c,this.b),Fa.subVectors(this.a,this.b),aa.cross(Fa).length()*.5}getMidpoint(t){return t.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(t){return ra.getNormal(this.a,this.b,this.c,t)}getPlane(t){return t.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(t,n){return ra.getBarycoord(t,this.a,this.b,this.c,n)}getInterpolation(t,n,a,o,c){return ra.getInterpolation(t,this.a,this.b,this.c,n,a,o,c)}containsPoint(t){return ra.containsPoint(t,this.a,this.b,this.c)}isFrontFacing(t){return ra.isFrontFacing(this.a,this.b,this.c,t)}intersectsBox(t){return t.intersectsTriangle(this)}closestPointToPoint(t,n){const a=this.a,o=this.b,c=this.c;let u,h;Kr.subVectors(o,a),Jr.subVectors(c,a),md.subVectors(t,a);const p=Kr.dot(md),d=Jr.dot(md);if(p<=0&&d<=0)return n.copy(a);gd.subVectors(t,o);const g=Kr.dot(gd),v=Jr.dot(gd);if(g>=0&&v<=g)return n.copy(o);const _=p*v-g*d;if(_<=0&&p>=0&&g<=0)return u=p/(p-g),n.copy(a).addScaledVector(Kr,u);vd.subVectors(t,c);const x=Kr.dot(vd),b=Jr.dot(vd);if(b>=0&&x<=b)return n.copy(c);const R=x*d-p*b;if(R<=0&&d>=0&&b<=0)return h=d/(d-b),n.copy(a).addScaledVector(Jr,h);const y=g*b-x*v;if(y<=0&&v-g>=0&&x-b>=0)return __.subVectors(c,o),h=(v-g)/(v-g+(x-b)),n.copy(o).addScaledVector(__,h);const M=1/(y+R+_);return u=R*M,h=_*M,n.copy(a).addScaledVector(Kr,u).addScaledVector(Jr,h)}equals(t){return t.a.equals(this.a)&&t.b.equals(this.b)&&t.c.equals(this.c)}}class ur{constructor(t=new B(1/0,1/0,1/0),n=new B(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=t,this.max=n}set(t,n){return this.min.copy(t),this.max.copy(n),this}setFromArray(t){this.makeEmpty();for(let n=0,a=t.length;n<a;n+=3)this.expandByPoint(sa.fromArray(t,n));return this}setFromBufferAttribute(t){this.makeEmpty();for(let n=0,a=t.count;n<a;n++)this.expandByPoint(sa.fromBufferAttribute(t,n));return this}setFromPoints(t){this.makeEmpty();for(let n=0,a=t.length;n<a;n++)this.expandByPoint(t[n]);return this}setFromCenterAndSize(t,n){const a=sa.copy(n).multiplyScalar(.5);return this.min.copy(t).sub(a),this.max.copy(t).add(a),this}setFromObject(t,n=!1){return this.makeEmpty(),this.expandByObject(t,n)}clone(){return new this.constructor().copy(this)}copy(t){return this.min.copy(t.min),this.max.copy(t.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(t){return this.isEmpty()?t.set(0,0,0):t.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(t){return this.isEmpty()?t.set(0,0,0):t.subVectors(this.max,this.min)}expandByPoint(t){return this.min.min(t),this.max.max(t),this}expandByVector(t){return this.min.sub(t),this.max.add(t),this}expandByScalar(t){return this.min.addScalar(-t),this.max.addScalar(t),this}expandByObject(t,n=!1){t.updateWorldMatrix(!1,!1);const a=t.geometry;if(a!==void 0){const c=a.getAttribute("position");if(n===!0&&c!==void 0&&t.isInstancedMesh!==!0)for(let u=0,h=c.count;u<h;u++)t.isMesh===!0?t.getVertexPosition(u,sa):sa.fromBufferAttribute(c,u),sa.applyMatrix4(t.matrixWorld),this.expandByPoint(sa);else t.boundingBox!==void 0?(t.boundingBox===null&&t.computeBoundingBox(),$c.copy(t.boundingBox)):(a.boundingBox===null&&a.computeBoundingBox(),$c.copy(a.boundingBox)),$c.applyMatrix4(t.matrixWorld),this.union($c)}const o=t.children;for(let c=0,u=o.length;c<u;c++)this.expandByObject(o[c],n);return this}containsPoint(t){return t.x>=this.min.x&&t.x<=this.max.x&&t.y>=this.min.y&&t.y<=this.max.y&&t.z>=this.min.z&&t.z<=this.max.z}containsBox(t){return this.min.x<=t.min.x&&t.max.x<=this.max.x&&this.min.y<=t.min.y&&t.max.y<=this.max.y&&this.min.z<=t.min.z&&t.max.z<=this.max.z}getParameter(t,n){return n.set((t.x-this.min.x)/(this.max.x-this.min.x),(t.y-this.min.y)/(this.max.y-this.min.y),(t.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(t){return t.max.x>=this.min.x&&t.min.x<=this.max.x&&t.max.y>=this.min.y&&t.min.y<=this.max.y&&t.max.z>=this.min.z&&t.min.z<=this.max.z}intersectsSphere(t){return this.clampPoint(t.center,sa),sa.distanceToSquared(t.center)<=t.radius*t.radius}intersectsPlane(t){let n,a;return t.normal.x>0?(n=t.normal.x*this.min.x,a=t.normal.x*this.max.x):(n=t.normal.x*this.max.x,a=t.normal.x*this.min.x),t.normal.y>0?(n+=t.normal.y*this.min.y,a+=t.normal.y*this.max.y):(n+=t.normal.y*this.max.y,a+=t.normal.y*this.min.y),t.normal.z>0?(n+=t.normal.z*this.min.z,a+=t.normal.z*this.max.z):(n+=t.normal.z*this.max.z,a+=t.normal.z*this.min.z),n<=-t.constant&&a>=-t.constant}intersectsTriangle(t){if(this.isEmpty())return!1;this.getCenter(cl),tu.subVectors(this.max,cl),Qr.subVectors(t.a,cl),jr.subVectors(t.b,cl),$r.subVectors(t.c,cl),Ts.subVectors(jr,Qr),As.subVectors($r,jr),qs.subVectors(Qr,$r);let n=[0,-Ts.z,Ts.y,0,-As.z,As.y,0,-qs.z,qs.y,Ts.z,0,-Ts.x,As.z,0,-As.x,qs.z,0,-qs.x,-Ts.y,Ts.x,0,-As.y,As.x,0,-qs.y,qs.x,0];return!yd(n,Qr,jr,$r,tu)||(n=[1,0,0,0,1,0,0,0,1],!yd(n,Qr,jr,$r,tu))?!1:(eu.crossVectors(Ts,As),n=[eu.x,eu.y,eu.z],yd(n,Qr,jr,$r,tu))}clampPoint(t,n){return n.copy(t).clamp(this.min,this.max)}distanceToPoint(t){return this.clampPoint(t,sa).distanceTo(t)}getBoundingSphere(t){return this.isEmpty()?t.makeEmpty():(this.getCenter(t.center),t.radius=this.getSize(sa).length()*.5),t}intersect(t){return this.min.max(t.min),this.max.min(t.max),this.isEmpty()&&this.makeEmpty(),this}union(t){return this.min.min(t.min),this.max.max(t.max),this}applyMatrix4(t){return this.isEmpty()?this:(Ga[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(t),Ga[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(t),Ga[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(t),Ga[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(t),Ga[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(t),Ga[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(t),Ga[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(t),Ga[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(t),this.setFromPoints(Ga),this)}translate(t){return this.min.add(t),this.max.add(t),this}equals(t){return t.min.equals(this.min)&&t.max.equals(this.max)}toJSON(){return{min:this.min.toArray(),max:this.max.toArray()}}fromJSON(t){return this.min.fromArray(t.min),this.max.fromArray(t.max),this}}const Ga=[new B,new B,new B,new B,new B,new B,new B,new B],sa=new B,$c=new ur,Qr=new B,jr=new B,$r=new B,Ts=new B,As=new B,qs=new B,cl=new B,tu=new B,eu=new B,Ys=new B;function yd(s,t,n,a,o){for(let c=0,u=s.length-3;c<=u;c+=3){Ys.fromArray(s,c);const h=o.x*Math.abs(Ys.x)+o.y*Math.abs(Ys.y)+o.z*Math.abs(Ys.z),p=t.dot(Ys),d=n.dot(Ys),g=a.dot(Ys);if(Math.max(-Math.max(p,d,g),Math.min(p,d,g))>h)return!1}return!0}const Hn=new B,nu=new Ot;let W1=0;class ti extends lr{constructor(t,n,a=!1){if(super(),Array.isArray(t))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:W1++}),this.name="",this.array=t,this.itemSize=n,this.count=t!==void 0?t.length/n:0,this.normalized=a,this.usage=qx,this.updateRanges=[],this.gpuType=oa,this.version=0}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}setUsage(t){return this.usage=t,this}addUpdateRange(t,n){this.updateRanges.push({start:t,count:n})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.name=t.name,this.array=new t.array.constructor(t.array),this.itemSize=t.itemSize,this.count=t.count,this.normalized=t.normalized,this.usage=t.usage,this.gpuType=t.gpuType,this}copyAt(t,n,a){t*=this.itemSize,a*=n.itemSize;for(let o=0,c=this.itemSize;o<c;o++)this.array[t+o]=n.array[a+o];return this}copyArray(t){return this.array.set(t),this}applyMatrix3(t){if(this.itemSize===2)for(let n=0,a=this.count;n<a;n++)nu.fromBufferAttribute(this,n),nu.applyMatrix3(t),this.setXY(n,nu.x,nu.y);else if(this.itemSize===3)for(let n=0,a=this.count;n<a;n++)Hn.fromBufferAttribute(this,n),Hn.applyMatrix3(t),this.setXYZ(n,Hn.x,Hn.y,Hn.z);return this}applyMatrix4(t){for(let n=0,a=this.count;n<a;n++)Hn.fromBufferAttribute(this,n),Hn.applyMatrix4(t),this.setXYZ(n,Hn.x,Hn.y,Hn.z);return this}applyNormalMatrix(t){for(let n=0,a=this.count;n<a;n++)Hn.fromBufferAttribute(this,n),Hn.applyNormalMatrix(t),this.setXYZ(n,Hn.x,Hn.y,Hn.z);return this}transformDirection(t){for(let n=0,a=this.count;n<a;n++)Hn.fromBufferAttribute(this,n),Hn.transformDirection(t),this.setXYZ(n,Hn.x,Hn.y,Hn.z);return this}set(t,n=0){return this.array.set(t,n),this}getComponent(t,n){let a=this.array[t*this.itemSize+n];return this.normalized&&(a=oo(a,this.array)),a}setComponent(t,n,a){return this.normalized&&(a=mi(a,this.array)),this.array[t*this.itemSize+n]=a,this}getX(t){let n=this.array[t*this.itemSize];return this.normalized&&(n=oo(n,this.array)),n}setX(t,n){return this.normalized&&(n=mi(n,this.array)),this.array[t*this.itemSize]=n,this}getY(t){let n=this.array[t*this.itemSize+1];return this.normalized&&(n=oo(n,this.array)),n}setY(t,n){return this.normalized&&(n=mi(n,this.array)),this.array[t*this.itemSize+1]=n,this}getZ(t){let n=this.array[t*this.itemSize+2];return this.normalized&&(n=oo(n,this.array)),n}setZ(t,n){return this.normalized&&(n=mi(n,this.array)),this.array[t*this.itemSize+2]=n,this}getW(t){let n=this.array[t*this.itemSize+3];return this.normalized&&(n=oo(n,this.array)),n}setW(t,n){return this.normalized&&(n=mi(n,this.array)),this.array[t*this.itemSize+3]=n,this}setXY(t,n,a){return t*=this.itemSize,this.normalized&&(n=mi(n,this.array),a=mi(a,this.array)),this.array[t+0]=n,this.array[t+1]=a,this}setXYZ(t,n,a,o){return t*=this.itemSize,this.normalized&&(n=mi(n,this.array),a=mi(a,this.array),o=mi(o,this.array)),this.array[t+0]=n,this.array[t+1]=a,this.array[t+2]=o,this}setXYZW(t,n,a,o,c){return t*=this.itemSize,this.normalized&&(n=mi(n,this.array),a=mi(a,this.array),o=mi(o,this.array),c=mi(c,this.array)),this.array[t+0]=n,this.array[t+1]=a,this.array[t+2]=o,this.array[t+3]=c,this}onUpload(t){return this.onUploadCallback=t,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const t={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return t.name=this.name,t.usage=this.usage,t.gpuType=this.gpuType,t}dispose(){this.dispatchEvent({type:"dispose"})}}class Jx extends ti{constructor(t,n,a){super(new Uint16Array(t),n,a)}}class Qx extends ti{constructor(t,n,a){super(new Uint32Array(t),n,a)}}class ae extends ti{constructor(t,n,a){super(new Float32Array(t),n,a)}}const q1=new ur,ul=new B,Sd=new B;class fr{constructor(t=new B,n=-1){this.isSphere=!0,this.center=t,this.radius=n}set(t,n){return this.center.copy(t),this.radius=n,this}setFromPoints(t,n){const a=this.center;n!==void 0?a.copy(n):q1.setFromPoints(t).getCenter(a);let o=0;for(let c=0,u=t.length;c<u;c++)o=Math.max(o,a.distanceToSquared(t[c]));return this.radius=Math.sqrt(o),this}copy(t){return this.center.copy(t.center),this.radius=t.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(t){return t.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(t){return t.distanceTo(this.center)-this.radius}intersectsSphere(t){const n=this.radius+t.radius;return t.center.distanceToSquared(this.center)<=n*n}intersectsBox(t){return t.intersectsSphere(this)}intersectsPlane(t){return Math.abs(t.distanceToPoint(this.center))<=this.radius}clampPoint(t,n){const a=this.center.distanceToSquared(t);return n.copy(t),a>this.radius*this.radius&&(n.sub(this.center).normalize(),n.multiplyScalar(this.radius).add(this.center)),n}getBoundingBox(t){return this.isEmpty()?(t.makeEmpty(),t):(t.set(this.center,this.center),t.expandByScalar(this.radius),t)}applyMatrix4(t){return this.center.applyMatrix4(t),this.radius=this.radius*t.getMaxScaleOnAxis(),this}translate(t){return this.center.add(t),this}expandByPoint(t){if(this.isEmpty())return this.center.copy(t),this.radius=0,this;ul.subVectors(t,this.center);const n=ul.lengthSq();if(n>this.radius*this.radius){const a=Math.sqrt(n),o=(a-this.radius)*.5;this.center.addScaledVector(ul,o/a),this.radius+=o}return this}union(t){return t.isEmpty()?this:this.isEmpty()?(this.copy(t),this):(this.center.equals(t.center)===!0?this.radius=Math.max(this.radius,t.radius):(Sd.subVectors(t.center,this.center).setLength(t.radius),this.expandByPoint(ul.copy(t.center).add(Sd)),this.expandByPoint(ul.copy(t.center).sub(Sd))),this)}equals(t){return t.center.equals(this.center)&&t.radius===this.radius}clone(){return new this.constructor().copy(this)}toJSON(){return{radius:this.radius,center:this.center.toArray()}}fromJSON(t){return this.radius=t.radius,this.center.fromArray(t.center),this}}let Y1=0;const Ki=new ln,bd=new An,to=new B,Pi=new ur,fl=new ur,Jn=new B;class Ie extends lr{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:Y1++}),this.uuid=cr(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.indirectOffset=0,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={},this._transformed=!1}getIndex(){return this.index}setIndex(t){return Array.isArray(t)?this.index=new(f1(t)?Qx:Jx)(t,1):this.index=t,this}setIndirect(t,n=0){return this.indirect=t,this.indirectOffset=n,this}getIndirect(){return this.indirect}getAttribute(t){return this.attributes[t]}setAttribute(t,n){return this.attributes[t]=n,this}deleteAttribute(t){return delete this.attributes[t],this}hasAttribute(t){return this.attributes[t]!==void 0}addGroup(t,n,a=0){this.groups.push({start:t,count:n,materialIndex:a})}clearGroups(){this.groups=[]}setDrawRange(t,n){this.drawRange.start=t,this.drawRange.count=n}applyMatrix4(t){const n=this.attributes.position;n!==void 0&&(n.applyMatrix4(t),n.needsUpdate=!0);const a=this.attributes.normal;if(a!==void 0){const c=new we().getNormalMatrix(t);a.applyNormalMatrix(c),a.needsUpdate=!0}const o=this.attributes.tangent;return o!==void 0&&(o.transformDirection(t),o.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this._transformed=!0,this}applyQuaternion(t){return Ki.makeRotationFromQuaternion(t),this.applyMatrix4(Ki),this}rotateX(t){return Ki.makeRotationX(t),this.applyMatrix4(Ki),this}rotateY(t){return Ki.makeRotationY(t),this.applyMatrix4(Ki),this}rotateZ(t){return Ki.makeRotationZ(t),this.applyMatrix4(Ki),this}translate(t,n,a){return Ki.makeTranslation(t,n,a),this.applyMatrix4(Ki),this}scale(t,n,a){return Ki.makeScale(t,n,a),this.applyMatrix4(Ki),this}lookAt(t){return bd.lookAt(t),bd.updateMatrix(),this.applyMatrix4(bd.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(to).negate(),this.translate(to.x,to.y,to.z),this}setFromPoints(t){const n=this.getAttribute("position");if(n===void 0){const a=[];for(let o=0,c=t.length;o<c;o++){const u=t[o];a.push(u.x,u.y,u.z||0)}this.setAttribute("position",new ae(a,3))}else{const a=Math.min(t.length,n.count);for(let o=0;o<a;o++){const c=t[o];n.setXYZ(o,c.x,c.y,c.z||0)}t.length>n.count&&ye("BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),n.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new ur);const t=this.attributes.position,n=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){Je("BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new B(-1/0,-1/0,-1/0),new B(1/0,1/0,1/0));return}if(t!==void 0){if(this.boundingBox.setFromBufferAttribute(t),n)for(let a=0,o=n.length;a<o;a++){const c=n[a];Pi.setFromBufferAttribute(c),this.morphTargetsRelative?(Jn.addVectors(this.boundingBox.min,Pi.min),this.boundingBox.expandByPoint(Jn),Jn.addVectors(this.boundingBox.max,Pi.max),this.boundingBox.expandByPoint(Jn)):(this.boundingBox.expandByPoint(Pi.min),this.boundingBox.expandByPoint(Pi.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&Je('BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new fr);const t=this.attributes.position,n=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){Je("BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new B,1/0);return}if(t){const a=this.boundingSphere.center;if(Pi.setFromBufferAttribute(t),n)for(let c=0,u=n.length;c<u;c++){const h=n[c];fl.setFromBufferAttribute(h),this.morphTargetsRelative?(Jn.addVectors(Pi.min,fl.min),Pi.expandByPoint(Jn),Jn.addVectors(Pi.max,fl.max),Pi.expandByPoint(Jn)):(Pi.expandByPoint(fl.min),Pi.expandByPoint(fl.max))}Pi.getCenter(a);let o=0;for(let c=0,u=t.count;c<u;c++)Jn.fromBufferAttribute(t,c),o=Math.max(o,a.distanceToSquared(Jn));if(n)for(let c=0,u=n.length;c<u;c++){const h=n[c],p=this.morphTargetsRelative;for(let d=0,g=h.count;d<g;d++)Jn.fromBufferAttribute(h,d),p&&(to.fromBufferAttribute(t,d),Jn.add(to)),o=Math.max(o,a.distanceToSquared(Jn))}this.boundingSphere.radius=Math.sqrt(o),isNaN(this.boundingSphere.radius)&&Je('BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const t=this.index,n=this.attributes;if(t===null||n.position===void 0||n.normal===void 0||n.uv===void 0){Je("BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const a=n.position,o=n.normal,c=n.uv;let u=this.getAttribute("tangent");(u===void 0||u.count!==a.count)&&(u=new ti(new Float32Array(4*a.count),4),this.setAttribute("tangent",u));const h=[],p=[];for(let T=0;T<a.count;T++)h[T]=new B,p[T]=new B;const d=new B,g=new B,v=new B,_=new Ot,x=new Ot,b=new Ot,R=new B,y=new B;function M(T,z,W){d.fromBufferAttribute(a,T),g.fromBufferAttribute(a,z),v.fromBufferAttribute(a,W),_.fromBufferAttribute(c,T),x.fromBufferAttribute(c,z),b.fromBufferAttribute(c,W),g.sub(d),v.sub(d),x.sub(_),b.sub(_);const J=1/(x.x*b.y-b.x*x.y);isFinite(J)&&(R.copy(g).multiplyScalar(b.y).addScaledVector(v,-x.y).multiplyScalar(J),y.copy(v).multiplyScalar(x.x).addScaledVector(g,-b.x).multiplyScalar(J),h[T].add(R),h[z].add(R),h[W].add(R),p[T].add(y),p[z].add(y),p[W].add(y))}let C=this.groups;C.length===0&&(C=[{start:0,count:t.count}]);for(let T=0,z=C.length;T<z;++T){const W=C[T],J=W.start,$=W.count;for(let lt=J,X=J+$;lt<X;lt+=3)M(t.getX(lt+0),t.getX(lt+1),t.getX(lt+2))}const P=new B,E=new B,U=new B,L=new B;function N(T){U.fromBufferAttribute(o,T),L.copy(U);const z=h[T];P.copy(z),P.sub(U.multiplyScalar(U.dot(z))).normalize(),E.crossVectors(L,z);const J=E.dot(p[T])<0?-1:1;u.setXYZW(T,P.x,P.y,P.z,J)}for(let T=0,z=C.length;T<z;++T){const W=C[T],J=W.start,$=W.count;for(let lt=J,X=J+$;lt<X;lt+=3)N(t.getX(lt+0)),N(t.getX(lt+1)),N(t.getX(lt+2))}this._transformed=!0}computeVertexNormals(){const t=this.index,n=this.getAttribute("position");if(n!==void 0){let a=this.getAttribute("normal");if(a===void 0||a.count!==n.count)a=new ti(new Float32Array(n.count*3),3),this.setAttribute("normal",a);else for(let _=0,x=a.count;_<x;_++)a.setXYZ(_,0,0,0);const o=new B,c=new B,u=new B,h=new B,p=new B,d=new B,g=new B,v=new B;if(t)for(let _=0,x=t.count;_<x;_+=3){const b=t.getX(_+0),R=t.getX(_+1),y=t.getX(_+2);o.fromBufferAttribute(n,b),c.fromBufferAttribute(n,R),u.fromBufferAttribute(n,y),g.subVectors(u,c),v.subVectors(o,c),g.cross(v),h.fromBufferAttribute(a,b),p.fromBufferAttribute(a,R),d.fromBufferAttribute(a,y),h.add(g),p.add(g),d.add(g),a.setXYZ(b,h.x,h.y,h.z),a.setXYZ(R,p.x,p.y,p.z),a.setXYZ(y,d.x,d.y,d.z)}else for(let _=0,x=n.count;_<x;_+=3)o.fromBufferAttribute(n,_+0),c.fromBufferAttribute(n,_+1),u.fromBufferAttribute(n,_+2),g.subVectors(u,c),v.subVectors(o,c),g.cross(v),a.setXYZ(_+0,g.x,g.y,g.z),a.setXYZ(_+1,g.x,g.y,g.z),a.setXYZ(_+2,g.x,g.y,g.z);this.normalizeNormals(),a.needsUpdate=!0}}normalizeNormals(){const t=this.attributes.normal;for(let n=0,a=t.count;n<a;n++)Jn.fromBufferAttribute(t,n),Jn.normalize(),t.setXYZ(n,Jn.x,Jn.y,Jn.z)}toNonIndexed(){function t(h,p){const d=h.array,g=h.itemSize,v=h.normalized,_=new d.constructor(p.length*g);let x=0,b=0;for(let R=0,y=p.length;R<y;R++){h.isInterleavedBufferAttribute?x=p[R]*h.data.stride+h.offset:x=p[R]*g;for(let M=0;M<g;M++)_[b++]=d[x++]}return new ti(_,g,v)}if(this.index===null)return ye("BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const n=new Ie,a=this.index.array,o=this.attributes;for(const h in o){const p=o[h],d=t(p,a);n.setAttribute(h,d)}const c=this.morphAttributes;for(const h in c){const p=[],d=c[h];for(let g=0,v=d.length;g<v;g++){const _=d[g],x=t(_,a);p.push(x)}n.morphAttributes[h]=p}n.morphTargetsRelative=this.morphTargetsRelative;const u=this.groups;for(let h=0,p=u.length;h<p;h++){const d=u[h];n.addGroup(d.start,d.count,d.materialIndex)}return n}toJSON(){const t={metadata:{version:4.7,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(t.uuid=this.uuid,t.type=this.parameters!==void 0&&this._transformed===!0?"BufferGeometry":this.type,t.name=this.name,Object.keys(this.userData).length>0&&(t.userData=this.userData),this.parameters!==void 0&&this._transformed!==!0){const p=this.parameters;for(const d in p)p[d]!==void 0&&(t[d]=p[d]);return t}t.data={attributes:{}};const n=this.index;n!==null&&(t.data.index={type:n.array.constructor.name,array:Array.prototype.slice.call(n.array)});const a=this.attributes;for(const p in a){const d=a[p];t.data.attributes[p]=d.toJSON(t.data)}const o={};let c=!1;for(const p in this.morphAttributes){const d=this.morphAttributes[p],g=[];for(let v=0,_=d.length;v<_;v++){const x=d[v];g.push(x.toJSON(t.data))}g.length>0&&(o[p]=g,c=!0)}c&&(t.data.morphAttributes=o,t.data.morphTargetsRelative=this.morphTargetsRelative);const u=this.groups;u.length>0&&(t.data.groups=JSON.parse(JSON.stringify(u)));const h=this.boundingSphere;return h!==null&&(t.data.boundingSphere=h.toJSON()),t}clone(){return new this.constructor().copy(this)}copy(t){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const n={};this.name=t.name;const a=t.index;a!==null&&this.setIndex(a.clone());const o=t.attributes;for(const d in o){const g=o[d];this.setAttribute(d,g.clone(n))}const c=t.morphAttributes;for(const d in c){const g=[],v=c[d];for(let _=0,x=v.length;_<x;_++)g.push(v[_].clone(n));this.morphAttributes[d]=g}this.morphTargetsRelative=t.morphTargetsRelative;const u=t.groups;for(let d=0,g=u.length;d<g;d++){const v=u[d];this.addGroup(v.start,v.count,v.materialIndex)}const h=t.boundingBox;h!==null&&(this.boundingBox=h.clone());const p=t.boundingSphere;return p!==null&&(this.boundingSphere=p.clone()),this.drawRange.start=t.drawRange.start,this.drawRange.count=t.drawRange.count,this.userData=t.userData,this._transformed=t._transformed,this}dispose(){this.dispatchEvent({type:"dispose"})}}const Ed=new B,Z1=new B,K1=new we;class Rs{constructor(t=new B(1,0,0),n=0){this.isPlane=!0,this.normal=t,this.constant=n}set(t,n){return this.normal.copy(t),this.constant=n,this}setComponents(t,n,a,o){return this.normal.set(t,n,a),this.constant=o,this}setFromNormalAndCoplanarPoint(t,n){return this.normal.copy(t),this.constant=-n.dot(this.normal),this}setFromCoplanarPoints(t,n,a){const o=Ed.subVectors(a,n).cross(Z1.subVectors(t,n)).normalize();return this.setFromNormalAndCoplanarPoint(o,t),this}copy(t){return this.normal.copy(t.normal),this.constant=t.constant,this}normalize(){const t=1/this.normal.length();return this.normal.multiplyScalar(t),this.constant*=t,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(t){return this.normal.dot(t)+this.constant}distanceToSphere(t){return this.distanceToPoint(t.center)-t.radius}projectPoint(t,n){return n.copy(t).addScaledVector(this.normal,-this.distanceToPoint(t))}intersectLine(t,n,a=!0){const o=t.delta(Ed),c=this.normal.dot(o);if(c===0)return this.distanceToPoint(t.start)===0?n.copy(t.start):null;const u=-(t.start.dot(this.normal)+this.constant)/c;return a===!0&&(u<0||u>1)?null:n.copy(t.start).addScaledVector(o,u)}intersectsLine(t){const n=this.distanceToPoint(t.start),a=this.distanceToPoint(t.end);return n<0&&a>0||a<0&&n>0}intersectsBox(t){return t.intersectsPlane(this)}intersectsSphere(t){return t.intersectsPlane(this)}coplanarPoint(t){return t.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(t,n){const a=n||K1.getNormalMatrix(t),o=this.coplanarPoint(Ed).applyMatrix4(t),c=this.normal.applyMatrix3(a).normalize();return this.constant=-o.dot(c),this}translate(t){return this.constant-=t.dot(this.normal),this}equals(t){return t.normal.equals(this.normal)&&t.constant===this.constant}clone(){return new this.constructor().copy(this)}toJSON(){return{normal:this.normal.toArray(),constant:this.constant}}fromJSON(t){return this.normal.fromArray(t.normal),this.constant=t.constant,this}}let J1=0;class hr extends lr{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:J1++}),this.uuid=cr(),this.name="",this.type="Material",this.blending=Sl,this.side=er,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=Dx,this.blendDst=Ux,this.blendEquation=ro,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new ce(0,0,0),this.blendAlpha=0,this.depthFunc=Rl,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=a1,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=rd,this.stencilZFail=rd,this.stencilZPass=rd,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.allowOverride=!0,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(t){this._alphaTest>0!=t>0&&this.version++,this._alphaTest=t}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(t){if(t!==void 0)for(const n in t){const a=t[n];if(a===void 0){ye(`Material: parameter '${n}' has value of undefined.`);continue}const o=this[n];if(o===void 0){ye(`Material: '${n}' is not a property of THREE.${this.type}.`);continue}o&&o.isColor?o.set(a):o&&o.isVector2&&a&&a.isVector2||o&&o.isEuler&&a&&a.isEuler||o&&o.isVector3&&a&&a.isVector3?o.copy(a):this[n]=a}}toJSON(t){const n=t===void 0||typeof t=="string";n&&(t={textures:{},images:{}});const a={metadata:{version:4.7,type:"Material",generator:"Material.toJSON"}};a.uuid=this.uuid,a.type=this.type,a.blending=this.blending,a.side=this.side,a.shadowSide=this.shadowSide,a.vertexColors=this.vertexColors,a.opacity=this.opacity,a.transparent=this.transparent,a.blendSrc=this.blendSrc,a.blendDst=this.blendDst,a.blendEquation=this.blendEquation,a.blendSrcAlpha=this.blendSrcAlpha,a.blendDstAlpha=this.blendDstAlpha,a.blendEquationAlpha=this.blendEquationAlpha,a.blendColor=this.blendColor.getHex(),a.blendAlpha=this.blendAlpha,a.depthFunc=this.depthFunc,a.depthTest=this.depthTest,a.depthWrite=this.depthWrite,a.colorWrite=this.colorWrite,a.clipIntersection=this.clipIntersection,a.clipShadows=this.clipShadows,a.stencilWriteMask=this.stencilWriteMask,a.stencilFunc=this.stencilFunc,a.stencilRef=this.stencilRef,a.stencilFuncMask=this.stencilFuncMask,a.stencilFail=this.stencilFail,a.stencilZFail=this.stencilZFail,a.stencilZPass=this.stencilZPass,a.stencilWrite=this.stencilWrite,a.polygonOffset=this.polygonOffset,a.polygonOffsetFactor=this.polygonOffsetFactor,a.polygonOffsetUnits=this.polygonOffsetUnits,a.dithering=this.dithering,a.alphaTest=this.alphaTest,a.alphaHash=this.alphaHash,a.alphaToCoverage=this.alphaToCoverage,a.premultipliedAlpha=this.premultipliedAlpha,a.forceSinglePass=this.forceSinglePass,a.allowOverride=this.allowOverride,a.visible=this.visible,a.toneMapped=this.toneMapped,a.name=this.name,this.color&&this.color.isColor&&(a.color=this.color.getHex()),this.roughness!==void 0&&(a.roughness=this.roughness),this.metalness!==void 0&&(a.metalness=this.metalness),this.sheen!==void 0&&(a.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(a.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(a.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(a.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&(a.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(a.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(a.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(a.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(a.shininess=this.shininess),this.clearcoat!==void 0&&(a.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(a.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(a.clearcoatMap=this.clearcoatMap.toJSON(t).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(a.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(t).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(a.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(t).uuid,a.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.sheenColorMap&&this.sheenColorMap.isTexture&&(a.sheenColorMap=this.sheenColorMap.toJSON(t).uuid),this.sheenRoughnessMap&&this.sheenRoughnessMap.isTexture&&(a.sheenRoughnessMap=this.sheenRoughnessMap.toJSON(t).uuid),this.dispersion!==void 0&&(a.dispersion=this.dispersion),this.retroreflectivity!==void 0&&(a.retroreflectivity=this.retroreflectivity),this.iridescence!==void 0&&(a.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(a.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(a.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(a.iridescenceMap=this.iridescenceMap.toJSON(t).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(a.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(t).uuid),this.anisotropy!==void 0&&(a.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(a.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(a.anisotropyMap=this.anisotropyMap.toJSON(t).uuid),this.map&&this.map.isTexture&&(a.map=this.map.toJSON(t).uuid),this.matcap&&this.matcap.isTexture&&(a.matcap=this.matcap.toJSON(t).uuid),this.alphaMap&&this.alphaMap.isTexture&&(a.alphaMap=this.alphaMap.toJSON(t).uuid),this.lightMap&&this.lightMap.isTexture&&(a.lightMap=this.lightMap.toJSON(t).uuid,a.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(a.aoMap=this.aoMap.toJSON(t).uuid,a.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(a.bumpMap=this.bumpMap.toJSON(t).uuid,a.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(a.normalMap=this.normalMap.toJSON(t).uuid,a.normalMapType=this.normalMapType,a.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(a.displacementMap=this.displacementMap.toJSON(t).uuid,a.displacementScale=this.displacementScale,a.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(a.roughnessMap=this.roughnessMap.toJSON(t).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(a.metalnessMap=this.metalnessMap.toJSON(t).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(a.emissiveMap=this.emissiveMap.toJSON(t).uuid),this.specularMap&&this.specularMap.isTexture&&(a.specularMap=this.specularMap.toJSON(t).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(a.specularIntensityMap=this.specularIntensityMap.toJSON(t).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(a.specularColorMap=this.specularColorMap.toJSON(t).uuid),this.envMap&&this.envMap.isTexture&&(a.envMap=this.envMap.toJSON(t).uuid,this.combine!==void 0&&(a.combine=this.combine)),this.envMapRotation!==void 0&&(a.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(a.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(a.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(a.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(a.gradientMap=this.gradientMap.toJSON(t).uuid),this.transmission!==void 0&&(a.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(a.transmissionMap=this.transmissionMap.toJSON(t).uuid),this.thickness!==void 0&&(a.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(a.thicknessMap=this.thicknessMap.toJSON(t).uuid),this.attenuationDistance!==void 0&&(a.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(a.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(a.size=this.size),this.sizeAttenuation!==void 0&&(a.sizeAttenuation=this.sizeAttenuation),Array.isArray(this.clippingPlanes)&&this.clippingPlanes.length>0&&(a.clippingPlanes=this.clippingPlanes.map(c=>c.toJSON())),this.rotation!==void 0&&(a.rotation=this.rotation),this.depthPacking!==void 0&&(a.depthPacking=this.depthPacking),this.linewidth!==void 0&&(a.linewidth=this.linewidth),this.linecap!==void 0&&(a.linecap=this.linecap),this.linejoin!==void 0&&(a.linejoin=this.linejoin),this.dashSize!==void 0&&(a.dashSize=this.dashSize),this.gapSize!==void 0&&(a.gapSize=this.gapSize),this.scale!==void 0&&(a.scale=this.scale),this.wireframe!==void 0&&(a.wireframe=this.wireframe),this.wireframeLinewidth!==void 0&&(a.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!==void 0&&(a.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!==void 0&&(a.wireframeLinejoin=this.wireframeLinejoin),this.flatShading!==void 0&&(a.flatShading=this.flatShading),this.fog!==void 0&&(a.fog=this.fog),Object.keys(this.userData).length>0&&(a.userData=this.userData);function o(c){const u=[];for(const h in c){const p=c[h];delete p.metadata,u.push(p)}return u}if(n){const c=o(t.textures),u=o(t.images);c.length>0&&(a.textures=c),u.length>0&&(a.images=u)}return a}fromJSON(t,n){if(t.uuid!==void 0&&(this.uuid=t.uuid),t.name!==void 0&&(this.name=t.name),t.color!==void 0&&this.color!==void 0&&this.color.setHex(t.color),t.roughness!==void 0&&(this.roughness=t.roughness),t.metalness!==void 0&&(this.metalness=t.metalness),t.sheen!==void 0&&(this.sheen=t.sheen),t.sheenColor!==void 0&&(this.sheenColor=new ce().setHex(t.sheenColor)),t.sheenRoughness!==void 0&&(this.sheenRoughness=t.sheenRoughness),t.emissive!==void 0&&this.emissive!==void 0&&this.emissive.setHex(t.emissive),t.specular!==void 0&&this.specular!==void 0&&this.specular.setHex(t.specular),t.specularIntensity!==void 0&&(this.specularIntensity=t.specularIntensity),t.specularColor!==void 0&&this.specularColor!==void 0&&this.specularColor.setHex(t.specularColor),t.shininess!==void 0&&(this.shininess=t.shininess),t.clearcoat!==void 0&&(this.clearcoat=t.clearcoat),t.clearcoatRoughness!==void 0&&(this.clearcoatRoughness=t.clearcoatRoughness),t.dispersion!==void 0&&(this.dispersion=t.dispersion),t.retroreflectivity!==void 0&&(this.retroreflectivity=t.retroreflectivity),t.iridescence!==void 0&&(this.iridescence=t.iridescence),t.iridescenceIOR!==void 0&&(this.iridescenceIOR=t.iridescenceIOR),t.iridescenceThicknessRange!==void 0&&(this.iridescenceThicknessRange=t.iridescenceThicknessRange),t.transmission!==void 0&&(this.transmission=t.transmission),t.thickness!==void 0&&(this.thickness=t.thickness),t.attenuationDistance!==void 0&&(this.attenuationDistance=t.attenuationDistance),t.attenuationColor!==void 0&&this.attenuationColor!==void 0&&this.attenuationColor.setHex(t.attenuationColor),t.anisotropy!==void 0&&(this.anisotropy=t.anisotropy),t.anisotropyRotation!==void 0&&(this.anisotropyRotation=t.anisotropyRotation),t.fog!==void 0&&(this.fog=t.fog),t.flatShading!==void 0&&(this.flatShading=t.flatShading),t.blending!==void 0&&(this.blending=t.blending),t.combine!==void 0&&(this.combine=t.combine),t.side!==void 0&&(this.side=t.side),t.shadowSide!==void 0&&(this.shadowSide=t.shadowSide),t.opacity!==void 0&&(this.opacity=t.opacity),t.transparent!==void 0&&(this.transparent=t.transparent),t.alphaTest!==void 0&&(this.alphaTest=t.alphaTest),t.alphaHash!==void 0&&(this.alphaHash=t.alphaHash),t.depthFunc!==void 0&&(this.depthFunc=t.depthFunc),t.depthTest!==void 0&&(this.depthTest=t.depthTest),t.depthWrite!==void 0&&(this.depthWrite=t.depthWrite),t.colorWrite!==void 0&&(this.colorWrite=t.colorWrite),t.clippingPlanes!==void 0&&(this.clippingPlanes=t.clippingPlanes.map(a=>new Rs().fromJSON(a))),t.clipIntersection!==void 0&&(this.clipIntersection=t.clipIntersection),t.clipShadows!==void 0&&(this.clipShadows=t.clipShadows),t.depthPacking!==void 0&&(this.depthPacking=t.depthPacking),t.blendSrc!==void 0&&(this.blendSrc=t.blendSrc),t.blendDst!==void 0&&(this.blendDst=t.blendDst),t.blendEquation!==void 0&&(this.blendEquation=t.blendEquation),t.blendSrcAlpha!==void 0&&(this.blendSrcAlpha=t.blendSrcAlpha),t.blendDstAlpha!==void 0&&(this.blendDstAlpha=t.blendDstAlpha),t.blendEquationAlpha!==void 0&&(this.blendEquationAlpha=t.blendEquationAlpha),t.blendColor!==void 0&&this.blendColor!==void 0&&this.blendColor.setHex(t.blendColor),t.blendAlpha!==void 0&&(this.blendAlpha=t.blendAlpha),t.stencilWriteMask!==void 0&&(this.stencilWriteMask=t.stencilWriteMask),t.stencilFunc!==void 0&&(this.stencilFunc=t.stencilFunc),t.stencilRef!==void 0&&(this.stencilRef=t.stencilRef),t.stencilFuncMask!==void 0&&(this.stencilFuncMask=t.stencilFuncMask),t.stencilFail!==void 0&&(this.stencilFail=t.stencilFail),t.stencilZFail!==void 0&&(this.stencilZFail=t.stencilZFail),t.stencilZPass!==void 0&&(this.stencilZPass=t.stencilZPass),t.stencilWrite!==void 0&&(this.stencilWrite=t.stencilWrite),t.wireframe!==void 0&&(this.wireframe=t.wireframe),t.wireframeLinewidth!==void 0&&(this.wireframeLinewidth=t.wireframeLinewidth),t.wireframeLinecap!==void 0&&(this.wireframeLinecap=t.wireframeLinecap),t.wireframeLinejoin!==void 0&&(this.wireframeLinejoin=t.wireframeLinejoin),t.rotation!==void 0&&(this.rotation=t.rotation),t.linewidth!==void 0&&(this.linewidth=t.linewidth),t.linecap!==void 0&&(this.linecap=t.linecap),t.linejoin!==void 0&&(this.linejoin=t.linejoin),t.dashSize!==void 0&&(this.dashSize=t.dashSize),t.gapSize!==void 0&&(this.gapSize=t.gapSize),t.scale!==void 0&&(this.scale=t.scale),t.polygonOffset!==void 0&&(this.polygonOffset=t.polygonOffset),t.polygonOffsetFactor!==void 0&&(this.polygonOffsetFactor=t.polygonOffsetFactor),t.polygonOffsetUnits!==void 0&&(this.polygonOffsetUnits=t.polygonOffsetUnits),t.dithering!==void 0&&(this.dithering=t.dithering),t.alphaToCoverage!==void 0&&(this.alphaToCoverage=t.alphaToCoverage),t.premultipliedAlpha!==void 0&&(this.premultipliedAlpha=t.premultipliedAlpha),t.forceSinglePass!==void 0&&(this.forceSinglePass=t.forceSinglePass),t.allowOverride!==void 0&&(this.allowOverride=t.allowOverride),t.visible!==void 0&&(this.visible=t.visible),t.toneMapped!==void 0&&(this.toneMapped=t.toneMapped),t.userData!==void 0&&(this.userData=t.userData),t.vertexColors!==void 0&&(typeof t.vertexColors=="number"?this.vertexColors=t.vertexColors>0:this.vertexColors=t.vertexColors),t.size!==void 0&&(this.size=t.size),t.sizeAttenuation!==void 0&&(this.sizeAttenuation=t.sizeAttenuation),t.map!==void 0&&(this.map=n[t.map]||null),t.matcap!==void 0&&(this.matcap=n[t.matcap]||null),t.alphaMap!==void 0&&(this.alphaMap=n[t.alphaMap]||null),t.bumpMap!==void 0&&(this.bumpMap=n[t.bumpMap]||null),t.bumpScale!==void 0&&(this.bumpScale=t.bumpScale),t.normalMap!==void 0&&(this.normalMap=n[t.normalMap]||null),t.normalMapType!==void 0&&(this.normalMapType=t.normalMapType),t.normalScale!==void 0){let a=t.normalScale;Array.isArray(a)===!1&&(a=[a,a]),this.normalScale=new Ot().fromArray(a)}return t.displacementMap!==void 0&&(this.displacementMap=n[t.displacementMap]||null),t.displacementScale!==void 0&&(this.displacementScale=t.displacementScale),t.displacementBias!==void 0&&(this.displacementBias=t.displacementBias),t.roughnessMap!==void 0&&(this.roughnessMap=n[t.roughnessMap]||null),t.metalnessMap!==void 0&&(this.metalnessMap=n[t.metalnessMap]||null),t.emissiveMap!==void 0&&(this.emissiveMap=n[t.emissiveMap]||null),t.emissiveIntensity!==void 0&&(this.emissiveIntensity=t.emissiveIntensity),t.specularMap!==void 0&&(this.specularMap=n[t.specularMap]||null),t.specularIntensityMap!==void 0&&(this.specularIntensityMap=n[t.specularIntensityMap]||null),t.specularColorMap!==void 0&&(this.specularColorMap=n[t.specularColorMap]||null),t.envMap!==void 0&&(this.envMap=n[t.envMap]||null),t.envMapRotation!==void 0&&this.envMapRotation.fromArray(t.envMapRotation),t.envMapIntensity!==void 0&&(this.envMapIntensity=t.envMapIntensity),t.reflectivity!==void 0&&(this.reflectivity=t.reflectivity),t.refractionRatio!==void 0&&(this.refractionRatio=t.refractionRatio),t.lightMap!==void 0&&(this.lightMap=n[t.lightMap]||null),t.lightMapIntensity!==void 0&&(this.lightMapIntensity=t.lightMapIntensity),t.aoMap!==void 0&&(this.aoMap=n[t.aoMap]||null),t.aoMapIntensity!==void 0&&(this.aoMapIntensity=t.aoMapIntensity),t.gradientMap!==void 0&&(this.gradientMap=n[t.gradientMap]||null),t.clearcoatMap!==void 0&&(this.clearcoatMap=n[t.clearcoatMap]||null),t.clearcoatRoughnessMap!==void 0&&(this.clearcoatRoughnessMap=n[t.clearcoatRoughnessMap]||null),t.clearcoatNormalMap!==void 0&&(this.clearcoatNormalMap=n[t.clearcoatNormalMap]||null),t.clearcoatNormalScale!==void 0&&(this.clearcoatNormalScale=new Ot().fromArray(t.clearcoatNormalScale)),t.iridescenceMap!==void 0&&(this.iridescenceMap=n[t.iridescenceMap]||null),t.iridescenceThicknessMap!==void 0&&(this.iridescenceThicknessMap=n[t.iridescenceThicknessMap]||null),t.transmissionMap!==void 0&&(this.transmissionMap=n[t.transmissionMap]||null),t.thicknessMap!==void 0&&(this.thicknessMap=n[t.thicknessMap]||null),t.anisotropyMap!==void 0&&(this.anisotropyMap=n[t.anisotropyMap]||null),t.sheenColorMap!==void 0&&(this.sheenColorMap=n[t.sheenColorMap]||null),t.sheenRoughnessMap!==void 0&&(this.sheenRoughnessMap=n[t.sheenRoughnessMap]||null),this}clone(){return new this.constructor().copy(this)}copy(t){this.name=t.name,this.blending=t.blending,this.side=t.side,this.vertexColors=t.vertexColors,this.opacity=t.opacity,this.transparent=t.transparent,this.blendSrc=t.blendSrc,this.blendDst=t.blendDst,this.blendEquation=t.blendEquation,this.blendSrcAlpha=t.blendSrcAlpha,this.blendDstAlpha=t.blendDstAlpha,this.blendEquationAlpha=t.blendEquationAlpha,this.blendColor.copy(t.blendColor),this.blendAlpha=t.blendAlpha,this.depthFunc=t.depthFunc,this.depthTest=t.depthTest,this.depthWrite=t.depthWrite,this.stencilWriteMask=t.stencilWriteMask,this.stencilFunc=t.stencilFunc,this.stencilRef=t.stencilRef,this.stencilFuncMask=t.stencilFuncMask,this.stencilFail=t.stencilFail,this.stencilZFail=t.stencilZFail,this.stencilZPass=t.stencilZPass,this.stencilWrite=t.stencilWrite;const n=t.clippingPlanes;let a=null;if(n!==null){const o=n.length;a=new Array(o);for(let c=0;c!==o;++c)a[c]=n[c].clone()}return this.clippingPlanes=a,this.clipIntersection=t.clipIntersection,this.clipShadows=t.clipShadows,this.shadowSide=t.shadowSide,this.colorWrite=t.colorWrite,this.precision=t.precision,this.polygonOffset=t.polygonOffset,this.polygonOffsetFactor=t.polygonOffsetFactor,this.polygonOffsetUnits=t.polygonOffsetUnits,this.dithering=t.dithering,this.alphaTest=t.alphaTest,this.alphaHash=t.alphaHash,this.alphaToCoverage=t.alphaToCoverage,this.premultipliedAlpha=t.premultipliedAlpha,this.forceSinglePass=t.forceSinglePass,this.allowOverride=t.allowOverride,this.visible=t.visible,this.toneMapped=t.toneMapped,this.userData=JSON.parse(JSON.stringify(t.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(t){t===!0&&this.version++}}const Va=new B,Td=new B,iu=new B,au=new B;class ku{constructor(t=new B,n=new B(0,0,-1)){this.origin=t,this.direction=n}set(t,n){return this.origin.copy(t),this.direction.copy(n),this}copy(t){return this.origin.copy(t.origin),this.direction.copy(t.direction),this}at(t,n){return n.copy(this.origin).addScaledVector(this.direction,t)}lookAt(t){return this.direction.copy(t).sub(this.origin).normalize(),this}recast(t){return this.origin.copy(this.at(t,Va)),this}closestPointToPoint(t,n){n.subVectors(t,this.origin);const a=n.dot(this.direction);return a<0?n.copy(this.origin):n.copy(this.origin).addScaledVector(this.direction,a)}distanceToPoint(t){return Math.sqrt(this.distanceSqToPoint(t))}distanceSqToPoint(t){const n=Va.subVectors(t,this.origin).dot(this.direction);return n<0?this.origin.distanceToSquared(t):(Va.copy(this.origin).addScaledVector(this.direction,n),Va.distanceToSquared(t))}distanceSqToSegment(t,n,a,o){Td.copy(t).add(n).multiplyScalar(.5),iu.copy(n).sub(t).normalize(),au.copy(this.origin).sub(Td);const c=t.distanceTo(n)*.5,u=-this.direction.dot(iu),h=au.dot(this.direction),p=-au.dot(iu),d=au.lengthSq(),g=Math.abs(1-u*u);let v,_,x,b;if(g>0)if(v=u*p-h,_=u*h-p,b=c*g,v>=0)if(_>=-b)if(_<=b){const R=1/g;v*=R,_*=R,x=v*(v+u*_+2*h)+_*(u*v+_+2*p)+d}else _=c,v=Math.max(0,-(u*_+h)),x=-v*v+_*(_+2*p)+d;else _=-c,v=Math.max(0,-(u*_+h)),x=-v*v+_*(_+2*p)+d;else _<=-b?(v=Math.max(0,-(-u*c+h)),_=v>0?-c:Math.min(Math.max(-c,-p),c),x=-v*v+_*(_+2*p)+d):_<=b?(v=0,_=Math.min(Math.max(-c,-p),c),x=_*(_+2*p)+d):(v=Math.max(0,-(u*c+h)),_=v>0?c:Math.min(Math.max(-c,-p),c),x=-v*v+_*(_+2*p)+d);else _=u>0?-c:c,v=Math.max(0,-(u*_+h)),x=-v*v+_*(_+2*p)+d;return a&&a.copy(this.origin).addScaledVector(this.direction,v),o&&o.copy(Td).addScaledVector(iu,_),x}intersectSphere(t,n){if(t.radius<0)return null;Va.subVectors(t.center,this.origin);const a=Va.dot(this.direction),o=Va.dot(Va)-a*a,c=t.radius*t.radius;if(o>c)return null;const u=Math.sqrt(c-o),h=a-u,p=a+u;return p<0?null:h<0?this.at(p,n):this.at(h,n)}intersectsSphere(t){return t.radius<0?!1:this.distanceSqToPoint(t.center)<=t.radius*t.radius}distanceToPlane(t){const n=t.normal.dot(this.direction);if(n===0)return t.distanceToPoint(this.origin)===0?0:null;const a=-(this.origin.dot(t.normal)+t.constant)/n;return a>=0?a:null}intersectPlane(t,n){const a=this.distanceToPlane(t);return a===null?null:this.at(a,n)}intersectsPlane(t){const n=t.distanceToPoint(this.origin);return n===0||t.normal.dot(this.direction)*n<0}intersectBox(t,n){let a,o,c,u,h,p;const d=1/this.direction.x,g=1/this.direction.y,v=1/this.direction.z,_=this.origin;return d>=0?(a=(t.min.x-_.x)*d,o=(t.max.x-_.x)*d):(a=(t.max.x-_.x)*d,o=(t.min.x-_.x)*d),g>=0?(c=(t.min.y-_.y)*g,u=(t.max.y-_.y)*g):(c=(t.max.y-_.y)*g,u=(t.min.y-_.y)*g),a>u||c>o||((c>a||isNaN(a))&&(a=c),(u<o||isNaN(o))&&(o=u),v>=0?(h=(t.min.z-_.z)*v,p=(t.max.z-_.z)*v):(h=(t.max.z-_.z)*v,p=(t.min.z-_.z)*v),a>p||h>o)||((h>a||a!==a)&&(a=h),(p<o||o!==o)&&(o=p),o<0)?null:this.at(a>=0?a:o,n)}intersectsBox(t){return this.intersectBox(t,Va)!==null}intersectTriangle(t,n,a,o,c){const u=this.origin,h=this.direction,p=h.x,d=h.y,g=h.z,v=t.x-u.x,_=t.y-u.y,x=t.z-u.z,b=n.x-u.x,R=n.y-u.y,y=n.z-u.z,M=a.x-u.x,C=a.y-u.y,P=a.z-u.z,E=Math.abs(p),U=Math.abs(d),L=Math.abs(g);let N,T,z,W,J,$,lt,X,k,H,Y,it;if(E>=U&&E>=L?(z=p,$=v,k=b,it=M,p>=0?(N=d,T=g,W=_,J=x,lt=R,X=y,H=C,Y=P):(N=g,T=d,W=x,J=_,lt=y,X=R,H=P,Y=C)):U>=L?(z=d,$=_,k=R,it=C,d>=0?(N=g,T=p,W=x,J=v,lt=y,X=b,H=P,Y=M):(N=p,T=g,W=v,J=x,lt=b,X=y,H=M,Y=P)):(z=g,$=x,k=y,it=P,g>=0?(N=p,T=d,W=v,J=_,lt=b,X=R,H=M,Y=C):(N=d,T=p,W=_,J=v,lt=R,X=b,H=C,Y=M)),z===0)return null;const rt=N/z,ht=T/z,I=1/z,ct=W-rt*$,Tt=J-ht*$,Ut=lt-rt*k,Vt=X-ht*k,Bt=H-rt*it,ft=Y-ht*it,Et=Bt*Vt-ft*Ut,Ft=ct*ft-Tt*Bt,$t=Ut*Tt-Vt*ct;if(o){if(Et<0||Ft<0||$t<0)return null}else if((Et<0||Ft<0||$t<0)&&(Et>0||Ft>0||$t>0))return null;const Xt=Et+Ft+$t;if(Xt===0)return null;const oe=I*(Et*$+Ft*k+$t*it);return(Xt>0?oe<0:oe>0)?null:this.at(oe/Xt,c)}applyMatrix4(t){return this.origin.applyMatrix4(t),this.direction.transformDirection(t),this}equals(t){return t.origin.equals(this.origin)&&t.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class qa extends hr{constructor(t){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new ce(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Ja,this.combine=Lx,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.specularMap=t.specularMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapRotation.copy(t.envMapRotation),this.combine=t.combine,this.reflectivity=t.reflectivity,this.refractionRatio=t.refractionRatio,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.fog=t.fog,this}}const x_=new ln,Zs=new ku,su=new fr,M_=new B,ru=new B,ou=new B,lu=new B,Ad=new B,cu=new B,y_=new B,uu=new B;class le extends An{constructor(t=new Ie,n=new qa){super(),this.isMesh=!0,this.type="Mesh",this.geometry=t,this.material=n,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.count=1,this.updateMorphTargets()}copy(t,n){return super.copy(t,n),t.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=t.morphTargetInfluences.slice()),t.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},t.morphTargetDictionary)),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}updateMorphTargets(){const n=this.geometry.morphAttributes,a=Object.keys(n);if(a.length>0){const o=n[a[0]];if(o!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let c=0,u=o.length;c<u;c++){const h=o[c].name||String(c);this.morphTargetInfluences.push(0),this.morphTargetDictionary[h]=c}}}}getVertexPosition(t,n){const a=this.geometry,o=a.attributes.position,c=a.morphAttributes.position,u=a.morphTargetsRelative;n.fromBufferAttribute(o,t);const h=this.morphTargetInfluences;if(c&&h){cu.set(0,0,0);for(let p=0,d=c.length;p<d;p++){const g=h[p],v=c[p];g!==0&&(Ad.fromBufferAttribute(v,t),u?cu.addScaledVector(Ad,g):cu.addScaledVector(Ad.sub(n),g))}n.add(cu)}return n}intersectsFrustum(t){return t.intersectsObject(this)}raycast(t,n){const a=this.geometry,o=this.material,c=this.matrixWorld;o!==void 0&&(a.boundingSphere===null&&a.computeBoundingSphere(),su.copy(a.boundingSphere),su.applyMatrix4(c),Zs.copy(t.ray).recast(t.near),!(su.containsPoint(Zs.origin)===!1&&(Zs.intersectSphere(su,M_)===null||Zs.origin.distanceToSquared(M_)>(t.far-t.near)**2))&&(x_.copy(c).invert(),Zs.copy(t.ray).applyMatrix4(x_),!(a.boundingBox!==null&&Zs.intersectsBox(a.boundingBox)===!1)&&this._computeIntersections(t,n,Zs)))}_computeIntersections(t,n,a){let o;const c=this.geometry,u=this.material,h=c.index,p=c.attributes.position,d=c.attributes.uv,g=c.attributes.uv1,v=c.attributes.normal,_=c.groups,x=c.drawRange;if(h!==null)if(Array.isArray(u))for(let b=0,R=_.length;b<R;b++){const y=_[b],M=u[y.materialIndex],C=Math.max(y.start,x.start),P=Math.min(h.count,Math.min(y.start+y.count,x.start+x.count));for(let E=C,U=P;E<U;E+=3){const L=h.getX(E),N=h.getX(E+1),T=h.getX(E+2);o=fu(this,M,t,a,d,g,v,L,N,T),o&&(o.faceIndex=Math.floor(E/3),o.face.materialIndex=y.materialIndex,n.push(o))}}else{const b=Math.max(0,x.start),R=Math.min(h.count,x.start+x.count);for(let y=b,M=R;y<M;y+=3){const C=h.getX(y),P=h.getX(y+1),E=h.getX(y+2);o=fu(this,u,t,a,d,g,v,C,P,E),o&&(o.faceIndex=Math.floor(y/3),n.push(o))}}else if(p!==void 0)if(Array.isArray(u))for(let b=0,R=_.length;b<R;b++){const y=_[b],M=u[y.materialIndex],C=Math.max(y.start,x.start),P=Math.min(p.count,Math.min(y.start+y.count,x.start+x.count));for(let E=C,U=P;E<U;E+=3){const L=E,N=E+1,T=E+2;o=fu(this,M,t,a,d,g,v,L,N,T),o&&(o.faceIndex=Math.floor(E/3),o.face.materialIndex=y.materialIndex,n.push(o))}}else{const b=Math.max(0,x.start),R=Math.min(p.count,x.start+x.count);for(let y=b,M=R;y<M;y+=3){const C=y,P=y+1,E=y+2;o=fu(this,u,t,a,d,g,v,C,P,E),o&&(o.faceIndex=Math.floor(y/3),n.push(o))}}}}function Q1(s,t,n,a,o,c,u,h){let p;if(t.side===vi?p=a.intersectTriangle(u,c,o,!0,h):p=a.intersectTriangle(o,c,u,t.side===er,h),p===null)return null;uu.copy(h),uu.applyMatrix4(s.matrixWorld);const d=n.ray.origin.distanceTo(uu);return d<n.near||d>n.far?null:{distance:d,point:uu.clone(),object:s}}function fu(s,t,n,a,o,c,u,h,p,d){s.getVertexPosition(h,ru),s.getVertexPosition(p,ou),s.getVertexPosition(d,lu);const g=Q1(s,t,n,a,ru,ou,lu,y_);if(g){const v=new B;ra.getBarycoord(y_,ru,ou,lu,v),o&&(g.uv=ra.getInterpolatedAttribute(o,h,p,d,v,new Ot)),c&&(g.uv1=ra.getInterpolatedAttribute(c,h,p,d,v,new Ot)),u&&(g.normal=ra.getInterpolatedAttribute(u,h,p,d,v,new B),g.normal.dot(a.direction)>0&&g.normal.multiplyScalar(-1));const _={a:h,b:p,c:d,normal:new B,materialIndex:0};ra.getNormal(ru,ou,lu,_.normal),g.face=_,g.barycoord=v}return g}class jx extends $n{constructor(t=null,n=1,a=1,o,c,u,h,p,d=ri,g=ri,v,_){super(null,u,h,p,d,g,o,c,v,_),this.isDataTexture=!0,this.image={data:t,width:n,height:a},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class S_ extends ti{constructor(t,n,a,o=1){super(t,n,a),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=o}copy(t){return super.copy(t),this.meshPerAttribute=t.meshPerAttribute,this}toJSON(){const t=super.toJSON();return t.meshPerAttribute=this.meshPerAttribute,t.isInstancedBufferAttribute=!0,t}}const eo=new ln,b_=new ln,hu=[],E_=new ur,j1=new ln,hl=new le,dl=new fr;class Nn extends le{constructor(t,n,a){super(t,n),this.isInstancedMesh=!0,this.instanceMatrix=new S_(new Float32Array(a*16),16),this.instanceColor=null,this.morphTexture=null,this.count=a,this.boundingBox=null,this.boundingSphere=null;for(let o=0;o<a;o++)this.setMatrixAt(o,j1)}computeBoundingBox(){const t=this.geometry,n=this.count;this.boundingBox===null&&(this.boundingBox=new ur),t.boundingBox===null&&t.computeBoundingBox(),this.boundingBox.makeEmpty();for(let a=0;a<n;a++)this.getMatrixAt(a,eo),E_.copy(t.boundingBox).applyMatrix4(eo),this.boundingBox.union(E_)}computeBoundingSphere(){const t=this.geometry,n=this.count;this.boundingSphere===null&&(this.boundingSphere=new fr),t.boundingSphere===null&&t.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let a=0;a<n;a++)this.getMatrixAt(a,eo),dl.copy(t.boundingSphere).applyMatrix4(eo),this.boundingSphere.union(dl)}copy(t,n){return super.copy(t,n),this.instanceMatrix.copy(t.instanceMatrix),t.morphTexture!==null&&(this.morphTexture=t.morphTexture.clone()),t.instanceColor!==null&&(this.instanceColor=t.instanceColor.clone()),this.count=t.count,t.boundingBox!==null&&(this.boundingBox=t.boundingBox.clone()),t.boundingSphere!==null&&(this.boundingSphere=t.boundingSphere.clone()),this}getColorAt(t,n){return this.instanceColor===null?n.setRGB(1,1,1):n.fromArray(this.instanceColor.array,t*3)}getMatrixAt(t,n){return n.fromArray(this.instanceMatrix.array,t*16)}getMorphAt(t,n){const a=n.morphTargetInfluences,o=this.morphTexture.source.data.data,c=a.length+1,u=t*c+1;for(let h=0;h<a.length;h++)a[h]=o[u+h]}raycast(t,n){const a=this.matrixWorld,o=this.count;if(hl.geometry=this.geometry,hl.material=this.material,hl.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),dl.copy(this.boundingSphere),dl.applyMatrix4(a),t.ray.intersectsSphere(dl)!==!1))for(let c=0;c<o;c++){this.getMatrixAt(c,eo),b_.multiplyMatrices(a,eo),hl.matrixWorld=b_,hl.raycast(t,hu);for(let u=0,h=hu.length;u<h;u++){const p=hu[u];p.instanceId=c,p.object=this,n.push(p)}hu.length=0}}setColorAt(t,n){return this.instanceColor===null&&(this.instanceColor=new S_(new Float32Array(this.instanceMatrix.count*3).fill(1),3)),n.toArray(this.instanceColor.array,t*3),this}setMatrixAt(t,n){return n.toArray(this.instanceMatrix.array,t*16),this}setMorphAt(t,n){const a=n.morphTargetInfluences,o=a.length+1;this.morphTexture===null&&(this.morphTexture=new jx(new Float32Array(o*this.count),o,this.count,Jp,oa));const c=this.morphTexture.source.data.data;let u=0;for(let d=0;d<a.length;d++)u+=a[d];const h=this.geometry.morphTargetsRelative?1:1-u,p=o*t;return c[p]=h,c.set(a,p+1),this}updateMorphTargets(){}dispose(){super.dispose(),this.morphTexture!==null&&(this.morphTexture.dispose(),this.morphTexture=null)}}const Ks=new fr,$1=new Ot(.5,.5),du=new B;class im{constructor(t=new Rs,n=new Rs,a=new Rs,o=new Rs,c=new Rs,u=new Rs){this.planes=[t,n,a,o,c,u]}set(t,n,a,o,c,u){const h=this.planes;return h[0].copy(t),h[1].copy(n),h[2].copy(a),h[3].copy(o),h[4].copy(c),h[5].copy(u),this}copy(t){const n=this.planes;for(let a=0;a<6;a++)n[a].copy(t.planes[a]);return this}setFromProjectionMatrix(t,n=_a,a=!1){const o=this.planes,c=t.elements,u=c[0],h=c[1],p=c[2],d=c[3],g=c[4],v=c[5],_=c[6],x=c[7],b=c[8],R=c[9],y=c[10],M=c[11],C=c[12],P=c[13],E=c[14],U=c[15];if(o[0].setComponents(d-u,x-g,M-b,U-C).normalize(),o[1].setComponents(d+u,x+g,M+b,U+C).normalize(),o[2].setComponents(d+h,x+v,M+R,U+P).normalize(),o[3].setComponents(d-h,x-v,M-R,U-P).normalize(),a)o[4].setComponents(p,_,y,E).normalize(),o[5].setComponents(d-p,x-_,M-y,U-E).normalize();else if(o[4].setComponents(d-p,x-_,M-y,U-E).normalize(),n===_a)o[5].setComponents(d+p,x+_,M+y,U+E).normalize();else if(n===Ul)o[5].setComponents(p,_,y,E).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+n);return this}intersectsObject(t){if(t.boundingSphere!==void 0)t.boundingSphere===null&&t.computeBoundingSphere(),Ks.copy(t.boundingSphere).applyMatrix4(t.matrixWorld);else{const n=t.geometry;n.boundingSphere===null&&n.computeBoundingSphere(),Ks.copy(n.boundingSphere).applyMatrix4(t.matrixWorld)}return this.intersectsSphere(Ks)}intersectsSprite(t){Ks.center.set(0,0,0);const n=$1.distanceTo(t.center);return Ks.radius=.7071067811865476+n,Ks.applyMatrix4(t.matrixWorld),this.intersectsSphere(Ks)}intersectsSphere(t){const n=this.planes,a=t.center,o=-t.radius;for(let c=0;c<6;c++)if(n[c].distanceToPoint(a)<o)return!1;return!0}intersectsBox(t){const n=this.planes;for(let a=0;a<6;a++){const o=n[a];if(du.x=o.normal.x>0?t.max.x:t.min.x,du.y=o.normal.y>0?t.max.y:t.min.y,du.z=o.normal.z>0?t.max.z:t.min.z,o.distanceToPoint(du)<0)return!1}return!0}containsPoint(t){const n=this.planes;for(let a=0;a<6;a++)if(n[a].distanceToPoint(t)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}class ar extends hr{constructor(t){super(),this.isLineBasicMaterial=!0,this.type="LineBasicMaterial",this.color=new ce(16777215),this.map=null,this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.linewidth=t.linewidth,this.linecap=t.linecap,this.linejoin=t.linejoin,this.fog=t.fog,this}}const Pu=new B,zu=new B,T_=new ln,pl=new ku,pu=new fr,wd=new B,A_=new B;class tb extends An{constructor(t=new Ie,n=new ar){super(),this.isLine=!0,this.type="Line",this.geometry=t,this.material=n,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(t,n){return super.copy(t,n),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}computeLineDistances(){const t=this.geometry;if(t.index===null){const n=t.attributes.position,a=[0];for(let o=1,c=n.count;o<c;o++)Pu.fromBufferAttribute(n,o-1),zu.fromBufferAttribute(n,o),a[o]=a[o-1],a[o]+=Pu.distanceTo(zu);t.setAttribute("lineDistance",new ae(a,1))}else ye("Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}intersectsFrustum(t){return t.intersectsObject(this)}raycast(t,n){const a=this.geometry,o=this.matrixWorld,c=t.params.Line.threshold,u=a.drawRange;if(a.boundingSphere===null&&a.computeBoundingSphere(),pu.copy(a.boundingSphere),pu.applyMatrix4(o),pu.radius+=c,t.ray.intersectsSphere(pu)===!1)return;T_.copy(o).invert(),pl.copy(t.ray).applyMatrix4(T_);const h=c/((this.scale.x+this.scale.y+this.scale.z)/3),p=h*h,d=this.isLineSegments?2:1,g=a.index,_=a.attributes.position;if(g!==null){const x=Math.max(0,u.start),b=Math.min(g.count,u.start+u.count);for(let R=x,y=b-1;R<y;R+=d){const M=g.getX(R),C=g.getX(R+1),P=mu(this,t,pl,p,M,C,R);P&&n.push(P)}if(this.isLineLoop){const R=g.getX(b-1),y=g.getX(x),M=mu(this,t,pl,p,R,y,b-1);M&&n.push(M)}}else{const x=Math.max(0,u.start),b=Math.min(_.count,u.start+u.count);for(let R=x,y=b-1;R<y;R+=d){const M=mu(this,t,pl,p,R,R+1,R);M&&n.push(M)}if(this.isLineLoop){const R=mu(this,t,pl,p,b-1,x,b-1);R&&n.push(R)}}}updateMorphTargets(){const n=this.geometry.morphAttributes,a=Object.keys(n);if(a.length>0){const o=n[a[0]];if(o!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let c=0,u=o.length;c<u;c++){const h=o[c].name||String(c);this.morphTargetInfluences.push(0),this.morphTargetDictionary[h]=c}}}}}function mu(s,t,n,a,o,c,u){const h=s.geometry.attributes.position;if(Pu.fromBufferAttribute(h,o),zu.fromBufferAttribute(h,c),n.distanceSqToSegment(Pu,zu,wd,A_)>a)return;wd.applyMatrix4(s.matrixWorld);const d=t.ray.origin.distanceTo(wd);if(!(d<t.near||d>t.far))return{distance:d,point:A_.clone().applyMatrix4(s.matrixWorld),index:u,face:null,faceIndex:null,barycoord:null,object:s}}const w_=new B,R_=new B;class sr extends tb{constructor(t,n){super(t,n),this.isLineSegments=!0,this.type="LineSegments"}computeLineDistances(){const t=this.geometry;if(t.index===null){const n=t.attributes.position,a=[];for(let o=0,c=n.count;o<c;o+=2)w_.fromBufferAttribute(n,o),R_.fromBufferAttribute(n,o+1),a[o]=o===0?0:a[o-1],a[o+1]=a[o]+w_.distanceTo(R_);t.setAttribute("lineDistance",new ae(a,1))}else ye("LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}}class $x extends hr{constructor(t){super(),this.isPointsMaterial=!0,this.type="PointsMaterial",this.color=new ce(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.alphaMap=t.alphaMap,this.size=t.size,this.sizeAttenuation=t.sizeAttenuation,this.fog=t.fog,this}}const C_=new ln,Lp=new ku,gu=new fr,vu=new B;class eb extends An{constructor(t=new Ie,n=new $x){super(),this.isPoints=!0,this.type="Points",this.geometry=t,this.material=n,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(t,n){return super.copy(t,n),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}intersectsFrustum(t){return t.intersectsObject(this)}raycast(t,n){const a=this.geometry,o=this.matrixWorld,c=t.params.Points.threshold,u=a.drawRange;if(a.boundingSphere===null&&a.computeBoundingSphere(),gu.copy(a.boundingSphere),gu.applyMatrix4(o),gu.radius+=c,t.ray.intersectsSphere(gu)===!1)return;C_.copy(o).invert(),Lp.copy(t.ray).applyMatrix4(C_);const h=c/((this.scale.x+this.scale.y+this.scale.z)/3),p=h*h,d=a.index,v=a.attributes.position;if(d!==null){const _=Math.max(0,u.start),x=Math.min(d.count,u.start+u.count);for(let b=_,R=x;b<R;b++){const y=d.getX(b);vu.fromBufferAttribute(v,y),D_(vu,y,p,o,t,n,this)}}else{const _=Math.max(0,u.start),x=Math.min(v.count,u.start+u.count);for(let b=_,R=x;b<R;b++)vu.fromBufferAttribute(v,b),D_(vu,b,p,o,t,n,this)}}updateMorphTargets(){const n=this.geometry.morphAttributes,a=Object.keys(n);if(a.length>0){const o=n[a[0]];if(o!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let c=0,u=o.length;c<u;c++){const h=o[c].name||String(c);this.morphTargetInfluences.push(0),this.morphTargetDictionary[h]=c}}}}}function D_(s,t,n,a,o,c,u){const h=Lp.distanceSqToPoint(s);if(h<n){const p=new B;Lp.closestPointToPoint(s,p),p.applyMatrix4(a);const d=o.ray.origin.distanceTo(p);if(d<o.near||d>o.far)return;c.push({distance:d,distanceToRay:Math.sqrt(h),point:p,index:t,face:null,faceIndex:null,barycoord:null,object:u})}}class tM extends $n{constructor(t=[],n=nr,a,o,c,u,h,p,d,g){super(t,n,a,o,c,u,h,p,d,g),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(t){this.image=t}}class rr extends $n{constructor(t,n,a,o,c,u,h,p,d){super(t,n,a,o,c,u,h,p,d),this.isCanvasTexture=!0,this.needsUpdate=!0}}class po extends $n{constructor(t,n,a=la,o,c,u,h=ri,p=ri,d,g=Ma,v=1){if(g!==Ma&&g!==js)throw new Error("THREE.DepthTexture: format must be either THREE.DepthFormat or THREE.DepthStencilFormat");const _={width:t,height:n,depth:v};super(_,o,c,u,h,p,g,a,d),this.isDepthTexture=!0,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(t){return super.copy(t),this.source=new em(Object.assign({},t.image)),this.compareFunction=t.compareFunction,this}toJSON(t){const n=super.toJSON(t);return n.compareFunction=this.compareFunction,n}}class nb extends po{constructor(t,n=la,a=nr,o,c,u=ri,h=ri,p,d=Ma){const g={width:t,height:t,depth:1},v=[g,g,g,g,g,g];super(t,t,n,a,o,c,u,h,p,d),this.image=v,this.isCubeDepthTexture=!0,this.isCubeTexture=!0}get images(){return this.image}set images(t){this.image=t}}class eM extends $n{constructor(t=null){super(),this.sourceTexture=t,this.isExternalTexture=!0}copy(t){return super.copy(t),this.sourceTexture=t.sourceTexture,this}}class Qa extends Ie{constructor(t=1,n=1,a=1,o=1,c=1,u=1){super(),this.type="BoxGeometry",this.parameters={width:t,height:n,depth:a,widthSegments:o,heightSegments:c,depthSegments:u};const h=this;o=Math.floor(o),c=Math.floor(c),u=Math.floor(u);const p=[],d=[],g=[],v=[];let _=0,x=0;b("z","y","x",-1,-1,a,n,t,u,c,0),b("z","y","x",1,-1,a,n,-t,u,c,1),b("x","z","y",1,1,t,a,n,o,u,2),b("x","z","y",1,-1,t,a,-n,o,u,3),b("x","y","z",1,-1,t,n,a,o,c,4),b("x","y","z",-1,-1,t,n,-a,o,c,5),this.setIndex(p),this.setAttribute("position",new ae(d,3)),this.setAttribute("normal",new ae(g,3)),this.setAttribute("uv",new ae(v,2));function b(R,y,M,C,P,E,U,L,N,T,z){const W=E/N,J=U/T,$=E/2,lt=U/2,X=L/2,k=N+1,H=T+1;let Y=0,it=0;const rt=new B;for(let ht=0;ht<H;ht++){const I=ht*J-lt;for(let ct=0;ct<k;ct++){const Tt=ct*W-$;rt[R]=Tt*C,rt[y]=I*P,rt[M]=X,d.push(rt.x,rt.y,rt.z),rt[R]=0,rt[y]=0,rt[M]=L>0?1:-1,g.push(rt.x,rt.y,rt.z),v.push(ct/N),v.push(1-ht/T),Y+=1}}for(let ht=0;ht<T;ht++)for(let I=0;I<N;I++){const ct=_+I+k*ht,Tt=_+I+k*(ht+1),Ut=_+(I+1)+k*(ht+1),Vt=_+(I+1)+k*ht;p.push(ct,Tt,Vt),p.push(Tt,Ut,Vt),it+=6}h.addGroup(x,it,z),x+=it,_+=Y}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new Qa(t.width,t.height,t.depth,t.widthSegments,t.heightSegments,t.depthSegments)}}class Cs extends Ie{constructor(t=1,n=32,a=0,o=Math.PI*2){super(),this.type="CircleGeometry",this.parameters={radius:t,segments:n,thetaStart:a,thetaLength:o},n=Math.max(3,n);const c=[],u=[],h=[],p=[],d=new B,g=new Ot;u.push(0,0,0),h.push(0,0,1),p.push(.5,.5);for(let v=0,_=3;v<=n;v++,_+=3){const x=a+v/n*o;d.x=t*Math.cos(x),d.y=t*Math.sin(x),u.push(d.x,d.y,d.z),h.push(0,0,1),g.x=(u[_]/t+1)/2,g.y=(u[_+1]/t+1)/2,p.push(g.x,g.y)}for(let v=1;v<=n;v++)c.push(v,v+1,0);this.setIndex(c),this.setAttribute("position",new ae(u,3)),this.setAttribute("normal",new ae(h,3)),this.setAttribute("uv",new ae(p,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new Cs(t.radius,t.segments,t.thetaStart,t.thetaLength)}}class Sn extends Ie{constructor(t=1,n=1,a=1,o=32,c=1,u=!1,h=0,p=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:t,radiusBottom:n,height:a,radialSegments:o,heightSegments:c,openEnded:u,thetaStart:h,thetaLength:p};const d=this;o=Math.floor(o),c=Math.floor(c);const g=[],v=[],_=[],x=[];let b=0;const R=[],y=a/2;let M=0;C(),u===!1&&(t>0&&P(!0),n>0&&P(!1)),this.setIndex(g),this.setAttribute("position",new ae(v,3)),this.setAttribute("normal",new ae(_,3)),this.setAttribute("uv",new ae(x,2));function C(){const E=new B,U=new B;let L=0;const N=(n-t)/a;for(let T=0;T<=c;T++){const z=[],W=T/c,J=W*(n-t)+t;for(let $=0;$<=o;$++){const lt=$/o,X=lt*p+h,k=Math.sin(X),H=Math.cos(X);U.x=J*k,U.y=-W*a+y,U.z=J*H,v.push(U.x,U.y,U.z),E.set(k,N,H).normalize(),_.push(E.x,E.y,E.z),x.push(lt,1-W),z.push(b++)}R.push(z)}for(let T=0;T<o;T++)for(let z=0;z<c;z++){const W=R[z][T],J=R[z+1][T],$=R[z+1][T+1],lt=R[z][T+1];(t>0||z!==0)&&(g.push(W,J,lt),L+=3),(n>0||z!==c-1)&&(g.push(J,$,lt),L+=3)}d.addGroup(M,L,0),M+=L}function P(E){const U=b,L=new Ot,N=new B;let T=0;const z=E===!0?t:n,W=E===!0?1:-1;for(let $=1;$<=o;$++)v.push(0,y*W,0),_.push(0,W,0),x.push(.5,.5),b++;const J=b;for(let $=0;$<=o;$++){const X=$/o*p+h,k=Math.cos(X),H=Math.sin(X);N.x=z*H,N.y=y*W,N.z=z*k,v.push(N.x,N.y,N.z),_.push(0,W,0),L.x=k*.5+.5,L.y=H*.5*W+.5,x.push(L.x,L.y),b++}for(let $=0;$<o;$++){const lt=U+$,X=J+$;E===!0?g.push(X,X+1,lt):g.push(X+1,X,lt),T+=3}d.addGroup(M,T,E===!0?1:2),M+=T}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new Sn(t.radiusTop,t.radiusBottom,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}}class Xu extends Sn{constructor(t=1,n=1,a=32,o=1,c=!1,u=0,h=Math.PI*2){super(0,t,n,a,o,c,u,h),this.type="ConeGeometry",this.parameters={radius:t,height:n,radialSegments:a,heightSegments:o,openEnded:c,thetaStart:u,thetaLength:h}}static fromJSON(t){return new Xu(t.radius,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}}class am extends Ie{constructor(t=[],n=[],a=1,o=0){super(),this.type="PolyhedronGeometry",this.parameters={vertices:t,indices:n,radius:a,detail:o};const c=[],u=[];h(o),d(a),g(),this.setAttribute("position",new ae(c,3)),this.setAttribute("normal",new ae(c.slice(),3)),this.setAttribute("uv",new ae(u,2)),o===0?this.computeVertexNormals():this.normalizeNormals();function h(C){const P=new B,E=new B,U=new B;for(let L=0;L<n.length;L+=3)x(n[L+0],P),x(n[L+1],E),x(n[L+2],U),p(P,E,U,C)}function p(C,P,E,U){const L=U+1,N=[];for(let T=0;T<=L;T++){N[T]=[];const z=C.clone().lerp(E,T/L),W=P.clone().lerp(E,T/L),J=L-T;for(let $=0;$<=J;$++)$===0&&T===L?N[T][$]=z:N[T][$]=z.clone().lerp(W,$/J)}for(let T=0;T<L;T++)for(let z=0;z<2*(L-T)-1;z++){const W=Math.floor(z/2);z%2===0?(_(N[T][W+1]),_(N[T+1][W]),_(N[T][W])):(_(N[T][W+1]),_(N[T+1][W+1]),_(N[T+1][W]))}}function d(C){const P=new B;for(let E=0;E<c.length;E+=3)P.x=c[E+0],P.y=c[E+1],P.z=c[E+2],P.normalize().multiplyScalar(C),c[E+0]=P.x,c[E+1]=P.y,c[E+2]=P.z}function g(){const C=new B;for(let P=0;P<c.length;P+=3){C.x=c[P+0],C.y=c[P+1],C.z=c[P+2];const E=y(C)/2/Math.PI+.5,U=M(C)/Math.PI+.5;u.push(E,1-U)}b(),v()}function v(){for(let C=0;C<u.length;C+=6){const P=u[C+0],E=u[C+2],U=u[C+4],L=Math.max(P,E,U),N=Math.min(P,E,U);L>.9&&N<.1&&(P<.2&&(u[C+0]+=1),E<.2&&(u[C+2]+=1),U<.2&&(u[C+4]+=1))}}function _(C){c.push(C.x,C.y,C.z)}function x(C,P){const E=C*3;P.x=t[E+0],P.y=t[E+1],P.z=t[E+2]}function b(){const C=new B,P=new B,E=new B,U=new B,L=new Ot,N=new Ot,T=new Ot;for(let z=0,W=0;z<c.length;z+=9,W+=6){C.set(c[z+0],c[z+1],c[z+2]),P.set(c[z+3],c[z+4],c[z+5]),E.set(c[z+6],c[z+7],c[z+8]),L.set(u[W+0],u[W+1]),N.set(u[W+2],u[W+3]),T.set(u[W+4],u[W+5]),U.copy(C).add(P).add(E).divideScalar(3);const J=y(U);R(L,W+0,C,J),R(N,W+2,P,J),R(T,W+4,E,J)}}function R(C,P,E,U){U<0&&C.x===1&&(u[P]=C.x-1),E.x===0&&E.z===0&&(u[P]=U/2/Math.PI+.5)}function y(C){return Math.atan2(C.z,-C.x)}function M(C){return Math.atan2(-C.y,Math.sqrt(C.x*C.x+C.z*C.z))}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new am(t.vertices,t.indices,t.radius,t.detail)}}class ya{constructor(){this.type="Curve",this.arcLengthDivisions=200,this.needsUpdate=!1,this.cacheArcLengths=null}getPoint(){ye("Curve: .getPoint() not implemented.")}getPointAt(t,n){const a=this.getUtoTmapping(t);return this.getPoint(a,n)}getPoints(t=5){const n=[];for(let a=0;a<=t;a++)n.push(this.getPoint(a/t));return n}getSpacedPoints(t=5){const n=[];for(let a=0;a<=t;a++)n.push(this.getPointAt(a/t));return n}getLength(){const t=this.getLengths();return t[t.length-1]}getLengths(t=this.arcLengthDivisions){if(this.cacheArcLengths&&this.cacheArcLengths.length===t+1&&!this.needsUpdate)return this.cacheArcLengths;this.needsUpdate=!1;const n=[];let a,o=this.getPoint(0),c=0;n.push(0);for(let u=1;u<=t;u++)a=this.getPoint(u/t),c+=a.distanceTo(o),n.push(c),o=a;return this.cacheArcLengths=n,n}updateArcLengths(){this.needsUpdate=!0,this.getLengths()}getUtoTmapping(t,n=null){const a=this.getLengths();let o=0;const c=a.length;let u;n?u=n:u=t*a[c-1];let h=0,p=c-1,d;for(;h<=p;)if(o=Math.floor(h+(p-h)/2),d=a[o]-u,d<0)h=o+1;else if(d>0)p=o-1;else{p=o;break}if(o=p,a[o]===u)return o/(c-1);const g=a[o],_=a[o+1]-g,x=(u-g)/_;return(o+x)/(c-1)}getTangent(t,n){let o=t-1e-4,c=t+1e-4;o<0&&(o=0),c>1&&(c=1);const u=this.getPoint(o),h=this.getPoint(c),p=n||(u.isVector2?new Ot:new B);return p.copy(h).sub(u).normalize(),p}getTangentAt(t,n){const a=this.getUtoTmapping(t);return this.getTangent(a,n)}computeFrenetFrames(t,n=!1){const a=new B,o=[],c=[],u=[],h=new B,p=new ln;for(let x=0;x<=t;x++){const b=x/t;o[x]=this.getTangentAt(b,new B)}c[0]=new B,u[0]=new B;let d=Number.MAX_VALUE;const g=Math.abs(o[0].x),v=Math.abs(o[0].y),_=Math.abs(o[0].z);g<=d&&(d=g,a.set(1,0,0)),v<=d&&(d=v,a.set(0,1,0)),_<=d&&a.set(0,0,1),h.crossVectors(o[0],a).normalize(),c[0].crossVectors(o[0],h),u[0].crossVectors(o[0],c[0]);for(let x=1;x<=t;x++){if(c[x]=c[x-1].clone(),u[x]=u[x-1].clone(),h.crossVectors(o[x-1],o[x]),h.length()>Number.EPSILON){h.normalize();const b=Math.acos(ze(o[x-1].dot(o[x]),-1,1));c[x].applyMatrix4(p.makeRotationAxis(h,b))}u[x].crossVectors(o[x],c[x])}if(n===!0){let x=Math.acos(ze(c[0].dot(c[t]),-1,1));x/=t,o[0].dot(h.crossVectors(c[0],c[t]))>0&&(x=-x);for(let b=1;b<=t;b++)c[b].applyMatrix4(p.makeRotationAxis(o[b],x*b)),u[b].crossVectors(o[b],c[b])}return{tangents:o,normals:c,binormals:u}}clone(){return new this.constructor().copy(this)}copy(t){return this.arcLengthDivisions=t.arcLengthDivisions,this}toJSON(){const t={metadata:{version:4.7,type:"Curve",generator:"Curve.toJSON"}};return t.arcLengthDivisions=this.arcLengthDivisions,t.type=this.type,t}fromJSON(t){return this.arcLengthDivisions=t.arcLengthDivisions,this}}class sm extends ya{constructor(t=0,n=0,a=1,o=1,c=0,u=Math.PI*2,h=!1,p=0){super(),this.isEllipseCurve=!0,this.type="EllipseCurve",this.aX=t,this.aY=n,this.xRadius=a,this.yRadius=o,this.aStartAngle=c,this.aEndAngle=u,this.aClockwise=h,this.aRotation=p}getPoint(t,n=new Ot){const a=n,o=Math.PI*2;let c=this.aEndAngle-this.aStartAngle;const u=Math.abs(c)<Number.EPSILON;for(;c<0;)c+=o;for(;c>o;)c-=o;c<Number.EPSILON&&(u?c=0:c=o),this.aClockwise===!0&&!u&&(c===o?c=-o:c=c-o);const h=this.aStartAngle+t*c;let p=this.aX+this.xRadius*Math.cos(h),d=this.aY+this.yRadius*Math.sin(h);if(this.aRotation!==0){const g=Math.cos(this.aRotation),v=Math.sin(this.aRotation),_=p-this.aX,x=d-this.aY;p=_*g-x*v+this.aX,d=_*v+x*g+this.aY}return a.set(p,d)}copy(t){return super.copy(t),this.aX=t.aX,this.aY=t.aY,this.xRadius=t.xRadius,this.yRadius=t.yRadius,this.aStartAngle=t.aStartAngle,this.aEndAngle=t.aEndAngle,this.aClockwise=t.aClockwise,this.aRotation=t.aRotation,this}toJSON(){const t=super.toJSON();return t.aX=this.aX,t.aY=this.aY,t.xRadius=this.xRadius,t.yRadius=this.yRadius,t.aStartAngle=this.aStartAngle,t.aEndAngle=this.aEndAngle,t.aClockwise=this.aClockwise,t.aRotation=this.aRotation,t}fromJSON(t){return super.fromJSON(t),this.aX=t.aX,this.aY=t.aY,this.xRadius=t.xRadius,this.yRadius=t.yRadius,this.aStartAngle=t.aStartAngle,this.aEndAngle=t.aEndAngle,this.aClockwise=t.aClockwise,this.aRotation=t.aRotation,this}}class ib extends sm{constructor(t,n,a,o,c,u){super(t,n,a,a,o,c,u),this.isArcCurve=!0,this.type="ArcCurve"}}function rm(){let s=0,t=0,n=0,a=0;function o(c,u,h,p){s=c,t=h,n=-3*c+3*u-2*h-p,a=2*c-2*u+h+p}return{initCatmullRom:function(c,u,h,p,d){o(u,h,d*(h-c),d*(p-u))},initNonuniformCatmullRom:function(c,u,h,p,d,g,v){let _=(u-c)/d-(h-c)/(d+g)+(h-u)/g,x=(h-u)/g-(p-u)/(g+v)+(p-h)/v;_*=g,x*=g,o(u,h,_,x)},calc:function(c){const u=c*c,h=u*c;return s+t*c+n*u+a*h}}}const U_=new B,L_=new B,Rd=new rm,Cd=new rm,Dd=new rm;class Iu extends ya{constructor(t=[],n=!1,a="centripetal",o=.5){super(),this.isCatmullRomCurve3=!0,this.type="CatmullRomCurve3",this.points=t,this.closed=n,this.curveType=a,this.tension=o}getPoint(t,n=new B){const a=n,o=this.points,c=o.length,u=(c-(this.closed?0:1))*t;let h=Math.floor(u),p=u-h;this.closed?h+=h>0?0:(Math.floor(Math.abs(h)/c)+1)*c:p===0&&h===c-1&&(h=c-2,p=1);let d,g;this.closed||h>0?d=o[(h-1)%c]:(L_.subVectors(o[0],o[1]).add(o[0]),d=L_);const v=o[h%c],_=o[(h+1)%c];if(this.closed||h+2<c?g=o[(h+2)%c]:(U_.subVectors(o[c-1],o[c-2]).add(o[c-1]),g=U_),this.curveType==="centripetal"||this.curveType==="chordal"){const x=this.curveType==="chordal"?.5:.25;let b=Math.pow(d.distanceToSquared(v),x),R=Math.pow(v.distanceToSquared(_),x),y=Math.pow(_.distanceToSquared(g),x);R<1e-4&&(R=1),b<1e-4&&(b=R),y<1e-4&&(y=R),Rd.initNonuniformCatmullRom(d.x,v.x,_.x,g.x,b,R,y),Cd.initNonuniformCatmullRom(d.y,v.y,_.y,g.y,b,R,y),Dd.initNonuniformCatmullRom(d.z,v.z,_.z,g.z,b,R,y)}else this.curveType==="catmullrom"&&(Rd.initCatmullRom(d.x,v.x,_.x,g.x,this.tension),Cd.initCatmullRom(d.y,v.y,_.y,g.y,this.tension),Dd.initCatmullRom(d.z,v.z,_.z,g.z,this.tension));return a.set(Rd.calc(p),Cd.calc(p),Dd.calc(p)),a}copy(t){super.copy(t),this.points=[];for(let n=0,a=t.points.length;n<a;n++){const o=t.points[n];this.points.push(o.clone())}return this.closed=t.closed,this.curveType=t.curveType,this.tension=t.tension,this}toJSON(){const t=super.toJSON();t.points=[];for(let n=0,a=this.points.length;n<a;n++){const o=this.points[n];t.points.push(o.toArray())}return t.closed=this.closed,t.curveType=this.curveType,t.tension=this.tension,t}fromJSON(t){super.fromJSON(t),this.points=[];for(let n=0,a=t.points.length;n<a;n++){const o=t.points[n];this.points.push(new B().fromArray(o))}return this.closed=t.closed,this.curveType=t.curveType,this.tension=t.tension,this}}function N_(s,t,n,a,o){const c=(a-t)*.5,u=(o-n)*.5,h=s*s,p=s*h;return(2*n-2*a+c+u)*p+(-3*n+3*a-2*c-u)*h+c*s+n}function ab(s,t){const n=1-s;return n*n*t}function sb(s,t){return 2*(1-s)*s*t}function rb(s,t){return s*s*t}function Tl(s,t,n,a){return ab(s,t)+sb(s,n)+rb(s,a)}function ob(s,t){const n=1-s;return n*n*n*t}function lb(s,t){const n=1-s;return 3*n*n*s*t}function cb(s,t){return 3*(1-s)*s*s*t}function ub(s,t){return s*s*s*t}function Al(s,t,n,a,o){return ob(s,t)+lb(s,n)+cb(s,a)+ub(s,o)}class nM extends ya{constructor(t=new Ot,n=new Ot,a=new Ot,o=new Ot){super(),this.isCubicBezierCurve=!0,this.type="CubicBezierCurve",this.v0=t,this.v1=n,this.v2=a,this.v3=o}getPoint(t,n=new Ot){const a=n,o=this.v0,c=this.v1,u=this.v2,h=this.v3;return a.set(Al(t,o.x,c.x,u.x,h.x),Al(t,o.y,c.y,u.y,h.y)),a}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this.v3.copy(t.v3),this}toJSON(){const t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t.v3=this.v3.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this.v3.fromArray(t.v3),this}}class fb extends ya{constructor(t=new B,n=new B,a=new B,o=new B){super(),this.isCubicBezierCurve3=!0,this.type="CubicBezierCurve3",this.v0=t,this.v1=n,this.v2=a,this.v3=o}getPoint(t,n=new B){const a=n,o=this.v0,c=this.v1,u=this.v2,h=this.v3;return a.set(Al(t,o.x,c.x,u.x,h.x),Al(t,o.y,c.y,u.y,h.y),Al(t,o.z,c.z,u.z,h.z)),a}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this.v3.copy(t.v3),this}toJSON(){const t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t.v3=this.v3.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this.v3.fromArray(t.v3),this}}class iM extends ya{constructor(t=new Ot,n=new Ot){super(),this.isLineCurve=!0,this.type="LineCurve",this.v1=t,this.v2=n}getPoint(t,n=new Ot){const a=n;return t===1?a.copy(this.v2):(a.copy(this.v2).sub(this.v1),a.multiplyScalar(t).add(this.v1)),a}getPointAt(t,n){return this.getPoint(t,n)}getTangent(t,n=new Ot){return n.subVectors(this.v2,this.v1).normalize()}getTangentAt(t,n){return this.getTangent(t,n)}copy(t){return super.copy(t),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){const t=super.toJSON();return t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}}class hb extends ya{constructor(t=new B,n=new B){super(),this.isLineCurve3=!0,this.type="LineCurve3",this.v1=t,this.v2=n}getPoint(t,n=new B){const a=n;return t===1?a.copy(this.v2):(a.copy(this.v2).sub(this.v1),a.multiplyScalar(t).add(this.v1)),a}getPointAt(t,n){return this.getPoint(t,n)}getTangent(t,n=new B){return n.subVectors(this.v2,this.v1).normalize()}getTangentAt(t,n){return this.getTangent(t,n)}copy(t){return super.copy(t),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){const t=super.toJSON();return t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}}class aM extends ya{constructor(t=new Ot,n=new Ot,a=new Ot){super(),this.isQuadraticBezierCurve=!0,this.type="QuadraticBezierCurve",this.v0=t,this.v1=n,this.v2=a}getPoint(t,n=new Ot){const a=n,o=this.v0,c=this.v1,u=this.v2;return a.set(Tl(t,o.x,c.x,u.x),Tl(t,o.y,c.y,u.y)),a}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){const t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}}class sM extends ya{constructor(t=new B,n=new B,a=new B){super(),this.isQuadraticBezierCurve3=!0,this.type="QuadraticBezierCurve3",this.v0=t,this.v1=n,this.v2=a}getPoint(t,n=new B){const a=n,o=this.v0,c=this.v1,u=this.v2;return a.set(Tl(t,o.x,c.x,u.x),Tl(t,o.y,c.y,u.y),Tl(t,o.z,c.z,u.z)),a}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){const t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}}class rM extends ya{constructor(t=[]){super(),this.isSplineCurve=!0,this.type="SplineCurve",this.points=t}getPoint(t,n=new Ot){const a=n,o=this.points,c=(o.length-1)*t,u=Math.floor(c),h=c-u,p=o[u===0?u:u-1],d=o[u],g=o[u>o.length-2?o.length-1:u+1],v=o[u>o.length-3?o.length-1:u+2];return a.set(N_(h,p.x,d.x,g.x,v.x),N_(h,p.y,d.y,g.y,v.y)),a}copy(t){super.copy(t),this.points=[];for(let n=0,a=t.points.length;n<a;n++){const o=t.points[n];this.points.push(o.clone())}return this}toJSON(){const t=super.toJSON();t.points=[];for(let n=0,a=this.points.length;n<a;n++){const o=this.points[n];t.points.push(o.toArray())}return t}fromJSON(t){super.fromJSON(t),this.points=[];for(let n=0,a=t.points.length;n<a;n++){const o=t.points[n];this.points.push(new Ot().fromArray(o))}return this}}var Np=Object.freeze({__proto__:null,ArcCurve:ib,CatmullRomCurve3:Iu,CubicBezierCurve:nM,CubicBezierCurve3:fb,EllipseCurve:sm,LineCurve:iM,LineCurve3:hb,QuadraticBezierCurve:aM,QuadraticBezierCurve3:sM,SplineCurve:rM});class db extends ya{constructor(){super(),this.type="CurvePath",this.curves=[],this.autoClose=!1}add(t){this.curves.push(t)}closePath(){const t=this.curves[0].getPoint(0),n=this.curves[this.curves.length-1].getPoint(1);if(!t.equals(n)){const a=t.isVector2===!0?"LineCurve":"LineCurve3";this.curves.push(new Np[a](n,t))}return this}getPoint(t,n){const a=t*this.getLength(),o=this.getCurveLengths();let c=0;for(;c<o.length;){if(o[c]>=a){const u=o[c]-a,h=this.curves[c],p=h.getLength(),d=p===0?0:1-u/p;return h.getPointAt(d,n)}c++}return null}getLength(){const t=this.getCurveLengths();return t[t.length-1]}updateArcLengths(){this.needsUpdate=!0,this.cacheLengths=null,this.getCurveLengths()}getCurveLengths(){if(this.cacheLengths&&this.cacheLengths.length===this.curves.length)return this.cacheLengths;const t=[];let n=0;for(let a=0,o=this.curves.length;a<o;a++)n+=this.curves[a].getLength(),t.push(n);return this.cacheLengths=t,t}getSpacedPoints(t=40){const n=[];for(let a=0;a<=t;a++)n.push(this.getPoint(a/t));return this.autoClose&&n.push(n[0]),n}getPoints(t=12){const n=[];let a;for(let o=0,c=this.curves;o<c.length;o++){const u=c[o],h=u.isEllipseCurve?t*2:u.isLineCurve||u.isLineCurve3?1:u.isSplineCurve?t*u.points.length:t,p=u.getPoints(h);for(let d=0;d<p.length;d++){const g=p[d];a&&a.equals(g)||(n.push(g),a=g)}}return this.autoClose&&n.length>1&&!n[n.length-1].equals(n[0])&&n.push(n[0]),n}copy(t){super.copy(t),this.curves=[];for(let n=0,a=t.curves.length;n<a;n++){const o=t.curves[n];this.curves.push(o.clone())}return this.autoClose=t.autoClose,this}toJSON(){const t=super.toJSON();t.autoClose=this.autoClose,t.curves=[];for(let n=0,a=this.curves.length;n<a;n++){const o=this.curves[n];t.curves.push(o.toJSON())}return t}fromJSON(t){super.fromJSON(t),this.autoClose=t.autoClose,this.curves=[];for(let n=0,a=t.curves.length;n<a;n++){const o=t.curves[n];this.curves.push(new Np[o.type]().fromJSON(o))}return this}}class O_ extends db{constructor(t){super(),this.type="Path",this.currentPoint=new Ot,t&&this.setFromPoints(t)}setFromPoints(t){this.moveTo(t[0].x,t[0].y);for(let n=1,a=t.length;n<a;n++)this.lineTo(t[n].x,t[n].y);return this}moveTo(t,n){return this.currentPoint.set(t,n),this}lineTo(t,n){const a=new iM(this.currentPoint.clone(),new Ot(t,n));return this.curves.push(a),this.currentPoint.set(t,n),this}quadraticCurveTo(t,n,a,o){const c=new aM(this.currentPoint.clone(),new Ot(t,n),new Ot(a,o));return this.curves.push(c),this.currentPoint.set(a,o),this}bezierCurveTo(t,n,a,o,c,u){const h=new nM(this.currentPoint.clone(),new Ot(t,n),new Ot(a,o),new Ot(c,u));return this.curves.push(h),this.currentPoint.set(c,u),this}splineThru(t){const n=[this.currentPoint.clone()].concat(t),a=new rM(n);return this.curves.push(a),this.currentPoint.copy(t[t.length-1]),this}arc(t,n,a,o,c,u){const h=this.currentPoint.x,p=this.currentPoint.y;return this.absarc(t+h,n+p,a,o,c,u),this}absarc(t,n,a,o,c,u){return this.absellipse(t,n,a,a,o,c,u),this}ellipse(t,n,a,o,c,u,h,p){const d=this.currentPoint.x,g=this.currentPoint.y;return this.absellipse(t+d,n+g,a,o,c,u,h,p),this}absellipse(t,n,a,o,c,u,h,p){const d=new sm(t,n,a,o,c,u,h,p);if(this.curves.length>0){const v=d.getPoint(0);v.equals(this.currentPoint)||this.lineTo(v.x,v.y)}this.curves.push(d);const g=d.getPoint(1);return this.currentPoint.copy(g),this}copy(t){return super.copy(t),this.currentPoint.copy(t.currentPoint),this}toJSON(){const t=super.toJSON();return t.currentPoint=this.currentPoint.toArray(),t}fromJSON(t){return super.fromJSON(t),this.currentPoint.fromArray(t.currentPoint),this}}class Op extends O_{constructor(t){super(t),this.uuid=cr(),this.type="Shape",this.holes=[]}getPointsHoles(t){const n=[];for(let a=0,o=this.holes.length;a<o;a++)n[a]=this.holes[a].getPoints(t);return n}extractPoints(t){return{shape:this.getPoints(t),holes:this.getPointsHoles(t)}}copy(t){super.copy(t),this.holes=[];for(let n=0,a=t.holes.length;n<a;n++){const o=t.holes[n];this.holes.push(o.clone())}return this}toJSON(){const t=super.toJSON();t.uuid=this.uuid,t.holes=[];for(let n=0,a=this.holes.length;n<a;n++){const o=this.holes[n];t.holes.push(o.toJSON())}return t}fromJSON(t){super.fromJSON(t),this.uuid=t.uuid,this.holes=[];for(let n=0,a=t.holes.length;n<a;n++){const o=t.holes[n];this.holes.push(new O_().fromJSON(o))}return this}}function pb(s,t,n=2){const a=t&&t.length,o=a?t[0]*n:s.length;let c=oM(s,0,o,n,!0);const u=[];if(!c||c.next===c.prev)return u;let h,p,d;if(a&&(c=xb(s,t,c,n)),s.length>80*n){h=s[0],p=s[1];let g=h,v=p;for(let _=n;_<o;_+=n){const x=s[_],b=s[_+1];x<h&&(h=x),b<p&&(p=b),x>g&&(g=x),b>v&&(v=b)}d=Math.max(g-h,v-p),d=d!==0?32767/d:0}return Nl(c,u,n,h,p,d,0),u}function oM(s,t,n,a,o){let c;if(o===Db(s,t,n,a)>0)for(let u=t;u<n;u+=a)c=P_(u/a|0,s[u],s[u+1],c);else for(let u=n-a;u>=t;u-=a)c=P_(u/a|0,s[u],s[u+1],c);return c&&mo(c,c.next)&&(Pl(c),c=c.next),c}function or(s,t){if(!s)return s;t||(t=s);let n=s,a;do if(a=!1,!n.steiner&&(mo(n,n.next)||Tn(n.prev,n,n.next)===0)){if(Pl(n),n=t=n.prev,n===n.next)break;a=!0}else n=n.next;while(a||n!==t);return t}function Nl(s,t,n,a,o,c,u){if(!s)return;!u&&c&&Eb(s,a,o,c);let h=s;for(;s.prev!==s.next;){const p=s.prev,d=s.next;if(c?gb(s,a,o,c):mb(s)){t.push(p.i,s.i,d.i),Pl(s),s=d.next,h=d.next;continue}if(s=d,s===h){u?u===1?(s=vb(or(s),t),Nl(s,t,n,a,o,c,2)):u===2&&_b(s,t,n,a,o,c):Nl(or(s),t,n,a,o,c,1);break}}}function mb(s){const t=s.prev,n=s,a=s.next;if(Tn(t,n,a)>=0)return!1;const o=t.x,c=n.x,u=a.x,h=t.y,p=n.y,d=a.y,g=Math.min(o,c,u),v=Math.min(h,p,d),_=Math.max(o,c,u),x=Math.max(h,p,d);let b=a.next;for(;b!==t;){if(b.x>=g&&b.x<=_&&b.y>=v&&b.y<=x&&xl(o,h,c,p,u,d,b.x,b.y)&&Tn(b.prev,b,b.next)>=0)return!1;b=b.next}return!0}function gb(s,t,n,a){const o=s.prev,c=s,u=s.next;if(Tn(o,c,u)>=0)return!1;const h=o.x,p=c.x,d=u.x,g=o.y,v=c.y,_=u.y,x=Math.min(h,p,d),b=Math.min(g,v,_),R=Math.max(h,p,d),y=Math.max(g,v,_),M=Pp(x,b,t,n,a),C=Pp(R,y,t,n,a);let P=s.prevZ,E=s.nextZ;for(;P&&P.z>=M&&E&&E.z<=C;){if(P.x>=x&&P.x<=R&&P.y>=b&&P.y<=y&&P!==o&&P!==u&&xl(h,g,p,v,d,_,P.x,P.y)&&Tn(P.prev,P,P.next)>=0||(P=P.prevZ,E.x>=x&&E.x<=R&&E.y>=b&&E.y<=y&&E!==o&&E!==u&&xl(h,g,p,v,d,_,E.x,E.y)&&Tn(E.prev,E,E.next)>=0))return!1;E=E.nextZ}for(;P&&P.z>=M;){if(P.x>=x&&P.x<=R&&P.y>=b&&P.y<=y&&P!==o&&P!==u&&xl(h,g,p,v,d,_,P.x,P.y)&&Tn(P.prev,P,P.next)>=0)return!1;P=P.prevZ}for(;E&&E.z<=C;){if(E.x>=x&&E.x<=R&&E.y>=b&&E.y<=y&&E!==o&&E!==u&&xl(h,g,p,v,d,_,E.x,E.y)&&Tn(E.prev,E,E.next)>=0)return!1;E=E.nextZ}return!0}function vb(s,t){let n=s;do{const a=n.prev,o=n.next.next;!mo(a,o)&&cM(a,n,n.next,o)&&Ol(a,o)&&Ol(o,a)&&(t.push(a.i,n.i,o.i),Pl(n),Pl(n.next),n=s=o),n=n.next}while(n!==s);return or(n)}function _b(s,t,n,a,o,c){let u=s;do{let h=u.next.next;for(;h!==u.prev;){if(u.i!==h.i&&wb(u,h)){let p=uM(u,h);u=or(u,u.next),p=or(p,p.next),Nl(u,t,n,a,o,c,0),Nl(p,t,n,a,o,c,0);return}h=h.next}u=u.next}while(u!==s)}function xb(s,t,n,a){const o=[];for(let c=0,u=t.length;c<u;c++){const h=t[c]*a,p=c<u-1?t[c+1]*a:s.length,d=oM(s,h,p,a,!1);d===d.next&&(d.steiner=!0),o.push(Ab(d))}o.sort(Mb);for(let c=0;c<o.length;c++)n=yb(o[c],n);return n}function Mb(s,t){let n=s.x-t.x;if(n===0&&(n=s.y-t.y,n===0)){const a=(s.next.y-s.y)/(s.next.x-s.x),o=(t.next.y-t.y)/(t.next.x-t.x);n=a-o}return n}function yb(s,t){const n=Sb(s,t);if(!n)return t;const a=uM(n,s);return or(a,a.next),or(n,n.next)}function Sb(s,t){let n=t;const a=s.x,o=s.y;let c=-1/0,u;if(mo(s,n))return n;do{if(mo(s,n.next))return n.next;if(o<=n.y&&o>=n.next.y&&n.next.y!==n.y){const v=n.x+(o-n.y)*(n.next.x-n.x)/(n.next.y-n.y);if(v<=a&&v>c&&(c=v,u=n.x<n.next.x?n:n.next,v===a))return u}n=n.next}while(n!==t);if(!u)return null;const h=u,p=u.x,d=u.y;let g=1/0;n=u;do{if(a>=n.x&&n.x>=p&&a!==n.x&&lM(o<d?a:c,o,p,d,o<d?c:a,o,n.x,n.y)){const v=Math.abs(o-n.y)/(a-n.x);Ol(n,s)&&(v<g||v===g&&(n.x>u.x||n.x===u.x&&bb(u,n)))&&(u=n,g=v)}n=n.next}while(n!==h);return u}function bb(s,t){return Tn(s.prev,s,t.prev)<0&&Tn(t.next,s,s.next)<0}function Eb(s,t,n,a){let o=s;do o.z===0&&(o.z=Pp(o.x,o.y,t,n,a)),o.prevZ=o.prev,o.nextZ=o.next,o=o.next;while(o!==s);o.prevZ.nextZ=null,o.prevZ=null,Tb(o)}function Tb(s){let t,n=1;do{let a=s,o;s=null;let c=null;for(t=0;a;){t++;let u=a,h=0;for(let d=0;d<n&&(h++,u=u.nextZ,!!u);d++);let p=n;for(;h>0||p>0&&u;)h!==0&&(p===0||!u||a.z<=u.z)?(o=a,a=a.nextZ,h--):(o=u,u=u.nextZ,p--),c?c.nextZ=o:s=o,o.prevZ=c,c=o;a=u}c.nextZ=null,n*=2}while(t>1);return s}function Pp(s,t,n,a,o){return s=(s-n)*o|0,t=(t-a)*o|0,s=(s|s<<8)&16711935,s=(s|s<<4)&252645135,s=(s|s<<2)&858993459,s=(s|s<<1)&1431655765,t=(t|t<<8)&16711935,t=(t|t<<4)&252645135,t=(t|t<<2)&858993459,t=(t|t<<1)&1431655765,s|t<<1}function Ab(s){let t=s,n=s;do(t.x<n.x||t.x===n.x&&t.y<n.y)&&(n=t),t=t.next;while(t!==s);return n}function lM(s,t,n,a,o,c,u,h){return(o-u)*(t-h)>=(s-u)*(c-h)&&(s-u)*(a-h)>=(n-u)*(t-h)&&(n-u)*(c-h)>=(o-u)*(a-h)}function xl(s,t,n,a,o,c,u,h){return!(s===u&&t===h)&&lM(s,t,n,a,o,c,u,h)}function wb(s,t){return s.next.i!==t.i&&s.prev.i!==t.i&&!Rb(s,t)&&(Ol(s,t)&&Ol(t,s)&&Cb(s,t)&&(Tn(s.prev,s,t.prev)||Tn(s,t.prev,t))||mo(s,t)&&Tn(s.prev,s,s.next)>0&&Tn(t.prev,t,t.next)>0)}function Tn(s,t,n){return(t.y-s.y)*(n.x-t.x)-(t.x-s.x)*(n.y-t.y)}function mo(s,t){return s.x===t.x&&s.y===t.y}function cM(s,t,n,a){const o=xu(Tn(s,t,n)),c=xu(Tn(s,t,a)),u=xu(Tn(n,a,s)),h=xu(Tn(n,a,t));return!!(o!==c&&u!==h||o===0&&_u(s,n,t)||c===0&&_u(s,a,t)||u===0&&_u(n,s,a)||h===0&&_u(n,t,a))}function _u(s,t,n){return t.x<=Math.max(s.x,n.x)&&t.x>=Math.min(s.x,n.x)&&t.y<=Math.max(s.y,n.y)&&t.y>=Math.min(s.y,n.y)}function xu(s){return s>0?1:s<0?-1:0}function Rb(s,t){let n=s;do{if(n.i!==s.i&&n.next.i!==s.i&&n.i!==t.i&&n.next.i!==t.i&&cM(n,n.next,s,t))return!0;n=n.next}while(n!==s);return!1}function Ol(s,t){return Tn(s.prev,s,s.next)<0?Tn(s,t,s.next)>=0&&Tn(s,s.prev,t)>=0:Tn(s,t,s.prev)<0||Tn(s,s.next,t)<0}function Cb(s,t){let n=s,a=!1;const o=(s.x+t.x)/2,c=(s.y+t.y)/2;do n.y>c!=n.next.y>c&&n.next.y!==n.y&&o<(n.next.x-n.x)*(c-n.y)/(n.next.y-n.y)+n.x&&(a=!a),n=n.next;while(n!==s);return a}function uM(s,t){const n=zp(s.i,s.x,s.y),a=zp(t.i,t.x,t.y),o=s.next,c=t.prev;return s.next=t,t.prev=s,n.next=o,o.prev=n,a.next=n,n.prev=a,c.next=a,a.prev=c,a}function P_(s,t,n,a){const o=zp(s,t,n);return a?(o.next=a.next,o.prev=a,a.next.prev=o,a.next=o):(o.prev=o,o.next=o),o}function Pl(s){s.next.prev=s.prev,s.prev.next=s.next,s.prevZ&&(s.prevZ.nextZ=s.nextZ),s.nextZ&&(s.nextZ.prevZ=s.prevZ)}function zp(s,t,n){return{i:s,x:t,y:n,prev:null,next:null,z:0,prevZ:null,nextZ:null,steiner:!1}}function Db(s,t,n,a){let o=0;for(let c=t,u=n-a;c<n;c+=a)o+=(s[u]-s[c])*(s[c+1]+s[u+1]),u=c;return o}class Ub{static triangulate(t,n,a=2){return pb(t,n,a)}}class wl{static area(t){const n=t.length;let a=0;for(let o=n-1,c=0;c<n;o=c++)a+=t[o].x*t[c].y-t[c].x*t[o].y;return a*.5}static isClockWise(t){return wl.area(t)<0}static triangulateShape(t,n){const a=[],o=[],c=[];z_(t),I_(a,t);let u=t.length;n.forEach(z_);for(let p=0;p<n.length;p++)o.push(u),u+=n[p].length,I_(a,n[p]);const h=Ub.triangulate(a,o);for(let p=0;p<h.length;p+=3)c.push(h.slice(p,p+3));return c}}function z_(s){const t=s.length;t>2&&s[t-1].equals(s[0])&&s.pop()}function I_(s,t){for(let n=0;n<t.length;n++)s.push(t[n].x),s.push(t[n].y)}class _o extends am{constructor(t=1,n=0){const a=(1+Math.sqrt(5))/2,o=[-1,a,0,1,a,0,-1,-a,0,1,-a,0,0,-1,a,0,1,a,0,-1,-a,0,1,-a,a,0,-1,a,0,1,-a,0,-1,-a,0,1],c=[0,11,5,0,5,1,0,1,7,0,7,10,0,10,11,1,5,9,5,11,4,11,10,2,10,7,6,7,1,8,3,9,4,3,4,2,3,2,6,3,6,8,3,8,9,4,9,5,2,4,11,6,2,10,8,6,7,9,8,1];super(o,c,t,n),this.type="IcosahedronGeometry",this.parameters={radius:t,detail:n}}static fromJSON(t){return new _o(t.radius,t.detail)}}class Hl extends Ie{constructor(t=[new Ot(0,-.5),new Ot(.5,0),new Ot(0,.5)],n=12,a=0,o=Math.PI*2){super(),this.type="LatheGeometry",this.parameters={points:t,segments:n,phiStart:a,phiLength:o},n=Math.floor(n),o=ze(o,0,Math.PI*2);const c=[],u=[],h=[],p=[],d=[],g=1/n,v=new B,_=new Ot,x=new B,b=new B,R=new B;let y=0,M=0;for(let C=0;C<=t.length-1;C++)switch(C){case 0:y=t[C+1].x-t[C].x,M=t[C+1].y-t[C].y,x.x=M*1,x.y=-y,x.z=M*0,R.copy(x),x.normalize(),p.push(x.x,x.y,x.z);break;case t.length-1:p.push(R.x,R.y,R.z);break;default:y=t[C+1].x-t[C].x,M=t[C+1].y-t[C].y,x.x=M*1,x.y=-y,x.z=M*0,b.copy(x),x.x+=R.x,x.y+=R.y,x.z+=R.z,x.normalize(),p.push(x.x,x.y,x.z),R.copy(b)}for(let C=0;C<=n;C++){const P=a+C*g*o,E=Math.sin(P),U=Math.cos(P);for(let L=0;L<=t.length-1;L++){v.x=t[L].x*E,v.y=t[L].y,v.z=t[L].x*U,u.push(v.x,v.y,v.z),_.x=C/n,_.y=L/(t.length-1),h.push(_.x,_.y);const N=p[3*L+0]*E,T=p[3*L+1],z=p[3*L+0]*U;d.push(N,T,z)}}for(let C=0;C<n;C++)for(let P=0;P<t.length-1;P++){const E=P+C*t.length,U=E,L=E+t.length,N=E+t.length+1,T=E+1;c.push(U,L,T),c.push(N,T,L)}this.setIndex(c),this.setAttribute("position",new ae(u,3)),this.setAttribute("uv",new ae(h,2)),this.setAttribute("normal",new ae(d,3))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new Hl(t.points,t.segments,t.phiStart,t.phiLength)}}class jn extends Ie{constructor(t=1,n=1,a=1,o=1){super(),this.type="PlaneGeometry",this.parameters={width:t,height:n,widthSegments:a,heightSegments:o};const c=t/2,u=n/2,h=Math.floor(a),p=Math.floor(o),d=h+1,g=p+1,v=t/h,_=n/p,x=[],b=[],R=[],y=[];for(let M=0;M<g;M++){const C=M*_-u;for(let P=0;P<d;P++){const E=P*v-c;b.push(E,-C,0),R.push(0,0,1),y.push(P/h),y.push(1-M/p)}}for(let M=0;M<p;M++)for(let C=0;C<h;C++){const P=C+d*M,E=C+d*(M+1),U=C+1+d*(M+1),L=C+1+d*M;x.push(P,E,L),x.push(E,U,L)}this.setIndex(x),this.setAttribute("position",new ae(b,3)),this.setAttribute("normal",new ae(R,3)),this.setAttribute("uv",new ae(y,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new jn(t.width,t.height,t.widthSegments,t.heightSegments)}}class om extends Ie{constructor(t=.5,n=1,a=32,o=1,c=0,u=Math.PI*2){super(),this.type="RingGeometry",this.parameters={innerRadius:t,outerRadius:n,thetaSegments:a,phiSegments:o,thetaStart:c,thetaLength:u},a=Math.max(3,a),o=Math.max(1,o);const h=[],p=[],d=[],g=[];let v=t;const _=(n-t)/o,x=new B,b=new Ot;for(let R=0;R<=o;R++){for(let y=0;y<=a;y++){const M=c+y/a*u;x.x=v*Math.cos(M),x.y=v*Math.sin(M),p.push(x.x,x.y,x.z),d.push(0,0,1),b.x=(x.x/n+1)/2,b.y=(x.y/n+1)/2,g.push(b.x,b.y)}v+=_}for(let R=0;R<o;R++){const y=R*(a+1);for(let M=0;M<a;M++){const C=M+y,P=C,E=C+a+1,U=C+a+2,L=C+1;h.push(P,E,L),h.push(E,U,L)}}this.setIndex(h),this.setAttribute("position",new ae(p,3)),this.setAttribute("normal",new ae(d,3)),this.setAttribute("uv",new ae(g,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new om(t.innerRadius,t.outerRadius,t.thetaSegments,t.phiSegments,t.thetaStart,t.thetaLength)}}class Bu extends Ie{constructor(t=new Op([new Ot(0,.5),new Ot(-.5,-.5),new Ot(.5,-.5)]),n=12){super(),this.type="ShapeGeometry",this.parameters={shapes:t,curveSegments:n};const a=[],o=[],c=[],u=[];let h=0,p=0;if(Array.isArray(t)===!1)d(t);else for(let g=0;g<t.length;g++)d(t[g]),this.addGroup(h,p,g),h+=p,p=0;this.setIndex(a),this.setAttribute("position",new ae(o,3)),this.setAttribute("normal",new ae(c,3)),this.setAttribute("uv",new ae(u,2));function d(g){const v=o.length/3,_=g.extractPoints(n);let x=_.shape;const b=_.holes;wl.isClockWise(x)===!1&&(x=x.reverse());for(let y=0,M=b.length;y<M;y++){const C=b[y];wl.isClockWise(C)===!0&&(b[y]=C.reverse())}const R=wl.triangulateShape(x,b);for(let y=0,M=b.length;y<M;y++){const C=b[y];x=x.concat(C)}for(let y=0,M=x.length;y<M;y++){const C=x[y];o.push(C.x,C.y,0),c.push(0,0,1),u.push(C.x,C.y)}for(let y=0,M=R.length;y<M;y++){const C=R[y],P=C[0]+v,E=C[1]+v,U=C[2]+v;a.push(P,E,U),p+=3}}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}toJSON(){const t=super.toJSON(),n=this.parameters.shapes;return Lb(n,t)}static fromJSON(t,n){const a=[];for(let o=0,c=t.shapes.length;o<c;o++){const u=n[t.shapes[o]];a.push(u)}return new Bu(a,t.curveSegments)}}function Lb(s,t){if(t.shapes=[],Array.isArray(s))for(let n=0,a=s.length;n<a;n++){const o=s[n];t.shapes.push(o.uuid)}else t.shapes.push(s.uuid);return t}class Wu extends Ie{constructor(t=1,n=32,a=16,o=0,c=Math.PI*2,u=0,h=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:t,widthSegments:n,heightSegments:a,phiStart:o,phiLength:c,thetaStart:u,thetaLength:h},n=Math.max(3,Math.floor(n)),a=Math.max(2,Math.floor(a));const p=Math.min(u+h,Math.PI);let d=0;const g=[],v=new B,_=new B,x=[],b=[],R=[],y=[];for(let M=0;M<=a;M++){const C=[],P=M/a,E=u+P*h,U=t*Math.cos(E),L=Math.sqrt(t*t-U*U);let N=0;M===0&&u===0?N=.5/n:M===a&&p===Math.PI&&(N=-.5/n);for(let T=0;T<=n;T++){const z=T/n,W=o+z*c;v.x=-L*Math.cos(W),v.y=U,v.z=L*Math.sin(W),b.push(v.x,v.y,v.z),_.copy(v).normalize(),R.push(_.x,_.y,_.z),y.push(z+N,1-P),C.push(d++)}g.push(C)}for(let M=0;M<a;M++)for(let C=0;C<n;C++){const P=g[M][C+1],E=g[M][C],U=g[M+1][C],L=g[M+1][C+1];(M!==0||u>0)&&x.push(P,E,L),(M!==a-1||p<Math.PI)&&x.push(E,U,L)}this.setIndex(x),this.setAttribute("position",new ae(b,3)),this.setAttribute("normal",new ae(R,3)),this.setAttribute("uv",new ae(y,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new Wu(t.radius,t.widthSegments,t.heightSegments,t.phiStart,t.phiLength,t.thetaStart,t.thetaLength)}}class tr extends Ie{constructor(t=1,n=.4,a=12,o=48,c=Math.PI*2,u=0,h=Math.PI*2){super(),this.type="TorusGeometry",this.parameters={radius:t,tube:n,radialSegments:a,tubularSegments:o,arc:c,thetaStart:u,thetaLength:h},a=Math.floor(a),o=Math.floor(o);const p=[],d=[],g=[],v=[],_=new B,x=new B,b=new B;for(let R=0;R<=a;R++){const y=u+R/a*h;for(let M=0;M<=o;M++){const C=M/o*c;x.x=(t+n*Math.cos(y))*Math.cos(C),x.y=(t+n*Math.cos(y))*Math.sin(C),x.z=n*Math.sin(y),d.push(x.x,x.y,x.z),_.x=t*Math.cos(C),_.y=t*Math.sin(C),b.subVectors(x,_).normalize(),g.push(b.x,b.y,b.z),v.push(M/o),v.push(R/a)}}for(let R=1;R<=a;R++)for(let y=1;y<=o;y++){const M=(o+1)*R+y-1,C=(o+1)*(R-1)+y-1,P=(o+1)*(R-1)+y,E=(o+1)*R+y;p.push(M,C,E),p.push(C,P,E)}this.setIndex(p),this.setAttribute("position",new ae(d,3)),this.setAttribute("normal",new ae(g,3)),this.setAttribute("uv",new ae(v,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new tr(t.radius,t.tube,t.radialSegments,t.tubularSegments,t.arc,t.thetaStart,t.thetaLength)}}class zl extends Ie{constructor(t=new sM(new B(-1,-1,0),new B(-1,1,0),new B(1,1,0)),n=64,a=1,o=8,c=!1){super(),this.type="TubeGeometry",this.parameters={path:t,tubularSegments:n,radius:a,radialSegments:o,closed:c};const u=t.computeFrenetFrames(n,c);this.tangents=u.tangents,this.normals=u.normals,this.binormals=u.binormals;const h=new B,p=new B,d=new Ot;let g=new B;const v=[],_=[],x=[],b=[];R(),this.setIndex(b),this.setAttribute("position",new ae(v,3)),this.setAttribute("normal",new ae(_,3)),this.setAttribute("uv",new ae(x,2));function R(){for(let P=0;P<n;P++)y(P);y(c===!1?n:0),C(),M()}function y(P){g=t.getPointAt(P/n,g);const E=u.normals[P],U=u.binormals[P];for(let L=0;L<=o;L++){const N=L/o*Math.PI*2,T=Math.sin(N),z=-Math.cos(N);p.x=z*E.x+T*U.x,p.y=z*E.y+T*U.y,p.z=z*E.z+T*U.z,p.normalize(),_.push(p.x,p.y,p.z),h.x=g.x+a*p.x,h.y=g.y+a*p.y,h.z=g.z+a*p.z,v.push(h.x,h.y,h.z)}}function M(){for(let P=1;P<=n;P++)for(let E=1;E<=o;E++){const U=(o+1)*(P-1)+(E-1),L=(o+1)*P+(E-1),N=(o+1)*P+E,T=(o+1)*(P-1)+E;b.push(U,L,T),b.push(L,N,T)}}function C(){for(let P=0;P<=n;P++)for(let E=0;E<=o;E++)d.x=P/n,d.y=E/o,x.push(d.x,d.y)}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}toJSON(){const t=super.toJSON();return t.path=this.parameters.path.toJSON(),t}static fromJSON(t){return new zl(new Np[t.path.type]().fromJSON(t.path),t.tubularSegments,t.radius,t.radialSegments,t.closed)}}function go(s){const t={};for(const n in s){t[n]={};for(const a in s[n]){const o=s[n][a];if(B_(o))o.isRenderTargetTexture?(ye("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),t[n][a]=null):t[n][a]=o.clone();else if(Array.isArray(o))if(B_(o[0])){const c=[];for(let u=0,h=o.length;u<h;u++)c[u]=o[u].clone();t[n][a]=c}else t[n][a]=o.slice();else t[n][a]=o}}return t}function gi(s){const t={};for(let n=0;n<s.length;n++){const a=go(s[n]);for(const o in a)t[o]=a[o]}return t}function B_(s){return s&&(s.isColor||s.isMatrix3||s.isMatrix4||s.isVector2||s.isVector3||s.isVector4||s.isTexture||s.isQuaternion)}function Nb(s){const t=[];for(let n=0;n<s.length;n++)t.push(s[n].clone());return t}function fM(s){const t=s.getRenderTarget();return t===null?s.outputColorSpace:t.isXRRenderTarget===!0?t.texture.colorSpace:qe.workingColorSpace}const Ob={clone:go,merge:gi};var Pb=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,zb=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class ui extends hr{constructor(t){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=Pb,this.fragmentShader=zb,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,t!==void 0&&this.setValues(t)}copy(t){return super.copy(t),this.fragmentShader=t.fragmentShader,this.vertexShader=t.vertexShader,this.uniforms=go(t.uniforms),this.uniformsGroups=Nb(t.uniformsGroups),this.defines=Object.assign({},t.defines),this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.fog=t.fog,this.lights=t.lights,this.clipping=t.clipping,this.extensions=Object.assign({},t.extensions),this.glslVersion=t.glslVersion,this.defaultAttributeValues=Object.assign({},t.defaultAttributeValues),this.index0AttributeName=t.index0AttributeName,this.uniformsNeedUpdate=t.uniformsNeedUpdate,this}toJSON(t){const n=super.toJSON(t);n.glslVersion=this.glslVersion,n.uniforms={};for(const o in this.uniforms){const u=this.uniforms[o].value;u&&u.isTexture?n.uniforms[o]={type:"t",value:u.toJSON(t).uuid}:u&&u.isColor?n.uniforms[o]={type:"c",value:u.getHex()}:u&&u.isVector2?n.uniforms[o]={type:"v2",value:u.toArray()}:u&&u.isVector3?n.uniforms[o]={type:"v3",value:u.toArray()}:u&&u.isVector4?n.uniforms[o]={type:"v4",value:u.toArray()}:u&&u.isMatrix3?n.uniforms[o]={type:"m3",value:u.toArray()}:u&&u.isMatrix4?n.uniforms[o]={type:"m4",value:u.toArray()}:n.uniforms[o]={value:u}}Object.keys(this.defines).length>0&&(n.defines=this.defines),n.vertexShader=this.vertexShader,n.fragmentShader=this.fragmentShader,n.lights=this.lights,n.clipping=this.clipping;const a={};for(const o in this.extensions)this.extensions[o]===!0&&(a[o]=!0);return Object.keys(a).length>0&&(n.extensions=a),n}fromJSON(t,n){if(super.fromJSON(t,n),t.uniforms!==void 0)for(const a in t.uniforms){const o=t.uniforms[a];switch(this.uniforms[a]={},o.type){case"t":this.uniforms[a].value=n[o.value]||null;break;case"c":this.uniforms[a].value=new ce().setHex(o.value);break;case"v2":this.uniforms[a].value=new Ot().fromArray(o.value);break;case"v3":this.uniforms[a].value=new B().fromArray(o.value);break;case"v4":this.uniforms[a].value=new _n().fromArray(o.value);break;case"m3":this.uniforms[a].value=new we().fromArray(o.value);break;case"m4":this.uniforms[a].value=new ln().fromArray(o.value);break;default:this.uniforms[a].value=o.value}}if(t.defines!==void 0&&(this.defines=t.defines),t.vertexShader!==void 0&&(this.vertexShader=t.vertexShader),t.fragmentShader!==void 0&&(this.fragmentShader=t.fragmentShader),t.glslVersion!==void 0&&(this.glslVersion=t.glslVersion),t.extensions!==void 0)for(const a in t.extensions)this.extensions[a]=t.extensions[a];return t.lights!==void 0&&(this.lights=t.lights),t.clipping!==void 0&&(this.clipping=t.clipping),this}}class Ib extends ui{constructor(t){super(t),this.isRawShaderMaterial=!0,this.type="RawShaderMaterial"}}class ge extends hr{constructor(t){super(),this.isMeshStandardMaterial=!0,this.type="MeshStandardMaterial",this.defines={STANDARD:""},this.color=new ce(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new ce(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=Up,this.normalScale=new Ot(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Ja,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.defines={STANDARD:""},this.color.copy(t.color),this.roughness=t.roughness,this.metalness=t.metalness,this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.emissive.copy(t.emissive),this.emissiveMap=t.emissiveMap,this.emissiveIntensity=t.emissiveIntensity,this.bumpMap=t.bumpMap,this.bumpScale=t.bumpScale,this.normalMap=t.normalMap,this.normalMapType=t.normalMapType,this.normalScale.copy(t.normalScale),this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.roughnessMap=t.roughnessMap,this.metalnessMap=t.metalnessMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapRotation.copy(t.envMapRotation),this.envMapIntensity=t.envMapIntensity,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.flatShading=t.flatShading,this.fog=t.fog,this}}class Il extends ge{constructor(t){super(),this.isMeshPhysicalMaterial=!0,this.defines={STANDARD:"",PHYSICAL:""},this.type="MeshPhysicalMaterial",this.anisotropyRotation=0,this.anisotropyMap=null,this.clearcoatMap=null,this.clearcoatRoughness=0,this.clearcoatRoughnessMap=null,this.clearcoatNormalScale=new Ot(1,1),this.clearcoatNormalMap=null,this.ior=1.5,Object.defineProperty(this,"reflectivity",{get:function(){return ze(2.5*(this.ior-1)/(this.ior+1),0,1)},set:function(n){this.ior=(1+.4*n)/(1-.4*n)}}),this.iridescenceMap=null,this.iridescenceIOR=1.3,this.iridescenceThicknessRange=[100,400],this.iridescenceThicknessMap=null,this.sheenColor=new ce(0),this.sheenColorMap=null,this.sheenRoughness=1,this.sheenRoughnessMap=null,this.transmissionMap=null,this.thickness=0,this.thicknessMap=null,this.attenuationDistance=1/0,this.attenuationColor=new ce(1,1,1),this.specularIntensity=1,this.specularIntensityMap=null,this.specularColor=new ce(1,1,1),this.specularColorMap=null,this._anisotropy=0,this._clearcoat=0,this._dispersion=0,this._iridescence=0,this._retroreflectivity=0,this._sheen=0,this._transmission=0,this.setValues(t)}get anisotropy(){return this._anisotropy}set anisotropy(t){this._anisotropy>0!=t>0&&this.version++,this._anisotropy=t}get clearcoat(){return this._clearcoat}set clearcoat(t){this._clearcoat>0!=t>0&&this.version++,this._clearcoat=t}get iridescence(){return this._iridescence}set iridescence(t){this._iridescence>0!=t>0&&this.version++,this._iridescence=t}get dispersion(){return this._dispersion}set dispersion(t){this._dispersion>0!=t>0&&this.version++,this._dispersion=t}get retroreflectivity(){return this._retroreflectivity}set retroreflectivity(t){this._retroreflectivity>0!=t>0&&this.version++,this._retroreflectivity=t}get sheen(){return this._sheen}set sheen(t){this._sheen>0!=t>0&&this.version++,this._sheen=t}get transmission(){return this._transmission}set transmission(t){this._transmission>0!=t>0&&this.version++,this._transmission=t}copy(t){return super.copy(t),this.defines={STANDARD:"",PHYSICAL:""},this.anisotropy=t.anisotropy,this.anisotropyRotation=t.anisotropyRotation,this.anisotropyMap=t.anisotropyMap,this.clearcoat=t.clearcoat,this.clearcoatMap=t.clearcoatMap,this.clearcoatRoughness=t.clearcoatRoughness,this.clearcoatRoughnessMap=t.clearcoatRoughnessMap,this.clearcoatNormalMap=t.clearcoatNormalMap,this.clearcoatNormalScale.copy(t.clearcoatNormalScale),this.dispersion=t.dispersion,this.ior=t.ior,this.iridescence=t.iridescence,this.iridescenceMap=t.iridescenceMap,this.iridescenceIOR=t.iridescenceIOR,this.iridescenceThicknessRange=[...t.iridescenceThicknessRange],this.iridescenceThicknessMap=t.iridescenceThicknessMap,this.retroreflectivity=t.retroreflectivity,this.sheen=t.sheen,this.sheenColor.copy(t.sheenColor),this.sheenColorMap=t.sheenColorMap,this.sheenRoughness=t.sheenRoughness,this.sheenRoughnessMap=t.sheenRoughnessMap,this.transmission=t.transmission,this.transmissionMap=t.transmissionMap,this.thickness=t.thickness,this.thicknessMap=t.thicknessMap,this.attenuationDistance=t.attenuationDistance,this.attenuationColor.copy(t.attenuationColor),this.specularIntensity=t.specularIntensity,this.specularIntensityMap=t.specularIntensityMap,this.specularColor.copy(t.specularColor),this.specularColorMap=t.specularColorMap,this}}class Bb extends hr{constructor(t){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=n1,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(t)}copy(t){return super.copy(t),this.depthPacking=t.depthPacking,this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this}}class Fb extends hr{constructor(t){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(t)}copy(t){return super.copy(t),this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this}}class lm extends An{constructor(t,n=1){super(),this.isLight=!0,this.type="Light",this.color=new ce(t),this.intensity=n}copy(t,n){return super.copy(t,n),this.color.copy(t.color),this.intensity=t.intensity,this}toJSON(t){const n=super.toJSON(t);return n.object.color=this.color.getHex(),n.object.intensity=this.intensity,n}}class qu extends lm{constructor(t,n,a){super(t,a),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(An.DEFAULT_UP),this.updateMatrix(),this.groundColor=new ce(n)}copy(t,n){return super.copy(t,n),this.groundColor.copy(t.groundColor),this}toJSON(t){const n=super.toJSON(t);return n.object.groundColor=this.groundColor.getHex(),n}}const Ud=new ln,F_=new B,H_=new B;class hM{constructor(t){this.camera=t,this.intensity=1,this.bias=0,this.biasNode=null,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new Ot(512,512),this.mapType=Ti,this.map=null,this.mapPass=null,this.matrix=new ln,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new im,this._frameExtents=new Ot(1,1),this._viewportCount=1,this._viewports=[new _n(0,0,1,1)]}getViewportCount(){return this._viewportCount}getCamera(){return this.camera}getFrustum(){return this._frustum}updateMatrices(t){const n=this.camera;F_.setFromMatrixPosition(t.matrixWorld),n.position.copy(F_),H_.setFromMatrixPosition(t.target.matrixWorld),n.lookAt(H_),n.updateMatrixWorld(),this._updateMatrix(n,this.matrix,this._frustum)}_updateMatrix(t,n,a,o){Ud.multiplyMatrices(t.projectionMatrix,t.matrixWorldInverse),a.setFromProjectionMatrix(Ud,t.coordinateSystem,t.reversedDepth);const c=this._frameExtents,u=o?o.z/c.x:1,h=o?o.w/c.y:1,p=o?o.x/c.x:0,d=o?o.y/c.y:0;t.coordinateSystem===Ul||t.reversedDepth?n.set(.5*u,0,0,.5*u+p,0,.5*h,0,.5*h+d,0,0,1,0,0,0,0,1):n.set(.5*u,0,0,.5*u+p,0,.5*h,0,.5*h+d,0,0,.5,.5,0,0,0,1),n.multiply(Ud)}getViewport(t){return this._viewports[t]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(t){return this.camera=t.camera.clone(),this.intensity=t.intensity,this.bias=t.bias,this.radius=t.radius,this.autoUpdate=t.autoUpdate,this.needsUpdate=t.needsUpdate,this.normalBias=t.normalBias,this.blurSamples=t.blurSamples,this.mapSize.copy(t.mapSize),this.biasNode=t.biasNode,this}clone(){return new this.constructor().copy(this)}toJSON(){const t={};return t.intensity=this.intensity,t.bias=this.bias,t.normalBias=this.normalBias,t.radius=this.radius,t.blurSamples=this.blurSamples,t.mapSize=this.mapSize.toArray(),t.camera=this.camera.toJSON(!1).object,delete t.camera.matrix,t}}const Mu=new B,yu=new Ei,ma=new B;class dM extends An{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new ln,this.projectionMatrix=new ln,this.projectionMatrixInverse=new ln,this.coordinateSystem=_a,this._reversedDepth=!1}get reversedDepth(){return this._reversedDepth}copy(t,n){return super.copy(t,n),this.matrixWorldInverse.copy(t.matrixWorldInverse),this.projectionMatrix.copy(t.projectionMatrix),this.projectionMatrixInverse.copy(t.projectionMatrixInverse),this.coordinateSystem=t.coordinateSystem,this}getWorldDirection(t){return super.getWorldDirection(t).negate()}updateMatrixWorld(t){super.updateMatrixWorld(t),this.matrixWorld.decompose(Mu,yu,ma),ma.x===1&&ma.y===1&&ma.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(Mu,yu,ma.set(1,1,1)).invert()}updateWorldMatrix(t,n,a=!1){super.updateWorldMatrix(t,n,a),this.matrixWorld.decompose(Mu,yu,ma),ma.x===1&&ma.y===1&&ma.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(Mu,yu,ma.set(1,1,1)).invert()}clone(){return new this.constructor().copy(this)}}const ws=new B,G_=new Ot,V_=new Ot;class zi extends dM{constructor(t=50,n=1,a=.1,o=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=t,this.zoom=1,this.near=a,this.far=o,this.focus=10,this.aspect=n,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(t,n){return super.copy(t,n),this.fov=t.fov,this.zoom=t.zoom,this.near=t.near,this.far=t.far,this.focus=t.focus,this.aspect=t.aspect,this.view=t.view===null?null:Object.assign({},t.view),this.filmGauge=t.filmGauge,this.filmOffset=t.filmOffset,this}setFocalLength(t){const n=.5*this.getFilmHeight()/t;this.fov=Ll*2*Math.atan(n),this.updateProjectionMatrix()}getFocalLength(){const t=Math.tan(bl*.5*this.fov);return .5*this.getFilmHeight()/t}getEffectiveFOV(){return Ll*2*Math.atan(Math.tan(bl*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(t,n,a){ws.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),n.set(ws.x,ws.y).multiplyScalar(-t/ws.z),ws.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),a.set(ws.x,ws.y).multiplyScalar(-t/ws.z)}getViewSize(t,n){return this.getViewBounds(t,G_,V_),n.subVectors(V_,G_)}setViewOffset(t,n,a,o,c,u){this.aspect=t/n,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=n,this.view.offsetX=a,this.view.offsetY=o,this.view.width=c,this.view.height=u,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const t=this.near;let n=t*Math.tan(bl*.5*this.fov)/this.zoom,a=2*n,o=this.aspect*a,c=-.5*o;const u=this.view;if(this.view!==null&&this.view.enabled){const p=u.fullWidth,d=u.fullHeight;c+=u.offsetX*o/p,n-=u.offsetY*a/d,o*=u.width/p,a*=u.height/d}const h=this.filmOffset;h!==0&&(c+=t*h/this.getFilmWidth()),this.projectionMatrix.makePerspective(c,c+o,n,n-a,t,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){const n=super.toJSON(t);return n.object.fov=this.fov,n.object.zoom=this.zoom,n.object.near=this.near,n.object.far=this.far,n.object.focus=this.focus,n.object.aspect=this.aspect,this.view!==null&&(n.object.view=Object.assign({},this.view)),n.object.filmGauge=this.filmGauge,n.object.filmOffset=this.filmOffset,n}}class Hb extends hM{constructor(){super(new zi(90,1,.5,500)),this.isPointLightShadow=!0}}class Bl extends lm{constructor(t,n,a=0,o=2){super(t,n),this.isPointLight=!0,this.type="PointLight",this.distance=a,this.decay=o,this.shadow=new Hb}get power(){return this.intensity*4*Math.PI}set power(t){this.intensity=t/(4*Math.PI)}dispose(){super.dispose(),this.shadow.dispose()}copy(t,n){return super.copy(t,n),this.distance=t.distance,this.decay=t.decay,this.shadow=t.shadow.clone(),this}toJSON(t){const n=super.toJSON(t);return n.object.distance=this.distance,n.object.decay=this.decay,n.object.shadow=this.shadow.toJSON(),n}}class cm extends dM{constructor(t=-1,n=1,a=1,o=-1,c=.1,u=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=t,this.right=n,this.top=a,this.bottom=o,this.near=c,this.far=u,this.updateProjectionMatrix()}copy(t,n){return super.copy(t,n),this.left=t.left,this.right=t.right,this.top=t.top,this.bottom=t.bottom,this.near=t.near,this.far=t.far,this.zoom=t.zoom,this.view=t.view===null?null:Object.assign({},t.view),this}setViewOffset(t,n,a,o,c,u){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=n,this.view.offsetX=a,this.view.offsetY=o,this.view.width=c,this.view.height=u,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const t=(this.right-this.left)/(2*this.zoom),n=(this.top-this.bottom)/(2*this.zoom),a=(this.right+this.left)/2,o=(this.top+this.bottom)/2;let c=a-t,u=a+t,h=o+n,p=o-n;if(this.view!==null&&this.view.enabled){const d=(this.right-this.left)/this.view.fullWidth/this.zoom,g=(this.top-this.bottom)/this.view.fullHeight/this.zoom;c+=d*this.view.offsetX,u=c+d*this.view.width,h-=g*this.view.offsetY,p=h-g*this.view.height}this.projectionMatrix.makeOrthographic(c,u,h,p,this.near,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){const n=super.toJSON(t);return n.object.zoom=this.zoom,n.object.left=this.left,n.object.right=this.right,n.object.top=this.top,n.object.bottom=this.bottom,n.object.near=this.near,n.object.far=this.far,this.view!==null&&(n.object.view=Object.assign({},this.view)),n}}class Gb extends hM{constructor(){super(new cm(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}}class Yu extends lm{constructor(t,n){super(t,n),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(An.DEFAULT_UP),this.updateMatrix(),this.target=new An,this.shadow=new Gb}dispose(){super.dispose(),this.shadow.dispose()}copy(t){return super.copy(t),this.target=t.target.clone(),this.shadow=t.shadow.clone(),this}toJSON(t){const n=super.toJSON(t);return n.object.shadow=this.shadow.toJSON(),n.object.target=this.target.uuid,n}}const no=-90,io=1;class Vb extends An{constructor(t,n,a){super(),this.type="CubeCamera",this.renderTarget=a,this.coordinateSystem=null,this.activeMipmapLevel=0;const o=new zi(no,io,t,n);o.layers=this.layers,this.add(o);const c=new zi(no,io,t,n);c.layers=this.layers,this.add(c);const u=new zi(no,io,t,n);u.layers=this.layers,this.add(u);const h=new zi(no,io,t,n);h.layers=this.layers,this.add(h);const p=new zi(no,io,t,n);p.layers=this.layers,this.add(p);const d=new zi(no,io,t,n);d.layers=this.layers,this.add(d)}updateCoordinateSystem(){const t=this.coordinateSystem,n=this.children.concat(),[a,o,c,u,h,p]=n;for(const d of n)this.remove(d);if(t===_a)a.up.set(0,1,0),a.lookAt(1,0,0),o.up.set(0,1,0),o.lookAt(-1,0,0),c.up.set(0,0,-1),c.lookAt(0,1,0),u.up.set(0,0,1),u.lookAt(0,-1,0),h.up.set(0,1,0),h.lookAt(0,0,1),p.up.set(0,1,0),p.lookAt(0,0,-1);else if(t===Ul)a.up.set(0,-1,0),a.lookAt(-1,0,0),o.up.set(0,-1,0),o.lookAt(1,0,0),c.up.set(0,0,1),c.lookAt(0,1,0),u.up.set(0,0,-1),u.lookAt(0,-1,0),h.up.set(0,-1,0),h.lookAt(0,0,1),p.up.set(0,-1,0),p.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+t);for(const d of n)this.add(d),d.updateMatrixWorld()}update(t,n){this.parent===null&&this.updateMatrixWorld();const{renderTarget:a,activeMipmapLevel:o}=this;this.coordinateSystem!==t.coordinateSystem&&(this.coordinateSystem=t.coordinateSystem,this.updateCoordinateSystem());const[c,u,h,p,d,g]=this.children,v=t.getRenderTarget(),_=t.getActiveCubeFace(),x=t.getActiveMipmapLevel(),b=t.xr.enabled;t.xr.enabled=!1;const R=a.texture.generateMipmaps;a.texture.generateMipmaps=!1;let y=!1;t.isWebGLRenderer===!0?y=t.state.buffers.depth.getReversed():y=t.reversedDepthBuffer,t.setRenderTarget(a,0,o),y&&t.autoClear===!1&&t.clearDepth(),t.render(n,c),t.setRenderTarget(a,1,o),y&&t.autoClear===!1&&t.clearDepth(),t.render(n,u),t.setRenderTarget(a,2,o),y&&t.autoClear===!1&&t.clearDepth(),t.render(n,h),t.setRenderTarget(a,3,o),y&&t.autoClear===!1&&t.clearDepth(),t.render(n,p),t.setRenderTarget(a,4,o),y&&t.autoClear===!1&&t.clearDepth(),t.render(n,d),a.texture.generateMipmaps=R,t.setRenderTarget(a,5,o),y&&t.autoClear===!1&&t.clearDepth(),t.render(n,g),t.setRenderTarget(v,_,x),t.xr.enabled=b,a.texture.needsPMREMUpdate=!0}}class kb extends zi{constructor(t=[]){super(),this.isArrayCamera=!0,this.isMultiViewCamera=!1,this.cameras=t}}const k_=new ln;class Zu{constructor(t,n,a=0,o=1/0){this.ray=new ku(t,n),this.near=a,this.far=o,this.camera=null,this.layers=new nm,this.params={Mesh:{},Line:{threshold:1},LOD:{},Points:{threshold:1},Sprite:{}}}set(t,n){this.ray.set(t,n)}setFromCamera(t,n){n.isPerspectiveCamera?(this.ray.origin.setFromMatrixPosition(n.matrixWorld),this.ray.direction.set(t.x,t.y,.5).unproject(n).sub(this.ray.origin).normalize(),this.camera=n):n.isOrthographicCamera?(this.ray.origin.set(t.x,t.y,n.projectionMatrix.elements[14]).unproject(n),this.ray.direction.set(0,0,-1).transformDirection(n.matrixWorld),this.camera=n):Je("Raycaster: Unsupported camera type: "+n.type)}setFromXRController(t){return k_.identity().extractRotation(t.matrixWorld),this.ray.origin.setFromMatrixPosition(t.matrixWorld),this.ray.direction.set(0,0,-1).applyMatrix4(k_),this}intersectObject(t,n=!0,a=[]){return Ip(t,this,a,n),a.sort(X_),a}intersectObjects(t,n=!0,a=[]){for(let o=0,c=t.length;o<c;o++)Ip(t[o],this,a,n);return a.sort(X_),a}}function X_(s,t){return s.distance-t.distance}function Ip(s,t,n,a){let o=!0;if(s.layers.test(t.layers)&&s.raycast(t,n)===!1&&(o=!1),o===!0&&a===!0){const c=s.children;for(let u=0,h=c.length;u<h;u++)Ip(c[u],t,n,!0)}}const xm=class xm{constructor(t,n,a,o){this.elements=[1,0,0,1],t!==void 0&&this.set(t,n,a,o)}identity(){return this.set(1,0,0,1),this}fromArray(t,n=0){for(let a=0;a<4;a++)this.elements[a]=t[a+n];return this}set(t,n,a,o){const c=this.elements;return c[0]=t,c[2]=n,c[1]=a,c[3]=o,this}};xm.prototype.isMatrix2=!0;let W_=xm;function q_(s,t,n,a){const o=Xb(a);switch(n){case Xx:return s*t;case Jp:return s*t/o.components*o.byteLength;case Qp:return s*t/o.components*o.byteLength;case ir:return s*t*2/o.components*o.byteLength;case jp:return s*t*2/o.components*o.byteLength;case Wx:return s*t*3/o.components*o.byteLength;case Qi:return s*t*4/o.components*o.byteLength;case $p:return s*t*4/o.components*o.byteLength;case Eu:case Tu:return Math.floor((s+3)/4)*Math.floor((t+3)/4)*8;case Au:case wu:return Math.floor((s+3)/4)*Math.floor((t+3)/4)*16;case np:case ap:return Math.max(s,16)*Math.max(t,8)/4;case ep:case ip:return Math.max(s,8)*Math.max(t,8)/2;case sp:case rp:case lp:case cp:return Math.floor((s+3)/4)*Math.floor((t+3)/4)*8;case op:case Du:case up:return Math.floor((s+3)/4)*Math.floor((t+3)/4)*16;case fp:return Math.floor((s+3)/4)*Math.floor((t+3)/4)*16;case hp:return Math.floor((s+4)/5)*Math.floor((t+3)/4)*16;case dp:return Math.floor((s+4)/5)*Math.floor((t+4)/5)*16;case pp:return Math.floor((s+5)/6)*Math.floor((t+4)/5)*16;case mp:return Math.floor((s+5)/6)*Math.floor((t+5)/6)*16;case gp:return Math.floor((s+7)/8)*Math.floor((t+4)/5)*16;case vp:return Math.floor((s+7)/8)*Math.floor((t+5)/6)*16;case _p:return Math.floor((s+7)/8)*Math.floor((t+7)/8)*16;case xp:return Math.floor((s+9)/10)*Math.floor((t+4)/5)*16;case Mp:return Math.floor((s+9)/10)*Math.floor((t+5)/6)*16;case yp:return Math.floor((s+9)/10)*Math.floor((t+7)/8)*16;case Sp:return Math.floor((s+9)/10)*Math.floor((t+9)/10)*16;case bp:return Math.floor((s+11)/12)*Math.floor((t+9)/10)*16;case Ep:return Math.floor((s+11)/12)*Math.floor((t+11)/12)*16;case Tp:case Ap:case wp:return Math.ceil(s/4)*Math.ceil(t/4)*16;case Rp:case Cp:return Math.ceil(s/4)*Math.ceil(t/4)*8;case Uu:case Dp:return Math.ceil(s/4)*Math.ceil(t/4)*16}throw new Error(`Unable to determine texture byte length for ${n} format.`)}function Xb(s){switch(s){case Ti:case Hx:return{byteLength:1,components:1};case Cl:case Gx:case ji:return{byteLength:2,components:1};case Zp:case Kp:return{byteLength:2,components:4};case la:case Yp:case oa:return{byteLength:4,components:1};case Vx:case kx:return{byteLength:4,components:3}}throw new Error(`THREE.TextureUtils: Unknown texture type ${s}.`)}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:Xp}}));typeof window<"u"&&(window.__THREE__?ye("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=Xp);/**
 * @license
 * Copyright 2010-2026 Three.js Authors
 * SPDX-License-Identifier: MIT
 */function pM(){let s=null,t=!1,n=null,a=null;function o(c,u){a=s.requestAnimationFrame(o),n(c,u)}return{start:function(){t!==!0&&n!==null&&s!==null&&(a=s.requestAnimationFrame(o),t=!0)},stop:function(){s!==null&&s.cancelAnimationFrame(a),t=!1},setAnimationLoop:function(c){n=c},setContext:function(c){s=c}}}function Wb(s){const t=new WeakMap;function n(h,p){const d=h.array,g=h.usage,v=d.byteLength,_=s.createBuffer();s.bindBuffer(p,_),s.bufferData(p,d,g),h.onUploadCallback();let x;if(d instanceof Float32Array)x=s.FLOAT;else if(typeof Float16Array<"u"&&d instanceof Float16Array)x=s.HALF_FLOAT;else if(d instanceof Uint16Array)h.isFloat16BufferAttribute?x=s.HALF_FLOAT:x=s.UNSIGNED_SHORT;else if(d instanceof Int16Array)x=s.SHORT;else if(d instanceof Uint32Array)x=s.UNSIGNED_INT;else if(d instanceof Int32Array)x=s.INT;else if(d instanceof Int8Array)x=s.BYTE;else if(d instanceof Uint8Array)x=s.UNSIGNED_BYTE;else if(d instanceof Uint8ClampedArray)x=s.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+d);return{buffer:_,type:x,bytesPerElement:d.BYTES_PER_ELEMENT,version:h.version,size:v}}function a(h,p,d){const g=p.array,v=p.updateRanges;if(s.bindBuffer(d,h),v.length===0)s.bufferSubData(d,0,g);else{v.sort((x,b)=>x.start-b.start);let _=0;for(let x=1;x<v.length;x++){const b=v[_],R=v[x];R.start<=b.start+b.count+1?b.count=Math.max(b.count,R.start+R.count-b.start):(++_,v[_]=R)}v.length=_+1;for(let x=0,b=v.length;x<b;x++){const R=v[x];s.bufferSubData(d,R.start*g.BYTES_PER_ELEMENT,g,R.start,R.count)}p.clearUpdateRanges()}p.onUploadCallback()}function o(h){return h.isInterleavedBufferAttribute&&(h=h.data),t.get(h)}function c(h){h.isInterleavedBufferAttribute&&(h=h.data);const p=t.get(h);p&&(s.deleteBuffer(p.buffer),t.delete(h))}function u(h,p){if(h.isInterleavedBufferAttribute&&(h=h.data),h.isGLBufferAttribute){const g=t.get(h);(!g||g.version<h.version)&&t.set(h,{buffer:h.buffer,type:h.type,bytesPerElement:h.elementSize,version:h.version});return}const d=t.get(h);if(d===void 0)t.set(h,n(h,p));else if(d.version<h.version){if(d.size!==h.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");a(d.buffer,h,p),d.version=h.version}}return{get:o,remove:c,update:u}}var qb=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,Yb=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,Zb=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,Kb=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Jb=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,Qb=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,jb=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,$b=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,tE=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec4 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 );
	}
#endif`,eE=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,nE=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,iE=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,aE=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,sE=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,rE=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,oE=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,lE=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,cE=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,uE=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,fE=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#endif`,hE=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#endif`,dE=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec4 vColor;
#endif`,pE=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec4( 1.0 );
#endif
#ifdef USE_COLOR_ALPHA
	vColor *= color;
#elif defined( USE_COLOR )
	vColor.rgb *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.rgb *= instanceColor.rgb;
#endif
#ifdef USE_BATCHING_COLOR
	vColor *= getBatchingColor( getIndirectIndex( gl_DrawID ) );
#endif`,mE=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
#define inverseTransformDirection transformDirectionByInverseViewMatrix
vec3 transformNormalByInverseViewMatrix( in vec3 normal, in mat4 viewMatrix ) {
	return normalize( ( vec4( normal, 0.0 ) * viewMatrix ).xyz );
}
vec3 transformDirectionByInverseViewMatrix( in vec3 dir, in mat4 viewMatrix ) {
	return normalize( ( vec4( dir, 0.0 ) * viewMatrix ).xyz );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,gE=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,vE=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
#endif`,_E=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,xE=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,ME=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,yE=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,SE="gl_FragColor = linearToOutputTexel( gl_FragColor );",bE=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,EE=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * reflectVec );
		#ifdef ENVMAP_BLENDING_MULTIPLY
			outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_MIX )
			outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_ADD )
			outgoingLight += envColor.xyz * specularStrength * reflectivity;
		#endif
	#endif
#endif`,TE=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
#endif`,AE=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,wE=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,RE=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,CE=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,DE=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,UE=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,LE=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,NE=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,OE=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,PE=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,zE=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,IE=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_SUN_LIGHTS > 0
	struct SunLight {
		vec3 direction;
		vec3 color;
	};
	uniform SunLight sunLights[ NUM_SUN_LIGHTS ];
	void getSunLightInfo( const in SunLight sunLight, out IncidentLight light ) {
		light.color = sunLight.color;
		light.direction = sunLight.direction;
		light.visible = true;
	}
#endif
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif
#include <lightprobes_pars_fragment>`,BE=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, pow4( roughness ) ) );
			reflectVec = transformDirectionByInverseViewMatrix( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_RETROREFLECTION
		vec3 getIBLRetroRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 retroVec = normalize( mix( viewDir, normal, pow4( roughness ) ) );
				retroVec = transformDirectionByInverseViewMatrix( retroVec, viewMatrix );
				vec4 envMapColor = textureCubeUV( envMap, envMapRotation * retroVec, roughness );
				return envMapColor.rgb * envMapIntensity;
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
		#ifdef USE_RETROREFLECTION
			vec3 getIBLAnisotropyRetroRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
				#ifdef ENVMAP_TYPE_CUBE_UV
					vec3 bentNormal = cross( bitangent, viewDir );
					bentNormal = normalize( cross( bentNormal, bitangent ) );
					bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
					return getIBLRetroRadiance( viewDir, bentNormal, roughness );
				#else
					return vec3( 0.0 );
				#endif
			}
		#endif
	#endif
#endif`,FE=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,HE=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,GE=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,VE=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,kE=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.diffuseContribution = diffuseColor.rgb * ( 1.0 - metalnessFactor );
material.metalness = metalnessFactor;
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor;
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = vec3( 0.04 );
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_RETROREFLECTION
	material.retroreflectivity = retroreflectivity;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.0001, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,XE=`uniform sampler2D dfgLUT;
struct PhysicalMaterial {
	vec3 diffuseColor;
	vec3 diffuseContribution;
	vec3 specularColor;
	vec3 specularColorBlended;
	float roughness;
	float metalness;
	float specularF90;
	float dispersion;
	vec2 dfg;
	vec3 multiScatteringCompensation;
	#ifdef USE_RETROREFLECTION
		float retroreflectivity;
	#endif
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0Dielectric;
		vec3 iridescenceF0Metallic;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		return 0.5 / max( gv + gl, EPSILON );
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColorBlended;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transpose( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float rInv = 1.0 / ( roughness + 0.1 );
	float a = -1.9362 + 1.0678 * roughness + 0.4573 * r2 - 0.8469 * rInv;
	float b = -0.6014 + 0.5538 * roughness - 0.4670 * r2 - 0.1255 * rInv;
	float DG = exp( a * dotNV + b );
	return saturate( DG );
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec2 fab, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec2 fab, const in vec3 specularColor, const in float specularF90, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColorBlended * t2.x + ( material.specularF90 - material.specularColorBlended ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseContribution * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
		#ifdef USE_CLEARCOAT
			vec3 Ncc = geometryClearcoatNormal;
			vec2 uvClearcoat = LTC_Uv( Ncc, viewDir, material.clearcoatRoughness );
			vec4 t1Clearcoat = texture2D( ltc_1, uvClearcoat );
			vec4 t2Clearcoat = texture2D( ltc_2, uvClearcoat );
			mat3 mInvClearcoat = mat3(
				vec3( t1Clearcoat.x, 0, t1Clearcoat.y ),
				vec3(             0, 1,             0 ),
				vec3( t1Clearcoat.z, 0, t1Clearcoat.w )
			);
			vec3 fresnelClearcoat = material.clearcoatF0 * t2Clearcoat.x + ( material.clearcoatF90 - material.clearcoatF0 ) * t2Clearcoat.y;
			clearcoatSpecularDirect += lightColor * fresnelClearcoat * LTC_Evaluate( Ncc, viewDir, position, mInvClearcoat, rectCoords );
		#endif
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
 
 		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
 
 		float sheenAlbedoV = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
 		float sheenAlbedoL = IBLSheenBRDF( geometryNormal, directLight.direction, material.sheenRoughness );
 
 		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * max( sheenAlbedoV, sheenAlbedoL );
 
 		irradiance *= sheenEnergyComp;
 
 	#endif
	vec3 specularBRDF = BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	#ifdef USE_RETROREFLECTION
		vec3 retroViewDir = reflect( - geometryViewDir, geometryNormal );
		vec3 retroSpecularBRDF = BRDF_GGX( directLight.direction, retroViewDir, geometryNormal, material );
		specularBRDF = mix( specularBRDF, retroSpecularBRDF, saturate( material.retroreflectivity ) );
	#endif
	reflectedLight.directSpecular += irradiance * specularBRDF * material.multiScatteringCompensation;
	vec3 halfDir = normalize( directLight.direction + geometryViewDir );
	float dotVH = saturate( dot( geometryViewDir, halfDir ) );
	vec3 F = F_Schlick( material.specularColor, material.specularF90, dotVH );
	#ifdef USE_RETROREFLECTION
		vec3 retroHalfDir = normalize( directLight.direction + retroViewDir );
		float dotRetroVH = saturate( dot( retroViewDir, retroHalfDir ) );
		vec3 retroF = F_Schlick( material.specularColor, material.specularF90, dotRetroVH );
		F = mix( F, retroF, saturate( material.retroreflectivity ) );
	#endif
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseContribution ) * ( 1.0 - F );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( material.dfg, material.specularColor, material.specularF90, material.iridescence, material.iridescenceF0Dielectric, singleScattering, multiScattering );
	#else
		computeMultiscattering( material.dfg, material.specularColor, material.specularF90, singleScattering, multiScattering );
	#endif
	vec3 diffuse = irradiance * BRDF_Lambert( material.diffuseContribution ) * ( 1.0 - singleScattering - multiScattering );
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		sheenSpecularIndirect += irradiance * material.sheenColor * sheenAlbedo * RECIPROCAL_PI;
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		diffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectDiffuse += diffuse;
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness ) * RECIPROCAL_PI;
 	#endif
	vec3 singleScatteringDielectric = vec3( 0.0 );
	vec3 multiScatteringDielectric = vec3( 0.0 );
	vec3 singleScatteringMetallic = vec3( 0.0 );
	vec3 multiScatteringMetallic = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( material.dfg, material.specularColor, material.specularF90, material.iridescence, material.iridescenceF0Dielectric, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscatteringIridescence( material.dfg, material.diffuseColor, material.specularF90, material.iridescence, material.iridescenceF0Metallic, singleScatteringMetallic, multiScatteringMetallic );
	#else
		computeMultiscattering( material.dfg, material.specularColor, material.specularF90, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscattering( material.dfg, material.diffuseColor, material.specularF90, singleScatteringMetallic, multiScatteringMetallic );
	#endif
	vec3 singleScattering = mix( singleScatteringDielectric, singleScatteringMetallic, material.metalness );
	vec3 multiScattering = mix( multiScatteringDielectric, multiScatteringMetallic, material.metalness );
	vec3 totalScatteringDielectric = singleScatteringDielectric + multiScatteringDielectric;
	vec3 diffuse = material.diffuseContribution * ( 1.0 - totalScatteringDielectric );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	vec3 indirectSpecular = radiance * singleScattering;
	indirectSpecular += multiScattering * cosineWeightedIrradiance;
	vec3 indirectDiffuse = diffuse * cosineWeightedIrradiance;
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		indirectSpecular *= sheenEnergyComp;
		indirectDiffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectSpecular += indirectSpecular;
	reflectedLight.indirectDiffuse += indirectDiffuse;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,WE=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		vec3 iridescenceFresnelDielectric = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		vec3 iridescenceFresnelMetallic = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.diffuseColor );
		material.iridescenceFresnel = mix( iridescenceFresnelDielectric, iridescenceFresnelMetallic, material.metalness );
		material.iridescenceF0Dielectric = Schlick_to_F0( iridescenceFresnelDielectric, 1.0, dotNVi );
		material.iridescenceF0Metallic = Schlick_to_F0( iridescenceFresnelMetallic, 1.0, dotNVi );
	}
#endif
#ifdef STANDARD
	float dotNVms = saturate( dot( geometryNormal, geometryViewDir ) );
	material.dfg = texture2D( dfgLUT, vec2( material.roughness, dotNVms ) ).rg;
	#if ( NUM_SUN_LIGHTS > 0 || NUM_DIR_LIGHTS > 0 || NUM_POINT_LIGHTS > 0 || NUM_SPOT_LIGHTS > 0 )
		float EssMs = material.dfg.x + material.dfg.y;
		material.multiScatteringCompensation = 1.0 + material.specularColorBlended * ( 1.0 / EssMs - 1.0 );
	#endif
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS ) && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SUN_LIGHTS > 0 ) && defined( RE_Direct )
	SunLight sunLight;
	#if defined( USE_SHADOWMAP ) && NUM_SUN_LIGHT_SHADOWS > 0
	SunLightShadow sunLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SUN_LIGHTS; i ++ ) {
		sunLight = sunLights[ i ];
		getSunLightInfo( sunLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SUN_LIGHT_SHADOWS )
		sunLightShadow = sunLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getSunShadow( sunShadowMap[ i ], sunLightShadow, UNROLLED_LOOP_INDEX ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
	#ifdef USE_LIGHT_PROBES_GRID
		vec3 probeWorldPos = ( ( vec4( geometryPosition, 1.0 ) - viewMatrix[ 3 ] ) * viewMatrix ).xyz;
		vec3 probeWorldNormal = transformNormalByInverseViewMatrix( geometryNormal, viewMatrix );
		irradiance += getLightProbeGridIrradiance( probeWorldPos, probeWorldNormal );
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,qE=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( ENVMAP_TYPE_CUBE_UV )
		#if defined( STANDARD ) || defined( LAMBERT ) || defined( PHONG )
			iblIrradiance += getIBLIrradiance( geometryNormal );
		#endif
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		vec3 iblRadiance = getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		vec3 iblRadiance = getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_RETROREFLECTION
		#ifdef USE_ANISOTROPY
			vec3 retroIBLRadiance = getIBLAnisotropyRetroRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
		#else
			vec3 retroIBLRadiance = getIBLRetroRadiance( geometryViewDir, geometryNormal, material.roughness );
		#endif
		iblRadiance = mix( iblRadiance, retroIBLRadiance, saturate( material.retroreflectivity ) );
	#endif
	radiance += iblRadiance;
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,YE=`#if defined( RE_IndirectDiffuse )
	#if defined( LAMBERT ) || defined( PHONG )
		irradiance += iblIrradiance;
	#endif
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,ZE=`#ifdef USE_LIGHT_PROBES_GRID
uniform highp sampler3D probesSH;
uniform vec3 probesMin;
uniform vec3 probesMax;
uniform vec3 probesResolution;
vec3 getLightProbeGridIrradiance( vec3 worldPos, vec3 worldNormal ) {
	vec3 res = probesResolution;
	vec3 gridRange = probesMax - probesMin;
	vec3 resMinusOne = res - 1.0;
	vec3 probeSpacing = gridRange / resMinusOne;
	vec3 samplePos = worldPos + worldNormal * probeSpacing * 0.5;
	vec3 uvw = clamp( ( samplePos - probesMin ) / gridRange, 0.0, 1.0 );
	uvw = uvw * resMinusOne / res + 0.5 / res;
	float nz          = res.z;
	float paddedSlices = nz + 2.0;
	float atlasDepth  = 7.0 * paddedSlices;
	float uvZBase     = uvw.z * nz + 1.0;
	vec4 s0 = texture( probesSH, vec3( uvw.xy, ( uvZBase                       ) / atlasDepth ) );
	vec4 s1 = texture( probesSH, vec3( uvw.xy, ( uvZBase +       paddedSlices   ) / atlasDepth ) );
	vec4 s2 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 2.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s3 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 3.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s4 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 4.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s5 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 5.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s6 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 6.0 * paddedSlices   ) / atlasDepth ) );
	vec3 c0 = s0.xyz;
	vec3 c1 = vec3( s0.w, s1.xy );
	vec3 c2 = vec3( s1.zw, s2.x );
	vec3 c3 = s2.yzw;
	vec3 c4 = s3.xyz;
	vec3 c5 = vec3( s3.w, s4.xy );
	vec3 c6 = vec3( s4.zw, s5.x );
	vec3 c7 = s5.yzw;
	vec3 c8 = s6.xyz;
	float x = worldNormal.x, y = worldNormal.y, z = worldNormal.z;
	vec3 result = c0 * 0.886227;
	result += c1 * 2.0 * 0.511664 * y;
	result += c2 * 2.0 * 0.511664 * z;
	result += c3 * 2.0 * 0.511664 * x;
	result += c4 * 2.0 * 0.429043 * x * y;
	result += c5 * 2.0 * 0.429043 * y * z;
	result += c6 * ( 0.743125 * z * z - 0.247708 );
	result += c7 * 2.0 * 0.429043 * x * z;
	result += c8 * 0.429043 * ( x * x - y * y );
	return max( result, vec3( 0.0 ) );
}
#endif`,KE=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,JE=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,QE=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,jE=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,$E=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,tT=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,eT=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,nT=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,iT=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,aT=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,sT=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,rT=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,oT=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,lT=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,cT=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,uT=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#ifdef DOUBLE_SIDED
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#ifdef DOUBLE_SIDED
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,fT=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#if defined( USE_PACKED_NORMALMAP )
		mapN = vec3( mapN.xy, sqrt( saturate( 1.0 - dot( mapN.xy, mapN.xy ) ) ) );
	#endif
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,hT=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,dT=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,pT=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
		#ifdef FLIP_SIDED
			vBitangent = - vBitangent;
		#endif
	#endif
#endif`,mT=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,gT=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,vT=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,_T=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,xT=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,MT=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,yT=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	#ifdef USE_REVERSED_DEPTH_BUFFER
	
		return depth * ( far - near ) - far;
	#else
		return depth * ( near - far ) - near;
	#endif
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	
	#ifdef USE_REVERSED_DEPTH_BUFFER
		return ( near * far ) / ( ( near - far ) * depth - near );
	#else
		return ( near * far ) / ( ( far - near ) * depth - far );
	#endif
}`,ST=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,bT=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,ET=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,TT=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,AT=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,wT=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,RT=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
		#define SUN_LIGHT_CASCADES 2
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow sunShadowMap[ NUM_SUN_LIGHT_SHADOWS ];
		#else
			uniform sampler2D sunShadowMap[ NUM_SUN_LIGHT_SHADOWS ];
		#endif
		uniform mat4 sunShadowMatrix[ NUM_SUN_LIGHT_SHADOWS * SUN_LIGHT_CASCADES ];
		uniform vec4 sunShadowCascade[ NUM_SUN_LIGHT_SHADOWS * SUN_LIGHT_CASCADES ];
		varying vec4 vSunShadowWorldPosition;
		varying vec3 vSunShadowWorldNormal;
		struct SunLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SunLightShadow sunLightShadows[ NUM_SUN_LIGHT_SHADOWS ];
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#else
			uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#endif
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#else
			uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#endif
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform samplerCubeShadow pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#elif defined( SHADOWMAP_TYPE_BASIC )
			uniform samplerCube pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#endif
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float interleavedGradientNoise( vec2 position ) {
			return fract( 52.9829189 * fract( dot( position, vec2( 0.06711056, 0.00583715 ) ) ) );
		}
		vec2 vogelDiskSample( int sampleIndex, int samplesCount, float phi ) {
			const float goldenAngle = 2.399963229728653;
			float r = sqrt( ( float( sampleIndex ) + 0.5 ) / float( samplesCount ) );
			float theta = float( sampleIndex ) * goldenAngle + phi;
			return vec2( cos( theta ), sin( theta ) ) * r;
		}
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float getShadow( sampler2DShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			shadowCoord.z += shadowBias;
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
				float radius = shadowRadius * texelSize.x;
				float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
				shadow = (
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 0, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 1, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 2, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 3, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 4, 5, phi ) * radius, shadowCoord.z ) )
				) * 0.2;
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#elif defined( SHADOWMAP_TYPE_VSM )
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 distribution = texture2D( shadowMap, shadowCoord.xy ).rg;
				float mean = distribution.x;
				float variance = distribution.y * distribution.y;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					float hard_shadow = step( mean, shadowCoord.z );
				#else
					float hard_shadow = step( shadowCoord.z, mean );
				#endif
				
				if ( hard_shadow == 1.0 ) {
					shadow = 1.0;
				} else {
					variance = max( variance, 0.0000001 );
					float d = shadowCoord.z - mean;
					float p_max = variance / ( variance + d * d );
					p_max = clamp( ( p_max - 0.3 ) / 0.65, 0.0, 1.0 );
					shadow = max( hard_shadow, p_max );
				}
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#else
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				float depth = texture2D( shadowMap, shadowCoord.xy ).r;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					shadow = step( depth, shadowCoord.z );
				#else
					shadow = step( shadowCoord.z, depth );
				#endif
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#endif
	#if NUM_SUN_LIGHT_SHADOWS > 0
		float getSunShadow(
			#if defined( SHADOWMAP_TYPE_PCF )
				sampler2DShadow shadowMap,
			#else
				sampler2D shadowMap,
			#endif
			SunLightShadow sunLightShadow,
			int shadowIndex
		) {
			vec4 shadowWorldPosition = vec4( vSunShadowWorldPosition.xyz + vSunShadowWorldNormal * sunLightShadow.shadowNormalBias, 1.0 );
			float viewDepth = vSunShadowWorldPosition.w;
			int cascadeOffset = shadowIndex * SUN_LIGHT_CASCADES;
			float shadow = 1.0;
			for ( int i = SUN_LIGHT_CASCADES - 1; i >= 0; i -- ) {
				vec4 cascade = sunShadowCascade[ cascadeOffset + i ];
				if ( viewDepth >= cascade.x && viewDepth < cascade.y ) {
					float cascadeShadow = getShadow(
						shadowMap,
						sunLightShadow.shadowMapSize,
						sunLightShadow.shadowIntensity,
						sunLightShadow.shadowBias,
						sunLightShadow.shadowRadius,
						sunShadowMatrix[ cascadeOffset + i ] * shadowWorldPosition
					);
					shadow = mix( cascadeShadow, shadow, smoothstep( cascade.z, cascade.y, viewDepth ) );
				}
			}
			return shadow;
		}
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	#if defined( SHADOWMAP_TYPE_PCF )
	float getPointShadow( samplerCubeShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 bd3D = normalize( lightToPosition );
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			#ifdef USE_REVERSED_DEPTH_BUFFER
				float dp = ( shadowCameraNear * ( shadowCameraFar - viewSpaceZ ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp -= shadowBias;
			#else
				float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp += shadowBias;
			#endif
			float texelSize = shadowRadius / shadowMapSize.x;
			vec3 absDir = abs( bd3D );
			vec3 tangent = absDir.x > absDir.z ? vec3( 0.0, 1.0, 0.0 ) : vec3( 1.0, 0.0, 0.0 );
			tangent = normalize( cross( bd3D, tangent ) );
			vec3 bitangent = cross( bd3D, tangent );
			float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
			vec2 sample0 = vogelDiskSample( 0, 5, phi );
			vec2 sample1 = vogelDiskSample( 1, 5, phi );
			vec2 sample2 = vogelDiskSample( 2, 5, phi );
			vec2 sample3 = vogelDiskSample( 3, 5, phi );
			vec2 sample4 = vogelDiskSample( 4, 5, phi );
			shadow = (
				texture( shadowMap, vec4( bd3D + ( tangent * sample0.x + bitangent * sample0.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample1.x + bitangent * sample1.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample2.x + bitangent * sample2.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample3.x + bitangent * sample3.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample4.x + bitangent * sample4.y ) * texelSize, dp ) )
			) * 0.2;
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#elif defined( SHADOWMAP_TYPE_BASIC )
	float getPointShadow( samplerCube shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			float depth = textureCube( shadowMap, bd3D ).r;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				depth = 1.0 - depth;
			#endif
			shadow = step( dp, depth );
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#endif
	#endif
#endif`,CT=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
		varying vec4 vSunShadowWorldPosition;
		varying vec3 vSunShadowWorldNormal;
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,DT=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_SUN_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	#ifdef HAS_NORMAL
		vec3 shadowWorldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
	#else
		vec3 shadowWorldNormal = vec3( 0.0 );
	#endif
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_SUN_LIGHT_SHADOWS > 0
		vSunShadowWorldPosition = vec4( worldPosition.xyz, - mvPosition.z );
		vSunShadowWorldNormal = shadowWorldNormal;
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,UT=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
	SunLightShadow sunLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SUN_LIGHT_SHADOWS; i ++ ) {
		sunLight = sunLightShadows[ i ];
		shadow *= receiveShadow ? getSunShadow( sunShadowMap[ i ], sunLight, UNROLLED_LOOP_INDEX ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0 && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,LT=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,NT=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,OT=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,PT=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,zT=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,IT=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,BT=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,FT=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,HT=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseContribution, material.specularColorBlended, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,GT=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,VT=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,kT=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,XT=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,WT=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const qT=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,YT=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,ZT=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,KT=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vWorldDirection );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,JT=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,QT=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,jT=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,$T=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,t2=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,e2=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = vec4( dist, 0.0, 0.0, 1.0 );
}`,n2=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,i2=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,a2=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,s2=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,r2=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,o2=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,l2=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,c2=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,u2=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,f2=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,h2=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,d2=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( normalize( normal ) * 0.5 + 0.5, diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,p2=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,m2=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,g2=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,v2=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_RETROREFLECTION
	uniform float retroreflectivity;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
 
		outgoingLight = outgoingLight + sheenSpecularDirect + sheenSpecularIndirect;
 
 	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,_2=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,x2=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,M2=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,y2=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,S2=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,b2=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,E2=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,T2=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Pe={alphahash_fragment:qb,alphahash_pars_fragment:Yb,alphamap_fragment:Zb,alphamap_pars_fragment:Kb,alphatest_fragment:Jb,alphatest_pars_fragment:Qb,aomap_fragment:jb,aomap_pars_fragment:$b,batching_pars_vertex:tE,batching_vertex:eE,begin_vertex:nE,beginnormal_vertex:iE,bsdfs:aE,iridescence_fragment:sE,bumpmap_pars_fragment:rE,clipping_planes_fragment:oE,clipping_planes_pars_fragment:lE,clipping_planes_pars_vertex:cE,clipping_planes_vertex:uE,color_fragment:fE,color_pars_fragment:hE,color_pars_vertex:dE,color_vertex:pE,common:mE,cube_uv_reflection_fragment:gE,defaultnormal_vertex:vE,displacementmap_pars_vertex:_E,displacementmap_vertex:xE,emissivemap_fragment:ME,emissivemap_pars_fragment:yE,colorspace_fragment:SE,colorspace_pars_fragment:bE,envmap_fragment:EE,envmap_common_pars_fragment:TE,envmap_pars_fragment:AE,envmap_pars_vertex:wE,envmap_physical_pars_fragment:BE,envmap_vertex:RE,fog_vertex:CE,fog_pars_vertex:DE,fog_fragment:UE,fog_pars_fragment:LE,gradientmap_pars_fragment:NE,lightmap_pars_fragment:OE,lights_lambert_fragment:PE,lights_lambert_pars_fragment:zE,lights_pars_begin:IE,lights_toon_fragment:FE,lights_toon_pars_fragment:HE,lights_phong_fragment:GE,lights_phong_pars_fragment:VE,lights_physical_fragment:kE,lights_physical_pars_fragment:XE,lights_fragment_begin:WE,lights_fragment_maps:qE,lights_fragment_end:YE,lightprobes_pars_fragment:ZE,logdepthbuf_fragment:KE,logdepthbuf_pars_fragment:JE,logdepthbuf_pars_vertex:QE,logdepthbuf_vertex:jE,map_fragment:$E,map_pars_fragment:tT,map_particle_fragment:eT,map_particle_pars_fragment:nT,metalnessmap_fragment:iT,metalnessmap_pars_fragment:aT,morphinstance_vertex:sT,morphcolor_vertex:rT,morphnormal_vertex:oT,morphtarget_pars_vertex:lT,morphtarget_vertex:cT,normal_fragment_begin:uT,normal_fragment_maps:fT,normal_pars_fragment:hT,normal_pars_vertex:dT,normal_vertex:pT,normalmap_pars_fragment:mT,clearcoat_normal_fragment_begin:gT,clearcoat_normal_fragment_maps:vT,clearcoat_pars_fragment:_T,iridescence_pars_fragment:xT,opaque_fragment:MT,packing:yT,premultiplied_alpha_fragment:ST,project_vertex:bT,dithering_fragment:ET,dithering_pars_fragment:TT,roughnessmap_fragment:AT,roughnessmap_pars_fragment:wT,shadowmap_pars_fragment:RT,shadowmap_pars_vertex:CT,shadowmap_vertex:DT,shadowmask_pars_fragment:UT,skinbase_vertex:LT,skinning_pars_vertex:NT,skinning_vertex:OT,skinnormal_vertex:PT,specularmap_fragment:zT,specularmap_pars_fragment:IT,tonemapping_fragment:BT,tonemapping_pars_fragment:FT,transmission_fragment:HT,transmission_pars_fragment:GT,uv_pars_fragment:VT,uv_pars_vertex:kT,uv_vertex:XT,worldpos_vertex:WT,background_vert:qT,background_frag:YT,backgroundCube_vert:ZT,backgroundCube_frag:KT,cube_vert:JT,cube_frag:QT,depth_vert:jT,depth_frag:$T,distance_vert:t2,distance_frag:e2,equirect_vert:n2,equirect_frag:i2,linedashed_vert:a2,linedashed_frag:s2,meshbasic_vert:r2,meshbasic_frag:o2,meshlambert_vert:l2,meshlambert_frag:c2,meshmatcap_vert:u2,meshmatcap_frag:f2,meshnormal_vert:h2,meshnormal_frag:d2,meshphong_vert:p2,meshphong_frag:m2,meshphysical_vert:g2,meshphysical_frag:v2,meshtoon_vert:_2,meshtoon_frag:x2,points_vert:M2,points_frag:y2,shadow_vert:S2,shadow_frag:b2,sprite_vert:E2,sprite_frag:T2},Kt={common:{diffuse:{value:new ce(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new we},alphaMap:{value:null},alphaMapTransform:{value:new we},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new we}},envmap:{envMap:{value:null},envMapRotation:{value:new we},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98},dfgLUT:{value:null}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new we}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new we}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new we},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new we},normalScale:{value:new Ot(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new we},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new we}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new we}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new we}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new ce(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},sunLights:{value:[],properties:{direction:{},color:{}}},sunLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},sunShadowMatrix:{value:[]},sunShadowCascade:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null},probesSH:{value:null},probesMin:{value:new B},probesMax:{value:new B},probesResolution:{value:new B}},points:{diffuse:{value:new ce(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new we},alphaTest:{value:0},uvTransform:{value:new we}},sprite:{diffuse:{value:new ce(16777215)},opacity:{value:1},center:{value:new Ot(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new we},alphaMap:{value:null},alphaMapTransform:{value:new we},alphaTest:{value:0}}},va={basic:{uniforms:gi([Kt.common,Kt.specularmap,Kt.envmap,Kt.aomap,Kt.lightmap,Kt.fog]),vertexShader:Pe.meshbasic_vert,fragmentShader:Pe.meshbasic_frag},lambert:{uniforms:gi([Kt.common,Kt.specularmap,Kt.envmap,Kt.aomap,Kt.lightmap,Kt.emissivemap,Kt.bumpmap,Kt.normalmap,Kt.displacementmap,Kt.fog,Kt.lights,{emissive:{value:new ce(0)},envMapIntensity:{value:1}}]),vertexShader:Pe.meshlambert_vert,fragmentShader:Pe.meshlambert_frag},phong:{uniforms:gi([Kt.common,Kt.specularmap,Kt.envmap,Kt.aomap,Kt.lightmap,Kt.emissivemap,Kt.bumpmap,Kt.normalmap,Kt.displacementmap,Kt.fog,Kt.lights,{emissive:{value:new ce(0)},specular:{value:new ce(1118481)},shininess:{value:30},envMapIntensity:{value:1}}]),vertexShader:Pe.meshphong_vert,fragmentShader:Pe.meshphong_frag},standard:{uniforms:gi([Kt.common,Kt.envmap,Kt.aomap,Kt.lightmap,Kt.emissivemap,Kt.bumpmap,Kt.normalmap,Kt.displacementmap,Kt.roughnessmap,Kt.metalnessmap,Kt.fog,Kt.lights,{emissive:{value:new ce(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:Pe.meshphysical_vert,fragmentShader:Pe.meshphysical_frag},toon:{uniforms:gi([Kt.common,Kt.aomap,Kt.lightmap,Kt.emissivemap,Kt.bumpmap,Kt.normalmap,Kt.displacementmap,Kt.gradientmap,Kt.fog,Kt.lights,{emissive:{value:new ce(0)}}]),vertexShader:Pe.meshtoon_vert,fragmentShader:Pe.meshtoon_frag},matcap:{uniforms:gi([Kt.common,Kt.bumpmap,Kt.normalmap,Kt.displacementmap,Kt.fog,{matcap:{value:null}}]),vertexShader:Pe.meshmatcap_vert,fragmentShader:Pe.meshmatcap_frag},points:{uniforms:gi([Kt.points,Kt.fog]),vertexShader:Pe.points_vert,fragmentShader:Pe.points_frag},dashed:{uniforms:gi([Kt.common,Kt.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:Pe.linedashed_vert,fragmentShader:Pe.linedashed_frag},depth:{uniforms:gi([Kt.common,Kt.displacementmap]),vertexShader:Pe.depth_vert,fragmentShader:Pe.depth_frag},normal:{uniforms:gi([Kt.common,Kt.bumpmap,Kt.normalmap,Kt.displacementmap,{opacity:{value:1}}]),vertexShader:Pe.meshnormal_vert,fragmentShader:Pe.meshnormal_frag},sprite:{uniforms:gi([Kt.sprite,Kt.fog]),vertexShader:Pe.sprite_vert,fragmentShader:Pe.sprite_frag},background:{uniforms:{uvTransform:{value:new we},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:Pe.background_vert,fragmentShader:Pe.background_frag},backgroundCube:{uniforms:{envMap:{value:null},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new we}},vertexShader:Pe.backgroundCube_vert,fragmentShader:Pe.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:Pe.cube_vert,fragmentShader:Pe.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:Pe.equirect_vert,fragmentShader:Pe.equirect_frag},distance:{uniforms:gi([Kt.common,Kt.displacementmap,{referencePosition:{value:new B},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:Pe.distance_vert,fragmentShader:Pe.distance_frag},shadow:{uniforms:gi([Kt.lights,Kt.fog,{color:{value:new ce(0)},opacity:{value:1}}]),vertexShader:Pe.shadow_vert,fragmentShader:Pe.shadow_frag}};va.physical={uniforms:gi([va.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new we},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new we},clearcoatNormalScale:{value:new Ot(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new we},dispersion:{value:0},retroreflectivity:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new we},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new we},sheen:{value:0},sheenColor:{value:new ce(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new we},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new we},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new we},transmissionSamplerSize:{value:new Ot},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new we},attenuationDistance:{value:0},attenuationColor:{value:new ce(0)},specularColor:{value:new ce(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new we},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new we},anisotropyVector:{value:new Ot},anisotropyMap:{value:null},anisotropyMapTransform:{value:new we}}]),vertexShader:Pe.meshphysical_vert,fragmentShader:Pe.meshphysical_frag};const Su={r:0,b:0,g:0},A2=new ln,mM=new we;mM.set(-1,0,0,0,1,0,0,0,1);function w2(s,t,n,a,o,c){const u=new ce(0);let h=o===!0?0:1,p,d,g=null,v=0,_=null;function x(C){let P=C.isScene===!0?C.background:null;if(P&&P.isTexture){const E=C.backgroundBlurriness>0;P=t.get(P,E)}return P}function b(C){let P=!1;const E=x(C);E===null?y(u,h):E&&E.isColor&&(y(E,1),P=!0);const U=s.xr.getEnvironmentBlendMode();U==="additive"?n.buffers.color.setClear(0,0,0,1,c):U==="alpha-blend"&&n.buffers.color.setClear(0,0,0,0,c),(s.autoClear||P)&&(n.buffers.depth.setTest(!0),n.buffers.depth.setMask(!0),n.buffers.color.setMask(!0),s.clear(s.autoClearColor,s.autoClearDepth,s.autoClearStencil))}function R(C,P){const E=x(P);E&&(E.isCubeTexture||E.mapping===Hu)?(d===void 0&&(d=new le(new Qa(1,1,1),new ui({name:"BackgroundCubeMaterial",uniforms:go(va.backgroundCube.uniforms),vertexShader:va.backgroundCube.vertexShader,fragmentShader:va.backgroundCube.fragmentShader,side:vi,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),d.geometry.deleteAttribute("normal"),d.geometry.deleteAttribute("uv"),d.onBeforeRender=function(U,L,N){this.matrixWorld.copyPosition(N.matrixWorld)},Object.defineProperty(d.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),a.update(d)),d.material.uniforms.envMap.value=E,d.material.uniforms.backgroundBlurriness.value=P.backgroundBlurriness,d.material.uniforms.backgroundIntensity.value=P.backgroundIntensity,d.material.uniforms.backgroundRotation.value.setFromMatrix4(A2.makeRotationFromEuler(P.backgroundRotation)).transpose(),E.isCubeTexture&&E.isRenderTargetTexture===!1&&d.material.uniforms.backgroundRotation.value.premultiply(mM),d.material.toneMapped=qe.getTransfer(E.colorSpace)!==on,(g!==E||v!==E.version||_!==s.toneMapping)&&(d.material.needsUpdate=!0,g=E,v=E.version,_=s.toneMapping),d.layers.enableAll(),C.unshift(d,d.geometry,d.material,0,0,null)):E&&E.isTexture&&(p===void 0&&(p=new le(new jn(2,2),new ui({name:"BackgroundMaterial",uniforms:go(va.background.uniforms),vertexShader:va.background.vertexShader,fragmentShader:va.background.fragmentShader,side:er,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),p.geometry.deleteAttribute("normal"),Object.defineProperty(p.material,"map",{get:function(){return this.uniforms.t2D.value}}),a.update(p)),p.material.uniforms.t2D.value=E,p.material.uniforms.backgroundIntensity.value=P.backgroundIntensity,p.material.toneMapped=qe.getTransfer(E.colorSpace)!==on,E.matrixAutoUpdate===!0&&E.updateMatrix(),p.material.uniforms.uvTransform.value.copy(E.matrix),(g!==E||v!==E.version||_!==s.toneMapping)&&(p.material.needsUpdate=!0,g=E,v=E.version,_=s.toneMapping),p.layers.enableAll(),C.unshift(p,p.geometry,p.material,0,0,null))}function y(C,P){C.getRGB(Su,fM(s)),n.buffers.color.setClear(Su.r,Su.g,Su.b,P,c)}function M(){d!==void 0&&(d.geometry.dispose(),d.material.dispose(),d=void 0),p!==void 0&&(p.geometry.dispose(),p.material.dispose(),p=void 0)}return{getClearColor:function(){return u},setClearColor:function(C,P=1){u.set(C),h=P,y(u,h)},getClearAlpha:function(){return h},setClearAlpha:function(C){h=C,y(u,h)},render:b,addToRenderList:R,dispose:M}}function R2(s,t){const n=s.getParameter(s.MAX_VERTEX_ATTRIBS),a={},o=_(null);let c=o,u=!1;function h(J,$,lt,X,k){let H=!1;const Y=v(J,X,lt,$);c!==Y&&(c=Y,d(c.object)),H=x(J,X,lt,k),H&&b(J,X,lt,k),k!==null&&t.update(k,s.ELEMENT_ARRAY_BUFFER),(H||u)&&(u=!1,E(J,$,lt,X),k!==null&&s.bindBuffer(s.ELEMENT_ARRAY_BUFFER,t.get(k).buffer))}function p(){return s.createVertexArray()}function d(J){return s.bindVertexArray(J)}function g(J){return s.deleteVertexArray(J)}function v(J,$,lt,X){const k=X.wireframe===!0;let H=a[$.id];H===void 0&&(H={},a[$.id]=H);const Y=J.isInstancedMesh===!0?J.id:0;let it=H[Y];it===void 0&&(it={},H[Y]=it);let rt=it[lt.id];rt===void 0&&(rt={},it[lt.id]=rt);let ht=rt[k];return ht===void 0&&(ht=_(p()),rt[k]=ht),ht}function _(J){const $=[],lt=[],X=[];for(let k=0;k<n;k++)$[k]=0,lt[k]=0,X[k]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:$,enabledAttributes:lt,attributeDivisors:X,object:J,attributes:{},index:null}}function x(J,$,lt,X){const k=c.attributes,H=$.attributes;let Y=0;const it=lt.getAttributes();for(const rt in it)if(it[rt].location>=0){const I=k[rt];let ct=H[rt];if(ct===void 0&&(rt==="instanceMatrix"&&J.instanceMatrix&&(ct=J.instanceMatrix),rt==="instanceColor"&&J.instanceColor&&(ct=J.instanceColor)),I===void 0||I.attribute!==ct||ct&&I.data!==ct.data)return!0;Y++}return c.attributesNum!==Y||c.index!==X}function b(J,$,lt,X){const k={},H=$.attributes;let Y=0;const it=lt.getAttributes();for(const rt in it)if(it[rt].location>=0){let I=H[rt];I===void 0&&(rt==="instanceMatrix"&&J.instanceMatrix&&(I=J.instanceMatrix),rt==="instanceColor"&&J.instanceColor&&(I=J.instanceColor));const ct={};ct.attribute=I,I&&I.data&&(ct.data=I.data),k[rt]=ct,Y++}c.attributes=k,c.attributesNum=Y,c.index=X}function R(){const J=c.newAttributes;for(let $=0,lt=J.length;$<lt;$++)J[$]=0}function y(J){M(J,0)}function M(J,$){const lt=c.newAttributes,X=c.enabledAttributes,k=c.attributeDivisors;lt[J]=1,X[J]===0&&(s.enableVertexAttribArray(J),X[J]=1),k[J]!==$&&(s.vertexAttribDivisor(J,$),k[J]=$)}function C(){const J=c.newAttributes,$=c.enabledAttributes;for(let lt=0,X=$.length;lt<X;lt++)$[lt]!==J[lt]&&(s.disableVertexAttribArray(lt),$[lt]=0)}function P(J,$,lt,X,k,H,Y){Y===!0?s.vertexAttribIPointer(J,$,lt,k,H):s.vertexAttribPointer(J,$,lt,X,k,H)}function E(J,$,lt,X){R();const k=X.attributes,H=lt.getAttributes(),Y=$.defaultAttributeValues;for(const it in H){const rt=H[it];if(rt.location>=0){let ht=k[it];if(ht===void 0&&(it==="instanceMatrix"&&J.instanceMatrix&&(ht=J.instanceMatrix),it==="instanceColor"&&J.instanceColor&&(ht=J.instanceColor)),ht!==void 0){const I=ht.normalized,ct=ht.itemSize,Tt=t.get(ht);if(Tt===void 0)continue;const Ut=Tt.buffer,Vt=Tt.type,Bt=Tt.bytesPerElement,ft=Vt===s.INT||Vt===s.UNSIGNED_INT||ht.gpuType===Yp;if(ht.isInterleavedBufferAttribute){const Et=ht.data,Ft=Et.stride,$t=ht.offset;if(Et.isInstancedInterleavedBuffer){for(let Xt=0;Xt<rt.locationSize;Xt++)M(rt.location+Xt,Et.meshPerAttribute);J.isInstancedMesh!==!0&&X._maxInstanceCount===void 0&&(X._maxInstanceCount=Et.meshPerAttribute*Et.count)}else for(let Xt=0;Xt<rt.locationSize;Xt++)y(rt.location+Xt);s.bindBuffer(s.ARRAY_BUFFER,Ut);for(let Xt=0;Xt<rt.locationSize;Xt++)P(rt.location+Xt,ct/rt.locationSize,Vt,I,Ft*Bt,($t+ct/rt.locationSize*Xt)*Bt,ft)}else{if(ht.isInstancedBufferAttribute){for(let Et=0;Et<rt.locationSize;Et++)M(rt.location+Et,ht.meshPerAttribute);J.isInstancedMesh!==!0&&X._maxInstanceCount===void 0&&(X._maxInstanceCount=ht.meshPerAttribute*ht.count)}else for(let Et=0;Et<rt.locationSize;Et++)y(rt.location+Et);s.bindBuffer(s.ARRAY_BUFFER,Ut);for(let Et=0;Et<rt.locationSize;Et++)P(rt.location+Et,ct/rt.locationSize,Vt,I,ct*Bt,ct/rt.locationSize*Et*Bt,ft)}}else if(Y!==void 0){const I=Y[it];if(I!==void 0)switch(I.length){case 2:s.vertexAttrib2fv(rt.location,I);break;case 3:s.vertexAttrib3fv(rt.location,I);break;case 4:s.vertexAttrib4fv(rt.location,I);break;default:s.vertexAttrib1fv(rt.location,I)}}}}C()}function U(){z();for(const J in a){const $=a[J];for(const lt in $){const X=$[lt];for(const k in X){const H=X[k];for(const Y in H)g(H[Y].object),delete H[Y];delete X[k]}}delete a[J]}}function L(J){if(a[J.id]===void 0)return;const $=a[J.id];for(const lt in $){const X=$[lt];for(const k in X){const H=X[k];for(const Y in H)g(H[Y].object),delete H[Y];delete X[k]}}delete a[J.id]}function N(J){for(const $ in a){const lt=a[$];for(const X in lt){const k=lt[X];if(k[J.id]===void 0)continue;const H=k[J.id];for(const Y in H)g(H[Y].object),delete H[Y];delete k[J.id]}}}function T(J){for(const $ in a){const lt=a[$],X=J.isInstancedMesh===!0?J.id:0,k=lt[X];if(k!==void 0){for(const H in k){const Y=k[H];for(const it in Y)g(Y[it].object),delete Y[it];delete k[H]}delete lt[X],Object.keys(lt).length===0&&delete a[$]}}}function z(){W(),u=!0,c!==o&&(c=o,d(c.object))}function W(){o.geometry=null,o.program=null,o.wireframe=!1}return{setup:h,reset:z,resetDefaultState:W,dispose:U,releaseStatesOfGeometry:L,releaseStatesOfObject:T,releaseStatesOfProgram:N,initAttributes:R,enableAttribute:y,disableUnusedAttributes:C}}function C2(s,t,n){let a;function o(p){a=p}function c(p,d){s.drawArrays(a,p,d),n.update(d,a,1)}function u(p,d,g){g!==0&&(s.drawArraysInstanced(a,p,d,g),n.update(d,a,g))}function h(p,d,g){if(g===0)return;t.get("WEBGL_multi_draw").multiDrawArraysWEBGL(a,p,0,d,0,g);let _=0;for(let x=0;x<g;x++)_+=d[x];n.update(_,a,1)}this.setMode=o,this.render=c,this.renderInstances=u,this.renderMultiDraw=h}function D2(s,t,n,a){let o;function c(){if(o!==void 0)return o;if(t.has("EXT_texture_filter_anisotropic")===!0){const N=t.get("EXT_texture_filter_anisotropic");o=s.getParameter(N.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else o=0;return o}function u(N){return!(N!==Qi&&a.convert(N)!==s.getParameter(s.IMPLEMENTATION_COLOR_READ_FORMAT))}function h(N){const T=N===ji&&(t.has("EXT_color_buffer_half_float")||t.has("EXT_color_buffer_float"));return!(N!==Ti&&N!==oa&&!T&&a.convert(N)!==s.getParameter(s.IMPLEMENTATION_COLOR_READ_TYPE))}function p(N){if(N==="highp"){if(s.getShaderPrecisionFormat(s.VERTEX_SHADER,s.HIGH_FLOAT).precision>0&&s.getShaderPrecisionFormat(s.FRAGMENT_SHADER,s.HIGH_FLOAT).precision>0)return"highp";N="mediump"}return N==="mediump"&&s.getShaderPrecisionFormat(s.VERTEX_SHADER,s.MEDIUM_FLOAT).precision>0&&s.getShaderPrecisionFormat(s.FRAGMENT_SHADER,s.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let d=n.precision!==void 0?n.precision:"highp";const g=p(d);g!==d&&(ye("WebGLRenderer:",d,"not supported, using",g,"instead."),d=g);const v=n.logarithmicDepthBuffer===!0,_=n.reversedDepthBuffer===!0&&t.has("EXT_clip_control");n.reversedDepthBuffer===!0&&_===!1&&ye("WebGLRenderer: Unable to use reversed depth buffer due to missing EXT_clip_control extension. Fallback to default depth buffer.");const x=s.getParameter(s.MAX_TEXTURE_IMAGE_UNITS),b=s.getParameter(s.MAX_VERTEX_TEXTURE_IMAGE_UNITS),R=s.getParameter(s.MAX_TEXTURE_SIZE),y=s.getParameter(s.MAX_CUBE_MAP_TEXTURE_SIZE),M=s.getParameter(s.MAX_VERTEX_ATTRIBS),C=s.getParameter(s.MAX_VERTEX_UNIFORM_VECTORS),P=s.getParameter(s.MAX_VARYING_VECTORS),E=s.getParameter(s.MAX_FRAGMENT_UNIFORM_VECTORS),U=s.getParameter(s.MAX_SAMPLES),L=s.getParameter(s.SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:c,getMaxPrecision:p,textureFormatReadable:u,textureTypeReadable:h,precision:d,logarithmicDepthBuffer:v,reversedDepthBuffer:_,maxTextures:x,maxVertexTextures:b,maxTextureSize:R,maxCubemapSize:y,maxAttributes:M,maxVertexUniforms:C,maxVaryings:P,maxFragmentUniforms:E,maxSamples:U,samples:L}}function U2(s){const t=this;let n=null,a=0,o=!1,c=!1;const u=new Rs,h=new we,p={value:null,needsUpdate:!1};this.uniform=p,this.numPlanes=0,this.numIntersection=0,this.init=function(v,_){const x=v.length!==0||_||a!==0||o;return o=_,a=v.length,x},this.beginShadows=function(){c=!0,g(null)},this.endShadows=function(){c=!1},this.setGlobalState=function(v,_){n=g(v,_,0)},this.setState=function(v,_,x){const b=v.clippingPlanes,R=v.clipIntersection,y=v.clipShadows,M=s.get(v);if(!o||b===null||b.length===0||c&&!y)c?g(null):d();else{const C=c?0:a,P=C*4;let E=M.clippingState||null;p.value=E,E=g(b,_,P,x);for(let U=0;U!==P;++U)E[U]=n[U];M.clippingState=E,this.numIntersection=R?this.numPlanes:0,this.numPlanes+=C}};function d(){p.value!==n&&(p.value=n,p.needsUpdate=a>0),t.numPlanes=a,t.numIntersection=0}function g(v,_,x,b){const R=v!==null?v.length:0;let y=null;if(R!==0){if(y=p.value,b!==!0||y===null){const M=x+R*4,C=_.matrixWorldInverse;h.getNormalMatrix(C),(y===null||y.length<M)&&(y=new Float32Array(M));for(let P=0,E=x;P!==R;++P,E+=4)u.copy(v[P]).applyMatrix4(C,h),u.normal.toArray(y,E),y[E+3]=u.constant}p.value=y,p.needsUpdate=!0}return t.numPlanes=R,t.numIntersection=0,y}}const lo=4,L2=6,N2=20,O2=256,ml=new cm,Y_=new ce;let Ld=null,Nd=0,Od=0,Pd=!1;const P2=new B,Js=new B;class Z_{constructor(t){this._renderer=t,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._sizeLods=[],this._lodMeshes=[],this._backgroundBox=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._blurMaterial=null,this._ggxMaterial=null}fromScene(t,n=0,a=.1,o=100,c={}){const{size:u=256,position:h=P2}=c;Ld=this._renderer.getRenderTarget(),Nd=this._renderer.getActiveCubeFace(),Od=this._renderer.getActiveMipmapLevel(),Pd=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(u);const p=this._allocateTargets();return p.depthBuffer=!0,this._sceneToCubeUV(t,a,o,p,h),n>0&&this._blur(p,0,0,n),this._applyPMREM(p),this._cleanup(p),p}fromEquirectangular(t,n=null){return this._fromTexture(t,n)}fromCubemap(t,n=null){return this._fromTexture(t,n)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=Q_(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=J_(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose(),this._backgroundBox!==null&&(this._backgroundBox.geometry.dispose(),this._backgroundBox.material.dispose())}_setSize(t){this._lodMax=Math.floor(Math.log2(t)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._ggxMaterial!==null&&this._ggxMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let t=0;t<this._lodMeshes.length;t++)this._lodMeshes[t].geometry.dispose()}_cleanup(t){this._renderer.setRenderTarget(Ld,Nd,Od),this._renderer.xr.enabled=Pd,t.scissorTest=!1,ao(t,0,0,t.width,t.height)}_fromTexture(t,n){t.mapping===nr||t.mapping===ho?this._setSize(t.image.length===0?16:t.image[0].width||t.image[0].image.width):this._setSize(t.image.width/4),Ld=this._renderer.getRenderTarget(),Nd=this._renderer.getActiveCubeFace(),Od=this._renderer.getActiveMipmapLevel(),Pd=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;const a=n||this._allocateTargets();return this._textureToCubeUV(t,a),this._applyPMREM(a),this._cleanup(a),a}_allocateTargets(){const t=3*Math.max(this._cubeSize,112),n=4*this._cubeSize,a={magFilter:Wn,minFilter:Wn,generateMipmaps:!1,type:ji,format:Qi,colorSpace:Lu,depthBuffer:!1},o=K_(t,n,a);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==t||this._pingPongRenderTarget.height!==n){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=K_(t,n,a);const{_lodMax:c}=this;({lodMeshes:this._lodMeshes,sizeLods:this._sizeLods}=z2(c)),this._blurMaterial=B2(c,t,n),this._ggxMaterial=I2(c,t,n)}return o}_compileMaterial(t){const n=new le(new Ie,t);this._renderer.compile(n,ml)}_sceneToCubeUV(t,n,a,o,c){const p=new zi(90,1,n,a),d=[1,-1,1,1,1,1],g=[1,1,1,-1,-1,-1],v=this._renderer,_=v.autoClear,x=v.toneMapping;v.getClearColor(Y_),v.toneMapping=xa,v.autoClear=!1,v.state.buffers.depth.getReversed()&&(v.setRenderTarget(o),v.clearDepth(),v.setRenderTarget(null)),this._backgroundBox===null&&(this._backgroundBox=new le(new Qa,new qa({name:"PMREM.Background",side:vi,depthWrite:!1,depthTest:!1})));const R=this._backgroundBox,y=R.material;let M=!1;const C=t.background;C?C.isColor&&(y.color.copy(C),t.background=null,M=!0):(y.color.copy(Y_),M=!0);for(let P=0;P<6;P++){const E=P%3;E===0?(p.up.set(0,d[P],0),p.position.set(c.x,c.y,c.z),p.lookAt(c.x+g[P],c.y,c.z)):E===1?(p.up.set(0,0,d[P]),p.position.set(c.x,c.y,c.z),p.lookAt(c.x,c.y+g[P],c.z)):(p.up.set(0,d[P],0),p.position.set(c.x,c.y,c.z),p.lookAt(c.x,c.y,c.z+g[P]));const U=this._cubeSize;ao(o,E*U,P>2?U:0,U,U),v.setRenderTarget(o),M&&v.render(R,p),v.render(t,p)}v.toneMapping=x,v.autoClear=_,t.background=C}_textureToCubeUV(t,n){const a=this._renderer,o=t.mapping===nr||t.mapping===ho;o?(this._cubemapMaterial===null&&(this._cubemapMaterial=Q_()),this._cubemapMaterial.uniforms.flipEnvMap.value=t.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=J_());const c=o?this._cubemapMaterial:this._equirectMaterial,u=this._lodMeshes[0];u.material=c;const h=c.uniforms;h.envMap.value=t;const p=this._cubeSize;ao(n,0,0,3*p,2*p),a.setRenderTarget(n),a.render(u,ml)}_applyPMREM(t){const n=this._renderer,a=n.autoClear;n.autoClear=!1;const o=this._lodMeshes.length;for(let c=1;c<o;c++)this._applyGGXFilter(t,c-1,c);n.autoClear=a}_applyGGXFilter(t,n,a){const o=this._renderer,c=this._pingPongRenderTarget,u=this._ggxMaterial,h=this._lodMeshes[a];h.material=u;const p=u.uniforms,d=a/(this._lodMeshes.length-1),g=n/(this._lodMeshes.length-1),v=Math.sqrt(d*d-g*g),_=d*1.25,x=v*_,{_lodMax:b}=this,R=this._sizeLods[a],y=3*R*(a>b-lo?a-b+lo:0),M=4*(this._cubeSize-R);p.envMap.value=t.texture,p.roughness.value=x,p.mipInt.value=b-n,ao(c,y,M,3*R,2*R),o.setRenderTarget(c),o.render(h,ml),p.envMap.value=c.texture,p.roughness.value=0,p.mipInt.value=b-a,ao(t,y,M,3*R,2*R),o.setRenderTarget(t),o.render(h,ml)}_blur(t,n,a,o){const c=this._pingPongRenderTarget,u=Math.min(o,Math.PI)/Math.SQRT2;this._blurPass(t,c,n,a,u),this._blurPass(c,t,a,a,u)}_blurPass(t,n,a,o,c){const u=this._renderer,h=this._blurMaterial,p=this._lodMeshes[o];p.material=h;const d=h.uniforms;d.envMap.value=t.texture,d.sigma.value=c,d.mipInt.value=this._lodMax-a;const g=this._sizeLods[o],v=3*g*(o>this._lodMax-lo?o-this._lodMax+lo:0),_=4*(this._cubeSize-g);ao(n,v,_,3*g,2*g),u.setRenderTarget(n),u.render(p,ml)}}function z2(s){const t=[],n=[];let a=s;const o=s-lo+1+L2;for(let c=0;c<o;c++){const u=Math.pow(2,a);t.push(u);const h=1/(u-2),p=-h,d=1+h,g=[p,p,d,p,d,d,p,p,d,d,p,d],v=6,_=6,x=3,b=new Float32Array(x*_*v),R=new Float32Array(x*_*v);for(let M=0;M<v;M++){const C=M%3*2/3-1,P=M>2?0:-1,E=[C,P,0,C+2/3,P,0,C+2/3,P+1,0,C,P,0,C+2/3,P+1,0,C,P+1,0];b.set(E,x*_*M);for(let U=0;U<_;U++){const L=g[U*2]*2-1,N=g[U*2+1]*2-1;M===0?Js.set(1,N,L):M===1?Js.set(-L,1,-N):M===2?Js.set(-L,N,1):M===3?Js.set(-1,N,-L):M===4?Js.set(-L,-1,N):Js.set(L,N,-1),Js.toArray(R,(M*_+U)*x)}}const y=new Ie;y.setAttribute("position",new ti(b,x)),y.setAttribute("outputDirection",new ti(R,x)),n.push(new le(y,null)),a>lo&&a--}return{lodMeshes:n,sizeLods:t}}function K_(s,t,n){const a=new Bi(s,t,n);return a.texture.mapping=Hu,a.texture.name="PMREM.cubeUv",a.scissorTest=!0,a}function ao(s,t,n,a,o){s.viewport.set(t,n,a,o),s.scissor.set(t,n,a,o)}function I2(s,t,n){return new ui({name:"PMREMGGXConvolution",defines:{GGX_SAMPLES:O2,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/n,CUBEUV_MAX_MIP:`${s}.0`},uniforms:{envMap:{value:null},roughness:{value:0},mipInt:{value:0}},vertexShader:Ku(),fragmentShader:`

			precision highp float;
			precision highp int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform float roughness;
			uniform float mipInt;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			#define PI 3.14159265359

			// Van der Corput radical inverse
			float radicalInverse_VdC(uint bits) {
				bits = (bits << 16u) | (bits >> 16u);
				bits = ((bits & 0x55555555u) << 1u) | ((bits & 0xAAAAAAAAu) >> 1u);
				bits = ((bits & 0x33333333u) << 2u) | ((bits & 0xCCCCCCCCu) >> 2u);
				bits = ((bits & 0x0F0F0F0Fu) << 4u) | ((bits & 0xF0F0F0F0u) >> 4u);
				bits = ((bits & 0x00FF00FFu) << 8u) | ((bits & 0xFF00FF00u) >> 8u);
				return float(bits) * 2.3283064365386963e-10; // / 0x100000000
			}

			// Hammersley sequence
			vec2 hammersley(uint i, uint N) {
				return vec2(float(i) / float(N), radicalInverse_VdC(i));
			}

			// GGX VNDF importance sampling (Eric Heitz 2018)
			// "Sampling the GGX Distribution of Visible Normals"
			// https://jcgt.org/published/0007/04/01/
			vec3 importanceSampleGGX_VNDF(vec2 Xi, vec3 V, float roughness) {
				float alpha = roughness * roughness;

				// Section 4.1: Orthonormal basis
				vec3 T1 = vec3(1.0, 0.0, 0.0);
				vec3 T2 = cross(V, T1);

				// Section 4.2: Parameterization of projected area
				float r = sqrt(Xi.x);
				float phi = 2.0 * PI * Xi.y;
				float t1 = r * cos(phi);
				float t2 = r * sin(phi);
				float s = 0.5 * (1.0 + V.z);
				t2 = (1.0 - s) * sqrt(1.0 - t1 * t1) + s * t2;

				// Section 4.3: Reprojection onto hemisphere
				vec3 Nh = t1 * T1 + t2 * T2 + sqrt(max(0.0, 1.0 - t1 * t1 - t2 * t2)) * V;

				// Section 3.4: Transform back to ellipsoid configuration
				return normalize(vec3(alpha * Nh.x, alpha * Nh.y, max(0.0, Nh.z)));
			}

			void main() {
				vec3 N = normalize(vOutputDirection);
				vec3 V = N; // Assume view direction equals normal for pre-filtering

				vec3 prefilteredColor = vec3(0.0);
				float totalWeight = 0.0;

				// For very low roughness, just sample the environment directly
				if (roughness < 0.001) {
					gl_FragColor = vec4(bilinearCubeUV(envMap, N, mipInt), 1.0);
					return;
				}

				// Tangent space basis for VNDF sampling
				vec3 up = abs(N.z) < 0.999 ? vec3(0.0, 0.0, 1.0) : vec3(1.0, 0.0, 0.0);
				vec3 tangent = normalize(cross(up, N));
				vec3 bitangent = cross(N, tangent);

				for(uint i = 0u; i < uint(GGX_SAMPLES); i++) {
					vec2 Xi = hammersley(i, uint(GGX_SAMPLES));

					// For PMREM, V = N, so in tangent space V is always (0, 0, 1)
					vec3 H_tangent = importanceSampleGGX_VNDF(Xi, vec3(0.0, 0.0, 1.0), roughness);

					// Transform H back to world space
					vec3 H = normalize(tangent * H_tangent.x + bitangent * H_tangent.y + N * H_tangent.z);
					vec3 L = normalize(2.0 * dot(V, H) * H - V);

					float NdotL = max(dot(N, L), 0.0);

					if(NdotL > 0.0) {
						// Sample environment at fixed mip level
						// VNDF importance sampling handles the distribution filtering
						vec3 sampleColor = bilinearCubeUV(envMap, L, mipInt);

						// Weight by NdotL for the split-sum approximation
						// VNDF PDF naturally accounts for the visible microfacet distribution
						prefilteredColor += sampleColor * NdotL;
						totalWeight += NdotL;
					}
				}

				if (totalWeight > 0.0) {
					prefilteredColor = prefilteredColor / totalWeight;
				}

				gl_FragColor = vec4(prefilteredColor, 1.0);
			}
		`,blending:Ya,depthTest:!1,depthWrite:!1})}function B2(s,t,n){return new ui({name:"SphericalGaussianBlur",defines:{SAMPLES:N2,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/n,CUBEUV_MAX_MIP:`${s}.0`},uniforms:{envMap:{value:null},sigma:{value:0},mipInt:{value:0}},vertexShader:Ku(),fragmentShader:`

			precision highp float;
			precision highp int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform float sigma;
			uniform float mipInt;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			#define PI 3.14159265359
			#define GOLDEN_ANGLE 2.39996322973

			void main() {

				if ( sigma == 0.0 ) {

					gl_FragColor = vec4( bilinearCubeUV( envMap, vOutputDirection, mipInt ), 1.0 );
					return;

				}

				vec3 outputDirection = normalize( vOutputDirection );

				vec3 up = abs( outputDirection.z ) < 0.999 ? vec3( 0.0, 0.0, 1.0 ) : vec3( 1.0, 0.0, 0.0 );
				vec3 tangent = normalize( cross( up, outputDirection ) );
				vec3 bitangent = cross( outputDirection, tangent );

				// Truncate the kernel at three standard deviations or at the antipode.
				float thetaMax = min( 3.0 * sigma, PI );
				float truncation = 1.0 - exp( - 0.5 * thetaMax * thetaMax / ( sigma * sigma ) );

				vec3 accumColor = vec3( 0.0 );
				float accumWeight = 0.0;

				for ( int i = 0; i < SAMPLES; i ++ ) {

					// Stratified inverse-CDF sampling of the Gaussian, placed on a golden-angle spiral.
					float stratum = ( float( i ) + 0.5 ) / float( SAMPLES );
					float theta = sigma * sqrt( - 2.0 * log( 1.0 - stratum * truncation ) );
					float phi = float( i ) * GOLDEN_ANGLE;

					vec3 offset = cos( phi ) * tangent + sin( phi ) * bitangent;
					vec3 sampleDirection = cos( theta ) * outputDirection + sin( theta ) * offset;

					// Correct the planar sample density to solid angle.
					float weight = sin( theta ) / theta;

					accumColor += weight * bilinearCubeUV( envMap, sampleDirection, mipInt );
					accumWeight += weight;

				}

				gl_FragColor = vec4( accumColor / accumWeight, 1.0 );

			}
		`,blending:Ya,depthTest:!1,depthWrite:!1})}function J_(){return new ui({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:Ku(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:Ya,depthTest:!1,depthWrite:!1})}function Q_(){return new ui({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:Ku(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:Ya,depthTest:!1,depthWrite:!1})}function Ku(){return`

		precision mediump float;
		precision mediump int;

		attribute vec3 outputDirection;

		varying vec3 vOutputDirection;

		void main() {

			vOutputDirection = outputDirection;
			gl_Position = vec4( position, 1.0 );

		}
	`}class gM extends Bi{constructor(t=1,n={}){super(t,t,n),this.isWebGLCubeRenderTarget=!0;const a={width:t,height:t,depth:1},o=[a,a,a,a,a,a];this.texture=new tM(o),this._setTextureOptions(n),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(t,n){this.texture.type=n.type,this.texture.colorSpace=n.colorSpace,this.texture.generateMipmaps=n.generateMipmaps,this.texture.minFilter=n.minFilter,this.texture.magFilter=n.magFilter;const a={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},o=new Qa(5,5,5),c=new ui({name:"CubemapFromEquirect",uniforms:go(a.uniforms),vertexShader:a.vertexShader,fragmentShader:a.fragmentShader,side:vi,blending:Ya});c.uniforms.tEquirect.value=n;const u=new le(o,c),h=n.minFilter;return n.minFilter===Qs&&(n.minFilter=Wn),new Vb(1,10,this).update(t,u),n.minFilter=h,u.geometry.dispose(),u.material.dispose(),this}clear(t,n=!0,a=!0,o=!0){const c=t.getRenderTarget();for(let u=0;u<6;u++)t.setRenderTarget(this,u),t.clear(n,a,o);t.setRenderTarget(c)}}function F2(s){let t=new WeakMap,n=new WeakMap,a=null;function o(_,x=!1){return _==null?null:x?u(_):c(_)}function c(_){if(_&&_.isTexture){const x=_.mapping;if(x===id||x===ad)if(t.has(_)){const b=t.get(_).texture;return h(b,_.mapping)}else{const b=_.image;if(b&&b.height>0){const R=new gM(b.height);return R.fromEquirectangularTexture(s,_),t.set(_,R),_.addEventListener("dispose",d),h(R.texture,_.mapping)}else return null}}return _}function u(_){if(_&&_.isTexture){const x=_.mapping,b=x===id||x===ad,R=x===nr||x===ho;if(b||R){let y=n.get(_);const M=y!==void 0?y.texture.pmremVersion:0;if(_.isRenderTargetTexture&&_.pmremVersion!==M)return a===null&&(a=new Z_(s)),y=b?a.fromEquirectangular(_,y):a.fromCubemap(_,y),y.texture.pmremVersion=_.pmremVersion,n.set(_,y),y.texture;if(y!==void 0)return y.texture;{const C=_.image;return b&&C&&C.height>0||R&&C&&p(C)?(a===null&&(a=new Z_(s)),y=b?a.fromEquirectangular(_):a.fromCubemap(_),y.texture.pmremVersion=_.pmremVersion,n.set(_,y),_.addEventListener("dispose",g),y.texture):null}}}return _}function h(_,x){return x===id?_.mapping=nr:x===ad&&(_.mapping=ho),_}function p(_){let x=0;const b=6;for(let R=0;R<b;R++)_[R]!==void 0&&x++;return x===b}function d(_){const x=_.target;x.removeEventListener("dispose",d);const b=t.get(x);b!==void 0&&(t.delete(x),b.dispose())}function g(_){const x=_.target;x.removeEventListener("dispose",g);const b=n.get(x);b!==void 0&&(n.delete(x),b.dispose())}function v(){t=new WeakMap,n=new WeakMap,a!==null&&(a.dispose(),a=null)}return{get:o,dispose:v}}function H2(s){const t={};function n(a){if(t[a]!==void 0)return t[a];const o=s.getExtension(a);return t[a]=o,o}return{has:function(a){return n(a)!==null},init:function(){n("EXT_color_buffer_float"),n("WEBGL_clip_cull_distance"),n("OES_texture_float_linear"),n("EXT_color_buffer_half_float"),n("WEBGL_multisampled_render_to_texture"),n("WEBGL_render_shared_exponent")},get:function(a){const o=n(a);return o===null&&uo("WebGLRenderer: "+a+" extension not supported."),o}}}function G2(s,t,n,a){const o={},c=new WeakMap;function u(v){const _=v.target;_.index!==null&&t.remove(_.index);for(const b in _.attributes)t.remove(_.attributes[b]);_.removeEventListener("dispose",u),delete o[_.id];const x=c.get(_);x&&(t.remove(x),c.delete(_)),a.releaseStatesOfGeometry(_),_.isInstancedBufferGeometry===!0&&delete _._maxInstanceCount,n.memory.geometries--}function h(v,_){return o[_.id]===!0||(_.addEventListener("dispose",u),o[_.id]=!0,n.memory.geometries++),_}function p(v){const _=v.attributes;for(const x in _)t.update(_[x],s.ARRAY_BUFFER)}function d(v){const _=[],x=v.index,b=v.attributes.position;let R=0;if(b===void 0)return;if(x!==null){const C=x.array;R=x.version;for(let P=0,E=C.length;P<E;P+=3){const U=C[P+0],L=C[P+1],N=C[P+2];_.push(U,L,L,N,N,U)}}else{const C=b.array;R=b.version;for(let P=0,E=C.length/3-1;P<E;P+=3){const U=P+0,L=P+1,N=P+2;_.push(U,L,L,N,N,U)}}const y=new(b.count>=65535?Qx:Jx)(_,1);y.version=R;const M=c.get(v);M&&t.remove(M),c.set(v,y)}function g(v){const _=c.get(v);if(_){const x=v.index;x!==null&&_.version<x.version&&d(v)}else d(v);return c.get(v)}return{get:h,update:p,getWireframeAttribute:g}}function V2(s,t,n){let a;function o(v){a=v}let c,u;function h(v){c=v.type,u=v.bytesPerElement}function p(v,_){s.drawElements(a,_,c,v*u),n.update(_,a,1)}function d(v,_,x){x!==0&&(s.drawElementsInstanced(a,_,c,v*u,x),n.update(_,a,x))}function g(v,_,x){if(x===0)return;t.get("WEBGL_multi_draw").multiDrawElementsWEBGL(a,_,0,c,v,0,x);let R=0;for(let y=0;y<x;y++)R+=_[y];n.update(R,a,1)}this.setMode=o,this.setIndex=h,this.render=p,this.renderInstances=d,this.renderMultiDraw=g}function k2(s){const t={geometries:0,textures:0},n={frame:0,calls:0,triangles:0,points:0,lines:0};function a(c,u,h){switch(n.calls++,u){case s.TRIANGLES:n.triangles+=h*(c/3);break;case s.LINES:n.lines+=h*(c/2);break;case s.LINE_STRIP:n.lines+=h*(c-1);break;case s.LINE_LOOP:n.lines+=h*c;break;case s.POINTS:n.points+=h*c;break;default:Je("WebGLInfo: Unknown draw mode:",u);break}}function o(){n.calls=0,n.triangles=0,n.points=0,n.lines=0}return{memory:t,render:n,programs:null,autoReset:!0,reset:o,update:a}}function X2(s,t,n){const a=new WeakMap,o=new _n;function c(u,h,p){const d=u.morphTargetInfluences,g=h.morphAttributes.position||h.morphAttributes.normal||h.morphAttributes.color,v=g!==void 0?g.length:0;let _=a.get(h);if(_===void 0||_.count!==v){let W=function(){T.dispose(),a.delete(h),h.removeEventListener("dispose",W)};var x=W;_!==void 0&&_.texture.dispose();const b=h.morphAttributes.position!==void 0,R=h.morphAttributes.normal!==void 0,y=h.morphAttributes.color!==void 0,M=h.morphAttributes.position||[],C=h.morphAttributes.normal||[],P=h.morphAttributes.color||[];let E=0;b===!0&&(E=1),R===!0&&(E=2),y===!0&&(E=3);let U=h.attributes.position.count*E,L=1;U>t.maxTextureSize&&(L=Math.ceil(U/t.maxTextureSize),U=t.maxTextureSize);const N=new Float32Array(U*L*4*v),T=new Zx(N,U,L,v);T.type=oa,T.needsUpdate=!0;const z=E*4;for(let J=0;J<v;J++){const $=M[J],lt=C[J],X=P[J],k=U*L*4*J;for(let H=0;H<$.count;H++){const Y=H*z;b===!0&&(o.fromBufferAttribute($,H),N[k+Y+0]=o.x,N[k+Y+1]=o.y,N[k+Y+2]=o.z,N[k+Y+3]=0),R===!0&&(o.fromBufferAttribute(lt,H),N[k+Y+4]=o.x,N[k+Y+5]=o.y,N[k+Y+6]=o.z,N[k+Y+7]=0),y===!0&&(o.fromBufferAttribute(X,H),N[k+Y+8]=o.x,N[k+Y+9]=o.y,N[k+Y+10]=o.z,N[k+Y+11]=X.itemSize===4?o.w:1)}}_={count:v,texture:T,size:new Ot(U,L)},a.set(h,_),h.addEventListener("dispose",W)}if(u.isInstancedMesh===!0&&u.morphTexture!==null)p.getUniforms().setValue(s,"morphTexture",u.morphTexture,n);else{let b=0;for(let y=0;y<d.length;y++)b+=d[y];const R=h.morphTargetsRelative?1:1-b;p.getUniforms().setValue(s,"morphTargetBaseInfluence",R),p.getUniforms().setValue(s,"morphTargetInfluences",d)}p.getUniforms().setValue(s,"morphTargetsTexture",_.texture,n),p.getUniforms().setValue(s,"morphTargetsTextureSize",_.size)}return{update:c}}function W2(s,t,n,a,o){let c=new WeakMap;function u(d){const g=o.render.frame,v=d.geometry,_=t.get(d,v);if(c.get(_)!==g&&(t.update(_),c.set(_,g)),d.isInstancedMesh&&(d.hasEventListener("dispose",p)===!1&&d.addEventListener("dispose",p),c.get(d)!==g&&(n.update(d.instanceMatrix,s.ARRAY_BUFFER),d.instanceColor!==null&&n.update(d.instanceColor,s.ARRAY_BUFFER),c.set(d,g))),d.isSkinnedMesh){const x=d.skeleton;c.get(x)!==g&&(x.update(),c.set(x,g))}return _}function h(){c=new WeakMap}function p(d){const g=d.target;g.removeEventListener("dispose",p),a.releaseStatesOfObject(g),n.remove(g.instanceMatrix),g.instanceColor!==null&&n.remove(g.instanceColor)}return{update:u,dispose:h}}const q2={[Nx]:"LINEAR_TONE_MAPPING",[Ox]:"REINHARD_TONE_MAPPING",[Px]:"CINEON_TONE_MAPPING",[qp]:"ACES_FILMIC_TONE_MAPPING",[Ix]:"AGX_TONE_MAPPING",[Bx]:"NEUTRAL_TONE_MAPPING",[zx]:"CUSTOM_TONE_MAPPING"};function Y2(s,t,n,a,o,c){const u=new Bi(t,n,{type:s,depthBuffer:o,stencilBuffer:c,samples:a?4:0,storeMultisampledDepthBuffer:!1,storeMultisampledStencilBuffer:!1,resolveDepthBuffer:!1,resolveStencilBuffer:!1});let h=null,p=null;const d=new Ie;d.setAttribute("position",new ae([-1,3,0,-1,-1,0,3,-1,0],3)),d.setAttribute("uv",new ae([0,2,0,0,2,0],2));const g=new Ib({uniforms:{tDiffuse:{value:null}},vertexShader:`
			precision highp float;

			uniform mat4 modelViewMatrix;
			uniform mat4 projectionMatrix;

			attribute vec3 position;
			attribute vec2 uv;

			varying vec2 vUv;

			void main() {
				vUv = uv;
				gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
			}`,fragmentShader:`
			precision highp float;

			uniform sampler2D tDiffuse;

			varying vec2 vUv;

			#include <tonemapping_pars_fragment>
			#include <colorspace_pars_fragment>

			void main() {
				gl_FragColor = texture2D( tDiffuse, vUv );

				#ifdef LINEAR_TONE_MAPPING
					gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );
				#elif defined( REINHARD_TONE_MAPPING )
					gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );
				#elif defined( CINEON_TONE_MAPPING )
					gl_FragColor.rgb = CineonToneMapping( gl_FragColor.rgb );
				#elif defined( ACES_FILMIC_TONE_MAPPING )
					gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );
				#elif defined( AGX_TONE_MAPPING )
					gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );
				#elif defined( NEUTRAL_TONE_MAPPING )
					gl_FragColor.rgb = NeutralToneMapping( gl_FragColor.rgb );
				#elif defined( CUSTOM_TONE_MAPPING )
					gl_FragColor.rgb = CustomToneMapping( gl_FragColor.rgb );
				#endif

				#ifdef SRGB_TRANSFER
					gl_FragColor = sRGBTransferOETF( gl_FragColor );
				#endif
			}`,depthTest:!1,depthWrite:!1}),v=new le(d,g),_=new cm(-1,1,1,-1,0,1);let x=null,b=null,R=!1,y,M=null,C=[],P=!1;this.setSize=function(E,U){u.setSize(E,U),h!==null&&h.setSize(E,U),p!==null&&p.setSize(E,U);for(let L=0;L<C.length;L++){const N=C[L];N.setSize&&N.setSize(E,U)}},this.setEffects=function(E){C=E,P=C.length>0&&C[0].isRenderPass===!0;const U=u.width,L=u.height;C.length>0&&h===null&&(h=new Bi(U,L,{type:ji,depthBuffer:!1,stencilBuffer:!1}),p=new Bi(U,L,{type:ji,depthBuffer:!1,stencilBuffer:!1}));for(let N=0;N<C.length;N++){const T=C[N];T.setSize&&T.setSize(U,L)}},this.begin=function(E,U){if(R||E.toneMapping===xa&&C.length===0)return!1;if(M=U,U!==null){const L=U.width,N=U.height;(u.width!==L||u.height!==N)&&this.setSize(L,N)}return P===!1&&E.setRenderTarget(u),y=E.toneMapping,E.toneMapping=xa,!0},this.hasRenderPass=function(){return P},this.end=function(E,U){E.toneMapping=y,R=!0;let L=u,N=h;for(let T=0;T<C.length;T++){const z=C[T];z.enabled!==!1&&(z.render(E,N,L,U),z.needsSwap!==!1&&(L=N,N=N===h?p:h))}if(x!==E.outputColorSpace||b!==E.toneMapping){x=E.outputColorSpace,b=E.toneMapping,g.defines={},qe.getTransfer(x)===on&&(g.defines.SRGB_TRANSFER="");const T=q2[b];T&&(g.defines[T]=""),g.needsUpdate=!0}g.uniforms.tDiffuse.value=L.texture,E.setRenderTarget(M),E.render(v,_),M=null,R=!1},this.isCompositing=function(){return R},this.dispose=function(){u.dispose(),h!==null&&h.dispose(),p!==null&&p.dispose(),d.dispose(),g.dispose()}}const vM=new $n,Bp=new po(1,1),_M=new Zx,xM=new z1,MM=new tM,j_=[],$_=[],tx=new Float32Array(16),ex=new Float32Array(9),nx=new Float32Array(4);function xo(s,t,n){const a=s[0];if(a<=0||a>0)return s;const o=t*n;let c=j_[o];if(c===void 0&&(c=new Float32Array(o),j_[o]=c),t!==0){a.toArray(c,0);for(let u=1,h=0;u!==t;++u)h+=n,s[u].toArray(c,h)}return c}function qn(s,t){if(s.length!==t.length)return!1;for(let n=0,a=s.length;n<a;n++)if(s[n]!==t[n])return!1;return!0}function Yn(s,t){for(let n=0,a=t.length;n<a;n++)s[n]=t[n]}function Ju(s,t){let n=$_[t];n===void 0&&(n=new Int32Array(t),$_[t]=n);for(let a=0;a!==t;++a)n[a]=s.allocateTextureUnit();return n}function Z2(s,t){const n=this.cache;n[0]!==t&&(s.uniform1f(this.addr,t),n[0]=t)}function K2(s,t){const n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y)&&(s.uniform2f(this.addr,t.x,t.y),n[0]=t.x,n[1]=t.y);else{if(qn(n,t))return;s.uniform2fv(this.addr,t),Yn(n,t)}}function J2(s,t){const n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z)&&(s.uniform3f(this.addr,t.x,t.y,t.z),n[0]=t.x,n[1]=t.y,n[2]=t.z);else if(t.r!==void 0)(n[0]!==t.r||n[1]!==t.g||n[2]!==t.b)&&(s.uniform3f(this.addr,t.r,t.g,t.b),n[0]=t.r,n[1]=t.g,n[2]=t.b);else{if(qn(n,t))return;s.uniform3fv(this.addr,t),Yn(n,t)}}function Q2(s,t){const n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z||n[3]!==t.w)&&(s.uniform4f(this.addr,t.x,t.y,t.z,t.w),n[0]=t.x,n[1]=t.y,n[2]=t.z,n[3]=t.w);else{if(qn(n,t))return;s.uniform4fv(this.addr,t),Yn(n,t)}}function j2(s,t){const n=this.cache,a=t.elements;if(a===void 0){if(qn(n,t))return;s.uniformMatrix2fv(this.addr,!1,t),Yn(n,t)}else{if(qn(n,a))return;nx.set(a),s.uniformMatrix2fv(this.addr,!1,nx),Yn(n,a)}}function $2(s,t){const n=this.cache,a=t.elements;if(a===void 0){if(qn(n,t))return;s.uniformMatrix3fv(this.addr,!1,t),Yn(n,t)}else{if(qn(n,a))return;ex.set(a),s.uniformMatrix3fv(this.addr,!1,ex),Yn(n,a)}}function tA(s,t){const n=this.cache,a=t.elements;if(a===void 0){if(qn(n,t))return;s.uniformMatrix4fv(this.addr,!1,t),Yn(n,t)}else{if(qn(n,a))return;tx.set(a),s.uniformMatrix4fv(this.addr,!1,tx),Yn(n,a)}}function eA(s,t){const n=this.cache;n[0]!==t&&(s.uniform1i(this.addr,t),n[0]=t)}function nA(s,t){const n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y)&&(s.uniform2i(this.addr,t.x,t.y),n[0]=t.x,n[1]=t.y);else{if(qn(n,t))return;s.uniform2iv(this.addr,t),Yn(n,t)}}function iA(s,t){const n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z)&&(s.uniform3i(this.addr,t.x,t.y,t.z),n[0]=t.x,n[1]=t.y,n[2]=t.z);else{if(qn(n,t))return;s.uniform3iv(this.addr,t),Yn(n,t)}}function aA(s,t){const n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z||n[3]!==t.w)&&(s.uniform4i(this.addr,t.x,t.y,t.z,t.w),n[0]=t.x,n[1]=t.y,n[2]=t.z,n[3]=t.w);else{if(qn(n,t))return;s.uniform4iv(this.addr,t),Yn(n,t)}}function sA(s,t){const n=this.cache;n[0]!==t&&(s.uniform1ui(this.addr,t),n[0]=t)}function rA(s,t){const n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y)&&(s.uniform2ui(this.addr,t.x,t.y),n[0]=t.x,n[1]=t.y);else{if(qn(n,t))return;s.uniform2uiv(this.addr,t),Yn(n,t)}}function oA(s,t){const n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z)&&(s.uniform3ui(this.addr,t.x,t.y,t.z),n[0]=t.x,n[1]=t.y,n[2]=t.z);else{if(qn(n,t))return;s.uniform3uiv(this.addr,t),Yn(n,t)}}function lA(s,t){const n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z||n[3]!==t.w)&&(s.uniform4ui(this.addr,t.x,t.y,t.z,t.w),n[0]=t.x,n[1]=t.y,n[2]=t.z,n[3]=t.w);else{if(qn(n,t))return;s.uniform4uiv(this.addr,t),Yn(n,t)}}function cA(s,t,n){const a=this.cache,o=n.allocateTextureUnit();a[0]!==o&&(s.uniform1i(this.addr,o),a[0]=o);let c;this.type===s.SAMPLER_2D_SHADOW?(Bp.compareFunction=n.isReversedDepthBuffer()?Vu:Gu,c=Bp):c=vM,n.setTexture2D(t||c,o)}function uA(s,t,n){const a=this.cache,o=n.allocateTextureUnit();a[0]!==o&&(s.uniform1i(this.addr,o),a[0]=o),n.setTexture3D(t||xM,o)}function fA(s,t,n){const a=this.cache,o=n.allocateTextureUnit();a[0]!==o&&(s.uniform1i(this.addr,o),a[0]=o),n.setTextureCube(t||MM,o)}function hA(s,t,n){const a=this.cache,o=n.allocateTextureUnit();a[0]!==o&&(s.uniform1i(this.addr,o),a[0]=o),n.setTexture2DArray(t||_M,o)}function dA(s){switch(s){case 5126:return Z2;case 35664:return K2;case 35665:return J2;case 35666:return Q2;case 35674:return j2;case 35675:return $2;case 35676:return tA;case 5124:case 35670:return eA;case 35667:case 35671:return nA;case 35668:case 35672:return iA;case 35669:case 35673:return aA;case 5125:return sA;case 36294:return rA;case 36295:return oA;case 36296:return lA;case 35678:case 36198:case 36298:case 36306:case 35682:return cA;case 35679:case 36299:case 36307:return uA;case 35680:case 36300:case 36308:case 36293:return fA;case 36289:case 36303:case 36311:case 36292:return hA}}function pA(s,t){s.uniform1fv(this.addr,t)}function mA(s,t){const n=xo(t,this.size,2);s.uniform2fv(this.addr,n)}function gA(s,t){const n=xo(t,this.size,3);s.uniform3fv(this.addr,n)}function vA(s,t){const n=xo(t,this.size,4);s.uniform4fv(this.addr,n)}function _A(s,t){const n=xo(t,this.size,4);s.uniformMatrix2fv(this.addr,!1,n)}function xA(s,t){const n=xo(t,this.size,9);s.uniformMatrix3fv(this.addr,!1,n)}function MA(s,t){const n=xo(t,this.size,16);s.uniformMatrix4fv(this.addr,!1,n)}function yA(s,t){s.uniform1iv(this.addr,t)}function SA(s,t){s.uniform2iv(this.addr,t)}function bA(s,t){s.uniform3iv(this.addr,t)}function EA(s,t){s.uniform4iv(this.addr,t)}function TA(s,t){s.uniform1uiv(this.addr,t)}function AA(s,t){s.uniform2uiv(this.addr,t)}function wA(s,t){s.uniform3uiv(this.addr,t)}function RA(s,t){s.uniform4uiv(this.addr,t)}function CA(s,t,n){const a=this.cache,o=t.length,c=Ju(n,o);qn(a,c)||(s.uniform1iv(this.addr,c),Yn(a,c));let u;this.type===s.SAMPLER_2D_SHADOW?u=Bp:u=vM;for(let h=0;h!==o;++h)n.setTexture2D(t[h]||u,c[h])}function DA(s,t,n){const a=this.cache,o=t.length,c=Ju(n,o);qn(a,c)||(s.uniform1iv(this.addr,c),Yn(a,c));for(let u=0;u!==o;++u)n.setTexture3D(t[u]||xM,c[u])}function UA(s,t,n){const a=this.cache,o=t.length,c=Ju(n,o);qn(a,c)||(s.uniform1iv(this.addr,c),Yn(a,c));for(let u=0;u!==o;++u)n.setTextureCube(t[u]||MM,c[u])}function LA(s,t,n){const a=this.cache,o=t.length,c=Ju(n,o);qn(a,c)||(s.uniform1iv(this.addr,c),Yn(a,c));for(let u=0;u!==o;++u)n.setTexture2DArray(t[u]||_M,c[u])}function NA(s){switch(s){case 5126:return pA;case 35664:return mA;case 35665:return gA;case 35666:return vA;case 35674:return _A;case 35675:return xA;case 35676:return MA;case 5124:case 35670:return yA;case 35667:case 35671:return SA;case 35668:case 35672:return bA;case 35669:case 35673:return EA;case 5125:return TA;case 36294:return AA;case 36295:return wA;case 36296:return RA;case 35678:case 36198:case 36298:case 36306:case 35682:return CA;case 35679:case 36299:case 36307:return DA;case 35680:case 36300:case 36308:case 36293:return UA;case 36289:case 36303:case 36311:case 36292:return LA}}class OA{constructor(t,n,a){this.id=t,this.addr=a,this.cache=[],this.type=n.type,this.setValue=dA(n.type)}}class PA{constructor(t,n,a){this.id=t,this.addr=a,this.cache=[],this.type=n.type,this.size=n.size,this.setValue=NA(n.type)}}class zA{constructor(t){this.id=t,this.seq=[],this.map={}}setValue(t,n,a){const o=this.seq;for(let c=0,u=o.length;c!==u;++c){const h=o[c];h.setValue(t,n[h.id],a)}}}const zd=/(\w+)(\])?(\[|\.)?/g;function ix(s,t){s.seq.push(t),s.map[t.id]=t}function IA(s,t,n){const a=s.name,o=a.length;for(zd.lastIndex=0;;){const c=zd.exec(a),u=zd.lastIndex;let h=c[1];const p=c[2]==="]",d=c[3];if(p&&(h=h|0),d===void 0||d==="["&&u+2===o){ix(n,d===void 0?new OA(h,s,t):new PA(h,s,t));break}else{let v=n.map[h];v===void 0&&(v=new zA(h),ix(n,v)),n=v}}}class Ru{constructor(t,n){this.seq=[],this.map={};const a=t.getProgramParameter(n,t.ACTIVE_UNIFORMS);for(let u=0;u<a;++u){const h=t.getActiveUniform(n,u),p=t.getUniformLocation(n,h.name);IA(h,p,this)}const o=[],c=[];for(const u of this.seq)u.type===t.SAMPLER_2D_SHADOW||u.type===t.SAMPLER_CUBE_SHADOW||u.type===t.SAMPLER_2D_ARRAY_SHADOW?o.push(u):c.push(u);o.length>0&&(this.seq=o.concat(c))}setValue(t,n,a,o){const c=this.map[n];c!==void 0&&c.setValue(t,a,o)}setOptional(t,n,a){const o=n[a];o!==void 0&&this.setValue(t,a,o)}static upload(t,n,a,o){for(let c=0,u=n.length;c!==u;++c){const h=n[c],p=a[h.id];p.needsUpdate!==!1&&h.setValue(t,p.value,o)}}static seqWithValue(t,n){const a=[];for(let o=0,c=t.length;o!==c;++o){const u=t[o];u.id in n&&a.push(u)}return a}}function ax(s,t,n){const a=s.createShader(t);return s.shaderSource(a,n),s.compileShader(a),a}const BA=37297;let FA=0;function HA(s,t){const n=s.split(`
`),a=[],o=Math.max(t-6,0),c=Math.min(t+6,n.length);for(let u=o;u<c;u++){const h=u+1;a.push(`${h===t?">":" "} ${h}: ${n[u]}`)}return a.join(`
`)}const sx=new we;function GA(s){qe._getMatrix(sx,qe.workingColorSpace,s);const t=`mat3( ${sx.elements.map(n=>n.toFixed(4))} )`;switch(qe.getTransfer(s)){case Nu:return[t,"LinearTransferOETF"];case on:return[t,"sRGBTransferOETF"];default:return ye("WebGLProgram: Unsupported color space: ",s),[t,"LinearTransferOETF"]}}function rx(s,t,n){const a=s.getShaderParameter(t,s.COMPILE_STATUS),c=(s.getShaderInfoLog(t)||"").trim();if(a&&c==="")return"";const u=/ERROR: 0:(\d+)/.exec(c);if(u){const h=parseInt(u[1]);return n.toUpperCase()+`

`+c+`

`+HA(s.getShaderSource(t),h)}else return c}function VA(s,t){const n=GA(t);return[`vec4 ${s}( vec4 value ) {`,`	return ${n[1]}( vec4( value.rgb * ${n[0]}, value.a ) );`,"}"].join(`
`)}const kA={[Nx]:"Linear",[Ox]:"Reinhard",[Px]:"Cineon",[qp]:"ACESFilmic",[Ix]:"AgX",[Bx]:"Neutral",[zx]:"Custom"};function XA(s,t){const n=kA[t];return n===void 0?(ye("WebGLProgram: Unsupported toneMapping:",t),"vec3 "+s+"( vec3 color ) { return LinearToneMapping( color ); }"):"vec3 "+s+"( vec3 color ) { return "+n+"ToneMapping( color ); }"}const bu=new B;function WA(){qe.getLuminanceCoefficients(bu);const s=bu.x.toFixed(4),t=bu.y.toFixed(4),n=bu.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${s}, ${t}, ${n} );`,"	return dot( weights, rgb );","}"].join(`
`)}function qA(s){return[s.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",s.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(Ml).join(`
`)}function YA(s){const t=[];for(const n in s){const a=s[n];a!==!1&&t.push("#define "+n+" "+a)}return t.join(`
`)}function ZA(s,t){const n={},a=s.getProgramParameter(t,s.ACTIVE_ATTRIBUTES);for(let o=0;o<a;o++){const c=s.getActiveAttrib(t,o),u=c.name;let h=1;c.type===s.FLOAT_MAT2&&(h=2),c.type===s.FLOAT_MAT3&&(h=3),c.type===s.FLOAT_MAT4&&(h=4),n[u]={type:c.type,location:s.getAttribLocation(t,u),locationSize:h}}return n}function Ml(s){return s!==""}function ox(s,t){const n=t.numSpotLightShadows+t.numSpotLightMaps-t.numSpotLightShadowsWithMaps;return s.replace(/NUM_SUN_LIGHTS/g,t.numSunLights).replace(/NUM_DIR_LIGHTS/g,t.numDirLights).replace(/NUM_SPOT_LIGHTS/g,t.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,t.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,n).replace(/NUM_RECT_AREA_LIGHTS/g,t.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,t.numPointLights).replace(/NUM_HEMI_LIGHTS/g,t.numHemiLights).replace(/NUM_SUN_LIGHT_SHADOWS/g,t.numSunLightShadows).replace(/NUM_DIR_LIGHT_SHADOWS/g,t.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,t.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,t.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,t.numPointLightShadows)}function lx(s,t){return s.replace(/NUM_CLIPPING_PLANES/g,t.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,t.numClippingPlanes-t.numClipIntersection)}const KA=/^[ \t]*#include +<([\w\d./]+)>/gm;function Fp(s){return s.replace(KA,QA)}const JA=new Map;function QA(s,t){let n=Pe[t];if(n===void 0){const a=JA.get(t);if(a!==void 0)n=Pe[a],ye('WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',t,a);else throw new Error("THREE.WebGLProgram: Can not resolve #include <"+t+">")}return Fp(n)}const jA=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function cx(s){return s.replace(jA,$A)}function $A(s,t,n,a){let o="";for(let c=parseInt(t);c<parseInt(n);c++)o+=a.replace(/\[\s*i\s*\]/g,"[ "+c+" ]").replace(/UNROLLED_LOOP_INDEX/g,c);return o}function ux(s){let t=`precision ${s.precision} float;
	precision ${s.precision} int;
	precision ${s.precision} sampler2D;
	precision ${s.precision} samplerCube;
	precision ${s.precision} sampler3D;
	precision ${s.precision} sampler2DArray;
	precision ${s.precision} sampler2DShadow;
	precision ${s.precision} samplerCubeShadow;
	precision ${s.precision} sampler2DArrayShadow;
	precision ${s.precision} isampler2D;
	precision ${s.precision} isampler3D;
	precision ${s.precision} isamplerCube;
	precision ${s.precision} isampler2DArray;
	precision ${s.precision} usampler2D;
	precision ${s.precision} usampler3D;
	precision ${s.precision} usamplerCube;
	precision ${s.precision} usampler2DArray;
	`;return s.precision==="highp"?t+=`
#define HIGH_PRECISION`:s.precision==="mediump"?t+=`
#define MEDIUM_PRECISION`:s.precision==="lowp"&&(t+=`
#define LOW_PRECISION`),t}const t3={[yl]:"SHADOWMAP_TYPE_PCF",[_l]:"SHADOWMAP_TYPE_VSM"};function e3(s){return t3[s.shadowMapType]||"SHADOWMAP_TYPE_BASIC"}const n3={[nr]:"ENVMAP_TYPE_CUBE",[ho]:"ENVMAP_TYPE_CUBE",[Hu]:"ENVMAP_TYPE_CUBE_UV"};function i3(s){return s.envMap===!1?"ENVMAP_TYPE_CUBE":n3[s.envMapMode]||"ENVMAP_TYPE_CUBE"}const a3={[ho]:"ENVMAP_MODE_REFRACTION"};function s3(s){return s.envMap===!1?"ENVMAP_MODE_REFLECTION":a3[s.envMapMode]||"ENVMAP_MODE_REFLECTION"}const r3={[Lx]:"ENVMAP_BLENDING_MULTIPLY",[$S]:"ENVMAP_BLENDING_MIX",[t1]:"ENVMAP_BLENDING_ADD"};function o3(s){return s.envMap===!1?"ENVMAP_BLENDING_NONE":r3[s.combine]||"ENVMAP_BLENDING_NONE"}function l3(s){const t=s.envMapCubeUVHeight;if(t===null)return null;const n=Math.log2(t)-2,a=1/t;return{texelWidth:1/(3*Math.max(Math.pow(2,n),112)),texelHeight:a,maxMip:n}}function c3(s,t,n,a){const o=s.getContext(),c=n.defines;let u=n.vertexShader,h=n.fragmentShader;const p=e3(n),d=i3(n),g=s3(n),v=o3(n),_=l3(n),x=qA(n),b=YA(c),R=o.createProgram();let y,M,C=n.glslVersion?"#version "+n.glslVersion+`
`:"";n.isRawShaderMaterial?(y=["#define SHADER_TYPE "+n.shaderType,"#define SHADER_NAME "+n.shaderName,b].filter(Ml).join(`
`),y.length>0&&(y+=`
`),M=["#define SHADER_TYPE "+n.shaderType,"#define SHADER_NAME "+n.shaderName,b].filter(Ml).join(`
`),M.length>0&&(M+=`
`)):(y=[ux(n),"#define SHADER_TYPE "+n.shaderType,"#define SHADER_NAME "+n.shaderName,b,n.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",n.batching?"#define USE_BATCHING":"",n.batchingColor?"#define USE_BATCHING_COLOR":"",n.instancing?"#define USE_INSTANCING":"",n.instancingColor?"#define USE_INSTANCING_COLOR":"",n.instancingMorph?"#define USE_INSTANCING_MORPH":"",n.useFog&&n.fog?"#define USE_FOG":"",n.useFog&&n.fogExp2?"#define FOG_EXP2":"",n.map?"#define USE_MAP":"",n.envMap?"#define USE_ENVMAP":"",n.envMap?"#define "+g:"",n.lightMap?"#define USE_LIGHTMAP":"",n.aoMap?"#define USE_AOMAP":"",n.bumpMap?"#define USE_BUMPMAP":"",n.normalMap?"#define USE_NORMALMAP":"",n.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",n.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",n.displacementMap?"#define USE_DISPLACEMENTMAP":"",n.emissiveMap?"#define USE_EMISSIVEMAP":"",n.anisotropy?"#define USE_ANISOTROPY":"",n.anisotropyMap?"#define USE_ANISOTROPYMAP":"",n.clearcoatMap?"#define USE_CLEARCOATMAP":"",n.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",n.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",n.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",n.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",n.specularMap?"#define USE_SPECULARMAP":"",n.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",n.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",n.roughnessMap?"#define USE_ROUGHNESSMAP":"",n.metalnessMap?"#define USE_METALNESSMAP":"",n.alphaMap?"#define USE_ALPHAMAP":"",n.alphaHash?"#define USE_ALPHAHASH":"",n.transmission?"#define USE_TRANSMISSION":"",n.transmissionMap?"#define USE_TRANSMISSIONMAP":"",n.thicknessMap?"#define USE_THICKNESSMAP":"",n.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",n.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",n.mapUv?"#define MAP_UV "+n.mapUv:"",n.alphaMapUv?"#define ALPHAMAP_UV "+n.alphaMapUv:"",n.lightMapUv?"#define LIGHTMAP_UV "+n.lightMapUv:"",n.aoMapUv?"#define AOMAP_UV "+n.aoMapUv:"",n.emissiveMapUv?"#define EMISSIVEMAP_UV "+n.emissiveMapUv:"",n.bumpMapUv?"#define BUMPMAP_UV "+n.bumpMapUv:"",n.normalMapUv?"#define NORMALMAP_UV "+n.normalMapUv:"",n.displacementMapUv?"#define DISPLACEMENTMAP_UV "+n.displacementMapUv:"",n.metalnessMapUv?"#define METALNESSMAP_UV "+n.metalnessMapUv:"",n.roughnessMapUv?"#define ROUGHNESSMAP_UV "+n.roughnessMapUv:"",n.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+n.anisotropyMapUv:"",n.clearcoatMapUv?"#define CLEARCOATMAP_UV "+n.clearcoatMapUv:"",n.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+n.clearcoatNormalMapUv:"",n.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+n.clearcoatRoughnessMapUv:"",n.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+n.iridescenceMapUv:"",n.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+n.iridescenceThicknessMapUv:"",n.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+n.sheenColorMapUv:"",n.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+n.sheenRoughnessMapUv:"",n.specularMapUv?"#define SPECULARMAP_UV "+n.specularMapUv:"",n.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+n.specularColorMapUv:"",n.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+n.specularIntensityMapUv:"",n.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+n.transmissionMapUv:"",n.thicknessMapUv?"#define THICKNESSMAP_UV "+n.thicknessMapUv:"",n.vertexTangents&&n.flatShading===!1?"#define USE_TANGENT":"",n.vertexNormals?"#define HAS_NORMAL":"",n.vertexColors?"#define USE_COLOR":"",n.vertexAlphas?"#define USE_COLOR_ALPHA":"",n.vertexUv1s?"#define USE_UV1":"",n.vertexUv2s?"#define USE_UV2":"",n.vertexUv3s?"#define USE_UV3":"",n.pointsUvs?"#define USE_POINTS_UV":"",n.flatShading?"#define FLAT_SHADED":"",n.skinning?"#define USE_SKINNING":"",n.morphTargets?"#define USE_MORPHTARGETS":"",n.morphNormals&&n.flatShading===!1?"#define USE_MORPHNORMALS":"",n.morphColors?"#define USE_MORPHCOLORS":"",n.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+n.morphTextureStride:"",n.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+n.morphTargetsCount:"",n.doubleSided?"#define DOUBLE_SIDED":"",n.flipSided?"#define FLIP_SIDED":"",n.shadowMapEnabled?"#define USE_SHADOWMAP":"",n.shadowMapEnabled?"#define "+p:"",n.sizeAttenuation?"#define USE_SIZEATTENUATION":"",n.numLightProbes>0?"#define USE_LIGHT_PROBES":"",n.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",n.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(Ml).join(`
`),M=[ux(n),"#define SHADER_TYPE "+n.shaderType,"#define SHADER_NAME "+n.shaderName,b,n.useFog&&n.fog?"#define USE_FOG":"",n.useFog&&n.fogExp2?"#define FOG_EXP2":"",n.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",n.map?"#define USE_MAP":"",n.matcap?"#define USE_MATCAP":"",n.envMap?"#define USE_ENVMAP":"",n.envMap?"#define "+d:"",n.envMap?"#define "+g:"",n.envMap?"#define "+v:"",_?"#define CUBEUV_TEXEL_WIDTH "+_.texelWidth:"",_?"#define CUBEUV_TEXEL_HEIGHT "+_.texelHeight:"",_?"#define CUBEUV_MAX_MIP "+_.maxMip+".0":"",n.lightMap?"#define USE_LIGHTMAP":"",n.aoMap?"#define USE_AOMAP":"",n.bumpMap?"#define USE_BUMPMAP":"",n.normalMap?"#define USE_NORMALMAP":"",n.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",n.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",n.packedNormalMap?"#define USE_PACKED_NORMALMAP":"",n.emissiveMap?"#define USE_EMISSIVEMAP":"",n.anisotropy?"#define USE_ANISOTROPY":"",n.anisotropyMap?"#define USE_ANISOTROPYMAP":"",n.clearcoat?"#define USE_CLEARCOAT":"",n.clearcoatMap?"#define USE_CLEARCOATMAP":"",n.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",n.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",n.dispersion?"#define USE_DISPERSION":"",n.retroreflection?"#define USE_RETROREFLECTION":"",n.iridescence?"#define USE_IRIDESCENCE":"",n.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",n.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",n.specularMap?"#define USE_SPECULARMAP":"",n.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",n.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",n.roughnessMap?"#define USE_ROUGHNESSMAP":"",n.metalnessMap?"#define USE_METALNESSMAP":"",n.alphaMap?"#define USE_ALPHAMAP":"",n.alphaTest?"#define USE_ALPHATEST":"",n.alphaHash?"#define USE_ALPHAHASH":"",n.sheen?"#define USE_SHEEN":"",n.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",n.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",n.transmission?"#define USE_TRANSMISSION":"",n.transmissionMap?"#define USE_TRANSMISSIONMAP":"",n.thicknessMap?"#define USE_THICKNESSMAP":"",n.vertexTangents&&n.flatShading===!1?"#define USE_TANGENT":"",n.vertexColors||n.instancingColor?"#define USE_COLOR":"",n.vertexAlphas||n.batchingColor?"#define USE_COLOR_ALPHA":"",n.vertexUv1s?"#define USE_UV1":"",n.vertexUv2s?"#define USE_UV2":"",n.vertexUv3s?"#define USE_UV3":"",n.pointsUvs?"#define USE_POINTS_UV":"",n.gradientMap?"#define USE_GRADIENTMAP":"",n.flatShading?"#define FLAT_SHADED":"",n.doubleSided?"#define DOUBLE_SIDED":"",n.flipSided?"#define FLIP_SIDED":"",n.shadowMapEnabled?"#define USE_SHADOWMAP":"",n.shadowMapEnabled?"#define "+p:"",n.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",n.numLightProbes>0?"#define USE_LIGHT_PROBES":"",n.numLightProbeGrids>0?"#define USE_LIGHT_PROBES_GRID":"",n.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",n.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",n.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",n.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",n.toneMapping!==xa?"#define TONE_MAPPING":"",n.toneMapping!==xa?Pe.tonemapping_pars_fragment:"",n.toneMapping!==xa?XA("toneMapping",n.toneMapping):"",n.dithering?"#define DITHERING":"",n.opaque?"#define OPAQUE":"",Pe.colorspace_pars_fragment,VA("linearToOutputTexel",n.outputColorSpace),WA(),n.useDepthPacking?"#define DEPTH_PACKING "+n.depthPacking:"",`
`].filter(Ml).join(`
`)),u=Fp(u),u=ox(u,n),u=lx(u,n),h=Fp(h),h=ox(h,n),h=lx(h,n),u=cx(u),h=cx(h),n.isRawShaderMaterial!==!0&&(C=`#version 300 es
`,y=[x,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+y,M=["#define varying in",n.glslVersion===a_?"":"layout(location = 0) out highp vec4 pc_fragColor;",n.glslVersion===a_?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+M);const P=C+y+u,E=C+M+h,U=ax(o,o.VERTEX_SHADER,P),L=ax(o,o.FRAGMENT_SHADER,E);o.attachShader(R,U),o.attachShader(R,L),n.index0AttributeName!==void 0?o.bindAttribLocation(R,0,n.index0AttributeName):n.hasPositionAttribute===!0&&o.bindAttribLocation(R,0,"position"),o.linkProgram(R);function N(J){if(s.debug.checkShaderErrors){const $=o.getProgramInfoLog(R)||"",lt=o.getShaderInfoLog(U)||"",X=o.getShaderInfoLog(L)||"",k=$.trim(),H=lt.trim(),Y=X.trim();let it=!0,rt=!0;if(o.getProgramParameter(R,o.LINK_STATUS)===!1)if(it=!1,typeof s.debug.onShaderError=="function")s.debug.onShaderError(o,R,U,L);else{const ht=rx(o,U,"vertex"),I=rx(o,L,"fragment");Je("WebGLProgram: Shader Error "+o.getError()+" - VALIDATE_STATUS "+o.getProgramParameter(R,o.VALIDATE_STATUS)+`

Material Name: `+J.name+`
Material Type: `+J.type+`

Program Info Log: `+k+`
`+ht+`
`+I)}else k!==""?ye("WebGLProgram: Program Info Log:",k):(H===""||Y==="")&&(rt=!1);rt&&(J.diagnostics={runnable:it,programLog:k,vertexShader:{log:H,prefix:y},fragmentShader:{log:Y,prefix:M}})}o.deleteShader(U),o.deleteShader(L),T=new Ru(o,R),z=ZA(o,R)}let T;this.getUniforms=function(){return T===void 0&&N(this),T};let z;this.getAttributes=function(){return z===void 0&&N(this),z};let W=n.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return W===!1&&(W=o.getProgramParameter(R,BA)),W},this.destroy=function(){a.releaseStatesOfProgram(this),o.deleteProgram(R),this.program=void 0},this.type=n.shaderType,this.name=n.shaderName,this.id=FA++,this.cacheKey=t,this.usedTimes=1,this.program=R,this.vertexShader=U,this.fragmentShader=L,this}let u3=0;class f3{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(t,n,a){const o=this._getShaderCacheForMaterial(t);return o.has(n)===!1&&(o.add(n),n.usedTimes++),o.has(a)===!1&&(o.add(a),a.usedTimes++),this}remove(t){const n=this.materialCache.get(t);for(const a of n)a.usedTimes--,a.usedTimes===0&&this.shaderCache.delete(a.code);return this.materialCache.delete(t),this}getVertexShaderStage(t){return this._getShaderStage(t.vertexShader)}getFragmentShaderStage(t){return this._getShaderStage(t.fragmentShader)}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(t){const n=this.materialCache;let a=n.get(t);return a===void 0&&(a=new Set,n.set(t,a)),a}_getShaderStage(t){const n=this.shaderCache;let a=n.get(t);return a===void 0&&(a=new h3(t),n.set(t,a)),a}}class h3{constructor(t){this.id=u3++,this.code=t,this.usedTimes=0}}function d3(s){return s===ir||s===Du||s===Uu}function p3(s,t,n,a,o,c){const u=new nm,h=new f3,p=new Set,d=[],g=new Map,v=a.logarithmicDepthBuffer;let _=a.precision;const x={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distance",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function b(T){return p.add(T),T===0?"uv":`uv${T}`}function R(T,z,W,J,$,lt){const X=J.fog,k=$.geometry,H=T.isMeshStandardMaterial||T.isMeshLambertMaterial||T.isMeshPhongMaterial?J.environment:null,Y=T.isMeshStandardMaterial||T.isMeshLambertMaterial&&!T.envMap||T.isMeshPhongMaterial&&!T.envMap,it=t.get(T.envMap||H,Y),rt=it&&it.mapping===Hu?it.image.height:null,ht=x[T.type];T.precision!==null&&(_=a.getMaxPrecision(T.precision),_!==T.precision&&ye("WebGLProgram.getParameters:",T.precision,"not supported, using",_,"instead."));const I=k.morphAttributes.position||k.morphAttributes.normal||k.morphAttributes.color,ct=I!==void 0?I.length:0;let Tt=0;k.morphAttributes.position!==void 0&&(Tt=1),k.morphAttributes.normal!==void 0&&(Tt=2),k.morphAttributes.color!==void 0&&(Tt=3);let Ut,Vt,Bt,ft;if(ht){const te=va[ht];Ut=te.vertexShader,Vt=te.fragmentShader}else{Ut=T.vertexShader,Vt=T.fragmentShader;const te=h.getVertexShaderStage(T),se=h.getFragmentShaderStage(T);h.update(T,te,se),Bt=te.id,ft=se.id}const Et=s.getRenderTarget(),Ft=s.state.buffers.depth.getReversed(),$t=$.isInstancedMesh===!0,Xt=$.isBatchedMesh===!0,oe=!!T.map,Ye=!!T.matcap,jt=!!it,de=!!T.aoMap,xe=!!T.lightMap,pe=!!T.bumpMap&&T.wireframe===!1,Ce=!!T.normalMap,Xe=!!T.displacementMap,Be=!!T.emissiveMap,ie=!!T.metalnessMap,Ue=!!T.roughnessMap,j=T.anisotropy>0,Se=T.clearcoat>0,Ee=T.dispersion>0,F=T.retroreflectivity>0,A=T.iridescence>0,et=T.sheen>0,mt=T.transmission>0,Mt=j&&!!T.anisotropyMap,Ht=Se&&!!T.clearcoatMap,kt=Se&&!!T.clearcoatNormalMap,yt=Se&&!!T.clearcoatRoughnessMap,xt=A&&!!T.iridescenceMap,zt=A&&!!T.iridescenceThicknessMap,gt=et&&!!T.sheenColorMap,wt=et&&!!T.sheenRoughnessMap,Lt=!!T.specularMap,q=!!T.specularColorMap,Z=!!T.specularIntensityMap,at=mt&&!!T.transmissionMap,w=mt&&!!T.thicknessMap,G=!!T.gradientMap,V=!!T.alphaMap,nt=T.alphaTest>0,ot=!!T.alphaHash,st=!!T.extensions;let Ct=xa;T.toneMapped&&(Et===null||Et.isXRRenderTarget===!0)&&(Ct=s.toneMapping);const It={shaderID:ht,shaderType:T.type,shaderName:T.name,vertexShader:Ut,fragmentShader:Vt,defines:T.defines,customVertexShaderID:Bt,customFragmentShaderID:ft,isRawShaderMaterial:T.isRawShaderMaterial===!0,glslVersion:T.glslVersion,precision:_,batching:Xt,batchingColor:Xt&&$._colorsTexture!==null,instancing:$t,instancingColor:$t&&$.instanceColor!==null,instancingMorph:$t&&$.morphTexture!==null,outputColorSpace:Et===null?s.outputColorSpace:Et.isXRRenderTarget===!0?Et.texture.colorSpace:qe.workingColorSpace,alphaToCoverage:!!T.alphaToCoverage,map:oe,matcap:Ye,envMap:jt,envMapMode:jt&&it.mapping,envMapCubeUVHeight:rt,aoMap:de,lightMap:xe,bumpMap:pe,normalMap:Ce,displacementMap:Xe,emissiveMap:Be,normalMapObjectSpace:Ce&&T.normalMapType===i1,normalMapTangentSpace:Ce&&T.normalMapType===Up,packedNormalMap:Ce&&T.normalMapType===Up&&d3(T.normalMap.format),metalnessMap:ie,roughnessMap:Ue,anisotropy:j,anisotropyMap:Mt,clearcoat:Se,clearcoatMap:Ht,clearcoatNormalMap:kt,clearcoatRoughnessMap:yt,dispersion:Ee,retroreflection:F,iridescence:A,iridescenceMap:xt,iridescenceThicknessMap:zt,sheen:et,sheenColorMap:gt,sheenRoughnessMap:wt,specularMap:Lt,specularColorMap:q,specularIntensityMap:Z,transmission:mt,transmissionMap:at,thicknessMap:w,gradientMap:G,opaque:T.transparent===!1&&T.blending===Sl&&T.alphaToCoverage===!1,alphaMap:V,alphaTest:nt,alphaHash:ot,combine:T.combine,mapUv:oe&&b(T.map.channel),aoMapUv:de&&b(T.aoMap.channel),lightMapUv:xe&&b(T.lightMap.channel),bumpMapUv:pe&&b(T.bumpMap.channel),normalMapUv:Ce&&b(T.normalMap.channel),displacementMapUv:Xe&&b(T.displacementMap.channel),emissiveMapUv:Be&&b(T.emissiveMap.channel),metalnessMapUv:ie&&b(T.metalnessMap.channel),roughnessMapUv:Ue&&b(T.roughnessMap.channel),anisotropyMapUv:Mt&&b(T.anisotropyMap.channel),clearcoatMapUv:Ht&&b(T.clearcoatMap.channel),clearcoatNormalMapUv:kt&&b(T.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:yt&&b(T.clearcoatRoughnessMap.channel),iridescenceMapUv:xt&&b(T.iridescenceMap.channel),iridescenceThicknessMapUv:zt&&b(T.iridescenceThicknessMap.channel),sheenColorMapUv:gt&&b(T.sheenColorMap.channel),sheenRoughnessMapUv:wt&&b(T.sheenRoughnessMap.channel),specularMapUv:Lt&&b(T.specularMap.channel),specularColorMapUv:q&&b(T.specularColorMap.channel),specularIntensityMapUv:Z&&b(T.specularIntensityMap.channel),transmissionMapUv:at&&b(T.transmissionMap.channel),thicknessMapUv:w&&b(T.thicknessMap.channel),alphaMapUv:V&&b(T.alphaMap.channel),vertexTangents:!!k.attributes.tangent&&(Ce||j),vertexNormals:!!k.attributes.normal,vertexColors:T.vertexColors,vertexAlphas:T.vertexColors===!0&&!!k.attributes.color&&k.attributes.color.itemSize===4,pointsUvs:$.isPoints===!0&&!!k.attributes.uv&&(oe||V),fog:!!X,useFog:T.fog===!0,fogExp2:!!X&&X.isFogExp2,flatShading:T.wireframe===!1&&(T.flatShading===!0||k.attributes.normal===void 0&&Ce===!1&&(T.isMeshLambertMaterial||T.isMeshPhongMaterial||T.isMeshStandardMaterial||T.isMeshPhysicalMaterial)),sizeAttenuation:T.sizeAttenuation===!0,logarithmicDepthBuffer:v,reversedDepthBuffer:Ft,skinning:$.isSkinnedMesh===!0,hasPositionAttribute:k.attributes.position!==void 0,morphTargets:k.morphAttributes.position!==void 0,morphNormals:k.morphAttributes.normal!==void 0,morphColors:k.morphAttributes.color!==void 0,morphTargetsCount:ct,morphTextureStride:Tt,numSunLights:z.sun.length,numDirLights:z.directional.length,numPointLights:z.point.length,numSpotLights:z.spot.length,numSpotLightMaps:z.spotLightMap.length,numRectAreaLights:z.rectArea.length,numHemiLights:z.hemi.length,numSunLightShadows:z.sunShadowMap.length,numDirLightShadows:z.directionalShadowMap.length,numPointLightShadows:z.pointShadowMap.length,numSpotLightShadows:z.spotShadowMap.length,numSpotLightShadowsWithMaps:z.numSpotLightShadowsWithMaps,numLightProbes:z.numLightProbes,numLightProbeGrids:lt.length,numClippingPlanes:c.numPlanes,numClipIntersection:c.numIntersection,dithering:T.dithering,shadowMapEnabled:s.shadowMap.enabled&&W.length>0,shadowMapType:s.shadowMap.type,toneMapping:Ct,decodeVideoTexture:oe&&T.map.isVideoTexture===!0&&qe.getTransfer(T.map.colorSpace)===on,decodeVideoTextureEmissive:Be&&T.emissiveMap.isVideoTexture===!0&&qe.getTransfer(T.emissiveMap.colorSpace)===on,premultipliedAlpha:T.premultipliedAlpha,doubleSided:T.side===vn,flipSided:T.side===vi,useDepthPacking:T.depthPacking>=0,depthPacking:T.depthPacking||0,index0AttributeName:T.index0AttributeName,extensionClipCullDistance:st&&T.extensions.clipCullDistance===!0&&n.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(st&&T.extensions.multiDraw===!0||Xt)&&n.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:n.has("KHR_parallel_shader_compile"),customProgramCacheKey:T.customProgramCacheKey()};return It.vertexUv1s=p.has(1),It.vertexUv2s=p.has(2),It.vertexUv3s=p.has(3),p.clear(),It}function y(T){const z=[];if(T.shaderID?z.push(T.shaderID):(z.push(T.customVertexShaderID),z.push(T.customFragmentShaderID)),T.defines!==void 0)for(const W in T.defines)z.push(W),z.push(T.defines[W]);return T.isRawShaderMaterial===!1&&(M(z,T),C(z,T),z.push(s.outputColorSpace)),z.push(T.customProgramCacheKey),z.join()}function M(T,z){T.push(z.precision),T.push(z.outputColorSpace),T.push(z.envMapMode),T.push(z.envMapCubeUVHeight),T.push(z.mapUv),T.push(z.alphaMapUv),T.push(z.lightMapUv),T.push(z.aoMapUv),T.push(z.bumpMapUv),T.push(z.normalMapUv),T.push(z.displacementMapUv),T.push(z.emissiveMapUv),T.push(z.metalnessMapUv),T.push(z.roughnessMapUv),T.push(z.anisotropyMapUv),T.push(z.clearcoatMapUv),T.push(z.clearcoatNormalMapUv),T.push(z.clearcoatRoughnessMapUv),T.push(z.iridescenceMapUv),T.push(z.iridescenceThicknessMapUv),T.push(z.sheenColorMapUv),T.push(z.sheenRoughnessMapUv),T.push(z.specularMapUv),T.push(z.specularColorMapUv),T.push(z.specularIntensityMapUv),T.push(z.transmissionMapUv),T.push(z.thicknessMapUv),T.push(z.combine),T.push(z.fogExp2),T.push(z.sizeAttenuation),T.push(z.morphTargetsCount),T.push(z.morphAttributeCount),T.push(z.numSunLights),T.push(z.numDirLights),T.push(z.numPointLights),T.push(z.numSpotLights),T.push(z.numSpotLightMaps),T.push(z.numHemiLights),T.push(z.numRectAreaLights),T.push(z.numSunLightShadows),T.push(z.numDirLightShadows),T.push(z.numPointLightShadows),T.push(z.numSpotLightShadows),T.push(z.numSpotLightShadowsWithMaps),T.push(z.numLightProbes),T.push(z.shadowMapType),T.push(z.toneMapping),T.push(z.numClippingPlanes),T.push(z.numClipIntersection),T.push(z.depthPacking)}function C(T,z){u.disableAll(),z.instancing&&u.enable(0),z.instancingColor&&u.enable(1),z.instancingMorph&&u.enable(2),z.matcap&&u.enable(3),z.envMap&&u.enable(4),z.normalMapObjectSpace&&u.enable(5),z.normalMapTangentSpace&&u.enable(6),z.clearcoat&&u.enable(7),z.iridescence&&u.enable(8),z.alphaTest&&u.enable(9),z.vertexColors&&u.enable(10),z.vertexAlphas&&u.enable(11),z.vertexUv1s&&u.enable(12),z.vertexUv2s&&u.enable(13),z.vertexUv3s&&u.enable(14),z.vertexTangents&&u.enable(15),z.anisotropy&&u.enable(16),z.alphaHash&&u.enable(17),z.batching&&u.enable(18),z.dispersion&&u.enable(19),z.retroreflection&&u.enable(24),z.batchingColor&&u.enable(20),z.gradientMap&&u.enable(21),z.packedNormalMap&&u.enable(22),z.vertexNormals&&u.enable(23),T.push(u.mask),u.disableAll(),z.fog&&u.enable(0),z.useFog&&u.enable(1),z.flatShading&&u.enable(2),z.logarithmicDepthBuffer&&u.enable(3),z.reversedDepthBuffer&&u.enable(4),z.skinning&&u.enable(5),z.morphTargets&&u.enable(6),z.morphNormals&&u.enable(7),z.morphColors&&u.enable(8),z.premultipliedAlpha&&u.enable(9),z.shadowMapEnabled&&u.enable(10),z.doubleSided&&u.enable(11),z.flipSided&&u.enable(12),z.useDepthPacking&&u.enable(13),z.dithering&&u.enable(14),z.transmission&&u.enable(15),z.sheen&&u.enable(16),z.opaque&&u.enable(17),z.pointsUvs&&u.enable(18),z.decodeVideoTexture&&u.enable(19),z.decodeVideoTextureEmissive&&u.enable(20),z.alphaToCoverage&&u.enable(21),z.numLightProbeGrids>0&&u.enable(22),z.hasPositionAttribute&&u.enable(23),T.push(u.mask)}function P(T){const z=x[T.type];let W;if(z){const J=va[z];W=Ob.clone(J.uniforms)}else W=T.uniforms;return W}function E(T,z){let W=g.get(z);return W!==void 0?++W.usedTimes:(W=new c3(s,z,T,o),d.push(W),g.set(z,W)),W}function U(T){if(--T.usedTimes===0){const z=d.indexOf(T);d[z]=d[d.length-1],d.pop(),g.delete(T.cacheKey),T.destroy()}}function L(T){h.remove(T)}function N(){h.dispose()}return{getParameters:R,getProgramCacheKey:y,getUniforms:P,acquireProgram:E,releaseProgram:U,releaseShaderCache:L,programs:d,dispose:N}}function m3(){let s=new WeakMap;function t(u){return s.has(u)}function n(u){let h=s.get(u);return h===void 0&&(h={},s.set(u,h)),h}function a(u){s.delete(u)}function o(u,h,p){s.get(u)[h]=p}function c(){s=new WeakMap}return{has:t,get:n,remove:a,update:o,dispose:c}}function g3(s,t){return s.groupOrder!==t.groupOrder?s.groupOrder-t.groupOrder:s.renderOrder!==t.renderOrder?s.renderOrder-t.renderOrder:s.material.id!==t.material.id?s.material.id-t.material.id:s.materialVariant!==t.materialVariant?s.materialVariant-t.materialVariant:s.z!==t.z?s.z-t.z:s.id-t.id}function fx(s,t){return s.groupOrder!==t.groupOrder?s.groupOrder-t.groupOrder:s.renderOrder!==t.renderOrder?s.renderOrder-t.renderOrder:s.z!==t.z?t.z-s.z:s.id-t.id}function hx(){const s=[];let t=0;const n=[],a=[],o=[];function c(){t=0,n.length=0,a.length=0,o.length=0}function u(_){let x=0;return _.isInstancedMesh&&(x+=2),_.isSkinnedMesh&&(x+=1),x}function h(_,x,b,R,y,M){let C=s[t];return C===void 0?(C={id:_.id,object:_,geometry:x,material:b,materialVariant:u(_),groupOrder:R,renderOrder:_.renderOrder,z:y,group:M},s[t]=C):(C.id=_.id,C.object=_,C.geometry=x,C.material=b,C.materialVariant=u(_),C.groupOrder=R,C.renderOrder=_.renderOrder,C.z=y,C.group=M),t++,C}function p(_,x,b,R,y,M,C){C.reversedDepth===!0&&(y=-y);const P=h(_,x,b,R,y,M);b.transmission>0?a.push(P):b.transparent===!0?o.push(P):n.push(P)}function d(_,x,b,R,y,M){const C=h(_,x,b,R,y,M);b.transmission>0?a.unshift(C):b.transparent===!0?o.unshift(C):n.unshift(C)}function g(_,x){n.length>1&&n.sort(_||g3),a.length>1&&a.sort(x||fx),o.length>1&&o.sort(x||fx)}function v(){for(let _=t,x=s.length;_<x;_++){const b=s[_];if(b.id===null)break;b.id=null,b.object=null,b.geometry=null,b.material=null,b.group=null}}return{opaque:n,transmissive:a,transparent:o,init:c,push:p,unshift:d,finish:v,sort:g}}function v3(){let s=new WeakMap;function t(a,o){const c=s.get(a);let u;return c===void 0?(u=new hx,s.set(a,[u])):o>=c.length?(u=new hx,c.push(u)):u=c[o],u}function n(){s=new WeakMap}return{get:t,dispose:n}}function _3(){const s={};return{get:function(t){if(s[t.id]!==void 0)return s[t.id];let n;switch(t.type){case"SunLight":case"DirectionalLight":n={direction:new B,color:new ce};break;case"SpotLight":n={position:new B,direction:new B,color:new ce,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":n={position:new B,color:new ce,distance:0,decay:0};break;case"HemisphereLight":n={direction:new B,skyColor:new ce,groundColor:new ce};break;case"RectAreaLight":n={color:new ce,position:new B,halfWidth:new B,halfHeight:new B};break}return s[t.id]=n,n}}}function x3(){const s={};return{get:function(t){if(s[t.id]!==void 0)return s[t.id];let n;switch(t.type){case"SunLight":case"DirectionalLight":n={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Ot};break;case"SpotLight":n={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Ot};break;case"PointLight":n={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Ot,shadowCameraNear:1,shadowCameraFar:1e3};break}return s[t.id]=n,n}}}let M3=0;function y3(s,t){return(t.castShadow?2:0)-(s.castShadow?2:0)+(t.map?1:0)-(s.map?1:0)}function S3(s){const t=new _3,n=x3(),a={version:0,hash:{sunLength:-1,directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numSunShadows:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],sun:[],sunShadow:[],sunShadowMap:[],sunShadowMatrix:[],sunShadowCascade:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let d=0;d<9;d++)a.probe.push(new B);const o=new B,c=new ln,u=new ln;function h(d){let g=0,v=0,_=0;for(let $=0;$<9;$++)a.probe[$].set(0,0,0);let x=0,b=0,R=0,y=0,M=0,C=0,P=0,E=0,U=0,L=0,N=0,T=0,z=0,W=0;d.sort(y3);for(let $=0,lt=d.length;$<lt;$++){const X=d[$],k=X.color,H=X.intensity,Y=X.distance;let it=null;if(X.shadow&&X.shadow.map&&(X.shadow.map.texture.format===ir?it=X.shadow.map.texture:it=X.shadow.map.depthTexture||X.shadow.map.texture),X.isAmbientLight)g+=k.r*H,v+=k.g*H,_+=k.b*H;else if(X.isLightProbe){for(let rt=0;rt<9;rt++)a.probe[rt].addScaledVector(X.sh.coefficients[rt],H);W++}else if(X.isSunLight){const rt=t.get(X);if(rt.color.copy(X.color).multiplyScalar(X.intensity),X.castShadow){const ht=X.shadow,I=n.get(X);I.shadowIntensity=ht.intensity,I.shadowBias=ht.bias,I.shadowNormalBias=ht.normalBias,I.shadowRadius=ht.radius,I.shadowMapSize.copy(ht.mapSize).multiply(ht.getFrameExtents()),a.sunShadow[b]=I,a.sunShadowMap[b]=it;const ct=ht.getViewportCount();for(let Tt=0;Tt<ct;Tt++)a.sunShadowMatrix[R+Tt]=ht.getMatrix(Tt),a.sunShadowCascade[R+Tt]=ht._cascadeData[Tt];R+=ct,b++}a.sun[x]=rt,x++}else if(X.isDirectionalLight){const rt=t.get(X);if(rt.color.copy(X.color).multiplyScalar(X.intensity),X.castShadow){const ht=X.shadow,I=n.get(X);I.shadowIntensity=ht.intensity,I.shadowBias=ht.bias,I.shadowNormalBias=ht.normalBias,I.shadowRadius=ht.radius,I.shadowMapSize=ht.mapSize,a.directionalShadow[y]=I,a.directionalShadowMap[y]=it,a.directionalShadowMatrix[y]=X.shadow.matrix,U++}a.directional[y]=rt,y++}else if(X.isSpotLight){const rt=t.get(X);rt.position.setFromMatrixPosition(X.matrixWorld),rt.color.copy(k).multiplyScalar(H),rt.distance=Y,rt.coneCos=Math.cos(X.angle),rt.penumbraCos=Math.cos(X.angle*(1-X.penumbra)),rt.decay=X.decay,a.spot[C]=rt;const ht=X.shadow;if(X.map&&(a.spotLightMap[T]=X.map,T++,ht.updateMatrices(X),X.castShadow&&z++),a.spotLightMatrix[C]=ht.matrix,X.castShadow){const I=n.get(X);I.shadowIntensity=ht.intensity,I.shadowBias=ht.bias,I.shadowNormalBias=ht.normalBias,I.shadowRadius=ht.radius,I.shadowMapSize=ht.mapSize,a.spotShadow[C]=I,a.spotShadowMap[C]=it,N++}C++}else if(X.isRectAreaLight){const rt=t.get(X);rt.color.copy(k).multiplyScalar(H),rt.halfWidth.set(X.width*.5,0,0),rt.halfHeight.set(0,X.height*.5,0),a.rectArea[P]=rt,P++}else if(X.isPointLight){const rt=t.get(X);if(rt.color.copy(X.color).multiplyScalar(X.intensity),rt.distance=X.distance,rt.decay=X.decay,X.castShadow){const ht=X.shadow,I=n.get(X);I.shadowIntensity=ht.intensity,I.shadowBias=ht.bias,I.shadowNormalBias=ht.normalBias,I.shadowRadius=ht.radius,I.shadowMapSize=ht.mapSize,I.shadowCameraNear=ht.camera.near,I.shadowCameraFar=ht.camera.far,a.pointShadow[M]=I,a.pointShadowMap[M]=it,a.pointShadowMatrix[M]=X.shadow.matrix,L++}a.point[M]=rt,M++}else if(X.isHemisphereLight){const rt=t.get(X);rt.skyColor.copy(X.color).multiplyScalar(H),rt.groundColor.copy(X.groundColor).multiplyScalar(H),a.hemi[E]=rt,E++}}P>0&&(s.has("OES_texture_float_linear")===!0?(a.rectAreaLTC1=Kt.LTC_FLOAT_1,a.rectAreaLTC2=Kt.LTC_FLOAT_2):(a.rectAreaLTC1=Kt.LTC_HALF_1,a.rectAreaLTC2=Kt.LTC_HALF_2)),a.ambient[0]=g,a.ambient[1]=v,a.ambient[2]=_;const J=a.hash;(J.sunLength!==x||J.directionalLength!==y||J.pointLength!==M||J.spotLength!==C||J.rectAreaLength!==P||J.hemiLength!==E||J.numSunShadows!==b||J.numDirectionalShadows!==U||J.numPointShadows!==L||J.numSpotShadows!==N||J.numSpotMaps!==T||J.numLightProbes!==W)&&(a.sun.length=x,a.directional.length=y,a.spot.length=C,a.rectArea.length=P,a.point.length=M,a.hemi.length=E,a.sunShadow.length=b,a.sunShadowMap.length=b,a.sunShadowMatrix.length=R,a.sunShadowCascade.length=R,a.directionalShadow.length=U,a.directionalShadowMap.length=U,a.directionalShadowMatrix.length=U,a.pointShadow.length=L,a.pointShadowMap.length=L,a.pointShadowMatrix.length=L,a.spotShadow.length=N,a.spotShadowMap.length=N,a.spotLightMatrix.length=N+T-z,a.spotLightMap.length=T,a.numSpotLightShadowsWithMaps=z,a.numLightProbes=W,J.sunLength=x,J.directionalLength=y,J.pointLength=M,J.spotLength=C,J.rectAreaLength=P,J.hemiLength=E,J.numSunShadows=b,J.numDirectionalShadows=U,J.numPointShadows=L,J.numSpotShadows=N,J.numSpotMaps=T,J.numLightProbes=W,a.version=M3++)}function p(d,g){let v=0,_=0,x=0,b=0,R=0,y=0;const M=g.matrixWorldInverse;for(let C=0,P=d.length;C<P;C++){const E=d[C];if(E.isSunLight){const U=a.sun[v];U.direction.setFromMatrixPosition(E.matrixWorld),U.direction.transformDirection(M),v++}else if(E.isDirectionalLight){const U=a.directional[_];U.direction.setFromMatrixPosition(E.matrixWorld),o.setFromMatrixPosition(E.target.matrixWorld),U.direction.sub(o),U.direction.transformDirection(M),_++}else if(E.isSpotLight){const U=a.spot[b];U.position.setFromMatrixPosition(E.matrixWorld),U.position.applyMatrix4(M),U.direction.setFromMatrixPosition(E.matrixWorld),o.setFromMatrixPosition(E.target.matrixWorld),U.direction.sub(o),U.direction.transformDirection(M),b++}else if(E.isRectAreaLight){const U=a.rectArea[R];U.position.setFromMatrixPosition(E.matrixWorld),U.position.applyMatrix4(M),u.identity(),c.copy(E.matrixWorld),c.premultiply(M),u.extractRotation(c),U.halfWidth.set(E.width*.5,0,0),U.halfHeight.set(0,E.height*.5,0),U.halfWidth.applyMatrix4(u),U.halfHeight.applyMatrix4(u),R++}else if(E.isPointLight){const U=a.point[x];U.position.setFromMatrixPosition(E.matrixWorld),U.position.applyMatrix4(M),x++}else if(E.isHemisphereLight){const U=a.hemi[y];U.direction.setFromMatrixPosition(E.matrixWorld),U.direction.transformDirection(M),y++}}}return{setup:h,setupView:p,state:a}}function dx(s){const t=new S3(s),n=[],a=[],o=[];function c(_){v.camera=_,n.length=0,a.length=0,o.length=0}function u(_){n.push(_)}function h(_){a.push(_)}function p(_){o.push(_)}function d(){t.setup(n)}function g(_){t.setupView(n,_)}const v={lightsArray:n,shadowsArray:a,lightProbeGridArray:o,camera:null,lights:t,transmissionRenderTarget:{},textureUnits:0};return{init:c,state:v,setupLights:d,setupLightsView:g,pushLight:u,pushShadow:h,pushLightProbeGrid:p}}function b3(s){let t=new WeakMap;function n(o,c=0){const u=t.get(o);let h;return u===void 0?(h=new dx(s),t.set(o,[h])):c>=u.length?(h=new dx(s),u.push(h)):h=u[c],h}function a(){t=new WeakMap}return{get:n,dispose:a}}const E3=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,T3=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ).rg;
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ).r;
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( max( 0.0, squared_mean - mean * mean ) );
	gl_FragColor = vec4( mean, std_dev, 0.0, 1.0 );
}`,A3=[new B(1,0,0),new B(-1,0,0),new B(0,1,0),new B(0,-1,0),new B(0,0,1),new B(0,0,-1)],w3=[new B(0,-1,0),new B(0,-1,0),new B(0,0,1),new B(0,0,-1),new B(0,-1,0),new B(0,-1,0)],px=new ln,gl=new B,Id=new B;function R3(s,t,n){let a=new im;const o=new Ot,c=new Ot,u=new _n,h=new Bb,p=new Fb,d={},g=n.maxTextureSize,v={[er]:vi,[vi]:er,[vn]:vn},_=new ui({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new Ot},radius:{value:4}},vertexShader:E3,fragmentShader:T3}),x=_.clone();x.defines.HORIZONTAL_PASS=1;const b=new Ie;b.setAttribute("position",new ti(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const R=new le(b,_),y=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=yl;let M=this.type;this.render=function(L,N,T){if(y.enabled===!1||y.autoUpdate===!1&&y.needsUpdate===!1||L.length===0)return;this.type===Wp&&(ye("WebGLShadowMap: PCFSoftShadowMap has been removed. Using PCFShadowMap instead."),this.type=yl);const z=s.getRenderTarget(),W=s.getActiveCubeFace(),J=s.getActiveMipmapLevel(),$=s.state;$.setBlending(Ya),$.buffers.depth.getReversed()===!0?$.buffers.color.setClear(0,0,0,0):$.buffers.color.setClear(1,1,1,1),$.buffers.depth.setTest(!0),$.setScissorTest(!1);const lt=M!==this.type;lt&&N.traverse(function(X){X.material&&(Array.isArray(X.material)?X.material.forEach(k=>k.needsUpdate=!0):X.material.needsUpdate=!0)});for(let X=0,k=L.length;X<k;X++){const H=L[X],Y=H.shadow;if(Y===void 0){ye("WebGLShadowMap:",H,"has no shadow.");continue}if(Y.autoUpdate===!1&&Y.needsUpdate===!1)continue;o.copy(Y.mapSize);const it=Y.getFrameExtents();o.multiply(it),c.copy(Y.mapSize),(o.x>g||o.y>g)&&(o.x>g&&(c.x=Math.floor(g/it.x),o.x=c.x*it.x,Y.mapSize.x=c.x),o.y>g&&(c.y=Math.floor(g/it.y),o.y=c.y*it.y,Y.mapSize.y=c.y));const rt=s.state.buffers.depth.getReversed();if(Y.camera._reversedDepth=rt,Y.map===null||lt===!0){if(Y.map!==null&&(Y.map.depthTexture!==null&&(Y.map.depthTexture.dispose(),Y.map.depthTexture=null),Y.map.dispose()),this.type===_l){if(H.isPointLight){ye("WebGLShadowMap: VSM shadow maps are not supported for PointLights. Use PCF or BasicShadowMap instead.");continue}Y.map=new Bi(o.x,o.y,{format:ir,type:ji,minFilter:Wn,magFilter:Wn,generateMipmaps:!1}),Y.map.texture.name=H.name+".shadowMap",Y.map.depthTexture=new po(o.x,o.y,oa),Y.map.depthTexture.name=H.name+".shadowMapDepth",Y.map.depthTexture.format=Ma,Y.map.depthTexture.compareFunction=null,Y.map.depthTexture.minFilter=ri,Y.map.depthTexture.magFilter=ri}else H.isPointLight?(Y.map=new gM(o.x),Y.map.depthTexture=new nb(o.x,la)):(Y.map=new Bi(o.x,o.y),Y.map.depthTexture=new po(o.x,o.y,la)),Y.map.depthTexture.name=H.name+".shadowMap",Y.map.depthTexture.format=Ma,this.type===yl?(Y.map.depthTexture.compareFunction=rt?Vu:Gu,Y.map.depthTexture.minFilter=Wn,Y.map.depthTexture.magFilter=Wn):(Y.map.depthTexture.compareFunction=null,Y.map.depthTexture.minFilter=ri,Y.map.depthTexture.magFilter=ri);Y.camera.updateProjectionMatrix()}Y.map.isWebGLCubeRenderTarget!==!0&&(Y.map.width!==o.x||Y.map.height!==o.y)&&Y.map.setSize(o.x,o.y);const ht=Y.map.isWebGLCubeRenderTarget?6:Y.getViewportCount();H.isPointLight!==!0&&Y.updateMatrices(H,T);for(let I=0;I<ht;I++){const ct=Y.getCamera(I);if(H.isPointLight){const Tt=Y.camera,Ut=Y.matrix,Vt=H.distance||Tt.far;Vt!==Tt.far&&(Tt.far=Vt,Tt.updateProjectionMatrix()),gl.setFromMatrixPosition(H.matrixWorld),Tt.position.copy(gl),Id.copy(Tt.position),Id.add(A3[I]),Tt.up.copy(w3[I]),Tt.lookAt(Id),Tt.updateMatrixWorld(),Ut.makeTranslation(-gl.x,-gl.y,-gl.z),px.multiplyMatrices(Tt.projectionMatrix,Tt.matrixWorldInverse),Y._frustum.setFromProjectionMatrix(px,Tt.coordinateSystem,Tt.reversedDepth)}if(Y.map.isWebGLCubeRenderTarget)s.setRenderTarget(Y.map,I),s.clear();else{I===0&&(s.setRenderTarget(Y.map),s.clear());const Tt=Y.getViewport(I);u.set(c.x*Tt.x,c.y*Tt.y,c.x*Tt.z,c.y*Tt.w),$.viewport(u)}a=Y.getFrustum(I),E(N,T,ct,H,this.type)}Y.isPointLightShadow!==!0&&this.type===_l&&C(Y,T),Y.needsUpdate=!1}M=this.type,y.needsUpdate=!1,s.setRenderTarget(z,W,J)};function C(L,N){const T=t.update(R);_.defines.VSM_SAMPLES!==L.blurSamples&&(_.defines.VSM_SAMPLES=L.blurSamples,x.defines.VSM_SAMPLES=L.blurSamples,_.needsUpdate=!0,x.needsUpdate=!0),L.mapPass===null?L.mapPass=new Bi(o.x,o.y,{format:ir,type:ji}):(L.mapPass.width!==L.map.width||L.mapPass.height!==L.map.height)&&L.mapPass.setSize(L.map.width,L.map.height),_.uniforms.shadow_pass.value=L.map.depthTexture,_.uniforms.resolution.value.set(L.map.width,L.map.height),_.uniforms.radius.value=L.radius,s.setRenderTarget(L.mapPass),s.clear(),s.renderBufferDirect(N,null,T,_,R,null),x.uniforms.shadow_pass.value=L.mapPass.texture,x.uniforms.resolution.value.set(L.map.width,L.map.height),x.uniforms.radius.value=L.radius,s.setRenderTarget(L.map),s.clear(),s.renderBufferDirect(N,null,T,x,R,null)}function P(L,N,T,z){let W=null;const J=T.isPointLight===!0?L.customDistanceMaterial:L.customDepthMaterial;if(J!==void 0)W=J;else if(W=T.isPointLight===!0?p:h,s.localClippingEnabled&&N.clipShadows===!0&&Array.isArray(N.clippingPlanes)&&N.clippingPlanes.length!==0||N.displacementMap&&N.displacementScale!==0||N.alphaMap&&N.alphaTest>0||N.map&&N.alphaTest>0||N.alphaToCoverage===!0){const $=W.uuid,lt=N.uuid;let X=d[$];X===void 0&&(X={},d[$]=X);let k=X[lt];k===void 0&&(k=W.clone(),X[lt]=k,N.addEventListener("dispose",U)),W=k}if(W.visible=N.visible,W.wireframe=N.wireframe,z===_l?W.side=N.shadowSide!==null?N.shadowSide:N.side:W.side=N.shadowSide!==null?N.shadowSide:v[N.side],W.alphaMap=N.alphaMap,W.alphaTest=N.alphaToCoverage===!0?.5:N.alphaTest,W.map=N.map,W.clipShadows=N.clipShadows,W.clippingPlanes=N.clippingPlanes,W.clipIntersection=N.clipIntersection,W.displacementMap=N.displacementMap,W.displacementScale=N.displacementScale,W.displacementBias=N.displacementBias,W.wireframeLinewidth=N.wireframeLinewidth,W.linewidth=N.linewidth,T.isPointLight===!0&&W.isMeshDistanceMaterial===!0){const $=s.properties.get(W);$.light=T}return W}function E(L,N,T,z,W){if(L.visible===!1)return;if(L.layers.test(N.layers)&&(L.isMesh||L.isLine||L.isPoints)&&(L.castShadow||L.receiveShadow&&W===_l)&&(!L.frustumCulled||L.intersectsFrustum(a))){L.modelViewMatrix.multiplyMatrices(T.matrixWorldInverse,L.matrixWorld);const lt=t.update(L),X=L.material;if(Array.isArray(X)){const k=lt.groups;for(let H=0,Y=k.length;H<Y;H++){const it=k[H],rt=X[it.materialIndex];if(rt&&rt.visible){const ht=P(L,rt,z,W);L.onBeforeShadow(s,L,N,T,lt,ht,it),s.renderBufferDirect(T,null,lt,ht,L,it),L.onAfterShadow(s,L,N,T,lt,ht,it)}}}else if(X.visible){const k=P(L,X,z,W);L.onBeforeShadow(s,L,N,T,lt,k,null),s.renderBufferDirect(T,null,lt,k,L,null),L.onAfterShadow(s,L,N,T,lt,k,null)}}const $=L.children;for(let lt=0,X=$.length;lt<X;lt++)E($[lt],N,T,z,W)}function U(L){L.target.removeEventListener("dispose",U);for(const T in d){const z=d[T],W=L.target.uuid;W in z&&(z[W].dispose(),delete z[W])}}}function C3(s,t){function n(){let w=!1;const G=new _n;let V=null;const nt=new _n(0,0,0,0);return{setMask:function(ot){V!==ot&&!w&&(s.colorMask(ot,ot,ot,ot),V=ot)},setLocked:function(ot){w=ot},setClear:function(ot,st,Ct,It,te){te===!0&&(ot*=It,st*=It,Ct*=It),G.set(ot,st,Ct,It),nt.equals(G)===!1&&(s.clearColor(ot,st,Ct,It),nt.copy(G))},reset:function(){w=!1,V=null,nt.set(-1,0,0,0)}}}function a(){let w=!1,G=!1,V=null,nt=null,ot=null;return{setReversed:function(st){if(G!==st){const Ct=t.get("EXT_clip_control");st?Ct.clipControlEXT(Ct.LOWER_LEFT_EXT,Ct.ZERO_TO_ONE_EXT):Ct.clipControlEXT(Ct.LOWER_LEFT_EXT,Ct.NEGATIVE_ONE_TO_ONE_EXT),G=st;const It=ot;ot=null,this.setClear(It)}},getReversed:function(){return G},setTest:function(st){st?Et(s.DEPTH_TEST):Ft(s.DEPTH_TEST)},setMask:function(st){V!==st&&!w&&(s.depthMask(st),V=st)},setFunc:function(st){if(G&&(st=p1[st]),nt!==st){switch(st){case Yd:s.depthFunc(s.NEVER);break;case Zd:s.depthFunc(s.ALWAYS);break;case Kd:s.depthFunc(s.LESS);break;case Rl:s.depthFunc(s.LEQUAL);break;case Jd:s.depthFunc(s.EQUAL);break;case Qd:s.depthFunc(s.GEQUAL);break;case jd:s.depthFunc(s.GREATER);break;case $d:s.depthFunc(s.NOTEQUAL);break;default:s.depthFunc(s.LEQUAL)}nt=st}},setLocked:function(st){w=st},setClear:function(st){ot!==st&&(ot=st,G&&(st=1-st),s.clearDepth(st))},reset:function(){w=!1,V=null,nt=null,ot=null,G=!1}}}function o(){let w=!1,G=null,V=null,nt=null,ot=null,st=null,Ct=null,It=null,te=null;return{setTest:function(se){w||(se?Et(s.STENCIL_TEST):Ft(s.STENCIL_TEST))},setMask:function(se){G!==se&&!w&&(s.stencilMask(se),G=se)},setFunc:function(se,Me,be){(V!==se||nt!==Me||ot!==be)&&(s.stencilFunc(se,Me,be),V=se,nt=Me,ot=be)},setOp:function(se,Me,be){(st!==se||Ct!==Me||It!==be)&&(s.stencilOp(se,Me,be),st=se,Ct=Me,It=be)},setLocked:function(se){w=se},setClear:function(se){te!==se&&(s.clearStencil(se),te=se)},reset:function(){w=!1,G=null,V=null,nt=null,ot=null,st=null,Ct=null,It=null,te=null}}}const c=new n,u=new a,h=new o,p=new WeakMap,d=new WeakMap;let g={},v={},_={},x=new WeakMap,b=[],R=null,y=!1,M=null,C=null,P=null,E=null,U=null,L=null,N=null,T=new ce(0,0,0),z=0,W=!1,J=null,$=null,lt=null,X=null,k=null;const H=s.getParameter(s.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let Y=!1,it=0;const rt=s.getParameter(s.VERSION);rt.indexOf("WebGL")!==-1?(it=parseFloat(/^WebGL (\d)/.exec(rt)[1]),Y=it>=1):rt.indexOf("OpenGL ES")!==-1&&(it=parseFloat(/^OpenGL ES (\d)/.exec(rt)[1]),Y=it>=2);let ht=null,I={};const ct=s.getParameter(s.SCISSOR_BOX),Tt=s.getParameter(s.VIEWPORT),Ut=new _n().fromArray(ct),Vt=new _n().fromArray(Tt);function Bt(w,G,V,nt){const ot=new Uint8Array(4),st=s.createTexture();s.bindTexture(w,st),s.texParameteri(w,s.TEXTURE_MIN_FILTER,s.NEAREST),s.texParameteri(w,s.TEXTURE_MAG_FILTER,s.NEAREST);for(let Ct=0;Ct<V;Ct++)w===s.TEXTURE_3D||w===s.TEXTURE_2D_ARRAY?s.texImage3D(G,0,s.RGBA,1,1,nt,0,s.RGBA,s.UNSIGNED_BYTE,ot):s.texImage2D(G+Ct,0,s.RGBA,1,1,0,s.RGBA,s.UNSIGNED_BYTE,ot);return st}const ft={};ft[s.TEXTURE_2D]=Bt(s.TEXTURE_2D,s.TEXTURE_2D,1),ft[s.TEXTURE_CUBE_MAP]=Bt(s.TEXTURE_CUBE_MAP,s.TEXTURE_CUBE_MAP_POSITIVE_X,6),ft[s.TEXTURE_2D_ARRAY]=Bt(s.TEXTURE_2D_ARRAY,s.TEXTURE_2D_ARRAY,1,1),ft[s.TEXTURE_3D]=Bt(s.TEXTURE_3D,s.TEXTURE_3D,1,1),c.setClear(0,0,0,1),u.setClear(1),h.setClear(0),Et(s.DEPTH_TEST),u.setFunc(Rl),pe(!1),Ce(t_),Et(s.CULL_FACE),de(Ya);function Et(w){g[w]!==!0&&(s.enable(w),g[w]=!0)}function Ft(w){g[w]!==!1&&(s.disable(w),g[w]=!1)}function $t(w,G){return _[w]!==G?(s.bindFramebuffer(w,G),_[w]=G,w===s.DRAW_FRAMEBUFFER&&(_[s.FRAMEBUFFER]=G),w===s.FRAMEBUFFER&&(_[s.DRAW_FRAMEBUFFER]=G),!0):!1}function Xt(w,G){let V=b,nt=!1;if(w){V=x.get(G),V===void 0&&(V=[],x.set(G,V));const ot=w.textures;if(V.length!==ot.length||V[0]!==s.COLOR_ATTACHMENT0){for(let st=0,Ct=ot.length;st<Ct;st++)V[st]=s.COLOR_ATTACHMENT0+st;V.length=ot.length,nt=!0}}else V[0]!==s.BACK&&(V[0]=s.BACK,nt=!0);nt&&s.drawBuffers(V)}function oe(w){return R!==w?(s.useProgram(w),R=w,!0):!1}const Ye={[ro]:s.FUNC_ADD,[zS]:s.FUNC_SUBTRACT,[IS]:s.FUNC_REVERSE_SUBTRACT};Ye[BS]=s.MIN,Ye[FS]=s.MAX;const jt={[HS]:s.ZERO,[GS]:s.ONE,[VS]:s.SRC_COLOR,[Dx]:s.SRC_ALPHA,[ZS]:s.SRC_ALPHA_SATURATE,[qS]:s.DST_COLOR,[XS]:s.DST_ALPHA,[kS]:s.ONE_MINUS_SRC_COLOR,[Ux]:s.ONE_MINUS_SRC_ALPHA,[YS]:s.ONE_MINUS_DST_COLOR,[WS]:s.ONE_MINUS_DST_ALPHA,[KS]:s.CONSTANT_COLOR,[JS]:s.ONE_MINUS_CONSTANT_COLOR,[QS]:s.CONSTANT_ALPHA,[jS]:s.ONE_MINUS_CONSTANT_ALPHA};function de(w,G,V,nt,ot,st,Ct,It,te,se){if(w===Ya){y===!0&&(Ft(s.BLEND),y=!1);return}if(y===!1&&(Et(s.BLEND),y=!0),w!==PS){if(w!==M||se!==W){if((C!==ro||U!==ro)&&(s.blendEquation(s.FUNC_ADD),C=ro,U=ro),se)switch(w){case Sl:s.blendFuncSeparate(s.ONE,s.ONE_MINUS_SRC_ALPHA,s.ONE,s.ONE_MINUS_SRC_ALPHA);break;case e_:s.blendFunc(s.ONE,s.ONE);break;case n_:s.blendFuncSeparate(s.ZERO,s.ONE_MINUS_SRC_COLOR,s.ZERO,s.ONE);break;case i_:s.blendFuncSeparate(s.DST_COLOR,s.ONE_MINUS_SRC_ALPHA,s.ZERO,s.ONE);break;default:Je("WebGLState: Invalid blending: ",w);break}else switch(w){case Sl:s.blendFuncSeparate(s.SRC_ALPHA,s.ONE_MINUS_SRC_ALPHA,s.ONE,s.ONE_MINUS_SRC_ALPHA);break;case e_:s.blendFuncSeparate(s.SRC_ALPHA,s.ONE,s.ONE,s.ONE);break;case n_:Je("WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true");break;case i_:Je("WebGLState: MultiplyBlending requires material.premultipliedAlpha = true");break;default:Je("WebGLState: Invalid blending: ",w);break}P=null,E=null,L=null,N=null,T.set(0,0,0),z=0,M=w,W=se}return}ot=ot||G,st=st||V,Ct=Ct||nt,(G!==C||ot!==U)&&(s.blendEquationSeparate(Ye[G],Ye[ot]),C=G,U=ot),(V!==P||nt!==E||st!==L||Ct!==N)&&(s.blendFuncSeparate(jt[V],jt[nt],jt[st],jt[Ct]),P=V,E=nt,L=st,N=Ct),(It.equals(T)===!1||te!==z)&&(s.blendColor(It.r,It.g,It.b,te),T.copy(It),z=te),M=w,W=!1}function xe(w,G){w.side===vn?Ft(s.CULL_FACE):Et(s.CULL_FACE);let V=w.side===vi;G&&(V=!V),pe(V),w.blending===Sl&&w.transparent===!1?de(Ya):de(w.blending,w.blendEquation,w.blendSrc,w.blendDst,w.blendEquationAlpha,w.blendSrcAlpha,w.blendDstAlpha,w.blendColor,w.blendAlpha,w.premultipliedAlpha),u.setFunc(w.depthFunc),u.setTest(w.depthTest),u.setMask(w.depthWrite),c.setMask(w.colorWrite);const nt=w.stencilWrite;h.setTest(nt),nt&&(h.setMask(w.stencilWriteMask),h.setFunc(w.stencilFunc,w.stencilRef,w.stencilFuncMask),h.setOp(w.stencilFail,w.stencilZFail,w.stencilZPass)),Be(w.polygonOffset,w.polygonOffsetFactor,w.polygonOffsetUnits),w.alphaToCoverage===!0?Et(s.SAMPLE_ALPHA_TO_COVERAGE):Ft(s.SAMPLE_ALPHA_TO_COVERAGE)}function pe(w){J!==w&&(w?s.frontFace(s.CW):s.frontFace(s.CCW),J=w)}function Ce(w){w!==NS?(Et(s.CULL_FACE),w!==$&&(w===t_?s.cullFace(s.BACK):w===OS?s.cullFace(s.FRONT):s.cullFace(s.FRONT_AND_BACK))):Ft(s.CULL_FACE),$=w}function Xe(w){w!==lt&&(Y&&s.lineWidth(w),lt=w)}function Be(w,G,V){w?(Et(s.POLYGON_OFFSET_FILL),(X!==G||k!==V)&&(X=G,k=V,u.getReversed()&&(G=-G),s.polygonOffset(G,V))):Ft(s.POLYGON_OFFSET_FILL)}function ie(w){w?Et(s.SCISSOR_TEST):Ft(s.SCISSOR_TEST)}function Ue(w){w===void 0&&(w=s.TEXTURE0+H-1),ht!==w&&(s.activeTexture(w),ht=w)}function j(w,G,V){V===void 0&&(ht===null?V=s.TEXTURE0+H-1:V=ht);let nt=I[V];nt===void 0&&(nt={type:void 0,texture:void 0},I[V]=nt),(nt.type!==w||nt.texture!==G)&&(ht!==V&&(s.activeTexture(V),ht=V),s.bindTexture(w,G||ft[w]),nt.type=w,nt.texture=G)}function Se(){const w=I[ht];w!==void 0&&w.type!==void 0&&(s.bindTexture(w.type,null),w.type=void 0,w.texture=void 0)}function Ee(){try{s.compressedTexImage2D(...arguments)}catch(w){Je("WebGLState:",w)}}function F(){try{s.compressedTexImage3D(...arguments)}catch(w){Je("WebGLState:",w)}}function A(){try{s.texSubImage2D(...arguments)}catch(w){Je("WebGLState:",w)}}function et(){try{s.texSubImage3D(...arguments)}catch(w){Je("WebGLState:",w)}}function mt(){try{s.compressedTexSubImage2D(...arguments)}catch(w){Je("WebGLState:",w)}}function Mt(){try{s.compressedTexSubImage3D(...arguments)}catch(w){Je("WebGLState:",w)}}function Ht(){try{s.texStorage2D(...arguments)}catch(w){Je("WebGLState:",w)}}function kt(){try{s.texStorage3D(...arguments)}catch(w){Je("WebGLState:",w)}}function yt(){try{s.texImage2D(...arguments)}catch(w){Je("WebGLState:",w)}}function xt(){try{s.texImage3D(...arguments)}catch(w){Je("WebGLState:",w)}}function zt(w){return v[w]!==void 0?v[w]:s.getParameter(w)}function gt(w,G){v[w]!==G&&(s.pixelStorei(w,G),v[w]=G)}function wt(w){Ut.equals(w)===!1&&(s.scissor(w.x,w.y,w.z,w.w),Ut.copy(w))}function Lt(w){Vt.equals(w)===!1&&(s.viewport(w.x,w.y,w.z,w.w),Vt.copy(w))}function q(w,G){let V=d.get(G);V===void 0&&(V=new WeakMap,d.set(G,V));let nt=V.get(w);nt===void 0&&(nt=s.getUniformBlockIndex(G,w.name),V.set(w,nt))}function Z(w,G){const nt=d.get(G).get(w);p.get(G)!==nt&&(s.uniformBlockBinding(G,nt,w.__bindingPointIndex),p.set(G,nt))}function at(){s.disable(s.BLEND),s.disable(s.CULL_FACE),s.disable(s.DEPTH_TEST),s.disable(s.POLYGON_OFFSET_FILL),s.disable(s.SCISSOR_TEST),s.disable(s.STENCIL_TEST),s.disable(s.SAMPLE_ALPHA_TO_COVERAGE),s.blendEquation(s.FUNC_ADD),s.blendFunc(s.ONE,s.ZERO),s.blendFuncSeparate(s.ONE,s.ZERO,s.ONE,s.ZERO),s.blendColor(0,0,0,0),s.colorMask(!0,!0,!0,!0),s.clearColor(0,0,0,0),s.depthMask(!0),s.depthFunc(s.LESS),u.setReversed(!1),s.clearDepth(1),s.stencilMask(4294967295),s.stencilFunc(s.ALWAYS,0,4294967295),s.stencilOp(s.KEEP,s.KEEP,s.KEEP),s.clearStencil(0),s.cullFace(s.BACK),s.frontFace(s.CCW),s.polygonOffset(0,0),s.activeTexture(s.TEXTURE0),s.bindFramebuffer(s.FRAMEBUFFER,null),s.bindFramebuffer(s.DRAW_FRAMEBUFFER,null),s.bindFramebuffer(s.READ_FRAMEBUFFER,null),s.useProgram(null),s.lineWidth(1),s.scissor(0,0,s.canvas.width,s.canvas.height),s.viewport(0,0,s.canvas.width,s.canvas.height),s.pixelStorei(s.PACK_ALIGNMENT,4),s.pixelStorei(s.UNPACK_ALIGNMENT,4),s.pixelStorei(s.UNPACK_FLIP_Y_WEBGL,!1),s.pixelStorei(s.UNPACK_PREMULTIPLY_ALPHA_WEBGL,!1),s.pixelStorei(s.UNPACK_COLORSPACE_CONVERSION_WEBGL,s.BROWSER_DEFAULT_WEBGL),s.pixelStorei(s.PACK_ROW_LENGTH,0),s.pixelStorei(s.PACK_SKIP_PIXELS,0),s.pixelStorei(s.PACK_SKIP_ROWS,0),s.pixelStorei(s.UNPACK_ROW_LENGTH,0),s.pixelStorei(s.UNPACK_IMAGE_HEIGHT,0),s.pixelStorei(s.UNPACK_SKIP_PIXELS,0),s.pixelStorei(s.UNPACK_SKIP_ROWS,0),s.pixelStorei(s.UNPACK_SKIP_IMAGES,0),g={},v={},ht=null,I={},_={},x=new WeakMap,b=[],R=null,y=!1,M=null,C=null,P=null,E=null,U=null,L=null,N=null,T=new ce(0,0,0),z=0,W=!1,J=null,$=null,lt=null,X=null,k=null,Ut.set(0,0,s.canvas.width,s.canvas.height),Vt.set(0,0,s.canvas.width,s.canvas.height),c.reset(),u.reset(),h.reset()}return{buffers:{color:c,depth:u,stencil:h},enable:Et,disable:Ft,bindFramebuffer:$t,drawBuffers:Xt,useProgram:oe,setBlending:de,setMaterial:xe,setFlipSided:pe,setCullFace:Ce,setLineWidth:Xe,setPolygonOffset:Be,setScissorTest:ie,activeTexture:Ue,bindTexture:j,unbindTexture:Se,compressedTexImage2D:Ee,compressedTexImage3D:F,texImage2D:yt,texImage3D:xt,pixelStorei:gt,getParameter:zt,updateUBOMapping:q,uniformBlockBinding:Z,texStorage2D:Ht,texStorage3D:kt,texSubImage2D:A,texSubImage3D:et,compressedTexSubImage2D:mt,compressedTexSubImage3D:Mt,scissor:wt,viewport:Lt,reset:at}}function D3(s,t,n,a,o,c,u){const h=t.has("WEBGL_multisampled_render_to_texture")?t.get("WEBGL_multisampled_render_to_texture"):null,p=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),d=new Ot,g=new WeakMap,v=new Set;let _;const x=new WeakMap;let b=!1;try{b=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function R(F,A){return b?new OffscreenCanvas(F,A):Ou("canvas")}function y(F,A,et){let mt=1;const Mt=Ee(F);if((Mt.width>et||Mt.height>et)&&(mt=et/Math.max(Mt.width,Mt.height)),mt<1)if(typeof HTMLImageElement<"u"&&F instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&F instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&F instanceof ImageBitmap||typeof VideoFrame<"u"&&F instanceof VideoFrame){const Ht=Math.floor(mt*Mt.width),kt=Math.floor(mt*Mt.height);_===void 0&&(_=R(Ht,kt));const yt=A?R(Ht,kt):_;return yt.width=Ht,yt.height=kt,yt.getContext("2d").drawImage(F,0,0,Ht,kt),ye("WebGLRenderer: Texture has been resized from ("+Mt.width+"x"+Mt.height+") to ("+Ht+"x"+kt+")."),yt}else return"data"in F&&ye("WebGLRenderer: Image in DataTexture is too big ("+Mt.width+"x"+Mt.height+")."),F;return F}function M(F){return F.generateMipmaps}function C(F){s.generateMipmap(F)}function P(F){return F.isWebGLCubeRenderTarget?s.TEXTURE_CUBE_MAP:F.isWebGL3DRenderTarget?s.TEXTURE_3D:F.isWebGLArrayRenderTarget||F.isCompressedArrayTexture?s.TEXTURE_2D_ARRAY:s.TEXTURE_2D}function E(F,A,et,mt,Mt,Ht=!1){if(F!==null){if(s[F]!==void 0)return s[F];ye("WebGLRenderer: Attempt to use non-existing WebGL internal format '"+F+"'")}let kt;mt&&(kt=t.get("EXT_texture_norm16"),kt||ye("WebGLRenderer: Unable to use normalized textures without EXT_texture_norm16 extension"));let yt=A;if(A===s.RED&&(et===s.FLOAT&&(yt=s.R32F),et===s.HALF_FLOAT&&(yt=s.R16F),et===s.UNSIGNED_BYTE&&(yt=s.R8),et===s.UNSIGNED_SHORT&&kt&&(yt=kt.R16_EXT),et===s.SHORT&&kt&&(yt=kt.R16_SNORM_EXT)),A===s.RED_INTEGER&&(et===s.UNSIGNED_BYTE&&(yt=s.R8UI),et===s.UNSIGNED_SHORT&&(yt=s.R16UI),et===s.UNSIGNED_INT&&(yt=s.R32UI),et===s.BYTE&&(yt=s.R8I),et===s.SHORT&&(yt=s.R16I),et===s.INT&&(yt=s.R32I)),A===s.RG&&(et===s.FLOAT&&(yt=s.RG32F),et===s.HALF_FLOAT&&(yt=s.RG16F),et===s.UNSIGNED_BYTE&&(yt=s.RG8),et===s.UNSIGNED_SHORT&&kt&&(yt=kt.RG16_EXT),et===s.SHORT&&kt&&(yt=kt.RG16_SNORM_EXT)),A===s.RG_INTEGER&&(et===s.UNSIGNED_BYTE&&(yt=s.RG8UI),et===s.UNSIGNED_SHORT&&(yt=s.RG16UI),et===s.UNSIGNED_INT&&(yt=s.RG32UI),et===s.BYTE&&(yt=s.RG8I),et===s.SHORT&&(yt=s.RG16I),et===s.INT&&(yt=s.RG32I)),A===s.RGB_INTEGER&&(et===s.UNSIGNED_BYTE&&(yt=s.RGB8UI),et===s.UNSIGNED_SHORT&&(yt=s.RGB16UI),et===s.UNSIGNED_INT&&(yt=s.RGB32UI),et===s.BYTE&&(yt=s.RGB8I),et===s.SHORT&&(yt=s.RGB16I),et===s.INT&&(yt=s.RGB32I)),A===s.RGBA_INTEGER&&(et===s.UNSIGNED_BYTE&&(yt=s.RGBA8UI),et===s.UNSIGNED_SHORT&&(yt=s.RGBA16UI),et===s.UNSIGNED_INT&&(yt=s.RGBA32UI),et===s.BYTE&&(yt=s.RGBA8I),et===s.SHORT&&(yt=s.RGBA16I),et===s.INT&&(yt=s.RGBA32I)),A===s.RGB&&(et===s.UNSIGNED_SHORT&&kt&&(yt=kt.RGB16_EXT),et===s.SHORT&&kt&&(yt=kt.RGB16_SNORM_EXT),et===s.UNSIGNED_INT_5_9_9_9_REV&&(yt=s.RGB9_E5),et===s.UNSIGNED_INT_10F_11F_11F_REV&&(yt=s.R11F_G11F_B10F)),A===s.RGBA){const xt=Ht?Nu:qe.getTransfer(Mt);et===s.FLOAT&&(yt=s.RGBA32F),et===s.HALF_FLOAT&&(yt=s.RGBA16F),et===s.UNSIGNED_BYTE&&(yt=xt===on?s.SRGB8_ALPHA8:s.RGBA8),et===s.UNSIGNED_SHORT&&kt&&(yt=kt.RGBA16_EXT),et===s.SHORT&&kt&&(yt=kt.RGBA16_SNORM_EXT),et===s.UNSIGNED_SHORT_4_4_4_4&&(yt=s.RGBA4),et===s.UNSIGNED_SHORT_5_5_5_1&&(yt=s.RGB5_A1)}return(yt===s.R16F||yt===s.R32F||yt===s.RG16F||yt===s.RG32F||yt===s.RGBA16F||yt===s.RGBA32F)&&t.get("EXT_color_buffer_float"),yt}function U(F,A){let et;return F?A===null||A===la||A===Dl?et=s.DEPTH24_STENCIL8:A===oa?et=s.DEPTH32F_STENCIL8:A===Cl&&(et=s.DEPTH24_STENCIL8,ye("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):A===null||A===la||A===Dl?et=s.DEPTH_COMPONENT24:A===oa?et=s.DEPTH_COMPONENT32F:A===Cl&&(et=s.DEPTH_COMPONENT16),et}function L(F,A){return M(F)===!0||F.isFramebufferTexture&&F.minFilter!==ri&&F.minFilter!==Wn?Math.log2(Math.max(A.width,A.height))+1:F.mipmaps!==void 0&&F.mipmaps.length>0?F.mipmaps.length:F.isCompressedTexture&&Array.isArray(F.image)?A.mipmaps.length:1}function N(F){const A=F.target;A.removeEventListener("dispose",N),z(A),A.isVideoTexture&&g.delete(A),A.isHTMLTexture&&v.delete(A)}function T(F){const A=F.target;A.removeEventListener("dispose",T),J(A)}function z(F){const A=a.get(F);if(A.__webglInit===void 0)return;const et=F.source,mt=x.get(et);if(mt){const Mt=mt[A.__cacheKey];Mt.usedTimes--,Mt.usedTimes===0&&W(F),Object.keys(mt).length===0&&x.delete(et)}a.remove(F)}function W(F){const A=a.get(F);s.deleteTexture(A.__webglTexture);const et=F.source,mt=x.get(et);delete mt[A.__cacheKey],u.memory.textures--}function J(F){const A=a.get(F);if(F.depthTexture&&(F.depthTexture.dispose(),a.remove(F.depthTexture)),F.isWebGLCubeRenderTarget)for(let mt=0;mt<6;mt++){if(Array.isArray(A.__webglFramebuffer[mt]))for(let Mt=0;Mt<A.__webglFramebuffer[mt].length;Mt++)s.deleteFramebuffer(A.__webglFramebuffer[mt][Mt]);else s.deleteFramebuffer(A.__webglFramebuffer[mt]);A.__webglDepthbuffer&&s.deleteRenderbuffer(A.__webglDepthbuffer[mt])}else{if(Array.isArray(A.__webglFramebuffer))for(let mt=0;mt<A.__webglFramebuffer.length;mt++)s.deleteFramebuffer(A.__webglFramebuffer[mt]);else s.deleteFramebuffer(A.__webglFramebuffer);if(A.__webglDepthbuffer&&s.deleteRenderbuffer(A.__webglDepthbuffer),A.__webglMultisampledFramebuffer&&s.deleteFramebuffer(A.__webglMultisampledFramebuffer),A.__webglColorRenderbuffer)for(let mt=0;mt<A.__webglColorRenderbuffer.length;mt++)A.__webglColorRenderbuffer[mt]&&s.deleteRenderbuffer(A.__webglColorRenderbuffer[mt]);A.__webglDepthRenderbuffer&&s.deleteRenderbuffer(A.__webglDepthRenderbuffer)}const et=F.textures;for(let mt=0,Mt=et.length;mt<Mt;mt++){const Ht=a.get(et[mt]);Ht.__webglTexture&&(s.deleteTexture(Ht.__webglTexture),u.memory.textures--),a.remove(et[mt])}a.remove(F)}let $=0;function lt(){$=0}function X(){return $}function k(F){$=F}function H(){const F=$;return F>=o.maxTextures&&ye("WebGLTextures: Trying to use "+(F+1)+" texture units while this GPU supports only "+o.maxTextures),$+=1,F}function Y(F){const A=[];return A.push(F.wrapS),A.push(F.wrapT),A.push(F.wrapR||0),A.push(F.magFilter),A.push(F.minFilter),A.push(F.anisotropy),A.push(F.internalFormat),A.push(F.format),A.push(F.type),A.push(F.generateMipmaps),A.push(F.premultiplyAlpha),A.push(F.flipY),A.push(F.unpackAlignment),A.push(F.colorSpace),A.join()}function it(F,A){const et=a.get(F);if(F.isVideoTexture&&j(F),F.isRenderTargetTexture===!1&&F.isExternalTexture!==!0&&F.version>0&&et.__version!==F.version){const mt=F.image;if(mt===null)ye("WebGLRenderer: Texture marked for update but no image data found.");else if(mt.complete===!1)ye("WebGLRenderer: Texture marked for update but image is incomplete");else{Ft(et,F,A);return}}else F.isExternalTexture&&(et.__webglTexture=F.sourceTexture?F.sourceTexture:null);n.bindTexture(s.TEXTURE_2D,et.__webglTexture,s.TEXTURE0+A)}function rt(F,A){const et=a.get(F);if(F.isRenderTargetTexture===!1&&F.version>0&&et.__version!==F.version){Ft(et,F,A);return}else F.isExternalTexture&&(et.__webglTexture=F.sourceTexture?F.sourceTexture:null);n.bindTexture(s.TEXTURE_2D_ARRAY,et.__webglTexture,s.TEXTURE0+A)}function ht(F,A){const et=a.get(F);if(F.isRenderTargetTexture===!1&&F.version>0&&et.__version!==F.version){Ft(et,F,A);return}n.bindTexture(s.TEXTURE_3D,et.__webglTexture,s.TEXTURE0+A)}function I(F,A){const et=a.get(F);if(F.isCubeDepthTexture!==!0&&F.version>0&&et.__version!==F.version){$t(et,F,A);return}n.bindTexture(s.TEXTURE_CUBE_MAP,et.__webglTexture,s.TEXTURE0+A)}const ct={[Ka]:s.REPEAT,[Wa]:s.CLAMP_TO_EDGE,[tp]:s.MIRRORED_REPEAT},Tt={[ri]:s.NEAREST,[e1]:s.NEAREST_MIPMAP_NEAREST,[Kc]:s.NEAREST_MIPMAP_LINEAR,[Wn]:s.LINEAR,[sd]:s.LINEAR_MIPMAP_NEAREST,[Qs]:s.LINEAR_MIPMAP_LINEAR},Ut={[s1]:s.NEVER,[u1]:s.ALWAYS,[r1]:s.LESS,[Gu]:s.LEQUAL,[o1]:s.EQUAL,[Vu]:s.GEQUAL,[l1]:s.GREATER,[c1]:s.NOTEQUAL};function Vt(F,A){if(A.type===oa&&t.has("OES_texture_float_linear")===!1&&(A.magFilter===Wn||A.magFilter===sd||A.magFilter===Kc||A.magFilter===Qs||A.minFilter===Wn||A.minFilter===sd||A.minFilter===Kc||A.minFilter===Qs)&&ye("WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),s.texParameteri(F,s.TEXTURE_WRAP_S,ct[A.wrapS]),s.texParameteri(F,s.TEXTURE_WRAP_T,ct[A.wrapT]),(F===s.TEXTURE_3D||F===s.TEXTURE_2D_ARRAY)&&s.texParameteri(F,s.TEXTURE_WRAP_R,ct[A.wrapR]),s.texParameteri(F,s.TEXTURE_MAG_FILTER,Tt[A.magFilter]),s.texParameteri(F,s.TEXTURE_MIN_FILTER,Tt[A.minFilter]),A.compareFunction&&(s.texParameteri(F,s.TEXTURE_COMPARE_MODE,s.COMPARE_REF_TO_TEXTURE),s.texParameteri(F,s.TEXTURE_COMPARE_FUNC,Ut[A.compareFunction])),t.has("EXT_texture_filter_anisotropic")===!0){if(A.magFilter===ri||A.minFilter!==Kc&&A.minFilter!==Qs||A.type===oa&&t.has("OES_texture_float_linear")===!1)return;if(A.anisotropy>1||a.get(A).__currentAnisotropy){const et=t.get("EXT_texture_filter_anisotropic");s.texParameterf(F,et.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(A.anisotropy,o.getMaxAnisotropy())),a.get(A).__currentAnisotropy=A.anisotropy}}}function Bt(F,A){let et=!1;F.__webglInit===void 0&&(F.__webglInit=!0,A.addEventListener("dispose",N));const mt=A.source;let Mt=x.get(mt);Mt===void 0&&(Mt={},x.set(mt,Mt));const Ht=Y(A);if(Ht!==F.__cacheKey){Mt[Ht]===void 0&&(Mt[Ht]={texture:s.createTexture(),usedTimes:0},u.memory.textures++,et=!0),Mt[Ht].usedTimes++;const kt=Mt[F.__cacheKey];kt!==void 0&&(Mt[F.__cacheKey].usedTimes--,kt.usedTimes===0&&W(A)),F.__cacheKey=Ht,F.__webglTexture=Mt[Ht].texture}return et}function ft(F,A,et){return Math.floor(Math.floor(F/et)/A)}function Et(F,A,et,mt){const Ht=F.updateRanges;if(Ht.length===0)n.texSubImage2D(s.TEXTURE_2D,0,0,0,A.width,A.height,et,mt,A.data);else{Ht.sort((gt,wt)=>gt.start-wt.start);let kt=0;for(let gt=1;gt<Ht.length;gt++){const wt=Ht[kt],Lt=Ht[gt],q=wt.start+wt.count,Z=ft(Lt.start,A.width,4),at=ft(wt.start,A.width,4);Lt.start<=q+1&&Z===at&&ft(Lt.start+Lt.count-1,A.width,4)===Z?wt.count=Math.max(wt.count,Lt.start+Lt.count-wt.start):(++kt,Ht[kt]=Lt)}Ht.length=kt+1;const yt=n.getParameter(s.UNPACK_ROW_LENGTH),xt=n.getParameter(s.UNPACK_SKIP_PIXELS),zt=n.getParameter(s.UNPACK_SKIP_ROWS);n.pixelStorei(s.UNPACK_ROW_LENGTH,A.width);for(let gt=0,wt=Ht.length;gt<wt;gt++){const Lt=Ht[gt],q=Math.floor(Lt.start/4),Z=Math.ceil(Lt.count/4),at=q%A.width,w=Math.floor(q/A.width),G=Z,V=1;n.pixelStorei(s.UNPACK_SKIP_PIXELS,at),n.pixelStorei(s.UNPACK_SKIP_ROWS,w),n.texSubImage2D(s.TEXTURE_2D,0,at,w,G,V,et,mt,A.data)}F.clearUpdateRanges(),n.pixelStorei(s.UNPACK_ROW_LENGTH,yt),n.pixelStorei(s.UNPACK_SKIP_PIXELS,xt),n.pixelStorei(s.UNPACK_SKIP_ROWS,zt)}}function Ft(F,A,et){let mt=s.TEXTURE_2D;(A.isDataArrayTexture||A.isCompressedArrayTexture)&&(mt=s.TEXTURE_2D_ARRAY),A.isData3DTexture&&(mt=s.TEXTURE_3D);const Mt=Bt(F,A),Ht=A.source;n.bindTexture(mt,F.__webglTexture,s.TEXTURE0+et);const kt=a.get(Ht);if(Ht.version!==kt.__version||Mt===!0){if(n.activeTexture(s.TEXTURE0+et),(typeof ImageBitmap<"u"&&A.image instanceof ImageBitmap)===!1){const V=qe.getPrimaries(qe.workingColorSpace),nt=A.colorSpace===Xa?null:qe.getPrimaries(A.colorSpace),ot=A.colorSpace===Xa||V===nt?s.NONE:s.BROWSER_DEFAULT_WEBGL;n.pixelStorei(s.UNPACK_FLIP_Y_WEBGL,A.flipY),n.pixelStorei(s.UNPACK_PREMULTIPLY_ALPHA_WEBGL,A.premultiplyAlpha),n.pixelStorei(s.UNPACK_COLORSPACE_CONVERSION_WEBGL,ot)}n.pixelStorei(s.UNPACK_ALIGNMENT,A.unpackAlignment);let xt=y(A.image,!1,o.maxTextureSize);xt=Se(A,xt);const zt=c.convert(A.format,A.colorSpace),gt=c.convert(A.type);let wt=E(A.internalFormat,zt,gt,A.normalized,A.colorSpace,A.isVideoTexture);Vt(mt,A);let Lt;const q=A.mipmaps,Z=A.isVideoTexture!==!0,at=kt.__version===void 0||Mt===!0,w=Ht.dataReady,G=L(A,xt);if(A.isDepthTexture)wt=U(A.format===js,A.type),at&&(Z?n.texStorage2D(s.TEXTURE_2D,1,wt,xt.width,xt.height):n.texImage2D(s.TEXTURE_2D,0,wt,xt.width,xt.height,0,zt,gt,null));else if(A.isDataTexture)if(q.length>0){Z&&at&&n.texStorage2D(s.TEXTURE_2D,G,wt,q[0].width,q[0].height);for(let V=0,nt=q.length;V<nt;V++)Lt=q[V],Z?w&&n.texSubImage2D(s.TEXTURE_2D,V,0,0,Lt.width,Lt.height,zt,gt,Lt.data):n.texImage2D(s.TEXTURE_2D,V,wt,Lt.width,Lt.height,0,zt,gt,Lt.data);A.generateMipmaps=!1}else Z?(at&&n.texStorage2D(s.TEXTURE_2D,G,wt,xt.width,xt.height),w&&Et(A,xt,zt,gt)):n.texImage2D(s.TEXTURE_2D,0,wt,xt.width,xt.height,0,zt,gt,xt.data);else if(A.isCompressedTexture)if(A.isCompressedArrayTexture){Z&&at&&n.texStorage3D(s.TEXTURE_2D_ARRAY,G,wt,q[0].width,q[0].height,xt.depth);for(let V=0,nt=q.length;V<nt;V++)if(Lt=q[V],A.format!==Qi)if(zt!==null)if(Z){if(w)if(A.layerUpdates.size>0){const ot=q_(Lt.width,Lt.height,A.format,A.type);for(const st of A.layerUpdates){const Ct=Lt.data.subarray(st*ot/Lt.data.BYTES_PER_ELEMENT,(st+1)*ot/Lt.data.BYTES_PER_ELEMENT);n.compressedTexSubImage3D(s.TEXTURE_2D_ARRAY,V,0,0,st,Lt.width,Lt.height,1,zt,Ct)}}else n.compressedTexSubImage3D(s.TEXTURE_2D_ARRAY,V,0,0,0,Lt.width,Lt.height,xt.depth,zt,Lt.data)}else n.compressedTexImage3D(s.TEXTURE_2D_ARRAY,V,wt,Lt.width,Lt.height,xt.depth,0,Lt.data,0,0);else ye("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else Z?w&&n.texSubImage3D(s.TEXTURE_2D_ARRAY,V,0,0,0,Lt.width,Lt.height,xt.depth,zt,gt,Lt.data):n.texImage3D(s.TEXTURE_2D_ARRAY,V,wt,Lt.width,Lt.height,xt.depth,0,zt,gt,Lt.data);A.layerUpdates.size>0&&A.clearLayerUpdates()}else{Z&&at&&n.texStorage2D(s.TEXTURE_2D,G,wt,q[0].width,q[0].height);for(let V=0,nt=q.length;V<nt;V++)Lt=q[V],A.format!==Qi?zt!==null?Z?w&&n.compressedTexSubImage2D(s.TEXTURE_2D,V,0,0,Lt.width,Lt.height,zt,Lt.data):n.compressedTexImage2D(s.TEXTURE_2D,V,wt,Lt.width,Lt.height,0,Lt.data):ye("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):Z?w&&n.texSubImage2D(s.TEXTURE_2D,V,0,0,Lt.width,Lt.height,zt,gt,Lt.data):n.texImage2D(s.TEXTURE_2D,V,wt,Lt.width,Lt.height,0,zt,gt,Lt.data)}else if(A.isDataArrayTexture)if(Z){if(at&&n.texStorage3D(s.TEXTURE_2D_ARRAY,G,wt,xt.width,xt.height,xt.depth),w)if(A.layerUpdates.size>0){const V=q_(xt.width,xt.height,A.format,A.type);for(const nt of A.layerUpdates){const ot=xt.data.subarray(nt*V/xt.data.BYTES_PER_ELEMENT,(nt+1)*V/xt.data.BYTES_PER_ELEMENT);n.texSubImage3D(s.TEXTURE_2D_ARRAY,0,0,0,nt,xt.width,xt.height,1,zt,gt,ot)}A.clearLayerUpdates()}else n.texSubImage3D(s.TEXTURE_2D_ARRAY,0,0,0,0,xt.width,xt.height,xt.depth,zt,gt,xt.data)}else n.texImage3D(s.TEXTURE_2D_ARRAY,0,wt,xt.width,xt.height,xt.depth,0,zt,gt,xt.data);else if(A.isData3DTexture)Z?(at&&n.texStorage3D(s.TEXTURE_3D,G,wt,xt.width,xt.height,xt.depth),w&&n.texSubImage3D(s.TEXTURE_3D,0,0,0,0,xt.width,xt.height,xt.depth,zt,gt,xt.data)):n.texImage3D(s.TEXTURE_3D,0,wt,xt.width,xt.height,xt.depth,0,zt,gt,xt.data);else if(A.isFramebufferTexture){if(at)if(Z)n.texStorage2D(s.TEXTURE_2D,G,wt,xt.width,xt.height);else{let V=xt.width,nt=xt.height;for(let ot=0;ot<G;ot++)n.texImage2D(s.TEXTURE_2D,ot,wt,V,nt,0,zt,gt,null),V>>=1,nt>>=1}}else if(A.isHTMLTexture){if("texElementImage2D"in s){const V=s.canvas;if(V.hasAttribute("layoutsubtree")||V.setAttribute("layoutsubtree","true"),xt.parentNode!==V){V.appendChild(xt),v.add(A),V.onpaint=nt=>{const ot=nt.changedElements;for(const st of v)ot.includes(st.image)&&(st.needsUpdate=!0)},V.requestPaint();return}if(s.texElementImage2D.length===3)s.texElementImage2D(s.TEXTURE_2D,s.RGBA8,xt);else{const ot=s.RGBA,st=s.RGBA,Ct=s.UNSIGNED_BYTE;s.texElementImage2D(s.TEXTURE_2D,0,ot,st,Ct,xt)}s.texParameteri(s.TEXTURE_2D,s.TEXTURE_MIN_FILTER,s.LINEAR),s.texParameteri(s.TEXTURE_2D,s.TEXTURE_WRAP_S,s.CLAMP_TO_EDGE),s.texParameteri(s.TEXTURE_2D,s.TEXTURE_WRAP_T,s.CLAMP_TO_EDGE)}}else if(q.length>0){if(Z&&at){const V=Ee(q[0]);n.texStorage2D(s.TEXTURE_2D,G,wt,V.width,V.height)}for(let V=0,nt=q.length;V<nt;V++)Lt=q[V],Z?w&&n.texSubImage2D(s.TEXTURE_2D,V,0,0,zt,gt,Lt):n.texImage2D(s.TEXTURE_2D,V,wt,zt,gt,Lt);A.generateMipmaps=!1}else if(Z){if(at){const V=Ee(xt);n.texStorage2D(s.TEXTURE_2D,G,wt,V.width,V.height)}w&&n.texSubImage2D(s.TEXTURE_2D,0,0,0,zt,gt,xt)}else n.texImage2D(s.TEXTURE_2D,0,wt,zt,gt,xt);M(A)&&C(mt),kt.__version=Ht.version,A.onUpdate&&A.onUpdate(A)}F.__version=A.version}function $t(F,A,et){if(A.image.length!==6)return;const mt=Bt(F,A),Mt=A.source;n.bindTexture(s.TEXTURE_CUBE_MAP,F.__webglTexture,s.TEXTURE0+et);const Ht=a.get(Mt);if(Mt.version!==Ht.__version||mt===!0){n.activeTexture(s.TEXTURE0+et);const kt=qe.getPrimaries(qe.workingColorSpace),yt=A.colorSpace===Xa?null:qe.getPrimaries(A.colorSpace),xt=A.colorSpace===Xa||kt===yt?s.NONE:s.BROWSER_DEFAULT_WEBGL;n.pixelStorei(s.UNPACK_FLIP_Y_WEBGL,A.flipY),n.pixelStorei(s.UNPACK_PREMULTIPLY_ALPHA_WEBGL,A.premultiplyAlpha),n.pixelStorei(s.UNPACK_ALIGNMENT,A.unpackAlignment),n.pixelStorei(s.UNPACK_COLORSPACE_CONVERSION_WEBGL,xt);const zt=A.isCompressedTexture||A.image[0].isCompressedTexture,gt=A.image[0]&&A.image[0].isDataTexture,wt=[];for(let st=0;st<6;st++)!zt&&!gt?wt[st]=y(A.image[st],!0,o.maxCubemapSize):wt[st]=gt?A.image[st].image:A.image[st],wt[st]=Se(A,wt[st]);const Lt=wt[0],q=c.convert(A.format,A.colorSpace),Z=c.convert(A.type),at=E(A.internalFormat,q,Z,A.normalized,A.colorSpace),w=A.isVideoTexture!==!0,G=Ht.__version===void 0||mt===!0,V=Mt.dataReady;let nt=L(A,Lt);Vt(s.TEXTURE_CUBE_MAP,A);let ot;if(zt){w&&G&&n.texStorage2D(s.TEXTURE_CUBE_MAP,nt,at,Lt.width,Lt.height);for(let st=0;st<6;st++){ot=wt[st].mipmaps;for(let Ct=0;Ct<ot.length;Ct++){const It=ot[Ct];A.format!==Qi?q!==null?w?V&&n.compressedTexSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+st,Ct,0,0,It.width,It.height,q,It.data):n.compressedTexImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+st,Ct,at,It.width,It.height,0,It.data):ye("WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):w?V&&n.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+st,Ct,0,0,It.width,It.height,q,Z,It.data):n.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+st,Ct,at,It.width,It.height,0,q,Z,It.data)}}}else{if(ot=A.mipmaps,w&&G){ot.length>0&&nt++;const st=Ee(wt[0]);n.texStorage2D(s.TEXTURE_CUBE_MAP,nt,at,st.width,st.height)}for(let st=0;st<6;st++)if(gt){w?V&&n.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+st,0,0,0,wt[st].width,wt[st].height,q,Z,wt[st].data):n.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+st,0,at,wt[st].width,wt[st].height,0,q,Z,wt[st].data);for(let Ct=0;Ct<ot.length;Ct++){const te=ot[Ct].image[st].image;w?V&&n.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+st,Ct+1,0,0,te.width,te.height,q,Z,te.data):n.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+st,Ct+1,at,te.width,te.height,0,q,Z,te.data)}}else{w?V&&n.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+st,0,0,0,q,Z,wt[st]):n.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+st,0,at,q,Z,wt[st]);for(let Ct=0;Ct<ot.length;Ct++){const It=ot[Ct];w?V&&n.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+st,Ct+1,0,0,q,Z,It.image[st]):n.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+st,Ct+1,at,q,Z,It.image[st])}}}M(A)&&C(s.TEXTURE_CUBE_MAP),Ht.__version=Mt.version,A.onUpdate&&A.onUpdate(A)}F.__version=A.version}function Xt(F,A,et,mt,Mt,Ht){const kt=c.convert(et.format,et.colorSpace),yt=c.convert(et.type),xt=E(et.internalFormat,kt,yt,et.normalized,et.colorSpace),zt=a.get(A),gt=a.get(et);if(gt.__renderTarget=A,!zt.__hasExternalTextures){const wt=Math.max(1,A.width>>Ht),Lt=Math.max(1,A.height>>Ht);Mt===s.TEXTURE_3D||Mt===s.TEXTURE_2D_ARRAY?n.texImage3D(Mt,Ht,xt,wt,Lt,A.depth,0,kt,yt,null):n.texImage2D(Mt,Ht,xt,wt,Lt,0,kt,yt,null)}n.bindFramebuffer(s.FRAMEBUFFER,F),Ue(A)?h.framebufferTexture2DMultisampleEXT(s.FRAMEBUFFER,mt,Mt,gt.__webglTexture,0,ie(A)):(Mt===s.TEXTURE_2D||Mt>=s.TEXTURE_CUBE_MAP_POSITIVE_X&&Mt<=s.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&s.framebufferTexture2D(s.FRAMEBUFFER,mt,Mt,gt.__webglTexture,Ht),n.bindFramebuffer(s.FRAMEBUFFER,null)}function oe(F,A,et){if(s.bindRenderbuffer(s.RENDERBUFFER,F),A.depthBuffer){const mt=A.depthTexture,Mt=mt&&mt.isDepthTexture?mt.type:null,Ht=U(A.stencilBuffer,Mt),kt=A.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT;Ue(A)?h.renderbufferStorageMultisampleEXT(s.RENDERBUFFER,ie(A),Ht,A.width,A.height):et?s.renderbufferStorageMultisample(s.RENDERBUFFER,ie(A),Ht,A.width,A.height):s.renderbufferStorage(s.RENDERBUFFER,Ht,A.width,A.height),s.framebufferRenderbuffer(s.FRAMEBUFFER,kt,s.RENDERBUFFER,F)}else{const mt=A.textures;for(let Mt=0;Mt<mt.length;Mt++){const Ht=mt[Mt],kt=c.convert(Ht.format,Ht.colorSpace),yt=c.convert(Ht.type),xt=E(Ht.internalFormat,kt,yt,Ht.normalized,Ht.colorSpace);Ue(A)?h.renderbufferStorageMultisampleEXT(s.RENDERBUFFER,ie(A),xt,A.width,A.height):et?s.renderbufferStorageMultisample(s.RENDERBUFFER,ie(A),xt,A.width,A.height):s.renderbufferStorage(s.RENDERBUFFER,xt,A.width,A.height)}}s.bindRenderbuffer(s.RENDERBUFFER,null)}function Ye(F,A,et){const mt=A.isWebGLCubeRenderTarget===!0;if(n.bindFramebuffer(s.FRAMEBUFFER,F),!(A.depthTexture&&A.depthTexture.isDepthTexture))throw new Error("THREE.WebGLTextures: renderTarget.depthTexture must be an instance of THREE.DepthTexture.");const Mt=a.get(A.depthTexture);if(Mt.__renderTarget=A,(!Mt.__webglTexture||A.depthTexture.image.width!==A.width||A.depthTexture.image.height!==A.height)&&(A.depthTexture.image.width=A.width,A.depthTexture.image.height=A.height,A.depthTexture.needsUpdate=!0),mt){if(Mt.__webglInit===void 0&&(Mt.__webglInit=!0,A.depthTexture.addEventListener("dispose",N)),Mt.__webglTexture===void 0){Mt.__webglTexture=s.createTexture(),n.bindTexture(s.TEXTURE_CUBE_MAP,Mt.__webglTexture),Vt(s.TEXTURE_CUBE_MAP,A.depthTexture);const zt=c.convert(A.depthTexture.format),gt=c.convert(A.depthTexture.type);let wt;A.depthTexture.format===Ma?wt=s.DEPTH_COMPONENT24:A.depthTexture.format===js&&(wt=s.DEPTH24_STENCIL8);for(let Lt=0;Lt<6;Lt++)s.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+Lt,0,wt,A.width,A.height,0,zt,gt,null)}}else it(A.depthTexture,0);const Ht=Mt.__webglTexture,kt=ie(A),yt=mt?s.TEXTURE_CUBE_MAP_POSITIVE_X+et:s.TEXTURE_2D,xt=A.depthTexture.format===js?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT;if(A.depthTexture.format===Ma)Ue(A)?h.framebufferTexture2DMultisampleEXT(s.FRAMEBUFFER,xt,yt,Ht,0,kt):s.framebufferTexture2D(s.FRAMEBUFFER,xt,yt,Ht,0);else if(A.depthTexture.format===js)Ue(A)?h.framebufferTexture2DMultisampleEXT(s.FRAMEBUFFER,xt,yt,Ht,0,kt):s.framebufferTexture2D(s.FRAMEBUFFER,xt,yt,Ht,0);else throw new Error("THREE.WebGLTextures: Unknown depthTexture format.")}function jt(F){const A=a.get(F),et=F.isWebGLCubeRenderTarget===!0;if(A.__boundDepthTexture!==F.depthTexture){const mt=F.depthTexture;if(A.__depthDisposeCallback&&A.__depthDisposeCallback(),mt){const Mt=()=>{delete A.__boundDepthTexture,delete A.__depthDisposeCallback,mt.removeEventListener("dispose",Mt)};mt.addEventListener("dispose",Mt),A.__depthDisposeCallback=Mt}A.__boundDepthTexture=mt}if(F.depthTexture&&!A.__autoAllocateDepthBuffer)if(et)for(let mt=0;mt<6;mt++)Ye(A.__webglFramebuffer[mt],F,mt);else{const mt=F.texture.mipmaps;mt&&mt.length>0?Ye(A.__webglFramebuffer[0],F,0):Ye(A.__webglFramebuffer,F,0)}else if(et){A.__webglDepthbuffer=[];for(let mt=0;mt<6;mt++)if(n.bindFramebuffer(s.FRAMEBUFFER,A.__webglFramebuffer[mt]),A.__webglDepthbuffer[mt]===void 0)A.__webglDepthbuffer[mt]=s.createRenderbuffer(),oe(A.__webglDepthbuffer[mt],F,!1);else{const Mt=F.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT,Ht=A.__webglDepthbuffer[mt];s.bindRenderbuffer(s.RENDERBUFFER,Ht),s.framebufferRenderbuffer(s.FRAMEBUFFER,Mt,s.RENDERBUFFER,Ht)}}else{const mt=F.texture.mipmaps;if(mt&&mt.length>0?n.bindFramebuffer(s.FRAMEBUFFER,A.__webglFramebuffer[0]):n.bindFramebuffer(s.FRAMEBUFFER,A.__webglFramebuffer),A.__webglDepthbuffer===void 0)A.__webglDepthbuffer=s.createRenderbuffer(),oe(A.__webglDepthbuffer,F,!1);else{const Mt=F.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT,Ht=A.__webglDepthbuffer;s.bindRenderbuffer(s.RENDERBUFFER,Ht),s.framebufferRenderbuffer(s.FRAMEBUFFER,Mt,s.RENDERBUFFER,Ht)}}n.bindFramebuffer(s.FRAMEBUFFER,null)}function de(F,A,et){const mt=a.get(F);A!==void 0&&Xt(mt.__webglFramebuffer,F,F.texture,s.COLOR_ATTACHMENT0,s.TEXTURE_2D,0),et!==void 0&&jt(F)}function xe(F){const A=F.texture,et=a.get(F),mt=a.get(A);F.addEventListener("dispose",T);const Mt=F.textures,Ht=F.isWebGLCubeRenderTarget===!0,kt=Mt.length>1;if(kt||(mt.__webglTexture===void 0&&(mt.__webglTexture=s.createTexture()),mt.__version=A.version,u.memory.textures++),Ht){et.__webglFramebuffer=[];for(let yt=0;yt<6;yt++)if(A.mipmaps&&A.mipmaps.length>0){et.__webglFramebuffer[yt]=[];for(let xt=0;xt<A.mipmaps.length;xt++)et.__webglFramebuffer[yt][xt]=s.createFramebuffer()}else et.__webglFramebuffer[yt]=s.createFramebuffer()}else{if(A.mipmaps&&A.mipmaps.length>0){et.__webglFramebuffer=[];for(let yt=0;yt<A.mipmaps.length;yt++)et.__webglFramebuffer[yt]=s.createFramebuffer()}else et.__webglFramebuffer=s.createFramebuffer();if(kt)for(let yt=0,xt=Mt.length;yt<xt;yt++){const zt=a.get(Mt[yt]);zt.__webglTexture===void 0&&(zt.__webglTexture=s.createTexture(),u.memory.textures++)}if(F.samples>0&&Ue(F)===!1){et.__webglMultisampledFramebuffer=s.createFramebuffer(),et.__webglColorRenderbuffer=[],n.bindFramebuffer(s.FRAMEBUFFER,et.__webglMultisampledFramebuffer);for(let yt=0;yt<Mt.length;yt++){const xt=Mt[yt];et.__webglColorRenderbuffer[yt]=s.createRenderbuffer(),s.bindRenderbuffer(s.RENDERBUFFER,et.__webglColorRenderbuffer[yt]);const zt=c.convert(xt.format,xt.colorSpace),gt=c.convert(xt.type),wt=E(xt.internalFormat,zt,gt,xt.normalized,xt.colorSpace,F.isXRRenderTarget===!0),Lt=ie(F);s.renderbufferStorageMultisample(s.RENDERBUFFER,Lt,wt,F.width,F.height),s.framebufferRenderbuffer(s.FRAMEBUFFER,s.COLOR_ATTACHMENT0+yt,s.RENDERBUFFER,et.__webglColorRenderbuffer[yt])}s.bindRenderbuffer(s.RENDERBUFFER,null),F.depthBuffer&&(et.__webglDepthRenderbuffer=s.createRenderbuffer(),oe(et.__webglDepthRenderbuffer,F,!0)),n.bindFramebuffer(s.FRAMEBUFFER,null)}}if(Ht){n.bindTexture(s.TEXTURE_CUBE_MAP,mt.__webglTexture),Vt(s.TEXTURE_CUBE_MAP,A);for(let yt=0;yt<6;yt++)if(A.mipmaps&&A.mipmaps.length>0)for(let xt=0;xt<A.mipmaps.length;xt++)Xt(et.__webglFramebuffer[yt][xt],F,A,s.COLOR_ATTACHMENT0,s.TEXTURE_CUBE_MAP_POSITIVE_X+yt,xt);else Xt(et.__webglFramebuffer[yt],F,A,s.COLOR_ATTACHMENT0,s.TEXTURE_CUBE_MAP_POSITIVE_X+yt,0);M(A)&&C(s.TEXTURE_CUBE_MAP),n.unbindTexture()}else if(kt){for(let yt=0,xt=Mt.length;yt<xt;yt++){const zt=Mt[yt],gt=a.get(zt);let wt=s.TEXTURE_2D;(F.isWebGL3DRenderTarget||F.isWebGLArrayRenderTarget)&&(wt=F.isWebGL3DRenderTarget?s.TEXTURE_3D:s.TEXTURE_2D_ARRAY),n.bindTexture(wt,gt.__webglTexture),Vt(wt,zt),Xt(et.__webglFramebuffer,F,zt,s.COLOR_ATTACHMENT0+yt,wt,0),M(zt)&&C(wt)}n.unbindTexture()}else{let yt=s.TEXTURE_2D;if((F.isWebGL3DRenderTarget||F.isWebGLArrayRenderTarget)&&(yt=F.isWebGL3DRenderTarget?s.TEXTURE_3D:s.TEXTURE_2D_ARRAY),n.bindTexture(yt,mt.__webglTexture),Vt(yt,A),A.mipmaps&&A.mipmaps.length>0)for(let xt=0;xt<A.mipmaps.length;xt++)Xt(et.__webglFramebuffer[xt],F,A,s.COLOR_ATTACHMENT0,yt,xt);else Xt(et.__webglFramebuffer,F,A,s.COLOR_ATTACHMENT0,yt,0);M(A)&&C(yt),n.unbindTexture()}F.depthBuffer&&jt(F)}function pe(F){const A=F.textures;for(let et=0,mt=A.length;et<mt;et++){const Mt=A[et];if(M(Mt)){const Ht=P(F),kt=a.get(Mt).__webglTexture;n.bindTexture(Ht,kt),C(Ht),n.unbindTexture()}}}const Ce=[],Xe=[];function Be(F){if(F.samples>0){if(Ue(F)===!1){const A=F.textures,et=F.width,mt=F.height;let Mt=s.COLOR_BUFFER_BIT;const Ht=F.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT,kt=a.get(F),yt=A.length>1;if(yt)for(let zt=0;zt<A.length;zt++)n.bindFramebuffer(s.FRAMEBUFFER,kt.__webglMultisampledFramebuffer),s.framebufferRenderbuffer(s.FRAMEBUFFER,s.COLOR_ATTACHMENT0+zt,s.RENDERBUFFER,null),n.bindFramebuffer(s.FRAMEBUFFER,kt.__webglFramebuffer),s.framebufferTexture2D(s.DRAW_FRAMEBUFFER,s.COLOR_ATTACHMENT0+zt,s.TEXTURE_2D,null,0);n.bindFramebuffer(s.READ_FRAMEBUFFER,kt.__webglMultisampledFramebuffer);const xt=F.texture.mipmaps;xt&&xt.length>0?n.bindFramebuffer(s.DRAW_FRAMEBUFFER,kt.__webglFramebuffer[0]):n.bindFramebuffer(s.DRAW_FRAMEBUFFER,kt.__webglFramebuffer);for(let zt=0;zt<A.length;zt++){if(F.resolveDepthBuffer&&(F.depthBuffer&&(Mt|=s.DEPTH_BUFFER_BIT),F.stencilBuffer&&F.resolveStencilBuffer&&(Mt|=s.STENCIL_BUFFER_BIT)),yt){s.framebufferRenderbuffer(s.READ_FRAMEBUFFER,s.COLOR_ATTACHMENT0,s.RENDERBUFFER,kt.__webglColorRenderbuffer[zt]);const gt=a.get(A[zt]).__webglTexture;s.framebufferTexture2D(s.DRAW_FRAMEBUFFER,s.COLOR_ATTACHMENT0,s.TEXTURE_2D,gt,0)}s.blitFramebuffer(0,0,et,mt,0,0,et,mt,Mt,s.NEAREST),p===!0&&(Ce.length=0,Xe.length=0,Ce.push(s.COLOR_ATTACHMENT0+zt),F.depthBuffer&&F.storeMultisampledDepthBuffer===!1&&(Ce.push(Ht),Xe.push(Ht),s.invalidateFramebuffer(s.DRAW_FRAMEBUFFER,Xe)),s.invalidateFramebuffer(s.READ_FRAMEBUFFER,Ce))}if(n.bindFramebuffer(s.READ_FRAMEBUFFER,null),n.bindFramebuffer(s.DRAW_FRAMEBUFFER,null),yt)for(let zt=0;zt<A.length;zt++){n.bindFramebuffer(s.FRAMEBUFFER,kt.__webglMultisampledFramebuffer),s.framebufferRenderbuffer(s.FRAMEBUFFER,s.COLOR_ATTACHMENT0+zt,s.RENDERBUFFER,kt.__webglColorRenderbuffer[zt]);const gt=a.get(A[zt]).__webglTexture;n.bindFramebuffer(s.FRAMEBUFFER,kt.__webglFramebuffer),s.framebufferTexture2D(s.DRAW_FRAMEBUFFER,s.COLOR_ATTACHMENT0+zt,s.TEXTURE_2D,gt,0)}n.bindFramebuffer(s.DRAW_FRAMEBUFFER,kt.__webglMultisampledFramebuffer)}else if(F.depthBuffer&&F.storeMultisampledDepthBuffer===!1&&p){const A=F.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT;s.invalidateFramebuffer(s.DRAW_FRAMEBUFFER,[A])}}}function ie(F){return Math.min(o.maxSamples,F.samples)}function Ue(F){const A=a.get(F);return F.samples>0&&t.has("WEBGL_multisampled_render_to_texture")===!0&&A.__useRenderToTexture!==!1}function j(F){const A=u.render.frame;g.get(F)!==A&&(g.set(F,A),F.update())}function Se(F,A){const et=F.colorSpace,mt=F.format,Mt=F.type;return F.isCompressedTexture===!0||F.isVideoTexture===!0||et!==Lu&&et!==Xa&&(qe.getTransfer(et)===on?(mt!==Qi||Mt!==Ti)&&ye("WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):Je("WebGLTextures: Unsupported texture color space:",et)),A}function Ee(F){return typeof HTMLImageElement<"u"&&F instanceof HTMLImageElement?(d.width=F.naturalWidth||F.width,d.height=F.naturalHeight||F.height):typeof VideoFrame<"u"&&F instanceof VideoFrame?(d.width=F.displayWidth,d.height=F.displayHeight):(d.width=F.width,d.height=F.height),d}this.allocateTextureUnit=H,this.resetTextureUnits=lt,this.getTextureUnits=X,this.setTextureUnits=k,this.setTexture2D=it,this.setTexture2DArray=rt,this.setTexture3D=ht,this.setTextureCube=I,this.rebindTextures=de,this.setupRenderTarget=xe,this.updateRenderTargetMipmap=pe,this.updateMultisampleRenderTarget=Be,this.setupDepthRenderbuffer=jt,this.setupFrameBufferTexture=Xt,this.useMultisampledRTT=Ue,this.isReversedDepthBuffer=function(){return n.buffers.depth.getReversed()}}function U3(s,t){function n(a,o=Xa){let c;const u=qe.getTransfer(o);if(a===Ti)return s.UNSIGNED_BYTE;if(a===Zp)return s.UNSIGNED_SHORT_4_4_4_4;if(a===Kp)return s.UNSIGNED_SHORT_5_5_5_1;if(a===Vx)return s.UNSIGNED_INT_5_9_9_9_REV;if(a===kx)return s.UNSIGNED_INT_10F_11F_11F_REV;if(a===Hx)return s.BYTE;if(a===Gx)return s.SHORT;if(a===Cl)return s.UNSIGNED_SHORT;if(a===Yp)return s.INT;if(a===la)return s.UNSIGNED_INT;if(a===oa)return s.FLOAT;if(a===ji)return s.HALF_FLOAT;if(a===Xx)return s.ALPHA;if(a===Wx)return s.RGB;if(a===Qi)return s.RGBA;if(a===Ma)return s.DEPTH_COMPONENT;if(a===js)return s.DEPTH_STENCIL;if(a===Jp)return s.RED;if(a===Qp)return s.RED_INTEGER;if(a===ir)return s.RG;if(a===jp)return s.RG_INTEGER;if(a===$p)return s.RGBA_INTEGER;if(a===Eu||a===Tu||a===Au||a===wu)if(u===on)if(c=t.get("WEBGL_compressed_texture_s3tc_srgb"),c!==null){if(a===Eu)return c.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(a===Tu)return c.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(a===Au)return c.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(a===wu)return c.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(c=t.get("WEBGL_compressed_texture_s3tc"),c!==null){if(a===Eu)return c.COMPRESSED_RGB_S3TC_DXT1_EXT;if(a===Tu)return c.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(a===Au)return c.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(a===wu)return c.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(a===ep||a===np||a===ip||a===ap)if(c=t.get("WEBGL_compressed_texture_pvrtc"),c!==null){if(a===ep)return c.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(a===np)return c.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(a===ip)return c.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(a===ap)return c.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(a===sp||a===rp||a===op||a===lp||a===cp||a===Du||a===up)if(c=t.get("WEBGL_compressed_texture_etc"),c!==null){if(a===sp||a===rp)return u===on?c.COMPRESSED_SRGB8_ETC2:c.COMPRESSED_RGB8_ETC2;if(a===op)return u===on?c.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:c.COMPRESSED_RGBA8_ETC2_EAC;if(a===lp)return c.COMPRESSED_R11_EAC;if(a===cp)return c.COMPRESSED_SIGNED_R11_EAC;if(a===Du)return c.COMPRESSED_RG11_EAC;if(a===up)return c.COMPRESSED_SIGNED_RG11_EAC}else return null;if(a===fp||a===hp||a===dp||a===pp||a===mp||a===gp||a===vp||a===_p||a===xp||a===Mp||a===yp||a===Sp||a===bp||a===Ep)if(c=t.get("WEBGL_compressed_texture_astc"),c!==null){if(a===fp)return u===on?c.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:c.COMPRESSED_RGBA_ASTC_4x4_KHR;if(a===hp)return u===on?c.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:c.COMPRESSED_RGBA_ASTC_5x4_KHR;if(a===dp)return u===on?c.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:c.COMPRESSED_RGBA_ASTC_5x5_KHR;if(a===pp)return u===on?c.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:c.COMPRESSED_RGBA_ASTC_6x5_KHR;if(a===mp)return u===on?c.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:c.COMPRESSED_RGBA_ASTC_6x6_KHR;if(a===gp)return u===on?c.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:c.COMPRESSED_RGBA_ASTC_8x5_KHR;if(a===vp)return u===on?c.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:c.COMPRESSED_RGBA_ASTC_8x6_KHR;if(a===_p)return u===on?c.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:c.COMPRESSED_RGBA_ASTC_8x8_KHR;if(a===xp)return u===on?c.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:c.COMPRESSED_RGBA_ASTC_10x5_KHR;if(a===Mp)return u===on?c.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:c.COMPRESSED_RGBA_ASTC_10x6_KHR;if(a===yp)return u===on?c.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:c.COMPRESSED_RGBA_ASTC_10x8_KHR;if(a===Sp)return u===on?c.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:c.COMPRESSED_RGBA_ASTC_10x10_KHR;if(a===bp)return u===on?c.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:c.COMPRESSED_RGBA_ASTC_12x10_KHR;if(a===Ep)return u===on?c.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:c.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(a===Tp||a===Ap||a===wp)if(c=t.get("EXT_texture_compression_bptc"),c!==null){if(a===Tp)return u===on?c.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:c.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(a===Ap)return c.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(a===wp)return c.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(a===Rp||a===Cp||a===Uu||a===Dp)if(c=t.get("EXT_texture_compression_rgtc"),c!==null){if(a===Rp)return c.COMPRESSED_RED_RGTC1_EXT;if(a===Cp)return c.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(a===Uu)return c.COMPRESSED_RED_GREEN_RGTC2_EXT;if(a===Dp)return c.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return a===Dl?s.UNSIGNED_INT_24_8:s[a]!==void 0?s[a]:null}return{convert:n}}const L3=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,N3=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class O3{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(t,n){if(this.texture===null){const a=new eM(t.texture);(t.depthNear!==n.depthNear||t.depthFar!==n.depthFar)&&(this.depthNear=t.depthNear,this.depthFar=t.depthFar),this.texture=a}}getMesh(t){if(this.texture!==null&&this.mesh===null){const n=t.cameras[0].viewport,a=new ui({vertexShader:L3,fragmentShader:N3,uniforms:{depthColor:{value:this.texture},depthWidth:{value:n.z},depthHeight:{value:n.w}}});this.mesh=new le(new jn(20,20),a)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class P3 extends lr{constructor(t,n){super();const a=this;let o=null,c=1,u=null,h="local-floor",p=1,d=null,g=null,v=null,_=null,x=null,b=null;const R=typeof XRWebGLBinding<"u",y=new O3,M={},C=n.getContextAttributes();let P=null,E=null;const U=[],L=[],N=new Ot;let T=null,z=null;const W=new zi;W.viewport=new _n;const J=new zi;J.viewport=new _n;const $=[W,J],lt=new kb;let X=null,k=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(ft){let Et=U[ft];return Et===void 0&&(Et=new hd,U[ft]=Et),Et.getTargetRaySpace()},this.getControllerGrip=function(ft){let Et=U[ft];return Et===void 0&&(Et=new hd,U[ft]=Et),Et.getGripSpace()},this.getHand=function(ft){let Et=U[ft];return Et===void 0&&(Et=new hd,U[ft]=Et),Et.getHandSpace()};function H(ft){const Et=L.indexOf(ft.inputSource);if(Et===-1)return;const Ft=U[Et];Ft!==void 0&&(Ft.update(ft.inputSource,ft.frame,d||u),Ft.dispatchEvent({type:ft.type,data:ft.inputSource}))}function Y(){o.removeEventListener("select",H),o.removeEventListener("selectstart",H),o.removeEventListener("selectend",H),o.removeEventListener("squeeze",H),o.removeEventListener("squeezestart",H),o.removeEventListener("squeezeend",H),o.removeEventListener("end",Y),o.removeEventListener("inputsourceschange",it);for(let ft=0;ft<U.length;ft++){const Et=L[ft];Et!==null&&(L[ft]=null,U[ft].disconnect(Et))}X=null,k=null,y.reset();for(const ft in M)delete M[ft];if(t.setRenderTarget(P),x=null,_=null,v=null,o=null,E=null,Bt.stop(),a.isPresenting=!1,t.setPixelRatio(T),t.setSize(N.width,N.height,!1),z!==null){const ft=z.camera;ft.fov=z.fov,ft.zoom=z.zoom,ft.updateProjectionMatrix(),z=null}a.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(ft){c=ft,a.isPresenting===!0&&ye("WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(ft){h=ft,a.isPresenting===!0&&ye("WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return d||u},this.setReferenceSpace=function(ft){d=ft},this.getBaseLayer=function(){return _!==null?_:x},this.getBinding=function(){return v===null&&R&&(v=new XRWebGLBinding(o,n)),v},this.getFrame=function(){return b},this.getSession=function(){return o},this.setSession=async function(ft){if(o=ft,o!==null){if(P=t.getRenderTarget(),o.addEventListener("select",H),o.addEventListener("selectstart",H),o.addEventListener("selectend",H),o.addEventListener("squeeze",H),o.addEventListener("squeezestart",H),o.addEventListener("squeezeend",H),o.addEventListener("end",Y),o.addEventListener("inputsourceschange",it),C.xrCompatible!==!0&&await n.makeXRCompatible(),T=t.getPixelRatio(),t.getSize(N),R&&"createProjectionLayer"in XRWebGLBinding.prototype){let Ft=null,$t=null,Xt=null;C.depth&&(Xt=C.stencil?n.DEPTH24_STENCIL8:n.DEPTH_COMPONENT24,Ft=C.stencil?js:Ma,$t=C.stencil?Dl:la);const oe={colorFormat:n.RGBA8,depthFormat:Xt,scaleFactor:c};v=this.getBinding(),_=v.createProjectionLayer(oe),o.updateRenderState({layers:[_]}),t.setPixelRatio(1),t.setSize(_.textureWidth,_.textureHeight,!1),E=new Bi(_.textureWidth,_.textureHeight,{format:Qi,type:Ti,depthTexture:new po(_.textureWidth,_.textureHeight,$t,void 0,void 0,void 0,void 0,void 0,void 0,Ft),stencilBuffer:C.stencil,colorSpace:t.outputColorSpace,samples:C.antialias?4:0,resolveDepthBuffer:_.ignoreDepthValues===!1,resolveStencilBuffer:_.ignoreDepthValues===!1,storeMultisampledDepthBuffer:_.ignoreDepthValues===!1,storeMultisampledStencilBuffer:_.ignoreDepthValues===!1})}else{const Ft={antialias:C.antialias,alpha:!0,depth:C.depth,stencil:C.stencil,framebufferScaleFactor:c};x=new XRWebGLLayer(o,n,Ft),o.updateRenderState({baseLayer:x}),t.setPixelRatio(1),t.setSize(x.framebufferWidth,x.framebufferHeight,!1),E=new Bi(x.framebufferWidth,x.framebufferHeight,{format:Qi,type:Ti,colorSpace:t.outputColorSpace,stencilBuffer:C.stencil,resolveDepthBuffer:x.ignoreDepthValues===!1,resolveStencilBuffer:x.ignoreDepthValues===!1,storeMultisampledDepthBuffer:x.ignoreDepthValues===!1,storeMultisampledStencilBuffer:x.ignoreDepthValues===!1})}E.isXRRenderTarget=!0,this.setFoveation(p),d=null,u=await o.requestReferenceSpace(h),Bt.setContext(o),Bt.start(),a.isPresenting=!0,a.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(o!==null)return o.environmentBlendMode},this.getDepthTexture=function(){return y.getDepthTexture()};function it(ft){for(let Et=0;Et<ft.removed.length;Et++){const Ft=ft.removed[Et],$t=L.indexOf(Ft);$t>=0&&(L[$t]=null,U[$t].disconnect(Ft))}for(let Et=0;Et<ft.added.length;Et++){const Ft=ft.added[Et];let $t=L.indexOf(Ft);if($t===-1){for(let oe=0;oe<U.length;oe++)if(oe>=L.length){L.push(Ft),$t=oe;break}else if(L[oe]===null){L[oe]=Ft,$t=oe;break}if($t===-1)break}const Xt=U[$t];Xt&&Xt.connect(Ft)}}const rt=new B,ht=new B;function I(ft,Et,Ft){rt.setFromMatrixPosition(Et.matrixWorld),ht.setFromMatrixPosition(Ft.matrixWorld);const $t=rt.distanceTo(ht),Xt=Et.projectionMatrix.elements,oe=Ft.projectionMatrix.elements,Ye=Xt[14]/(Xt[10]-1),jt=Xt[14]/(Xt[10]+1),de=(Xt[9]+1)/Xt[5],xe=(Xt[9]-1)/Xt[5],pe=(Xt[8]-1)/Xt[0],Ce=(oe[8]+1)/oe[0],Xe=Ye*pe,Be=Ye*Ce,ie=$t/(-pe+Ce),Ue=ie*-pe;if(Et.matrixWorld.decompose(ft.position,ft.quaternion,ft.scale),ft.translateX(Ue),ft.translateZ(ie),ft.matrixWorld.compose(ft.position,ft.quaternion,ft.scale),ft.matrixWorldInverse.copy(ft.matrixWorld).invert(),Xt[10]===-1)ft.projectionMatrix.copy(Et.projectionMatrix),ft.projectionMatrixInverse.copy(Et.projectionMatrixInverse);else{const j=Ye+ie,Se=jt+ie,Ee=Xe-Ue,F=Be+($t-Ue),A=de*jt/Se*j,et=xe*jt/Se*j;ft.projectionMatrix.makePerspective(Ee,F,A,et,j,Se),ft.projectionMatrixInverse.copy(ft.projectionMatrix).invert()}}function ct(ft,Et){Et===null?ft.matrixWorld.copy(ft.matrix):ft.matrixWorld.multiplyMatrices(Et.matrixWorld,ft.matrix),ft.matrixWorldInverse.copy(ft.matrixWorld).invert()}this.updateCamera=function(ft){if(o===null)return;let Et=ft.near,Ft=ft.far;y.texture!==null&&(y.depthNear>0&&(Et=y.depthNear),y.depthFar>0&&(Ft=y.depthFar)),lt.near=J.near=W.near=Et,lt.far=J.far=W.far=Ft,(X!==lt.near||k!==lt.far)&&(o.updateRenderState({depthNear:lt.near,depthFar:lt.far}),X=lt.near,k=lt.far),lt.layers.mask=ft.layers.mask|6,W.layers.mask=lt.layers.mask&-5,J.layers.mask=lt.layers.mask&-3;const $t=ft.parent,Xt=lt.cameras;ct(lt,$t);for(let oe=0;oe<Xt.length;oe++)ct(Xt[oe],$t);Xt.length===2?I(lt,W,J):lt.projectionMatrix.copy(W.projectionMatrix),z===null&&ft.isPerspectiveCamera&&(z={camera:ft,fov:ft.fov,zoom:ft.zoom}),Tt(ft,lt,$t)};function Tt(ft,Et,Ft){Ft===null?ft.matrix.copy(Et.matrixWorld):(ft.matrix.copy(Ft.matrixWorld),ft.matrix.invert(),ft.matrix.multiply(Et.matrixWorld)),ft.matrix.decompose(ft.position,ft.quaternion,ft.scale),ft.updateMatrixWorld(!0),ft.projectionMatrix.copy(Et.projectionMatrix),ft.projectionMatrixInverse.copy(Et.projectionMatrixInverse),ft.isPerspectiveCamera&&(ft.fov=Ll*2*Math.atan(1/ft.projectionMatrix.elements[5]),ft.zoom=1)}this.getCamera=function(){return lt},this.getFoveation=function(){if(!(_===null&&x===null))return p},this.setFoveation=function(ft){p=ft,_!==null&&(_.fixedFoveation=ft),x!==null&&x.fixedFoveation!==void 0&&(x.fixedFoveation=ft)},this.hasDepthSensing=function(){return y.texture!==null},this.getDepthSensingMesh=function(){return y.getMesh(lt)},this.getCameraTexture=function(ft){return M[ft]};let Ut=null;function Vt(ft,Et){if(g=Et.getViewerPose(d||u),b=Et,g!==null){const Ft=g.views;x!==null&&(t.setRenderTargetFramebuffer(E,x.framebuffer),t.setRenderTarget(E));let $t=!1;Ft.length!==lt.cameras.length&&(lt.cameras.length=0,$t=!0);for(let jt=0;jt<Ft.length;jt++){const de=Ft[jt];let xe=null;if(x!==null)xe=x.getViewport(de);else{const Ce=v.getViewSubImage(_,de);xe=Ce.viewport,jt===0&&(t.setRenderTargetTextures(E,Ce.colorTexture,Ce.depthStencilTexture),t.setRenderTarget(E))}let pe=$[jt];pe===void 0&&(pe=new zi,pe.layers.enable(jt),pe.viewport=new _n,$[jt]=pe),pe.matrix.fromArray(de.transform.matrix),pe.matrix.decompose(pe.position,pe.quaternion,pe.scale),pe.projectionMatrix.fromArray(de.projectionMatrix),pe.projectionMatrixInverse.copy(pe.projectionMatrix).invert(),pe.viewport.set(xe.x,xe.y,xe.width,xe.height),jt===0&&(lt.matrix.copy(pe.matrix),lt.matrix.decompose(lt.position,lt.quaternion,lt.scale)),$t===!0&&lt.cameras.push(pe)}const Xt=o.enabledFeatures;if(Xt&&Xt.includes("depth-sensing")&&o.depthUsage=="gpu-optimized"&&R){v=a.getBinding();const jt=v.getDepthInformation(Ft[0]);jt&&jt.isValid&&jt.texture&&y.init(jt,o.renderState)}if(Xt&&Xt.includes("camera-access")&&R){t.state.unbindTexture(),v=a.getBinding();for(let jt=0;jt<Ft.length;jt++){const de=Ft[jt].camera;if(de){let xe=M[de];xe||(xe=new eM,M[de]=xe);const pe=v.getCameraImage(de);xe.sourceTexture=pe}}}}for(let Ft=0;Ft<U.length;Ft++){const $t=L[Ft],Xt=U[Ft];$t!==null&&Xt!==void 0&&Xt.update($t,Et,d||u)}Ut&&Ut(ft,Et),Et.detectedPlanes&&a.dispatchEvent({type:"planesdetected",data:Et}),b=null}const Bt=new pM;Bt.setAnimationLoop(Vt),this.setAnimationLoop=function(ft){Ut=ft},this.dispose=function(){}}}const z3=new ln,yM=new we;yM.set(-1,0,0,0,1,0,0,0,1);function I3(s,t){function n(y,M){y.matrixAutoUpdate===!0&&y.updateMatrix(),M.value.copy(y.matrix)}function a(y,M){M.color.getRGB(y.fogColor.value,fM(s)),M.isFog?(y.fogNear.value=M.near,y.fogFar.value=M.far):M.isFogExp2&&(y.fogDensity.value=M.density)}function o(y,M,C,P,E){M.isNodeMaterial?M.uniformsNeedUpdate=!1:M.isMeshBasicMaterial?c(y,M):M.isMeshLambertMaterial?(c(y,M),M.envMap&&(y.envMapIntensity.value=M.envMapIntensity)):M.isMeshToonMaterial?(c(y,M),v(y,M)):M.isMeshPhongMaterial?(c(y,M),g(y,M),M.envMap&&(y.envMapIntensity.value=M.envMapIntensity)):M.isMeshStandardMaterial?(c(y,M),_(y,M),M.isMeshPhysicalMaterial&&x(y,M,E)):M.isMeshMatcapMaterial?(c(y,M),b(y,M)):M.isMeshDepthMaterial?c(y,M):M.isMeshDistanceMaterial?(c(y,M),R(y,M)):M.isMeshNormalMaterial?c(y,M):M.isLineBasicMaterial?(u(y,M),M.isLineDashedMaterial&&h(y,M)):M.isPointsMaterial?p(y,M,C,P):M.isSpriteMaterial?d(y,M):M.isShadowMaterial?(y.color.value.copy(M.color),y.opacity.value=M.opacity):M.isShaderMaterial&&(M.uniformsNeedUpdate=!1)}function c(y,M){y.opacity.value=M.opacity,M.color&&y.diffuse.value.copy(M.color),M.emissive&&y.emissive.value.copy(M.emissive).multiplyScalar(M.emissiveIntensity),M.map&&(y.map.value=M.map,n(M.map,y.mapTransform)),M.alphaMap&&(y.alphaMap.value=M.alphaMap,n(M.alphaMap,y.alphaMapTransform)),M.bumpMap&&(y.bumpMap.value=M.bumpMap,n(M.bumpMap,y.bumpMapTransform),y.bumpScale.value=M.bumpScale,M.side===vi&&(y.bumpScale.value*=-1)),M.normalMap&&(y.normalMap.value=M.normalMap,n(M.normalMap,y.normalMapTransform),y.normalScale.value.copy(M.normalScale),M.side===vi&&y.normalScale.value.negate()),M.displacementMap&&(y.displacementMap.value=M.displacementMap,n(M.displacementMap,y.displacementMapTransform),y.displacementScale.value=M.displacementScale,y.displacementBias.value=M.displacementBias),M.emissiveMap&&(y.emissiveMap.value=M.emissiveMap,n(M.emissiveMap,y.emissiveMapTransform)),M.specularMap&&(y.specularMap.value=M.specularMap,n(M.specularMap,y.specularMapTransform)),M.alphaTest>0&&(y.alphaTest.value=M.alphaTest);const C=t.get(M),P=C.envMap,E=C.envMapRotation;P&&(y.envMap.value=P,y.envMapRotation.value.setFromMatrix4(z3.makeRotationFromEuler(E)).transpose(),P.isCubeTexture&&P.isRenderTargetTexture===!1&&y.envMapRotation.value.premultiply(yM),y.reflectivity.value=M.reflectivity,y.ior.value=M.ior,y.refractionRatio.value=M.refractionRatio),M.lightMap&&(y.lightMap.value=M.lightMap,y.lightMapIntensity.value=M.lightMapIntensity,n(M.lightMap,y.lightMapTransform)),M.aoMap&&(y.aoMap.value=M.aoMap,y.aoMapIntensity.value=M.aoMapIntensity,n(M.aoMap,y.aoMapTransform))}function u(y,M){y.diffuse.value.copy(M.color),y.opacity.value=M.opacity,M.map&&(y.map.value=M.map,n(M.map,y.mapTransform))}function h(y,M){y.dashSize.value=M.dashSize,y.totalSize.value=M.dashSize+M.gapSize,y.scale.value=M.scale}function p(y,M,C,P){y.diffuse.value.copy(M.color),y.opacity.value=M.opacity,y.size.value=M.size*C,y.scale.value=P*.5,M.map&&(y.map.value=M.map,n(M.map,y.uvTransform)),M.alphaMap&&(y.alphaMap.value=M.alphaMap,n(M.alphaMap,y.alphaMapTransform)),M.alphaTest>0&&(y.alphaTest.value=M.alphaTest)}function d(y,M){y.diffuse.value.copy(M.color),y.opacity.value=M.opacity,y.rotation.value=M.rotation,M.map&&(y.map.value=M.map,n(M.map,y.mapTransform)),M.alphaMap&&(y.alphaMap.value=M.alphaMap,n(M.alphaMap,y.alphaMapTransform)),M.alphaTest>0&&(y.alphaTest.value=M.alphaTest)}function g(y,M){y.specular.value.copy(M.specular),y.shininess.value=Math.max(M.shininess,1e-4)}function v(y,M){M.gradientMap&&(y.gradientMap.value=M.gradientMap)}function _(y,M){y.metalness.value=M.metalness,M.metalnessMap&&(y.metalnessMap.value=M.metalnessMap,n(M.metalnessMap,y.metalnessMapTransform)),y.roughness.value=M.roughness,M.roughnessMap&&(y.roughnessMap.value=M.roughnessMap,n(M.roughnessMap,y.roughnessMapTransform)),M.envMap&&(y.envMapIntensity.value=M.envMapIntensity)}function x(y,M,C){y.ior.value=M.ior,M.sheen>0&&(y.sheenColor.value.copy(M.sheenColor).multiplyScalar(M.sheen),y.sheenRoughness.value=M.sheenRoughness,M.sheenColorMap&&(y.sheenColorMap.value=M.sheenColorMap,n(M.sheenColorMap,y.sheenColorMapTransform)),M.sheenRoughnessMap&&(y.sheenRoughnessMap.value=M.sheenRoughnessMap,n(M.sheenRoughnessMap,y.sheenRoughnessMapTransform))),M.clearcoat>0&&(y.clearcoat.value=M.clearcoat,y.clearcoatRoughness.value=M.clearcoatRoughness,M.clearcoatMap&&(y.clearcoatMap.value=M.clearcoatMap,n(M.clearcoatMap,y.clearcoatMapTransform)),M.clearcoatRoughnessMap&&(y.clearcoatRoughnessMap.value=M.clearcoatRoughnessMap,n(M.clearcoatRoughnessMap,y.clearcoatRoughnessMapTransform)),M.clearcoatNormalMap&&(y.clearcoatNormalMap.value=M.clearcoatNormalMap,n(M.clearcoatNormalMap,y.clearcoatNormalMapTransform),y.clearcoatNormalScale.value.copy(M.clearcoatNormalScale),M.side===vi&&y.clearcoatNormalScale.value.negate())),M.dispersion>0&&(y.dispersion.value=M.dispersion),M.retroreflectivity>0&&(y.retroreflectivity.value=M.retroreflectivity),M.iridescence>0&&(y.iridescence.value=M.iridescence,y.iridescenceIOR.value=M.iridescenceIOR,y.iridescenceThicknessMinimum.value=M.iridescenceThicknessRange[0],y.iridescenceThicknessMaximum.value=M.iridescenceThicknessRange[1],M.iridescenceMap&&(y.iridescenceMap.value=M.iridescenceMap,n(M.iridescenceMap,y.iridescenceMapTransform)),M.iridescenceThicknessMap&&(y.iridescenceThicknessMap.value=M.iridescenceThicknessMap,n(M.iridescenceThicknessMap,y.iridescenceThicknessMapTransform))),M.transmission>0&&(y.transmission.value=M.transmission,y.transmissionSamplerMap.value=C.texture,y.transmissionSamplerSize.value.set(C.width,C.height),M.transmissionMap&&(y.transmissionMap.value=M.transmissionMap,n(M.transmissionMap,y.transmissionMapTransform)),y.thickness.value=M.thickness,M.thicknessMap&&(y.thicknessMap.value=M.thicknessMap,n(M.thicknessMap,y.thicknessMapTransform)),y.attenuationDistance.value=M.attenuationDistance,y.attenuationColor.value.copy(M.attenuationColor)),M.anisotropy>0&&(y.anisotropyVector.value.set(M.anisotropy*Math.cos(M.anisotropyRotation),M.anisotropy*Math.sin(M.anisotropyRotation)),M.anisotropyMap&&(y.anisotropyMap.value=M.anisotropyMap,n(M.anisotropyMap,y.anisotropyMapTransform))),y.specularIntensity.value=M.specularIntensity,y.specularColor.value.copy(M.specularColor),M.specularColorMap&&(y.specularColorMap.value=M.specularColorMap,n(M.specularColorMap,y.specularColorMapTransform)),M.specularIntensityMap&&(y.specularIntensityMap.value=M.specularIntensityMap,n(M.specularIntensityMap,y.specularIntensityMapTransform))}function b(y,M){M.matcap&&(y.matcap.value=M.matcap)}function R(y,M){const C=t.get(M).light;y.referencePosition.value.setFromMatrixPosition(C.matrixWorld),y.nearDistance.value=C.shadow.camera.near,y.farDistance.value=C.shadow.camera.far}return{refreshFogUniforms:a,refreshMaterialUniforms:o}}function B3(s,t,n,a){let o={},c={},u=[];const h=s.getParameter(s.MAX_UNIFORM_BUFFER_BINDINGS);function p(E,U){const L=U.program;a.uniformBlockBinding(E,L)}function d(E,U){let L=o[E.id];L===void 0&&(y(E),L=g(E),o[E.id]=L,E.addEventListener("dispose",C));const N=U.program;a.updateUBOMapping(E,N);const T=t.render.frame;c[E.id]!==T&&(_(E),c[E.id]=T)}function g(E){const U=v();E.__bindingPointIndex=U;const L=s.createBuffer(),N=E.__size,T=E.usage;return s.bindBuffer(s.UNIFORM_BUFFER,L),s.bufferData(s.UNIFORM_BUFFER,N,T),s.bindBuffer(s.UNIFORM_BUFFER,null),s.bindBufferBase(s.UNIFORM_BUFFER,U,L),L}function v(){for(let E=0;E<h;E++)if(u.indexOf(E)===-1)return u.push(E),E;return Je("WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function _(E){const U=o[E.id],L=E.uniforms,N=E.__cache;s.bindBuffer(s.UNIFORM_BUFFER,U);for(let T=0,z=L.length;T<z;T++){const W=L[T];if(Array.isArray(W))for(let J=0,$=W.length;J<$;J++)x(W[J],T,J,N);else x(W,T,0,N)}s.bindBuffer(s.UNIFORM_BUFFER,null)}function x(E,U,L,N){if(R(E,U,L,N)===!0){const T=E.__offset,z=E.value;if(Array.isArray(z)){let W=0;for(let J=0;J<z.length;J++){const $=z[J],lt=M($);b($,E.__data,W),typeof $!="number"&&typeof $!="boolean"&&!$.isMatrix3&&!ArrayBuffer.isView($)&&(W+=lt.storage/Float32Array.BYTES_PER_ELEMENT)}}else b(z,E.__data,0);s.bufferSubData(s.UNIFORM_BUFFER,T,E.__data)}}function b(E,U,L){typeof E=="number"||typeof E=="boolean"?U[0]=E:E.isMatrix3?(U[0]=E.elements[0],U[1]=E.elements[1],U[2]=E.elements[2],U[3]=0,U[4]=E.elements[3],U[5]=E.elements[4],U[6]=E.elements[5],U[7]=0,U[8]=E.elements[6],U[9]=E.elements[7],U[10]=E.elements[8],U[11]=0):ArrayBuffer.isView(E)?U.set(new E.constructor(E.buffer,E.byteOffset,U.length)):E.toArray(U,L)}function R(E,U,L,N){const T=E.value,z=U+"_"+L;if(N[z]===void 0)return typeof T=="number"||typeof T=="boolean"?N[z]=T:ArrayBuffer.isView(T)?N[z]=T.slice():N[z]=T.clone(),!0;{const W=N[z];if(typeof T=="number"||typeof T=="boolean"){if(W!==T)return N[z]=T,!0}else{if(ArrayBuffer.isView(T))return!0;if(W.equals(T)===!1)return W.copy(T),!0}}return!1}function y(E){const U=E.uniforms;let L=0;const N=16;for(let z=0,W=U.length;z<W;z++){const J=Array.isArray(U[z])?U[z]:[U[z]];for(let $=0,lt=J.length;$<lt;$++){const X=J[$],k=Array.isArray(X.value)?X.value:[X.value];for(let H=0,Y=k.length;H<Y;H++){const it=k[H],rt=M(it),ht=L%N,I=ht%rt.boundary,ct=ht+I;L+=I,ct!==0&&N-ct<rt.storage&&(L+=N-ct),X.__data=new Float32Array(rt.storage/Float32Array.BYTES_PER_ELEMENT),X.__offset=L,L+=rt.storage}}}const T=L%N;return T>0&&(L+=N-T),E.__size=L,E.__cache={},this}function M(E){const U={boundary:0,storage:0};return typeof E=="number"||typeof E=="boolean"?(U.boundary=4,U.storage=4):E.isVector2?(U.boundary=8,U.storage=8):E.isVector3||E.isColor?(U.boundary=16,U.storage=12):E.isVector4?(U.boundary=16,U.storage=16):E.isMatrix3?(U.boundary=48,U.storage=48):E.isMatrix4?(U.boundary=64,U.storage=64):E.isTexture?ye("WebGLRenderer: Texture samplers can not be part of an uniforms group."):ArrayBuffer.isView(E)?(U.boundary=16,U.storage=E.byteLength):ye("WebGLRenderer: Unsupported uniform value type.",E),U}function C(E){const U=E.target;U.removeEventListener("dispose",C);const L=u.indexOf(U.__bindingPointIndex);u.splice(L,1),s.deleteBuffer(o[U.id]),delete o[U.id],delete c[U.id]}function P(){for(const E in o)s.deleteBuffer(o[E]);u=[],o={},c={}}return{bind:p,update:d,dispose:P}}const F3=new Uint16Array([12469,15057,12620,14925,13266,14620,13807,14376,14323,13990,14545,13625,14713,13328,14840,12882,14931,12528,14996,12233,15039,11829,15066,11525,15080,11295,15085,10976,15082,10705,15073,10495,13880,14564,13898,14542,13977,14430,14158,14124,14393,13732,14556,13410,14702,12996,14814,12596,14891,12291,14937,11834,14957,11489,14958,11194,14943,10803,14921,10506,14893,10278,14858,9960,14484,14039,14487,14025,14499,13941,14524,13740,14574,13468,14654,13106,14743,12678,14818,12344,14867,11893,14889,11509,14893,11180,14881,10751,14852,10428,14812,10128,14765,9754,14712,9466,14764,13480,14764,13475,14766,13440,14766,13347,14769,13070,14786,12713,14816,12387,14844,11957,14860,11549,14868,11215,14855,10751,14825,10403,14782,10044,14729,9651,14666,9352,14599,9029,14967,12835,14966,12831,14963,12804,14954,12723,14936,12564,14917,12347,14900,11958,14886,11569,14878,11247,14859,10765,14828,10401,14784,10011,14727,9600,14660,9289,14586,8893,14508,8533,15111,12234,15110,12234,15104,12216,15092,12156,15067,12010,15028,11776,14981,11500,14942,11205,14902,10752,14861,10393,14812,9991,14752,9570,14682,9252,14603,8808,14519,8445,14431,8145,15209,11449,15208,11451,15202,11451,15190,11438,15163,11384,15117,11274,15055,10979,14994,10648,14932,10343,14871,9936,14803,9532,14729,9218,14645,8742,14556,8381,14461,8020,14365,7603,15273,10603,15272,10607,15267,10619,15256,10631,15231,10614,15182,10535,15118,10389,15042,10167,14963,9787,14883,9447,14800,9115,14710,8665,14615,8318,14514,7911,14411,7507,14279,7198,15314,9675,15313,9683,15309,9712,15298,9759,15277,9797,15229,9773,15166,9668,15084,9487,14995,9274,14898,8910,14800,8539,14697,8234,14590,7790,14479,7409,14367,7067,14178,6621,15337,8619,15337,8631,15333,8677,15325,8769,15305,8871,15264,8940,15202,8909,15119,8775,15022,8565,14916,8328,14804,8009,14688,7614,14569,7287,14448,6888,14321,6483,14088,6171,15350,7402,15350,7419,15347,7480,15340,7613,15322,7804,15287,7973,15229,8057,15148,8012,15046,7846,14933,7611,14810,7357,14682,7069,14552,6656,14421,6316,14251,5948,14007,5528,15356,5942,15356,5977,15353,6119,15348,6294,15332,6551,15302,6824,15249,7044,15171,7122,15070,7050,14949,6861,14818,6611,14679,6349,14538,6067,14398,5651,14189,5311,13935,4958,15359,4123,15359,4153,15356,4296,15353,4646,15338,5160,15311,5508,15263,5829,15188,6042,15088,6094,14966,6001,14826,5796,14678,5543,14527,5287,14377,4985,14133,4586,13869,4257,15360,1563,15360,1642,15358,2076,15354,2636,15341,3350,15317,4019,15273,4429,15203,4732,15105,4911,14981,4932,14836,4818,14679,4621,14517,4386,14359,4156,14083,3795,13808,3437,15360,122,15360,137,15358,285,15355,636,15344,1274,15322,2177,15281,2765,15215,3223,15120,3451,14995,3569,14846,3567,14681,3466,14511,3305,14344,3121,14037,2800,13753,2467,15360,0,15360,1,15359,21,15355,89,15346,253,15325,479,15287,796,15225,1148,15133,1492,15008,1749,14856,1882,14685,1886,14506,1783,14324,1608,13996,1398,13702,1183]);let ga=null;function H3(){return ga===null&&(ga=new jx(F3,16,16,ir,ji),ga.name="DFG_LUT",ga.minFilter=Wn,ga.magFilter=Wn,ga.wrapS=Wa,ga.wrapT=Wa,ga.generateMipmaps=!1,ga.needsUpdate=!0),ga}class G3{constructor(t={}){const{canvas:n=h1(),context:a=null,depth:o=!0,stencil:c=!1,alpha:u=!1,antialias:h=!1,premultipliedAlpha:p=!0,preserveDrawingBuffer:d=!1,powerPreference:g="default",failIfMajorPerformanceCaveat:v=!1,reversedDepthBuffer:_=!1,outputBufferType:x=Ti}=t;this.isWebGLRenderer=!0;let b;if(a!==null){if(typeof WebGLRenderingContext<"u"&&a instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");b=a.getContextAttributes().alpha}else b=u;const R=x,y=new Set([$p,jp,Qp]),M=new Set([Ti,la,Cl,Dl,Zp,Kp]),C=new Uint32Array(4),P=new Int32Array(4),E=new B;let U=null,L=null;const N=[],T=[];let z=null;this.domElement=n,this.debug={checkShaderErrors:!0,diagnostics:{keywords:!1},onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=xa,this.toneMappingExposure=1,this.transmissionResolutionScale=1;const W=this;let J=!1,$=null,lt=null,X=null,k=null;this._outputColorSpace=Ln;let H=0,Y=0,it=null,rt=-1,ht=null;const I=new _n,ct=new _n;let Tt=null;const Ut=new ce(0);let Vt=0,Bt=n.width,ft=n.height,Et=1,Ft=null,$t=null;const Xt=new _n(0,0,Bt,ft),oe=new _n(0,0,Bt,ft);let Ye=!1;const jt=new im;let de=!1,xe=!1;const pe=new ln,Ce=new B,Xe=new _n,Be={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};let ie=!1;function Ue(){return it===null?Et:1}let j=a;function Se(D,Q){return n.getContext(D,Q)}let Ee,F,A,et,mt,Mt,Ht,kt,yt,xt,zt,gt,wt,Lt,q,Z,at,w,G,V,nt,ot,st;try{const D={alpha:!0,depth:o,stencil:c,antialias:h,premultipliedAlpha:p,preserveDrawingBuffer:d,powerPreference:g,failIfMajorPerformanceCaveat:v};if("setAttribute"in n&&n.setAttribute("data-engine",`three.js r${Xp}`),n.addEventListener("webglcontextlost",te,!1),n.addEventListener("webglcontextrestored",se,!1),n.addEventListener("webglcontextcreationerror",Me,!1),j===null){const Q="webgl2";if(j=Se(Q,D),j===null)throw Se(Q)?new Error("THREE.WebGLRenderer: Error creating WebGL context with your selected attributes."):new Error("THREE.WebGLRenderer: Error creating WebGL context.")}Ct()}catch(D){throw n.removeEventListener("webglcontextlost",te,!1),n.removeEventListener("webglcontextrestored",se,!1),n.removeEventListener("webglcontextcreationerror",Me,!1),Je("WebGLRenderer: "+D.message),D}function Ct(){Ee=new H2(j),Ee.init(),nt=new U3(j,Ee),F=new D2(j,Ee,t,nt),A=new C3(j,Ee),F.reversedDepthBuffer&&_&&A.buffers.depth.setReversed(!0),lt=j.createFramebuffer(),X=j.createFramebuffer(),k=j.createFramebuffer(),et=new k2(j),mt=new m3,Mt=new D3(j,Ee,A,mt,F,nt,et),Ht=new F2(W),kt=new Wb(j),ot=new R2(j,kt),yt=new G2(j,kt,et,ot),xt=new W2(j,yt,kt,ot,et),w=new X2(j,F,Mt),q=new U2(mt),zt=new p3(W,Ht,Ee,F,ot,q),gt=new I3(W,mt),wt=new v3,Lt=new b3(Ee),at=new w2(W,Ht,A,xt,b,p),Z=new R3(W,xt,F),st=new B3(j,et,F,A),G=new C2(j,Ee,et),V=new V2(j,Ee,et),et.programs=zt.programs,W.capabilities=F,W.extensions=Ee,W.properties=mt,W.renderLists=wt,W.shadowMap=Z,W.state=A,W.info=et}R!==Ti&&(z=new Y2(R,n.width,n.height,h,o,c));const It=new P3(W,j);this.xr=It,this.getContext=function(){return j},this.getContextAttributes=function(){return j.getContextAttributes()},this.forceContextLoss=function(){const D=Ee.get("WEBGL_lose_context");D&&D.loseContext()},this.forceContextRestore=function(){const D=Ee.get("WEBGL_lose_context");D&&D.restoreContext()},this.getPixelRatio=function(){return Et},this.setPixelRatio=function(D){D!==void 0&&(Et=D,this.setSize(Bt,ft,!1))},this.getSize=function(D){return D.set(Bt,ft)},this.setSize=function(D,Q,bt=!0){if(It.isPresenting){ye("WebGLRenderer: Can't change size while VR device is presenting.");return}Bt=D,ft=Q,n.width=Math.floor(D*Et),n.height=Math.floor(Q*Et),bt===!0&&(n.style.width=D+"px",n.style.height=Q+"px"),z!==null&&z.setSize(n.width,n.height),this.setViewport(0,0,D,Q)},this.getDrawingBufferSize=function(D){return D.set(Bt*Et,ft*Et).floor()},this.setDrawingBufferSize=function(D,Q,bt){Bt=D,ft=Q,Et=bt,n.width=Math.floor(D*bt),n.height=Math.floor(Q*bt),this.setViewport(0,0,D,Q)},this.setEffects=function(D){if(R===Ti){Je("WebGLRenderer: setEffects() requires outputBufferType set to HalfFloatType or FloatType.");return}if(D){for(let Q=0;Q<D.length;Q++)if(D[Q].isOutputPass===!0){ye("WebGLRenderer: OutputPass is not needed in setEffects(). Tone mapping and color space conversion are applied automatically.");break}}z.setEffects(D||[])},this.getCurrentViewport=function(D){return D.copy(I)},this.getViewport=function(D){return D.copy(Xt)},this.setViewport=function(D,Q,bt,pt){D.isVector4?Xt.set(D.x,D.y,D.z,D.w):Xt.set(D,Q,bt,pt),A.viewport(I.copy(Xt).multiplyScalar(Et).round())},this.getScissor=function(D){return D.copy(oe)},this.setScissor=function(D,Q,bt,pt){D.isVector4?oe.set(D.x,D.y,D.z,D.w):oe.set(D,Q,bt,pt),A.scissor(ct.copy(oe).multiplyScalar(Et).round())},this.getScissorTest=function(){return Ye},this.setScissorTest=function(D){A.setScissorTest(Ye=D)},this.setOpaqueSort=function(D){Ft=D},this.setTransparentSort=function(D){$t=D},this.getClearColor=function(D){return D.copy(at.getClearColor())},this.setClearColor=function(){at.setClearColor(...arguments)},this.getClearAlpha=function(){return at.getClearAlpha()},this.setClearAlpha=function(){at.setClearAlpha(...arguments)},this.clear=function(D=!0,Q=!0,bt=!0){let pt=0;if(D){let dt=!1;if(it!==null){const qt=it.texture.format;dt=y.has(qt)}if(dt){const qt=it.texture.type,Jt=M.has(qt),Gt=at.getClearColor(),Zt=at.getClearAlpha(),Yt=Gt.r,Re=Gt.g,Fe=Gt.b;Jt?(C[0]=Yt,C[1]=Re,C[2]=Fe,C[3]=Zt,j.clearBufferuiv(j.COLOR,0,C)):(P[0]=Yt,P[1]=Re,P[2]=Fe,P[3]=Zt,j.clearBufferiv(j.COLOR,0,P))}else pt|=j.COLOR_BUFFER_BIT}Q&&(pt|=j.DEPTH_BUFFER_BIT,this.state.buffers.depth.setMask(!0)),bt&&(pt|=j.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),pt!==0&&j.clear(pt)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.setNodesHandler=function(D){D.setRenderer(this),$=D},this.dispose=function(){n.removeEventListener("webglcontextlost",te,!1),n.removeEventListener("webglcontextrestored",se,!1),n.removeEventListener("webglcontextcreationerror",Me,!1),at.dispose(),wt.dispose(),Lt.dispose(),mt.dispose(),Ht.dispose(),xt.dispose(),ot.dispose(),st.dispose(),zt.dispose(),It.dispose(),It.removeEventListener("sessionstart",Ze),It.removeEventListener("sessionend",un),Vn.stop()};function te(D){D.preventDefault(),r_("WebGLRenderer: Context Lost."),J=!0}function se(){r_("WebGLRenderer: Context Restored."),J=!1;const D=et.autoReset,Q=Z.enabled,bt=Z.autoUpdate,pt=Z.needsUpdate,dt=Z.type;Ct(),et.autoReset=D,Z.enabled=Q,Z.autoUpdate=bt,Z.needsUpdate=pt,Z.type=dt}function Me(D){Je("WebGLRenderer: A WebGL context could not be created. Reason: ",D.statusMessage)}function be(D){const Q=D.target;Q.removeEventListener("dispose",be),Te(Q)}function Te(D){cn(D),mt.remove(D)}function cn(D){const Q=mt.get(D).programs;Q!==void 0&&(Q.forEach(function(bt){zt.releaseProgram(bt)}),D.isShaderMaterial&&zt.releaseShaderCache(D))}this.renderBufferDirect=function(D,Q,bt,pt,dt,qt){Q===null&&(Q=Be);const Jt=dt.isMesh&&dt.matrixWorld.determinantAffine()<0,Gt=wn(D,Q,bt,pt,dt);A.setMaterial(pt,Jt);let Zt=bt.index,Yt=1;if(pt.wireframe===!0){if(Zt=yt.getWireframeAttribute(bt),Zt===void 0)return;Yt=2}const Re=bt.drawRange,Fe=bt.attributes.position;let ee=Re.start*Yt,Ke=(Re.start+Re.count)*Yt;qt!==null&&(ee=Math.max(ee,qt.start*Yt),Ke=Math.min(Ke,(qt.start+qt.count)*Yt)),Zt!==null?(ee=Math.max(ee,0),Ke=Math.min(Ke,Zt.count)):Fe!=null&&(ee=Math.max(ee,0),Ke=Math.min(Ke,Fe.count));const xn=Ke-ee;if(xn<0||xn===1/0)return;ot.setup(dt,pt,Gt,bt,Zt);let mn,Ne=G;if(Zt!==null&&(mn=kt.get(Zt),Ne=V,Ne.setIndex(mn)),dt.isMesh)pt.wireframe===!0?(A.setLineWidth(pt.wireframeLinewidth*Ue()),Ne.setMode(j.LINES)):Ne.setMode(j.TRIANGLES);else if(dt.isLine){let Pn=pt.linewidth;Pn===void 0&&(Pn=1),A.setLineWidth(Pn*Ue()),dt.isLineSegments?Ne.setMode(j.LINES):dt.isLineLoop?Ne.setMode(j.LINE_LOOP):Ne.setMode(j.LINE_STRIP)}else dt.isPoints?Ne.setMode(j.POINTS):dt.isSprite&&Ne.setMode(j.TRIANGLES);if(dt.isBatchedMesh)if(Ee.get("WEBGL_multi_draw"))Ne.renderMultiDraw(dt._multiDrawStarts,dt._multiDrawCounts,dt._multiDrawCount);else{const Pn=dt._multiDrawStarts,Qt=dt._multiDrawCounts,kn=dt._multiDrawCount,Oe=Zt?kt.get(Zt).bytesPerElement:1,hi=mt.get(pt).currentProgram.getUniforms();for(let Ai=0;Ai<kn;Ai++)hi.setValue(j,"_gl_DrawID",Ai),Ne.render(Pn[Ai]/Oe,Qt[Ai])}else if(dt.isInstancedMesh)Ne.renderInstances(ee,xn,dt.count);else if(bt.isInstancedBufferGeometry){const Pn=bt._maxInstanceCount!==void 0?bt._maxInstanceCount:1/0,Qt=Math.min(bt.instanceCount,Pn);Ne.renderInstances(ee,xn,Qt)}else Ne.render(ee,xn)};function Gn(D,Q,bt,pt){$!==null&&D.isNodeMaterial&&$.setObject(pt,D),de===!0&&q.setState(D,bt,!1),D.transparent===!0&&D.side===vn&&D.forceSinglePass===!1?(D.side=vi,D.needsUpdate=!0,fe(D,Q,pt),D.side=er,D.needsUpdate=!0,fe(D,Q,pt),D.side=vn):fe(D,Q,pt)}this.compile=function(D,Q,bt=null){bt===null&&(bt=D),$!==null&&$.renderStart(D,Q,bt),L=Lt.get(bt),L.init(Q),T.push(L),bt.traverseVisible(function(dt){dt.isLight&&dt.layers.test(Q.layers)&&(L.pushLight(dt),dt.castShadow&&L.pushShadow(dt))}),D!==bt&&D.traverseVisible(function(dt){dt.isLight&&dt.layers.test(Q.layers)&&(L.pushLight(dt),dt.castShadow&&L.pushShadow(dt))}),L.setupLights(),$!==null&&$.updateLights(L.state.lightsArray),xe=this.localClippingEnabled,de=q.init(this.clippingPlanes,xe),de===!0&&q.setGlobalState(this.clippingPlanes,Q),$!==null&&Z.render(L.state.shadowsArray,bt,Q);const pt=new Set;return D.traverse(function(dt){if(!(dt.isMesh||dt.isPoints||dt.isLine||dt.isSprite))return;const qt=dt.material;if(qt)if(Array.isArray(qt))for(let Jt=0;Jt<qt.length;Jt++){const Gt=qt[Jt];Gn(Gt,bt,Q,dt),pt.add(Gt)}else Gn(qt,bt,Q,dt),pt.add(qt)}),L=T.pop(),$!==null&&$.renderEnd(),pt},this.compileAsync=function(D,Q,bt=null){const pt=this.compile(D,Q,bt);return new Promise(dt=>{function qt(){if(pt.forEach(function(Jt){const Zt=mt.get(Jt).currentProgram;(Zt===void 0||Zt.isReady())&&pt.delete(Jt)}),pt.size===0){dt(D);return}setTimeout(qt,10)}Ee.get("KHR_parallel_shader_compile")!==null?qt():setTimeout(qt,10)})};let ei=null;function On(D){ei&&ei(D)}function Ze(){Vn.stop()}function un(){Vn.start()}const Vn=new pM;Vn.setAnimationLoop(On),typeof self<"u"&&Vn.setContext(self),this.setAnimationLoop=function(D){ei=D,It.setAnimationLoop(D),D===null?Vn.stop():Vn.start()},It.addEventListener("sessionstart",Ze),It.addEventListener("sessionend",un),this.render=function(D,Q){if(Q!==void 0&&Q.isCamera!==!0){Je("WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(J===!0)return;$!==null&&$.renderStart(D,Q);const bt=It.enabled===!0&&It.isPresenting===!0,pt=z!==null&&(it===null||bt)&&z.begin(W,it);if(D.matrixWorldAutoUpdate===!0&&D.updateMatrixWorld(),Q.parent===null&&Q.matrixWorldAutoUpdate===!0&&Q.updateMatrixWorld(),It.enabled===!0&&It.isPresenting===!0&&(z===null||z.isCompositing()===!1)&&(It.cameraAutoUpdate===!0&&It.updateCamera(Q),Q=It.getCamera()),D.isScene===!0&&D.onBeforeRender(W,D,Q,it),L=Lt.get(D,T.length),L.init(Q),L.state.textureUnits=Mt.getTextureUnits(),T.push(L),pe.multiplyMatrices(Q.projectionMatrix,Q.matrixWorldInverse),jt.setFromProjectionMatrix(pe,_a,Q.reversedDepth),xe=this.localClippingEnabled,de=q.init(this.clippingPlanes,xe),U=wt.get(D,N.length),U.init(),N.push(U),It.enabled===!0&&It.isPresenting===!0){const Jt=W.xr.getDepthSensingMesh();Jt!==null&&ca(Jt,Q,-1/0,W.sortObjects)}ca(D,Q,0,W.sortObjects),U.finish(),$!==null&&$.updateLights(L.state.lightsArray),W.sortObjects===!0&&U.sort(Ft,$t),ie=It.enabled===!1||It.isPresenting===!1||It.hasDepthSensing()===!1,ie&&at.addToRenderList(U,D),this.info.render.frame++,this.info.autoReset===!0&&this.info.reset(),de===!0&&q.beginShadows();const dt=L.state.shadowsArray;if(Z.render(dt,D,Q),de===!0&&q.endShadows(),(pt&&z.hasRenderPass())===!1){const Jt=U.opaque,Gt=U.transmissive;if(L.setupLights(),Q.isArrayCamera){const Zt=Q.cameras;if(Gt.length>0)for(let Yt=0,Re=Zt.length;Yt<Re;Yt++){const Fe=Zt[Yt];Wt(Jt,Gt,D,Fe)}ie&&at.render(D);for(let Yt=0,Re=Zt.length;Yt<Re;Yt++){const Fe=Zt[Yt];Rt(U,D,Fe,Fe.viewport)}}else Gt.length>0&&Wt(Jt,Gt,D,Q),ie&&at.render(D),Rt(U,D,Q)}it!==null&&Y===0&&(Mt.updateMultisampleRenderTarget(it),Mt.updateRenderTargetMipmap(it)),pt&&z.end(W),D.isScene===!0&&D.onAfterRender(W,D,Q),ot.resetDefaultState(),rt=-1,ht=null,T.pop(),T.length>0?(L=T[T.length-1],Mt.setTextureUnits(L.state.textureUnits),de===!0&&q.setGlobalState(W.clippingPlanes,L.state.camera)):L=null,N.pop(),N.length>0?U=N[N.length-1]:U=null,$!==null&&$.renderEnd()};function ca(D,Q,bt,pt){if(D.visible===!1)return;if(D.layers.test(Q.layers)){if(D.isGroup)bt=D.renderOrder;else if(D.isLOD)D.autoUpdate===!0&&D.update(Q);else if(D.isLightProbeGrid)L.pushLightProbeGrid(D);else if(D.isLight)L.pushLight(D),D.castShadow&&L.pushShadow(D);else if(D.isSprite){if(!D.frustumCulled||D.intersectsFrustum(jt)){pt&&Xe.setFromMatrixPosition(D.matrixWorld).applyMatrix4(pe);const Jt=xt.update(D),Gt=D.material;Gt.visible&&U.push(D,Jt,Gt,bt,Xe.z,null,Q)}}else if((D.isMesh||D.isLine||D.isPoints)&&(!D.frustumCulled||D.intersectsFrustum(jt))){const Jt=xt.update(D),Gt=D.material;if(pt&&(D.boundingSphere!==void 0?(D.boundingSphere===null&&D.computeBoundingSphere(),Xe.copy(D.boundingSphere.center)):(Jt.boundingSphere===null&&Jt.computeBoundingSphere(),Xe.copy(Jt.boundingSphere.center)),Xe.applyMatrix4(D.matrixWorld).applyMatrix4(pe)),Array.isArray(Gt)){const Zt=Jt.groups;for(let Yt=0,Re=Zt.length;Yt<Re;Yt++){const Fe=Zt[Yt],ee=Gt[Fe.materialIndex];ee&&ee.visible&&U.push(D,Jt,ee,bt,Xe.z,Fe,Q)}}else Gt.visible&&U.push(D,Jt,Gt,bt,Xe.z,null,Q)}}const qt=D.children;for(let Jt=0,Gt=qt.length;Jt<Gt;Jt++)ca(qt[Jt],Q,bt,pt)}function Rt(D,Q,bt,pt){const{opaque:dt,transmissive:qt,transparent:Jt}=D;L.setupLightsView(bt),de===!0&&q.setGlobalState(W.clippingPlanes,bt),pt&&A.viewport(I.copy(pt)),dt.length>0&&me(dt,Q,bt),qt.length>0&&me(qt,Q,bt),Jt.length>0&&me(Jt,Q,bt),A.buffers.depth.setTest(!0),A.buffers.depth.setMask(!0),A.buffers.color.setMask(!0),A.setPolygonOffset(!1)}function Wt(D,Q,bt,pt){if((bt.isScene===!0?bt.overrideMaterial:null)!==null)return;if(L.state.transmissionRenderTarget[pt.id]===void 0){const ee=Ee.has("EXT_color_buffer_half_float")||Ee.has("EXT_color_buffer_float");L.state.transmissionRenderTarget[pt.id]=new Bi(1,1,{generateMipmaps:!0,type:ee?ji:Ti,minFilter:Qs,samples:Math.max(4,F.samples),stencilBuffer:c,resolveDepthBuffer:!1,resolveStencilBuffer:!1,storeMultisampledDepthBuffer:!1,storeMultisampledStencilBuffer:!1,colorSpace:qe.workingColorSpace})}const qt=L.state.transmissionRenderTarget[pt.id],Jt=pt.viewport||I;qt.setSize(Jt.z*W.transmissionResolutionScale,Jt.w*W.transmissionResolutionScale);const Gt=W.getRenderTarget(),Zt=W.getActiveCubeFace(),Yt=W.getActiveMipmapLevel();W.setRenderTarget(qt),W.getClearColor(Ut),Vt=W.getClearAlpha(),Vt<1&&W.setClearColor(16777215,.5),W.clear(),ie&&at.render(bt);const Re=W.toneMapping;W.toneMapping=xa;const Fe=pt.viewport;if(pt.viewport!==void 0&&(pt.viewport=void 0),L.setupLightsView(pt),de===!0&&q.setGlobalState(W.clippingPlanes,pt),me(D,bt,pt),Mt.updateMultisampleRenderTarget(qt),Mt.updateRenderTargetMipmap(qt),Ee.has("WEBGL_multisampled_render_to_texture")===!1){let ee=!1;for(let Ke=0,xn=Q.length;Ke<xn;Ke++){const mn=Q[Ke],{object:Ne,geometry:Pn,material:Qt,group:kn}=mn;if(Qt.side===vn&&Ne.layers.test(pt.layers)){const Oe=Qt.side;Qt.side=vi,Qt.needsUpdate=!0,ue(Ne,bt,pt,Pn,Qt,kn),Qt.side=Oe,Qt.needsUpdate=!0,ee=!0}}ee===!0&&(Mt.updateMultisampleRenderTarget(qt),Mt.updateRenderTargetMipmap(qt))}W.setRenderTarget(Gt,Zt,Yt),W.setClearColor(Ut,Vt),Fe!==void 0&&(pt.viewport=Fe),W.toneMapping=Re}function me(D,Q,bt){const pt=Q.isScene===!0?Q.overrideMaterial:null;for(let dt=0,qt=D.length;dt<qt;dt++){const Jt=D[dt],{object:Gt,geometry:Zt,group:Yt}=Jt;let Re=Jt.material;Re.allowOverride===!0&&pt!==null&&(Re=pt),Gt.layers.test(bt.layers)&&ue(Gt,Q,bt,Zt,Re,Yt)}}function ue(D,Q,bt,pt,dt,qt){$!==null&&dt.isNodeMaterial&&$.setObject(D,dt),D.onBeforeRender(W,Q,bt,pt,dt,qt),D.modelViewMatrix.multiplyMatrices(bt.matrixWorldInverse,D.matrixWorld),D.normalMatrix.getNormalMatrix(D.modelViewMatrix),dt.onBeforeRender(W,Q,bt,pt,D,qt),dt.transparent===!0&&dt.side===vn&&dt.forceSinglePass===!1?(dt.side=vi,dt.needsUpdate=!0,W.renderBufferDirect(bt,Q,pt,dt,D,qt),dt.side=er,dt.needsUpdate=!0,W.renderBufferDirect(bt,Q,pt,dt,D,qt),dt.side=vn):W.renderBufferDirect(bt,Q,pt,dt,D,qt),D.onAfterRender(W,Q,bt,pt,dt,qt)}function fe(D,Q,bt){Q.isScene!==!0&&(Q=Be);const pt=mt.get(D),dt=L.state.lights,qt=L.state.shadowsArray,Jt=dt.state.version,Gt=zt.getParameters(D,dt.state,qt,Q,bt,L.state.lightProbeGridArray),Zt=zt.getProgramCacheKey(Gt);let Yt=pt.programs;pt.environment=D.isMeshStandardMaterial||D.isMeshLambertMaterial||D.isMeshPhongMaterial?Q.environment:null,pt.fog=Q.fog;const Re=D.isMeshStandardMaterial||D.isMeshLambertMaterial&&!D.envMap||D.isMeshPhongMaterial&&!D.envMap;pt.envMap=Ht.get(D.envMap||pt.environment,Re),pt.envMapRotation=pt.environment!==null&&D.envMap===null?Q.environmentRotation:D.envMapRotation,Yt===void 0&&(D.addEventListener("dispose",be),Yt=new Map,pt.programs=Yt);let Fe=Yt.get(Zt);if(Fe!==void 0){if(pt.currentProgram===Fe&&pt.lightsStateVersion===Jt)return an(D,Gt),Fe}else Gt.uniforms=zt.getUniforms(D),$!==null&&D.isNodeMaterial&&$.build(D,bt,Gt),D.onBeforeCompile(Gt,W),Fe=zt.acquireProgram(Gt,Zt),Yt.set(Zt,Fe),pt.uniforms=Gt.uniforms;const ee=pt.uniforms;return(!D.isShaderMaterial&&!D.isRawShaderMaterial||D.clipping===!0)&&(ee.clippingPlanes=q.uniform),an(D,Gt),pt.needsLights=ja(D),pt.lightsStateVersion=Jt,pt.needsLights&&(ee.ambientLightColor.value=dt.state.ambient,ee.lightProbe.value=dt.state.probe,ee.sunLights.value=dt.state.sun,ee.sunLightShadows.value=dt.state.sunShadow,ee.directionalLights.value=dt.state.directional,ee.directionalLightShadows.value=dt.state.directionalShadow,ee.spotLights.value=dt.state.spot,ee.spotLightShadows.value=dt.state.spotShadow,ee.rectAreaLights.value=dt.state.rectArea,ee.ltc_1.value=dt.state.rectAreaLTC1,ee.ltc_2.value=dt.state.rectAreaLTC2,ee.pointLights.value=dt.state.point,ee.pointLightShadows.value=dt.state.pointShadow,ee.hemisphereLights.value=dt.state.hemi,ee.sunShadowMatrix.value=dt.state.sunShadowMatrix,ee.sunShadowCascade.value=dt.state.sunShadowCascade,ee.directionalShadowMatrix.value=dt.state.directionalShadowMatrix,ee.spotLightMatrix.value=dt.state.spotLightMatrix,ee.spotLightMap.value=dt.state.spotLightMap,ee.pointShadowMatrix.value=dt.state.pointShadowMatrix),pt.lightProbeGrid=L.state.lightProbeGridArray.length>0,pt.currentProgram=Fe,pt.uniformsList=null,Fe}function ve(D){if(D.uniformsList===null){const Q=D.currentProgram.getUniforms();D.uniformsList=Ru.seqWithValue(Q.seq,D.uniforms)}return D.uniformsList}function an(D,Q){const bt=mt.get(D);bt.outputColorSpace=Q.outputColorSpace,bt.batching=Q.batching,bt.batchingColor=Q.batchingColor,bt.instancing=Q.instancing,bt.instancingColor=Q.instancingColor,bt.instancingMorph=Q.instancingMorph,bt.skinning=Q.skinning,bt.morphTargets=Q.morphTargets,bt.morphNormals=Q.morphNormals,bt.morphColors=Q.morphColors,bt.morphTargetsCount=Q.morphTargetsCount,bt.numClippingPlanes=Q.numClippingPlanes,bt.numIntersection=Q.numClipIntersection,bt.vertexAlphas=Q.vertexAlphas,bt.vertexTangents=Q.vertexTangents,bt.toneMapping=Q.toneMapping}function Zn(D,Q){if(D.length===0)return null;if(D.length===1)return D[0].texture!==null?D[0]:null;E.setFromMatrixPosition(Q.matrixWorld);for(let bt=0,pt=D.length;bt<pt;bt++){const dt=D[bt];if(dt.texture!==null&&dt.boundingBox.containsPoint(E))return dt}return null}function wn(D,Q,bt,pt,dt){Q.isScene!==!0&&(Q=Be),Mt.resetTextureUnits();const qt=Q.fog,Jt=pt.isMeshStandardMaterial||pt.isMeshLambertMaterial||pt.isMeshPhongMaterial?Q.environment:null,Gt=it===null?W.outputColorSpace:it.isXRRenderTarget===!0?it.texture.colorSpace:qe.workingColorSpace,Zt=pt.isMeshStandardMaterial||pt.isMeshLambertMaterial&&!pt.envMap||pt.isMeshPhongMaterial&&!pt.envMap,Yt=Ht.get(pt.envMap||Jt,Zt),Re=pt.vertexColors===!0&&!!bt.attributes.color&&bt.attributes.color.itemSize===4,Fe=!!bt.attributes.tangent&&(!!pt.normalMap||pt.anisotropy>0),ee=!!bt.morphAttributes.position,Ke=!!bt.morphAttributes.normal,xn=!!bt.morphAttributes.color;let mn=xa;pt.toneMapped&&(it===null||it.isXRRenderTarget===!0)&&(mn=W.toneMapping);const Ne=bt.morphAttributes.position||bt.morphAttributes.normal||bt.morphAttributes.color,Pn=Ne!==void 0?Ne.length:0,Qt=mt.get(pt),kn=L.state.lights;if(de===!0&&(xe===!0||D!==ht)){const fn=D===ht&&pt.id===rt;q.setState(pt,D,fn)}let Oe=!1;pt.version===Qt.__version?(Qt.needsLights&&Qt.lightsStateVersion!==kn.state.version||Qt.outputColorSpace!==Gt||dt.isBatchedMesh&&Qt.batching===!1||!dt.isBatchedMesh&&Qt.batching===!0||dt.isBatchedMesh&&Qt.batchingColor===!0&&dt._colorsTexture===null||dt.isBatchedMesh&&Qt.batchingColor===!1&&dt._colorsTexture!==null||dt.isInstancedMesh&&Qt.instancing===!1||!dt.isInstancedMesh&&Qt.instancing===!0||dt.isSkinnedMesh&&Qt.skinning===!1||!dt.isSkinnedMesh&&Qt.skinning===!0||dt.isInstancedMesh&&Qt.instancingColor===!0&&dt.instanceColor===null||dt.isInstancedMesh&&Qt.instancingColor===!1&&dt.instanceColor!==null||dt.isInstancedMesh&&Qt.instancingMorph===!0&&dt.morphTexture===null||dt.isInstancedMesh&&Qt.instancingMorph===!1&&dt.morphTexture!==null||Qt.envMap!==Yt||pt.fog===!0&&Qt.fog!==qt||Qt.numClippingPlanes!==void 0&&(Qt.numClippingPlanes!==q.numPlanes||Qt.numIntersection!==q.numIntersection)||Qt.vertexAlphas!==Re||Qt.vertexTangents!==Fe||Qt.morphTargets!==ee||Qt.morphNormals!==Ke||Qt.morphColors!==xn||Qt.toneMapping!==mn||Qt.morphTargetsCount!==Pn||!!Qt.lightProbeGrid!=L.state.lightProbeGridArray.length>0)&&(Oe=!0):(Oe=!0,Qt.__version=pt.version);let hi=Qt.currentProgram;Oe===!0&&(hi=fe(pt,Q,dt),$&&pt.isNodeMaterial&&$.onUpdateProgram(pt,hi,Qt));let Ai=!1,di=!1,$a=!1;const tn=hi.getUniforms(),bn=Qt.uniforms;if(A.useProgram(hi.program)&&(Ai=!0,di=!0,$a=!0),pt.id!==rt&&(rt=pt.id,di=!0),Qt.needsLights){const fn=Zn(L.state.lightProbeGridArray,dt);Qt.lightProbeGrid!==fn&&(Qt.lightProbeGrid=fn,di=!0)}if(Ai||ht!==D){A.buffers.depth.getReversed()&&D.reversedDepth!==!0&&(D._reversedDepth=!0,D.updateProjectionMatrix()),tn.setValue(j,"projectionMatrix",D.projectionMatrix),tn.setValue(j,"viewMatrix",D.matrixWorldInverse);const ua=tn.map.cameraPosition;ua!==void 0&&ua.setValue(j,Ce.setFromMatrixPosition(D.matrixWorld)),F.logarithmicDepthBuffer&&tn.setValue(j,"logDepthBufFC",2/(Math.log(D.far+1)/Math.LN2)),(pt.isMeshPhongMaterial||pt.isMeshToonMaterial||pt.isMeshLambertMaterial||pt.isMeshBasicMaterial||pt.isMeshStandardMaterial||pt.isShaderMaterial)&&tn.setValue(j,"isOrthographic",D.isOrthographicCamera===!0),ht!==D&&(ht=D,di=!0,$a=!0)}if(Qt.needsLights&&(kn.state.sunShadowMap.length>0&&tn.setValue(j,"sunShadowMap",kn.state.sunShadowMap,Mt),kn.state.directionalShadowMap.length>0&&tn.setValue(j,"directionalShadowMap",kn.state.directionalShadowMap,Mt),kn.state.spotShadowMap.length>0&&tn.setValue(j,"spotShadowMap",kn.state.spotShadowMap,Mt),kn.state.pointShadowMap.length>0&&tn.setValue(j,"pointShadowMap",kn.state.pointShadowMap,Mt)),dt.isSkinnedMesh){tn.setOptional(j,dt,"bindMatrix"),tn.setOptional(j,dt,"bindMatrixInverse");const fn=dt.skeleton;fn&&(fn.boneTexture===null&&fn.computeBoneTexture(),tn.setValue(j,"boneTexture",fn.boneTexture,Mt))}dt.isBatchedMesh&&(tn.setOptional(j,dt,"batchingTexture"),tn.setValue(j,"batchingTexture",dt._matricesTexture,Mt),tn.setOptional(j,dt,"batchingIdTexture"),tn.setValue(j,"batchingIdTexture",dt._indirectTexture,Mt),tn.setOptional(j,dt,"batchingColorTexture"),dt._colorsTexture!==null&&tn.setValue(j,"batchingColorTexture",dt._colorsTexture,Mt));const Fi=bt.morphAttributes;if((Fi.position!==void 0||Fi.normal!==void 0||Fi.color!==void 0)&&w.update(dt,bt,hi),(di||Qt.receiveShadow!==dt.receiveShadow)&&(Qt.receiveShadow=dt.receiveShadow,tn.setValue(j,"receiveShadow",dt.receiveShadow)),(pt.isMeshStandardMaterial||pt.isMeshLambertMaterial||pt.isMeshPhongMaterial)&&pt.envMap===null&&Q.environment!==null&&(bn.envMapIntensity.value=Q.environmentIntensity),bn.dfgLUT!==void 0&&(bn.dfgLUT.value=H3()),di){if(tn.setValue(j,"toneMappingExposure",W.toneMappingExposure),Qt.needsLights&&$e(bn,$a),qt&&pt.fog===!0&&gt.refreshFogUniforms(bn,qt),gt.refreshMaterialUniforms(bn,pt,Et,ft,L.state.transmissionRenderTarget[D.id]),Qt.needsLights&&Qt.lightProbeGrid){const fn=Qt.lightProbeGrid;bn.probesSH.value=fn.texture,bn.probesMin.value.copy(fn.boundingBox.min),bn.probesMax.value.copy(fn.boundingBox.max),bn.probesResolution.value.copy(fn.resolution)}Ru.upload(j,ve(Qt),bn,Mt)}if(pt.isShaderMaterial&&pt.uniformsNeedUpdate===!0&&(Ru.upload(j,ve(Qt),bn,Mt),pt.uniformsNeedUpdate=!1),pt.isSpriteMaterial&&tn.setValue(j,"center",dt.center),tn.setValue(j,"modelViewMatrix",dt.modelViewMatrix),tn.setValue(j,"normalMatrix",dt.normalMatrix),tn.setValue(j,"modelMatrix",dt.matrixWorld),pt.uniformsGroups!==void 0){const fn=pt.uniformsGroups;for(let ua=0,$i=fn.length;ua<$i;ua++){const Hi=fn[ua];st.update(Hi,hi),st.bind(Hi,hi)}}return hi}function $e(D,Q){D.ambientLightColor.needsUpdate=Q,D.lightProbe.needsUpdate=Q,D.sunLights.needsUpdate=Q,D.sunLightShadows.needsUpdate=Q,D.directionalLights.needsUpdate=Q,D.directionalLightShadows.needsUpdate=Q,D.pointLights.needsUpdate=Q,D.pointLightShadows.needsUpdate=Q,D.spotLights.needsUpdate=Q,D.spotLightShadows.needsUpdate=Q,D.rectAreaLights.needsUpdate=Q,D.hemisphereLights.needsUpdate=Q}function ja(D){return D.isMeshLambertMaterial||D.isMeshToonMaterial||D.isMeshPhongMaterial||D.isMeshStandardMaterial||D.isShadowMaterial||D.isShaderMaterial&&D.lights===!0}this.getActiveCubeFace=function(){return H},this.getActiveMipmapLevel=function(){return Y},this.getRenderTarget=function(){return it},this.setRenderTargetTextures=function(D,Q,bt){const pt=mt.get(D);pt.__autoAllocateDepthBuffer=D.resolveDepthBuffer===!1,pt.__autoAllocateDepthBuffer===!1&&(pt.__useRenderToTexture=!1),mt.get(D.texture).__webglTexture=Q,mt.get(D.depthTexture).__webglTexture=pt.__autoAllocateDepthBuffer?void 0:bt,pt.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(D,Q){const bt=mt.get(D);bt.__webglFramebuffer=Q,bt.__useDefaultFramebuffer=Q===void 0},this.setRenderTarget=function(D,Q=0,bt=0){it=D,H=Q,Y=bt;let pt=null,dt=!1,qt=!1;if(D){const Gt=mt.get(D);if(Gt.__useDefaultFramebuffer!==void 0){A.bindFramebuffer(j.FRAMEBUFFER,Gt.__webglFramebuffer),I.copy(D.viewport),ct.copy(D.scissor),Tt=D.scissorTest,A.viewport(I),A.scissor(ct),A.setScissorTest(Tt),rt=-1;return}else if(Gt.__webglFramebuffer===void 0)Mt.setupRenderTarget(D);else if(Gt.__hasExternalTextures)Mt.rebindTextures(D,mt.get(D.texture).__webglTexture,mt.get(D.depthTexture).__webglTexture);else if(D.depthBuffer){const Re=D.depthTexture;if(Gt.__boundDepthTexture!==Re){if(Re!==null&&mt.has(Re)&&(D.width!==Re.image.width||D.height!==Re.image.height))throw new Error("THREE.WebGLRenderer: Attached DepthTexture is initialized to the incorrect size.");Mt.setupDepthRenderbuffer(D)}}const Zt=D.texture;(Zt.isData3DTexture||Zt.isDataArrayTexture||Zt.isCompressedArrayTexture)&&(qt=!0);const Yt=mt.get(D).__webglFramebuffer;D.isWebGLCubeRenderTarget?(Array.isArray(Yt[Q])?pt=Yt[Q][bt]:pt=Yt[Q],dt=!0):D.samples>0&&Mt.useMultisampledRTT(D)===!1?pt=mt.get(D).__webglMultisampledFramebuffer:Array.isArray(Yt)?pt=Yt[bt]:pt=Yt,I.copy(D.viewport),ct.copy(D.scissor),Tt=D.scissorTest}else I.copy(Xt).multiplyScalar(Et).floor(),ct.copy(oe).multiplyScalar(Et).floor(),Tt=Ye;if(bt!==0&&(pt=lt),A.bindFramebuffer(j.FRAMEBUFFER,pt)&&A.drawBuffers(D,pt),A.viewport(I),A.scissor(ct),A.setScissorTest(Tt),dt){const Gt=mt.get(D.texture);j.framebufferTexture2D(j.FRAMEBUFFER,j.COLOR_ATTACHMENT0,j.TEXTURE_CUBE_MAP_POSITIVE_X+Q,Gt.__webglTexture,bt)}else if(qt){const Gt=Q;for(let Zt=0;Zt<D.textures.length;Zt++){const Yt=mt.get(D.textures[Zt]);j.framebufferTextureLayer(j.FRAMEBUFFER,j.COLOR_ATTACHMENT0+Zt,Yt.__webglTexture,bt,Gt)}}else if(D!==null&&bt!==0){const Gt=mt.get(D.texture);j.framebufferTexture2D(j.FRAMEBUFFER,j.COLOR_ATTACHMENT0,j.TEXTURE_2D,Gt.__webglTexture,bt)}rt=-1};function fi(D){const Q=mt.get(D);return(Q.__readFormat!==D.format||Q.__readType!==D.type)&&(Q.__readFormat=D.format,Q.__readType=D.type,Q.__formatReadable=F.textureFormatReadable(D.format),Q.__typeReadable=F.textureTypeReadable(D.type)),Q}this.readRenderTargetPixels=function(D,Q,bt,pt,dt,qt,Jt,Gt=0){if(!(D&&D.isWebGLRenderTarget)){Je("WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let Zt=mt.get(D).__webglFramebuffer;if(D.isWebGLCubeRenderTarget&&Jt!==void 0&&(Zt=Zt[Jt]),Zt){A.bindFramebuffer(j.FRAMEBUFFER,Zt);try{const Yt=D.textures[Gt],Re=Yt.format,Fe=Yt.type;D.textures.length>1&&j.readBuffer(j.COLOR_ATTACHMENT0+Gt);const ee=fi(Yt);if(ee.__formatReadable===!1){Je("WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(ee.__typeReadable===!1){Je("WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}Q>=0&&Q<=D.width-pt&&bt>=0&&bt<=D.height-dt&&j.readPixels(Q,bt,pt,dt,nt.convert(Re),nt.convert(Fe),qt)}finally{const Yt=it!==null?mt.get(it).__webglFramebuffer:null;A.bindFramebuffer(j.FRAMEBUFFER,Yt)}}},this.readRenderTargetPixelsAsync=async function(D,Q,bt,pt,dt,qt,Jt,Gt=0){if(!(D&&D.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let Zt=mt.get(D).__webglFramebuffer;if(D.isWebGLCubeRenderTarget&&Jt!==void 0&&(Zt=Zt[Jt]),Zt)if(Q>=0&&Q<=D.width-pt&&bt>=0&&bt<=D.height-dt){A.bindFramebuffer(j.FRAMEBUFFER,Zt);const Yt=D.textures[Gt],Re=Yt.format,Fe=Yt.type;D.textures.length>1&&j.readBuffer(j.COLOR_ATTACHMENT0+Gt);const ee=fi(Yt);if(ee.__formatReadable===!1)throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(ee.__typeReadable===!1)throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");const Ke=j.createBuffer();j.bindBuffer(j.PIXEL_PACK_BUFFER,Ke),j.bufferData(j.PIXEL_PACK_BUFFER,qt.byteLength,j.STREAM_READ),j.readPixels(Q,bt,pt,dt,nt.convert(Re),nt.convert(Fe),0),j.bindBuffer(j.PIXEL_PACK_BUFFER,null);const xn=it!==null?mt.get(it).__webglFramebuffer:null;A.bindFramebuffer(j.FRAMEBUFFER,xn);const mn=j.fenceSync(j.SYNC_GPU_COMMANDS_COMPLETE,0);return j.flush(),await d1(j,mn,4),j.bindBuffer(j.PIXEL_PACK_BUFFER,Ke),j.getBufferSubData(j.PIXEL_PACK_BUFFER,0,qt),j.bindBuffer(j.PIXEL_PACK_BUFFER,null),j.deleteBuffer(Ke),j.deleteSync(mn),qt}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")},this.copyFramebufferToTexture=function(D,Q=null,bt=0){const pt=Math.pow(2,-bt),dt=Math.floor(D.image.width*pt),qt=Math.floor(D.image.height*pt),Jt=Q!==null?Q.x:0,Gt=Q!==null?Q.y:0;Mt.setTexture2D(D,0),j.copyTexSubImage2D(j.TEXTURE_2D,bt,0,0,Jt,Gt,dt,qt),A.unbindTexture()},this.copyTextureToTexture=function(D,Q,bt=null,pt=null,dt=0,qt=0){let Jt,Gt,Zt,Yt,Re,Fe,ee,Ke,xn;const mn=D.isCompressedTexture?D.mipmaps[qt]:D.image;if(bt!==null)Jt=bt.max.x-bt.min.x,Gt=bt.max.y-bt.min.y,Zt=bt.isBox3?bt.max.z-bt.min.z:1,Yt=bt.min.x,Re=bt.min.y,Fe=bt.isBox3?bt.min.z:0;else{const bn=Math.pow(2,-dt);Jt=Math.floor(mn.width*bn),Gt=Math.floor(mn.height*bn),D.isDataArrayTexture?Zt=mn.depth:D.isData3DTexture?Zt=Math.floor(mn.depth*bn):Zt=1,Yt=0,Re=0,Fe=0}pt!==null?(ee=pt.x,Ke=pt.y,xn=pt.z):(ee=0,Ke=0,xn=0);const Ne=nt.convert(Q.format),Pn=nt.convert(Q.type);let Qt;Q.isData3DTexture?(Mt.setTexture3D(Q,0),Qt=j.TEXTURE_3D):Q.isDataArrayTexture||Q.isCompressedArrayTexture?(Mt.setTexture2DArray(Q,0),Qt=j.TEXTURE_2D_ARRAY):(Mt.setTexture2D(Q,0),Qt=j.TEXTURE_2D),A.activeTexture(j.TEXTURE0),A.pixelStorei(j.UNPACK_FLIP_Y_WEBGL,Q.flipY),A.pixelStorei(j.UNPACK_PREMULTIPLY_ALPHA_WEBGL,Q.premultiplyAlpha),A.pixelStorei(j.UNPACK_ALIGNMENT,Q.unpackAlignment);const kn=A.getParameter(j.UNPACK_ROW_LENGTH),Oe=A.getParameter(j.UNPACK_IMAGE_HEIGHT),hi=A.getParameter(j.UNPACK_SKIP_PIXELS),Ai=A.getParameter(j.UNPACK_SKIP_ROWS),di=A.getParameter(j.UNPACK_SKIP_IMAGES);A.pixelStorei(j.UNPACK_ROW_LENGTH,mn.width),A.pixelStorei(j.UNPACK_IMAGE_HEIGHT,mn.height),A.pixelStorei(j.UNPACK_SKIP_PIXELS,Yt),A.pixelStorei(j.UNPACK_SKIP_ROWS,Re),A.pixelStorei(j.UNPACK_SKIP_IMAGES,Fe);const $a=D.isDataArrayTexture||D.isData3DTexture,tn=Q.isDataArrayTexture||Q.isData3DTexture;if(D.isDepthTexture){const bn=mt.get(D),Fi=mt.get(Q),fn=mt.get(bn.__renderTarget),ua=mt.get(Fi.__renderTarget);A.bindFramebuffer(j.READ_FRAMEBUFFER,fn.__webglFramebuffer),A.bindFramebuffer(j.DRAW_FRAMEBUFFER,ua.__webglFramebuffer);for(let $i=0;$i<Zt;$i++)$a&&(j.framebufferTextureLayer(j.READ_FRAMEBUFFER,j.COLOR_ATTACHMENT0,mt.get(D).__webglTexture,dt,Fe+$i),j.framebufferTextureLayer(j.DRAW_FRAMEBUFFER,j.COLOR_ATTACHMENT0,mt.get(Q).__webglTexture,qt,xn+$i)),j.blitFramebuffer(Yt,Re,Jt,Gt,ee,Ke,Jt,Gt,j.DEPTH_BUFFER_BIT,j.NEAREST);A.bindFramebuffer(j.READ_FRAMEBUFFER,null),A.bindFramebuffer(j.DRAW_FRAMEBUFFER,null)}else if(dt!==0||D.isRenderTargetTexture||mt.has(D)){const bn=mt.get(D),Fi=mt.get(Q);A.bindFramebuffer(j.READ_FRAMEBUFFER,X),A.bindFramebuffer(j.DRAW_FRAMEBUFFER,k);for(let fn=0;fn<Zt;fn++)$a?j.framebufferTextureLayer(j.READ_FRAMEBUFFER,j.COLOR_ATTACHMENT0,bn.__webglTexture,dt,Fe+fn):j.framebufferTexture2D(j.READ_FRAMEBUFFER,j.COLOR_ATTACHMENT0,j.TEXTURE_2D,bn.__webglTexture,dt),tn?j.framebufferTextureLayer(j.DRAW_FRAMEBUFFER,j.COLOR_ATTACHMENT0,Fi.__webglTexture,qt,xn+fn):j.framebufferTexture2D(j.DRAW_FRAMEBUFFER,j.COLOR_ATTACHMENT0,j.TEXTURE_2D,Fi.__webglTexture,qt),dt!==0?j.blitFramebuffer(Yt,Re,Jt,Gt,ee,Ke,Jt,Gt,j.COLOR_BUFFER_BIT,j.NEAREST):tn?j.copyTexSubImage3D(Qt,qt,ee,Ke,xn+fn,Yt,Re,Jt,Gt):j.copyTexSubImage2D(Qt,qt,ee,Ke,Yt,Re,Jt,Gt);A.bindFramebuffer(j.READ_FRAMEBUFFER,null),A.bindFramebuffer(j.DRAW_FRAMEBUFFER,null)}else tn?D.isDataTexture||D.isData3DTexture?j.texSubImage3D(Qt,qt,ee,Ke,xn,Jt,Gt,Zt,Ne,Pn,mn.data):Q.isCompressedArrayTexture?j.compressedTexSubImage3D(Qt,qt,ee,Ke,xn,Jt,Gt,Zt,Ne,mn.data):j.texSubImage3D(Qt,qt,ee,Ke,xn,Jt,Gt,Zt,Ne,Pn,mn):D.isDataTexture?j.texSubImage2D(j.TEXTURE_2D,qt,ee,Ke,Jt,Gt,Ne,Pn,mn.data):D.isCompressedTexture?j.compressedTexSubImage2D(j.TEXTURE_2D,qt,ee,Ke,mn.width,mn.height,Ne,mn.data):j.texSubImage2D(j.TEXTURE_2D,qt,ee,Ke,Jt,Gt,Ne,Pn,mn);A.pixelStorei(j.UNPACK_ROW_LENGTH,kn),A.pixelStorei(j.UNPACK_IMAGE_HEIGHT,Oe),A.pixelStorei(j.UNPACK_SKIP_PIXELS,hi),A.pixelStorei(j.UNPACK_SKIP_ROWS,Ai),A.pixelStorei(j.UNPACK_SKIP_IMAGES,di),qt===0&&Q.generateMipmaps&&j.generateMipmap(Qt),A.unbindTexture()},this.initRenderTarget=function(D){mt.get(D).__webglFramebuffer===void 0&&Mt.setupRenderTarget(D)},this.initTexture=function(D){D.isCubeTexture?Mt.setTextureCube(D,0):D.isData3DTexture?Mt.setTexture3D(D,0):D.isDataArrayTexture||D.isCompressedArrayTexture?Mt.setTexture2DArray(D,0):Mt.setTexture2D(D,0),A.unbindTexture()},this.resetState=function(){H=0,Y=0,it=null,A.reset(),ot.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return _a}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(t){this._outputColorSpace=t;const n=this.getContext();n.drawingBufferColorSpace=qe._getDrawingBufferColorSpace(t),n.unpackColorSpace=qe._getUnpackColorSpace()}}const SM=new WeakMap,Hp=new WeakMap;function V3(s,t){if(Hp.has(s))throw new Error("Rain target mode must be selected before any target allocation.");SM.set(s,t)}function um(s){let t=Hp.get(s);if(!t){const n=s.getContext();t={mode:SM.get(s)??"auto",capabilities:{colorBufferFloat:!!n.getExtension("EXT_color_buffer_float"),colorBufferHalfFloat:!!n.getExtension("EXT_color_buffer_half_float")},checks:[],attempts:[]},Hp.set(s,t)}return t}function Fl(s){const t=s.getContext();return{target:s.getRenderTarget(),face:s.getActiveCubeFace(),mip:s.getActiveMipmapLevel(),viewport:s.getViewport(new _n),currentViewport:s.getCurrentViewport(new _n),scissor:s.getScissor(new _n),scissorTest:s.getScissorTest(),currentScissor:new _n().fromArray(Array.from(t.getParameter(t.SCISSOR_BOX))),currentScissorTest:t.isEnabled(t.SCISSOR_TEST),framebuffer:t.getParameter(t.FRAMEBUFFER_BINDING),xr:s.xr.enabled,autoClear:s.autoClear,shadowAutoUpdate:s.shadowMap.autoUpdate,toneMapping:s.toneMapping,clearColor:s.getClearColor(new ce),clearAlpha:s.getClearAlpha()}}function fm(s,t){if(s.xr.enabled=t.xr,s.autoClear=t.autoClear,s.shadowMap.autoUpdate=t.shadowAutoUpdate,s.toneMapping=t.toneMapping,s.setClearColor(t.clearColor,t.clearAlpha),s.setViewport(t.viewport),s.setScissor(t.scissor),s.setScissorTest(t.scissorTest),t.target){const{target:n}=t,a=n.viewport.clone(),o=n.scissor.clone(),c=n.scissorTest;try{n.viewport.copy(t.currentViewport),n.scissor.copy(t.currentScissor),n.scissorTest=t.currentScissorTest,s.setRenderTarget(n,t.face,t.mip)}finally{n.viewport.copy(a),n.scissor.copy(o),n.scissorTest=c}}else s.setRenderTarget(null,t.face,t.mip)}function k3(s,t){const n=Fl(s);try{return t()}finally{fm(s,n)}}function X3(s,t){const n=s.getRenderTarget(),a=s.getActiveCubeFace(),o=s.getActiveMipmapLevel(),c=s.xr.enabled,u=s.shadowMap.autoUpdate;try{return t()}finally{s.xr.enabled=c,s.shadowMap.autoUpdate=u,s.setRenderTarget(n,a,o)}}function mx(s){var t;return{target:((t=s.target)==null?void 0:t.texture.uuid)??null,face:s.face,mip:s.mip,viewport:s.viewport.toArray(),currentViewport:s.currentViewport.toArray(),scissor:s.scissor.toArray(),currentScissor:s.currentScissor.toArray(),scissorTest:s.scissorTest,currentScissorTest:s.currentScissorTest,xr:s.xr,autoClear:s.autoClear,shadowAutoUpdate:s.shadowAutoUpdate,toneMapping:s.toneMapping,clearColor:s.clearColor.toArray(),clearAlpha:s.clearAlpha}}function Bd(s){const t=[];for(let n=0;n<32;n++){const a=s.getError();if(a===s.NO_ERROR)break;t.push(a)}return t}class bM extends Error{}function EM(s,t,n){var M;const a=um(s),o=s.getContext(),c=Fl(s),u=mx(c),h=Bd(o);let p=null,d,g=[];try{s.setRenderTarget(t,0,0),p=o.checkFramebufferStatus(o.FRAMEBUFFER)}catch(C){d=C}finally{g=Bd(o),fm(s,c)}const v=Bd(o),_=Fl(s),x=mx(_),b=_.framebuffer===c.framebuffer,R=b&&JSON.stringify(u)===JSON.stringify(x)&&v.length===0,y=d===void 0&&p===o.FRAMEBUFFER_COMPLETE&&h.length===0&&g.length===0&&R;if(a.checks.push({label:n,width:t.width,height:t.height,storage:t.texture.type===ji?"half-float":"unsigned-byte",type:t.texture.type,format:t.texture.format,internalFormat:t.texture.internalFormat,depthBuffer:t.depthBuffer,depthTextureType:((M=t.depthTexture)==null?void 0:M.type)??null,samples:t.samples,status:p,glErrorsBefore:h,glErrors:g,restorationErrors:v,before:u,after:x,framebufferRestored:b,stateRestored:R,complete:y,...d===void 0?{}:{error:String(d)}}),!R)throw new bM(`Rain ${n}: failed to restore renderer state.`);if(d!==void 0)throw d;return y}function W3(s,t,n){const a=um(s),o=a.capabilities,c=a.mode==="auto"&&(o.colorBufferFloat||o.colorBufferHalfFloat)?["half-float","unsigned-byte"]:["unsigned-byte"],u=[];for(const h of c){const p=new Bi(t,n,{minFilter:Wn,magFilter:Wn,depthBuffer:!0,type:h==="half-float"?ji:Ti,format:Qi,generateMipmaps:!1,samples:0});p.texture.internalFormat=h==="half-float"?"RGBA16F":"RGBA8",p.texture.name="rainShelters.windowRefraction";let d;try{if(EM(s,p,"window-refraction"))return a.attempts.push({label:"window-refraction",width:t,height:n,storage:h,ok:!0}),p;d=new Error("Full-size framebuffer incomplete or GL error.")}catch(g){d=g}if(p.dispose(),a.attempts.push({label:"window-refraction",width:t,height:n,storage:h,ok:!1,error:String(d)}),d instanceof bM)throw d;u.push(`${h}: ${String(d)}`)}throw new Error(`Rain window refraction requires a complete full-size RGBA8 framebuffer. ${u.join(" | ")}`)}function q3(s){let t=null,n=!1;return{ensure(a,o){if(n)throw new Error("Rain refraction target is disposed.");if(!Number.isFinite(a)||!Number.isFinite(o)||a<1||o<1)throw new Error("Rain target size must be finite and positive.");if(a=Math.floor(a),o=Math.floor(o),(t==null?void 0:t.width)===a&&t.height===o)return t;const c=W3(s,a,o),u=t;return t=c,u==null||u.dispose(),t},dispose(){n||(n=!0,t==null||t.dispose(),t=null)}}}function Y3(s,t){if(s.shadowMap.enabled){if(s.shadowMap.type!==yl&&s.shadowMap.type!==Wp)throw new Error("Rain shadow target audit expects the original PCF shadow algorithm.");t.traverse(n=>{var g;const a=n;if(!a.isDirectionalLight||!a.castShadow)return;const o=a.shadow,c=o.getFrameExtents(),u=o.mapSize.x*c.x,h=o.mapSize.y*c.y;if(u>s.capabilities.maxTextureSize||h>s.capabilities.maxTextureSize)throw new Error("Rain shadow target exceeds native capacity; original shadow resolution was preserved.");const p=o.map??new Bi(u,h);if(!p.isWebGLRenderTarget)throw new Error("Rain directional shadow requires a WebGL render target.");const d=o.map===null;d&&(p.texture.name=`${a.name}.shadowMap`,p.texture.internalFormat="RGBA8",p.depthTexture=new po(u,h,la),p.depthTexture.name=`${a.name}.shadowMap`,p.depthTexture.format=Ma,p.depthTexture.compareFunction=s.capabilities.reversedDepthBuffer?Vu:Gu,p.depthTexture.minFilter=p.depthTexture.magFilter=Wn);try{if(!EM(s,p,"directional-shadow"))throw new Error("Rain directional shadow framebuffer is incomplete.");o.map=p,o.camera.updateProjectionMatrix()}catch(v){throw d&&((g=p.depthTexture)==null||g.dispose(),p.dispose()),v}})}}class dr{constructor(t,n,a,o){this.canvas=t,this.kind=n,this.builder=a,this.scene=new X1,this.camera=new zi(56,1,.055,240),this.recipe=null,this.raf=0,this.running=!1,this.disposed=!1,this.width=1,this.height=1,this.elapsed=0,this.frame=0,this.previous=0,this.baseRotation=new Ei,this.targetLook=new Ot,this.look=new Ot,this.lookRotation=new Ei,this.euler=new Ja(0,0,0,"YXZ"),this.renderer=new G3({canvas:t,antialias:!0,alpha:!1,powerPreference:"high-performance"}),this.renderer.outputColorSpace=Ln,this.renderer.toneMapping=qp,this.renderer.toneMappingExposure=1.1,this.renderer.shadowMap.enabled=!0,this.renderer.shadowMap.type=Wp,this.contextLost=c=>{c.preventDefault(),o()},t.addEventListener("webglcontextlost",this.contextLost),t.dataset.world=n}async init(){this.recipe=this.builder({scene:this.scene,camera:this.camera,renderer:this.renderer}),Y3(this.renderer,this.scene),this.applyComposition()}setSize(t,n,a){this.width=Math.max(1,t),this.height=Math.max(1,n),this.renderer.setPixelRatio(Math.min(2,Math.max(1,a))),this.renderer.setSize(this.width,this.height,!1),this.applyComposition()}applyComposition(){var t;this.camera.aspect=this.width/this.height,(t=this.recipe)==null||t.resize(this.camera.aspect),this.camera.updateProjectionMatrix(),this.baseRotation.copy(this.camera.quaternion)}renderFrame(t){if(this.disposed||!this.recipe)return;const n=Math.max(0,Math.min(t,.06));this.elapsed+=n,this.look.lerp(this.targetLook,n===0?1:1-Math.exp(-n*7)),this.euler.set(this.look.y,this.look.x,0),this.lookRotation.setFromEuler(this.euler),this.camera.quaternion.copy(this.baseRotation).multiply(this.lookRotation),this.camera.updateMatrixWorld(),this.recipe.update(this.elapsed,n),this.renderer.setRenderTarget(null),this.renderer.render(this.scene,this.camera),this.canvas.dataset.frame=String(++this.frame),this.canvas.dataset.time=this.elapsed.toFixed(4),this.canvas.dataset.drawCalls=String(this.renderer.info.render.calls),this.canvas.dataset.triangles=String(this.renderer.info.render.triangles),this.canvas.dataset.geometries=String(this.renderer.info.memory.geometries),this.canvas.dataset.textures=String(this.renderer.info.memory.textures)}start(){if(this.running||this.disposed)return;this.running=!0,this.previous=performance.now();const t=n=>{if(!this.running||this.disposed)return;const a=(n-this.previous)/1e3;this.previous=n,this.renderFrame(a),this.raf=requestAnimationFrame(t)};this.raf=requestAnimationFrame(t)}stop(){this.running=!1,cancelAnimationFrame(this.raf),this.raf=0,this.targetLook.set(0,0)}drag(t,n){this.targetLook.set($s.clamp(-t*.24,-.15,.15),$s.clamp(-n*.18,-.09,.09))}releaseDrag(){this.targetLook.set(0,0)}interact(t,n,a=!1){var c;const o=(c=this.recipe)==null?void 0:c.interact(t,n,a,!this.running);return o?(this.renderFrame(0),{world:this.kind,action:o.action,value:$s.clamp(o.value,0,1)}):null}dispose(){var o,c;if(this.disposed)return;this.disposed=!0,this.stop(),this.canvas.removeEventListener("webglcontextlost",this.contextLost),(c=(o=this.recipe)==null?void 0:o.dispose)==null||c.call(o);const t=new Set,n=new Set,a=new Set;this.scene.traverse(u=>{var g;const h=u;h.geometry&&t.add(h.geometry);const p=h.material?Array.isArray(h.material)?h.material:[h.material]:[];for(const v of p){n.add(v);for(const _ of Object.values(v))_ instanceof $n&&a.add(_);if(v instanceof ui)for(const _ of Object.values(v.uniforms))_.value instanceof $n&&a.add(_.value)}(g=u.shadow)==null||g.dispose()});for(const u of a)u.dispose();for(const u of n)u.dispose();for(const u of t)u.dispose();this.scene.clear(),this.renderer.dispose(),this.renderer.forceContextLoss(),this.recipe=null}}const co=[],gx=new WeakMap,Z3=new URLSearchParams(location.search);let TM=0,vx=performance.now(),Gp=0;const AM=[];setInterval(()=>{const s=performance.now(),t=s-vx;TM++,vx=s,Gp=Math.max(Gp,t),t>250&&AM.push({at:s,gapMs:t})},50);function hm(s){let t=gx.get(s);if(!t){t={id:co.length+1,engine:s,canvas:s.renderer.domElement,events:[],frames:[],disposed:!1},co.push(t),gx.set(s,t);const n=t;t.canvas.addEventListener("webglcontextlost",()=>n.events.push({type:"context-loss-event",at:performance.now()})),new MutationObserver(()=>{var o;const a=n.canvas.isConnected;((o=n.events.at(-1))==null?void 0:o.connected)!==a&&n.events.push({type:"dom-observer",at:performance.now(),connected:a})}).observe(document.documentElement,{subtree:!0,childList:!0})}return t}const K3=dr.prototype.init;dr.prototype.init=async function(){const s=hm(this),t=performance.now();s.events.push({type:"init-entry",at:t}),V3(this.renderer,Z3.get("target")==="byte"?"force-byte":"auto");try{await K3.call(this)}finally{s.events.push({type:"init-exit",at:performance.now(),elapsedMs:performance.now()-t})}};const J3=dr.prototype.renderFrame;dr.prototype.renderFrame=function(s){const t=hm(this),n=performance.now();try{return J3.call(this,s)}finally{t.frames.push({at:n,returnedAt:performance.now(),jsSubmissionMs:performance.now()-n,dt:s,frame:Number(t.canvas.dataset.frame),time:Number(t.canvas.dataset.time),drawCalls:this.renderer.info.render.calls,triangles:this.renderer.info.render.triangles})}};const Q3=dr.prototype.dispose;dr.prototype.dispose=function(){const s=hm(this),t=performance.now();s.events.push({type:"dispose-entry",at:t});try{return Q3.call(this)}finally{s.disposed=!0,s.events.push({type:"dispose-exit",at:performance.now(),elapsedMs:performance.now()-t,contextLost:this.renderer.getContext().isContextLost()})}};const j3={records:co,snapshot:()=>({at:performance.now(),beats:TM,maxHeartbeatGapMs:Gp,heartbeatGaps:AM,records:co.map(({id:s,canvas:t,engine:n,events:a,frames:o,disposed:c})=>({id:s,connected:t.isConnected,disposed:c,contextLost:n.renderer.getContext().isContextLost(),canvas:{width:t.width,height:t.height,frame:Number(t.dataset.frame),time:Number(t.dataset.time)},events:a,frames:o,targets:um(n.renderer)}))}),mark:s=>{const t=performance.now();return co.forEach(n=>n.events.push({type:s,at:t})),t},stateProbe:()=>{var o,c;const s=co.at(-1).engine.renderer,t=Fl(s);let n=!1;try{k3(s,()=>{throw s.setRenderTarget(null),new Error("QA intentional state probe")})}catch(u){n=u instanceof Error&&u.message==="QA intentional state probe"}const a=Fl(s);return fm(s,t),{caught:n,beforeTarget:((o=t.target)==null?void 0:o.uuid)??null,afterTarget:((c=a.target)==null?void 0:c.uuid)??null,beforeFace:t.face,afterFace:a.face,beforeMip:t.mip,afterMip:a.mip}}};Object.assign(window,{__rainFollowupQA:j3});var Fd={exports:{}},Ae={};/**
 * @license React
 * react.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var _x;function $3(){if(_x)return Ae;_x=1;var s=Symbol.for("react.transitional.element"),t=Symbol.for("react.portal"),n=Symbol.for("react.fragment"),a=Symbol.for("react.strict_mode"),o=Symbol.for("react.profiler"),c=Symbol.for("react.consumer"),u=Symbol.for("react.context"),h=Symbol.for("react.forward_ref"),p=Symbol.for("react.suspense"),d=Symbol.for("react.memo"),g=Symbol.for("react.lazy"),v=Symbol.for("react.activity"),_=Symbol.iterator;function x(I){return I===null||typeof I!="object"?null:(I=_&&I[_]||I["@@iterator"],typeof I=="function"?I:null)}var b={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},R=Object.assign,y={};function M(I,ct,Tt){this.props=I,this.context=ct,this.refs=y,this.updater=Tt||b}M.prototype.isReactComponent={},M.prototype.setState=function(I,ct){if(typeof I!="object"&&typeof I!="function"&&I!=null)throw Error("takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,I,ct,"setState")},M.prototype.forceUpdate=function(I){this.updater.enqueueForceUpdate(this,I,"forceUpdate")};function C(){}C.prototype=M.prototype;function P(I,ct,Tt){this.props=I,this.context=ct,this.refs=y,this.updater=Tt||b}var E=P.prototype=new C;E.constructor=P,R(E,M.prototype),E.isPureReactComponent=!0;var U=Array.isArray;function L(){}var N={H:null,A:null,T:null,S:null},T=Object.prototype.hasOwnProperty;function z(I,ct,Tt){var Ut=Tt.ref;return{$$typeof:s,type:I,key:ct,ref:Ut!==void 0?Ut:null,props:Tt}}function W(I,ct){return z(I.type,ct,I.props)}function J(I){return typeof I=="object"&&I!==null&&I.$$typeof===s}function $(I){var ct={"=":"=0",":":"=2"};return"$"+I.replace(/[=:]/g,function(Tt){return ct[Tt]})}var lt=/\/+/g;function X(I,ct){return typeof I=="object"&&I!==null&&I.key!=null?$(""+I.key):ct.toString(36)}function k(I){switch(I.status){case"fulfilled":return I.value;case"rejected":throw I.reason;default:switch(typeof I.status=="string"?I.then(L,L):(I.status="pending",I.then(function(ct){I.status==="pending"&&(I.status="fulfilled",I.value=ct)},function(ct){I.status==="pending"&&(I.status="rejected",I.reason=ct)})),I.status){case"fulfilled":return I.value;case"rejected":throw I.reason}}throw I}function H(I,ct,Tt,Ut,Vt){var Bt=typeof I;(Bt==="undefined"||Bt==="boolean")&&(I=null);var ft=!1;if(I===null)ft=!0;else switch(Bt){case"bigint":case"string":case"number":ft=!0;break;case"object":switch(I.$$typeof){case s:case t:ft=!0;break;case g:return ft=I._init,H(ft(I._payload),ct,Tt,Ut,Vt)}}if(ft)return Vt=Vt(I),ft=Ut===""?"."+X(I,0):Ut,U(Vt)?(Tt="",ft!=null&&(Tt=ft.replace(lt,"$&/")+"/"),H(Vt,ct,Tt,"",function($t){return $t})):Vt!=null&&(J(Vt)&&(Vt=W(Vt,Tt+(Vt.key==null||I&&I.key===Vt.key?"":(""+Vt.key).replace(lt,"$&/")+"/")+ft)),ct.push(Vt)),1;ft=0;var Et=Ut===""?".":Ut+":";if(U(I))for(var Ft=0;Ft<I.length;Ft++)Ut=I[Ft],Bt=Et+X(Ut,Ft),ft+=H(Ut,ct,Tt,Bt,Vt);else if(Ft=x(I),typeof Ft=="function")for(I=Ft.call(I),Ft=0;!(Ut=I.next()).done;)Ut=Ut.value,Bt=Et+X(Ut,Ft++),ft+=H(Ut,ct,Tt,Bt,Vt);else if(Bt==="object"){if(typeof I.then=="function")return H(k(I),ct,Tt,Ut,Vt);throw ct=String(I),Error("Objects are not valid as a React child (found: "+(ct==="[object Object]"?"object with keys {"+Object.keys(I).join(", ")+"}":ct)+"). If you meant to render a collection of children, use an array instead.")}return ft}function Y(I,ct,Tt){if(I==null)return I;var Ut=[],Vt=0;return H(I,Ut,"","",function(Bt){return ct.call(Tt,Bt,Vt++)}),Ut}function it(I){if(I._status===-1){var ct=I._result;ct=ct(),ct.then(function(Tt){(I._status===0||I._status===-1)&&(I._status=1,I._result=Tt)},function(Tt){(I._status===0||I._status===-1)&&(I._status=2,I._result=Tt)}),I._status===-1&&(I._status=0,I._result=ct)}if(I._status===1)return I._result.default;throw I._result}var rt=typeof reportError=="function"?reportError:function(I){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var ct=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof I=="object"&&I!==null&&typeof I.message=="string"?String(I.message):String(I),error:I});if(!window.dispatchEvent(ct))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",I);return}console.error(I)},ht={map:Y,forEach:function(I,ct,Tt){Y(I,function(){ct.apply(this,arguments)},Tt)},count:function(I){var ct=0;return Y(I,function(){ct++}),ct},toArray:function(I){return Y(I,function(ct){return ct})||[]},only:function(I){if(!J(I))throw Error("React.Children.only expected to receive a single React element child.");return I}};return Ae.Activity=v,Ae.Children=ht,Ae.Component=M,Ae.Fragment=n,Ae.Profiler=o,Ae.PureComponent=P,Ae.StrictMode=a,Ae.Suspense=p,Ae.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=N,Ae.__COMPILER_RUNTIME={__proto__:null,c:function(I){return N.H.useMemoCache(I)}},Ae.cache=function(I){return function(){return I.apply(null,arguments)}},Ae.cacheSignal=function(){return null},Ae.cloneElement=function(I,ct,Tt){if(I==null)throw Error("The argument must be a React element, but you passed "+I+".");var Ut=R({},I.props),Vt=I.key;if(ct!=null)for(Bt in ct.key!==void 0&&(Vt=""+ct.key),ct)!T.call(ct,Bt)||Bt==="key"||Bt==="__self"||Bt==="__source"||Bt==="ref"&&ct.ref===void 0||(Ut[Bt]=ct[Bt]);var Bt=arguments.length-2;if(Bt===1)Ut.children=Tt;else if(1<Bt){for(var ft=Array(Bt),Et=0;Et<Bt;Et++)ft[Et]=arguments[Et+2];Ut.children=ft}return z(I.type,Vt,Ut)},Ae.createContext=function(I){return I={$$typeof:u,_currentValue:I,_currentValue2:I,_threadCount:0,Provider:null,Consumer:null},I.Provider=I,I.Consumer={$$typeof:c,_context:I},I},Ae.createElement=function(I,ct,Tt){var Ut,Vt={},Bt=null;if(ct!=null)for(Ut in ct.key!==void 0&&(Bt=""+ct.key),ct)T.call(ct,Ut)&&Ut!=="key"&&Ut!=="__self"&&Ut!=="__source"&&(Vt[Ut]=ct[Ut]);var ft=arguments.length-2;if(ft===1)Vt.children=Tt;else if(1<ft){for(var Et=Array(ft),Ft=0;Ft<ft;Ft++)Et[Ft]=arguments[Ft+2];Vt.children=Et}if(I&&I.defaultProps)for(Ut in ft=I.defaultProps,ft)Vt[Ut]===void 0&&(Vt[Ut]=ft[Ut]);return z(I,Bt,Vt)},Ae.createRef=function(){return{current:null}},Ae.forwardRef=function(I){return{$$typeof:h,render:I}},Ae.isValidElement=J,Ae.lazy=function(I){return{$$typeof:g,_payload:{_status:-1,_result:I},_init:it}},Ae.memo=function(I,ct){return{$$typeof:d,type:I,compare:ct===void 0?null:ct}},Ae.startTransition=function(I){var ct=N.T,Tt={};N.T=Tt;try{var Ut=I(),Vt=N.S;Vt!==null&&Vt(Tt,Ut),typeof Ut=="object"&&Ut!==null&&typeof Ut.then=="function"&&Ut.then(L,rt)}catch(Bt){rt(Bt)}finally{ct!==null&&Tt.types!==null&&(ct.types=Tt.types),N.T=ct}},Ae.unstable_useCacheRefresh=function(){return N.H.useCacheRefresh()},Ae.use=function(I){return N.H.use(I)},Ae.useActionState=function(I,ct,Tt){return N.H.useActionState(I,ct,Tt)},Ae.useCallback=function(I,ct){return N.H.useCallback(I,ct)},Ae.useContext=function(I){return N.H.useContext(I)},Ae.useDebugValue=function(){},Ae.useDeferredValue=function(I,ct){return N.H.useDeferredValue(I,ct)},Ae.useEffect=function(I,ct){return N.H.useEffect(I,ct)},Ae.useEffectEvent=function(I){return N.H.useEffectEvent(I)},Ae.useId=function(){return N.H.useId()},Ae.useImperativeHandle=function(I,ct,Tt){return N.H.useImperativeHandle(I,ct,Tt)},Ae.useInsertionEffect=function(I,ct){return N.H.useInsertionEffect(I,ct)},Ae.useLayoutEffect=function(I,ct){return N.H.useLayoutEffect(I,ct)},Ae.useMemo=function(I,ct){return N.H.useMemo(I,ct)},Ae.useOptimistic=function(I,ct){return N.H.useOptimistic(I,ct)},Ae.useReducer=function(I,ct,Tt){return N.H.useReducer(I,ct,Tt)},Ae.useRef=function(I){return N.H.useRef(I)},Ae.useState=function(I){return N.H.useState(I)},Ae.useSyncExternalStore=function(I,ct,Tt){return N.H.useSyncExternalStore(I,ct,Tt)},Ae.useTransition=function(){return N.H.useTransition()},Ae.version="19.2.7",Ae}var xx;function dm(){return xx||(xx=1,Fd.exports=$3()),Fd.exports}var Qn=dm(),Hd={exports:{}},vl={},Gd={exports:{}},Vd={};/**
 * @license React
 * scheduler.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Mx;function tw(){return Mx||(Mx=1,(function(s){function t(H,Y){var it=H.length;H.push(Y);t:for(;0<it;){var rt=it-1>>>1,ht=H[rt];if(0<o(ht,Y))H[rt]=Y,H[it]=ht,it=rt;else break t}}function n(H){return H.length===0?null:H[0]}function a(H){if(H.length===0)return null;var Y=H[0],it=H.pop();if(it!==Y){H[0]=it;t:for(var rt=0,ht=H.length,I=ht>>>1;rt<I;){var ct=2*(rt+1)-1,Tt=H[ct],Ut=ct+1,Vt=H[Ut];if(0>o(Tt,it))Ut<ht&&0>o(Vt,Tt)?(H[rt]=Vt,H[Ut]=it,rt=Ut):(H[rt]=Tt,H[ct]=it,rt=ct);else if(Ut<ht&&0>o(Vt,it))H[rt]=Vt,H[Ut]=it,rt=Ut;else break t}}return Y}function o(H,Y){var it=H.sortIndex-Y.sortIndex;return it!==0?it:H.id-Y.id}if(s.unstable_now=void 0,typeof performance=="object"&&typeof performance.now=="function"){var c=performance;s.unstable_now=function(){return c.now()}}else{var u=Date,h=u.now();s.unstable_now=function(){return u.now()-h}}var p=[],d=[],g=1,v=null,_=3,x=!1,b=!1,R=!1,y=!1,M=typeof setTimeout=="function"?setTimeout:null,C=typeof clearTimeout=="function"?clearTimeout:null,P=typeof setImmediate<"u"?setImmediate:null;function E(H){for(var Y=n(d);Y!==null;){if(Y.callback===null)a(d);else if(Y.startTime<=H)a(d),Y.sortIndex=Y.expirationTime,t(p,Y);else break;Y=n(d)}}function U(H){if(R=!1,E(H),!b)if(n(p)!==null)b=!0,L||(L=!0,$());else{var Y=n(d);Y!==null&&k(U,Y.startTime-H)}}var L=!1,N=-1,T=5,z=-1;function W(){return y?!0:!(s.unstable_now()-z<T)}function J(){if(y=!1,L){var H=s.unstable_now();z=H;var Y=!0;try{t:{b=!1,R&&(R=!1,C(N),N=-1),x=!0;var it=_;try{e:{for(E(H),v=n(p);v!==null&&!(v.expirationTime>H&&W());){var rt=v.callback;if(typeof rt=="function"){v.callback=null,_=v.priorityLevel;var ht=rt(v.expirationTime<=H);if(H=s.unstable_now(),typeof ht=="function"){v.callback=ht,E(H),Y=!0;break e}v===n(p)&&a(p),E(H)}else a(p);v=n(p)}if(v!==null)Y=!0;else{var I=n(d);I!==null&&k(U,I.startTime-H),Y=!1}}break t}finally{v=null,_=it,x=!1}Y=void 0}}finally{Y?$():L=!1}}}var $;if(typeof P=="function")$=function(){P(J)};else if(typeof MessageChannel<"u"){var lt=new MessageChannel,X=lt.port2;lt.port1.onmessage=J,$=function(){X.postMessage(null)}}else $=function(){M(J,0)};function k(H,Y){N=M(function(){H(s.unstable_now())},Y)}s.unstable_IdlePriority=5,s.unstable_ImmediatePriority=1,s.unstable_LowPriority=4,s.unstable_NormalPriority=3,s.unstable_Profiling=null,s.unstable_UserBlockingPriority=2,s.unstable_cancelCallback=function(H){H.callback=null},s.unstable_forceFrameRate=function(H){0>H||125<H?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):T=0<H?Math.floor(1e3/H):5},s.unstable_getCurrentPriorityLevel=function(){return _},s.unstable_next=function(H){switch(_){case 1:case 2:case 3:var Y=3;break;default:Y=_}var it=_;_=Y;try{return H()}finally{_=it}},s.unstable_requestPaint=function(){y=!0},s.unstable_runWithPriority=function(H,Y){switch(H){case 1:case 2:case 3:case 4:case 5:break;default:H=3}var it=_;_=H;try{return Y()}finally{_=it}},s.unstable_scheduleCallback=function(H,Y,it){var rt=s.unstable_now();switch(typeof it=="object"&&it!==null?(it=it.delay,it=typeof it=="number"&&0<it?rt+it:rt):it=rt,H){case 1:var ht=-1;break;case 2:ht=250;break;case 5:ht=1073741823;break;case 4:ht=1e4;break;default:ht=5e3}return ht=it+ht,H={id:g++,callback:Y,priorityLevel:H,startTime:it,expirationTime:ht,sortIndex:-1},it>rt?(H.sortIndex=it,t(d,H),n(p)===null&&H===n(d)&&(R?(C(N),N=-1):R=!0,k(U,it-rt))):(H.sortIndex=ht,t(p,H),b||x||(b=!0,L||(L=!0,$()))),H},s.unstable_shouldYield=W,s.unstable_wrapCallback=function(H){var Y=_;return function(){var it=_;_=Y;try{return H.apply(this,arguments)}finally{_=it}}}})(Vd)),Vd}var yx;function ew(){return yx||(yx=1,Gd.exports=tw()),Gd.exports}var kd={exports:{}},ci={};/**
 * @license React
 * react-dom.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Sx;function nw(){if(Sx)return ci;Sx=1;var s=dm();function t(p){var d="https://react.dev/errors/"+p;if(1<arguments.length){d+="?args[]="+encodeURIComponent(arguments[1]);for(var g=2;g<arguments.length;g++)d+="&args[]="+encodeURIComponent(arguments[g])}return"Minified React error #"+p+"; visit "+d+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function n(){}var a={d:{f:n,r:function(){throw Error(t(522))},D:n,C:n,L:n,m:n,X:n,S:n,M:n},p:0,findDOMNode:null},o=Symbol.for("react.portal");function c(p,d,g){var v=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:o,key:v==null?null:""+v,children:p,containerInfo:d,implementation:g}}var u=s.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;function h(p,d){if(p==="font")return"";if(typeof d=="string")return d==="use-credentials"?d:""}return ci.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=a,ci.createPortal=function(p,d){var g=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!d||d.nodeType!==1&&d.nodeType!==9&&d.nodeType!==11)throw Error(t(299));return c(p,d,null,g)},ci.flushSync=function(p){var d=u.T,g=a.p;try{if(u.T=null,a.p=2,p)return p()}finally{u.T=d,a.p=g,a.d.f()}},ci.preconnect=function(p,d){typeof p=="string"&&(d?(d=d.crossOrigin,d=typeof d=="string"?d==="use-credentials"?d:"":void 0):d=null,a.d.C(p,d))},ci.prefetchDNS=function(p){typeof p=="string"&&a.d.D(p)},ci.preinit=function(p,d){if(typeof p=="string"&&d&&typeof d.as=="string"){var g=d.as,v=h(g,d.crossOrigin),_=typeof d.integrity=="string"?d.integrity:void 0,x=typeof d.fetchPriority=="string"?d.fetchPriority:void 0;g==="style"?a.d.S(p,typeof d.precedence=="string"?d.precedence:void 0,{crossOrigin:v,integrity:_,fetchPriority:x}):g==="script"&&a.d.X(p,{crossOrigin:v,integrity:_,fetchPriority:x,nonce:typeof d.nonce=="string"?d.nonce:void 0})}},ci.preinitModule=function(p,d){if(typeof p=="string")if(typeof d=="object"&&d!==null){if(d.as==null||d.as==="script"){var g=h(d.as,d.crossOrigin);a.d.M(p,{crossOrigin:g,integrity:typeof d.integrity=="string"?d.integrity:void 0,nonce:typeof d.nonce=="string"?d.nonce:void 0})}}else d==null&&a.d.M(p)},ci.preload=function(p,d){if(typeof p=="string"&&typeof d=="object"&&d!==null&&typeof d.as=="string"){var g=d.as,v=h(g,d.crossOrigin);a.d.L(p,g,{crossOrigin:v,integrity:typeof d.integrity=="string"?d.integrity:void 0,nonce:typeof d.nonce=="string"?d.nonce:void 0,type:typeof d.type=="string"?d.type:void 0,fetchPriority:typeof d.fetchPriority=="string"?d.fetchPriority:void 0,referrerPolicy:typeof d.referrerPolicy=="string"?d.referrerPolicy:void 0,imageSrcSet:typeof d.imageSrcSet=="string"?d.imageSrcSet:void 0,imageSizes:typeof d.imageSizes=="string"?d.imageSizes:void 0,media:typeof d.media=="string"?d.media:void 0})}},ci.preloadModule=function(p,d){if(typeof p=="string")if(d){var g=h(d.as,d.crossOrigin);a.d.m(p,{as:typeof d.as=="string"&&d.as!=="script"?d.as:void 0,crossOrigin:g,integrity:typeof d.integrity=="string"?d.integrity:void 0})}else a.d.m(p)},ci.requestFormReset=function(p){a.d.r(p)},ci.unstable_batchedUpdates=function(p,d){return p(d)},ci.useFormState=function(p,d,g){return u.H.useFormState(p,d,g)},ci.useFormStatus=function(){return u.H.useHostTransitionStatus()},ci.version="19.2.7",ci}var bx;function iw(){if(bx)return kd.exports;bx=1;function s(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(s)}catch(t){console.error(t)}}return s(),kd.exports=nw(),kd.exports}/**
 * @license React
 * react-dom-client.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Ex;function aw(){if(Ex)return vl;Ex=1;var s=ew(),t=dm(),n=iw();function a(e){var i="https://react.dev/errors/"+e;if(1<arguments.length){i+="?args[]="+encodeURIComponent(arguments[1]);for(var r=2;r<arguments.length;r++)i+="&args[]="+encodeURIComponent(arguments[r])}return"Minified React error #"+e+"; visit "+i+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function o(e){return!(!e||e.nodeType!==1&&e.nodeType!==9&&e.nodeType!==11)}function c(e){var i=e,r=e;if(e.alternate)for(;i.return;)i=i.return;else{e=i;do i=e,(i.flags&4098)!==0&&(r=i.return),e=i.return;while(e)}return i.tag===3?r:null}function u(e){if(e.tag===13){var i=e.memoizedState;if(i===null&&(e=e.alternate,e!==null&&(i=e.memoizedState)),i!==null)return i.dehydrated}return null}function h(e){if(e.tag===31){var i=e.memoizedState;if(i===null&&(e=e.alternate,e!==null&&(i=e.memoizedState)),i!==null)return i.dehydrated}return null}function p(e){if(c(e)!==e)throw Error(a(188))}function d(e){var i=e.alternate;if(!i){if(i=c(e),i===null)throw Error(a(188));return i!==e?null:e}for(var r=e,l=i;;){var f=r.return;if(f===null)break;var m=f.alternate;if(m===null){if(l=f.return,l!==null){r=l;continue}break}if(f.child===m.child){for(m=f.child;m;){if(m===r)return p(f),e;if(m===l)return p(f),i;m=m.sibling}throw Error(a(188))}if(r.return!==l.return)r=f,l=m;else{for(var S=!1,O=f.child;O;){if(O===r){S=!0,r=f,l=m;break}if(O===l){S=!0,l=f,r=m;break}O=O.sibling}if(!S){for(O=m.child;O;){if(O===r){S=!0,r=m,l=f;break}if(O===l){S=!0,l=m,r=f;break}O=O.sibling}if(!S)throw Error(a(189))}}if(r.alternate!==l)throw Error(a(190))}if(r.tag!==3)throw Error(a(188));return r.stateNode.current===r?e:i}function g(e){var i=e.tag;if(i===5||i===26||i===27||i===6)return e;for(e=e.child;e!==null;){if(i=g(e),i!==null)return i;e=e.sibling}return null}var v=Object.assign,_=Symbol.for("react.element"),x=Symbol.for("react.transitional.element"),b=Symbol.for("react.portal"),R=Symbol.for("react.fragment"),y=Symbol.for("react.strict_mode"),M=Symbol.for("react.profiler"),C=Symbol.for("react.consumer"),P=Symbol.for("react.context"),E=Symbol.for("react.forward_ref"),U=Symbol.for("react.suspense"),L=Symbol.for("react.suspense_list"),N=Symbol.for("react.memo"),T=Symbol.for("react.lazy"),z=Symbol.for("react.activity"),W=Symbol.for("react.memo_cache_sentinel"),J=Symbol.iterator;function $(e){return e===null||typeof e!="object"?null:(e=J&&e[J]||e["@@iterator"],typeof e=="function"?e:null)}var lt=Symbol.for("react.client.reference");function X(e){if(e==null)return null;if(typeof e=="function")return e.$$typeof===lt?null:e.displayName||e.name||null;if(typeof e=="string")return e;switch(e){case R:return"Fragment";case M:return"Profiler";case y:return"StrictMode";case U:return"Suspense";case L:return"SuspenseList";case z:return"Activity"}if(typeof e=="object")switch(e.$$typeof){case b:return"Portal";case P:return e.displayName||"Context";case C:return(e._context.displayName||"Context")+".Consumer";case E:var i=e.render;return e=e.displayName,e||(e=i.displayName||i.name||"",e=e!==""?"ForwardRef("+e+")":"ForwardRef"),e;case N:return i=e.displayName||null,i!==null?i:X(e.type)||"Memo";case T:i=e._payload,e=e._init;try{return X(e(i))}catch{}}return null}var k=Array.isArray,H=t.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,Y=n.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,it={pending:!1,data:null,method:null,action:null},rt=[],ht=-1;function I(e){return{current:e}}function ct(e){0>ht||(e.current=rt[ht],rt[ht]=null,ht--)}function Tt(e,i){ht++,rt[ht]=e.current,e.current=i}var Ut=I(null),Vt=I(null),Bt=I(null),ft=I(null);function Et(e,i){switch(Tt(Bt,i),Tt(Vt,e),Tt(Ut,null),i.nodeType){case 9:case 11:e=(e=i.documentElement)&&(e=e.namespaceURI)?yv(e):0;break;default:if(e=i.tagName,i=i.namespaceURI)i=yv(i),e=Sv(i,e);else switch(e){case"svg":e=1;break;case"math":e=2;break;default:e=0}}ct(Ut),Tt(Ut,e)}function Ft(){ct(Ut),ct(Vt),ct(Bt)}function $t(e){e.memoizedState!==null&&Tt(ft,e);var i=Ut.current,r=Sv(i,e.type);i!==r&&(Tt(Vt,e),Tt(Ut,r))}function Xt(e){Vt.current===e&&(ct(Ut),ct(Vt)),ft.current===e&&(ct(ft),il._currentValue=it)}var oe,Ye;function jt(e){if(oe===void 0)try{throw Error()}catch(r){var i=r.stack.trim().match(/\n( *(at )?)/);oe=i&&i[1]||"",Ye=-1<r.stack.indexOf(`
    at`)?" (<anonymous>)":-1<r.stack.indexOf("@")?"@unknown:0:0":""}return`
`+oe+e+Ye}var de=!1;function xe(e,i){if(!e||de)return"";de=!0;var r=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{var l={DetermineComponentFrameRoot:function(){try{if(i){var Pt=function(){throw Error()};if(Object.defineProperty(Pt.prototype,"props",{set:function(){throw Error()}}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(Pt,[])}catch(At){var St=At}Reflect.construct(e,[],Pt)}else{try{Pt.call()}catch(At){St=At}e.call(Pt.prototype)}}else{try{throw Error()}catch(At){St=At}(Pt=e())&&typeof Pt.catch=="function"&&Pt.catch(function(){})}}catch(At){if(At&&St&&typeof At.stack=="string")return[At.stack,St.stack]}return[null,null]}};l.DetermineComponentFrameRoot.displayName="DetermineComponentFrameRoot";var f=Object.getOwnPropertyDescriptor(l.DetermineComponentFrameRoot,"name");f&&f.configurable&&Object.defineProperty(l.DetermineComponentFrameRoot,"name",{value:"DetermineComponentFrameRoot"});var m=l.DetermineComponentFrameRoot(),S=m[0],O=m[1];if(S&&O){var K=S.split(`
`),_t=O.split(`
`);for(f=l=0;l<K.length&&!K[l].includes("DetermineComponentFrameRoot");)l++;for(;f<_t.length&&!_t[f].includes("DetermineComponentFrameRoot");)f++;if(l===K.length||f===_t.length)for(l=K.length-1,f=_t.length-1;1<=l&&0<=f&&K[l]!==_t[f];)f--;for(;1<=l&&0<=f;l--,f--)if(K[l]!==_t[f]){if(l!==1||f!==1)do if(l--,f--,0>f||K[l]!==_t[f]){var Dt=`
`+K[l].replace(" at new "," at ");return e.displayName&&Dt.includes("<anonymous>")&&(Dt=Dt.replace("<anonymous>",e.displayName)),Dt}while(1<=l&&0<=f);break}}}finally{de=!1,Error.prepareStackTrace=r}return(r=e?e.displayName||e.name:"")?jt(r):""}function pe(e,i){switch(e.tag){case 26:case 27:case 5:return jt(e.type);case 16:return jt("Lazy");case 13:return e.child!==i&&i!==null?jt("Suspense Fallback"):jt("Suspense");case 19:return jt("SuspenseList");case 0:case 15:return xe(e.type,!1);case 11:return xe(e.type.render,!1);case 1:return xe(e.type,!0);case 31:return jt("Activity");default:return""}}function Ce(e){try{var i="",r=null;do i+=pe(e,r),r=e,e=e.return;while(e);return i}catch(l){return`
Error generating stack: `+l.message+`
`+l.stack}}var Xe=Object.prototype.hasOwnProperty,Be=s.unstable_scheduleCallback,ie=s.unstable_cancelCallback,Ue=s.unstable_shouldYield,j=s.unstable_requestPaint,Se=s.unstable_now,Ee=s.unstable_getCurrentPriorityLevel,F=s.unstable_ImmediatePriority,A=s.unstable_UserBlockingPriority,et=s.unstable_NormalPriority,mt=s.unstable_LowPriority,Mt=s.unstable_IdlePriority,Ht=s.log,kt=s.unstable_setDisableYieldValue,yt=null,xt=null;function zt(e){if(typeof Ht=="function"&&kt(e),xt&&typeof xt.setStrictMode=="function")try{xt.setStrictMode(yt,e)}catch{}}var gt=Math.clz32?Math.clz32:q,wt=Math.log,Lt=Math.LN2;function q(e){return e>>>=0,e===0?32:31-(wt(e)/Lt|0)|0}var Z=256,at=262144,w=4194304;function G(e){var i=e&42;if(i!==0)return i;switch(e&-e){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:return 64;case 128:return 128;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:return e&261888;case 262144:case 524288:case 1048576:case 2097152:return e&3932160;case 4194304:case 8388608:case 16777216:case 33554432:return e&62914560;case 67108864:return 67108864;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 0;default:return e}}function V(e,i,r){var l=e.pendingLanes;if(l===0)return 0;var f=0,m=e.suspendedLanes,S=e.pingedLanes;e=e.warmLanes;var O=l&134217727;return O!==0?(l=O&~m,l!==0?f=G(l):(S&=O,S!==0?f=G(S):r||(r=O&~e,r!==0&&(f=G(r))))):(O=l&~m,O!==0?f=G(O):S!==0?f=G(S):r||(r=l&~e,r!==0&&(f=G(r)))),f===0?0:i!==0&&i!==f&&(i&m)===0&&(m=f&-f,r=i&-i,m>=r||m===32&&(r&4194048)!==0)?i:f}function nt(e,i){return(e.pendingLanes&~(e.suspendedLanes&~e.pingedLanes)&i)===0}function ot(e,i){switch(e){case 1:case 2:case 4:case 8:case 64:return i+250;case 16:case 32:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return i+5e3;case 4194304:case 8388608:case 16777216:case 33554432:return-1;case 67108864:case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function st(){var e=w;return w<<=1,(w&62914560)===0&&(w=4194304),e}function Ct(e){for(var i=[],r=0;31>r;r++)i.push(e);return i}function It(e,i){e.pendingLanes|=i,i!==268435456&&(e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0)}function te(e,i,r,l,f,m){var S=e.pendingLanes;e.pendingLanes=r,e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0,e.expiredLanes&=r,e.entangledLanes&=r,e.errorRecoveryDisabledLanes&=r,e.shellSuspendCounter=0;var O=e.entanglements,K=e.expirationTimes,_t=e.hiddenUpdates;for(r=S&~r;0<r;){var Dt=31-gt(r),Pt=1<<Dt;O[Dt]=0,K[Dt]=-1;var St=_t[Dt];if(St!==null)for(_t[Dt]=null,Dt=0;Dt<St.length;Dt++){var At=St[Dt];At!==null&&(At.lane&=-536870913)}r&=~Pt}l!==0&&se(e,l,0),m!==0&&f===0&&e.tag!==0&&(e.suspendedLanes|=m&~(S&~i))}function se(e,i,r){e.pendingLanes|=i,e.suspendedLanes&=~i;var l=31-gt(i);e.entangledLanes|=i,e.entanglements[l]=e.entanglements[l]|1073741824|r&261930}function Me(e,i){var r=e.entangledLanes|=i;for(e=e.entanglements;r;){var l=31-gt(r),f=1<<l;f&i|e[l]&i&&(e[l]|=i),r&=~f}}function be(e,i){var r=i&-i;return r=(r&42)!==0?1:Te(r),(r&(e.suspendedLanes|i))!==0?0:r}function Te(e){switch(e){case 2:e=1;break;case 8:e=4;break;case 32:e=16;break;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:e=128;break;case 268435456:e=134217728;break;default:e=0}return e}function cn(e){return e&=-e,2<e?8<e?(e&134217727)!==0?32:268435456:8:2}function Gn(){var e=Y.p;return e!==0?e:(e=window.event,e===void 0?32:Wv(e.type))}function ei(e,i){var r=Y.p;try{return Y.p=e,i()}finally{Y.p=r}}var On=Math.random().toString(36).slice(2),Ze="__reactFiber$"+On,un="__reactProps$"+On,Vn="__reactContainer$"+On,ca="__reactEvents$"+On,Rt="__reactListeners$"+On,Wt="__reactHandles$"+On,me="__reactResources$"+On,ue="__reactMarker$"+On;function fe(e){delete e[Ze],delete e[un],delete e[ca],delete e[Rt],delete e[Wt]}function ve(e){var i=e[Ze];if(i)return i;for(var r=e.parentNode;r;){if(i=r[Vn]||r[Ze]){if(r=i.alternate,i.child!==null||r!==null&&r.child!==null)for(e=Cv(e);e!==null;){if(r=e[Ze])return r;e=Cv(e)}return i}e=r,r=e.parentNode}return null}function an(e){if(e=e[Ze]||e[Vn]){var i=e.tag;if(i===5||i===6||i===13||i===31||i===26||i===27||i===3)return e}return null}function Zn(e){var i=e.tag;if(i===5||i===26||i===27||i===6)return e.stateNode;throw Error(a(33))}function wn(e){var i=e[me];return i||(i=e[me]={hoistableStyles:new Map,hoistableScripts:new Map}),i}function $e(e){e[ue]=!0}var ja=new Set,fi={};function D(e,i){Q(e,i),Q(e+"Capture",i)}function Q(e,i){for(fi[e]=i,e=0;e<i.length;e++)ja.add(i[e])}var bt=RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"),pt={},dt={};function qt(e){return Xe.call(dt,e)?!0:Xe.call(pt,e)?!1:bt.test(e)?dt[e]=!0:(pt[e]=!0,!1)}function Jt(e,i,r){if(qt(i))if(r===null)e.removeAttribute(i);else{switch(typeof r){case"undefined":case"function":case"symbol":e.removeAttribute(i);return;case"boolean":var l=i.toLowerCase().slice(0,5);if(l!=="data-"&&l!=="aria-"){e.removeAttribute(i);return}}e.setAttribute(i,""+r)}}function Gt(e,i,r){if(r===null)e.removeAttribute(i);else{switch(typeof r){case"undefined":case"function":case"symbol":case"boolean":e.removeAttribute(i);return}e.setAttribute(i,""+r)}}function Zt(e,i,r,l){if(l===null)e.removeAttribute(r);else{switch(typeof l){case"undefined":case"function":case"symbol":case"boolean":e.removeAttribute(r);return}e.setAttributeNS(i,r,""+l)}}function Yt(e){switch(typeof e){case"bigint":case"boolean":case"number":case"string":case"undefined":return e;case"object":return e;default:return""}}function Re(e){var i=e.type;return(e=e.nodeName)&&e.toLowerCase()==="input"&&(i==="checkbox"||i==="radio")}function Fe(e,i,r){var l=Object.getOwnPropertyDescriptor(e.constructor.prototype,i);if(!e.hasOwnProperty(i)&&typeof l<"u"&&typeof l.get=="function"&&typeof l.set=="function"){var f=l.get,m=l.set;return Object.defineProperty(e,i,{configurable:!0,get:function(){return f.call(this)},set:function(S){r=""+S,m.call(this,S)}}),Object.defineProperty(e,i,{enumerable:l.enumerable}),{getValue:function(){return r},setValue:function(S){r=""+S},stopTracking:function(){e._valueTracker=null,delete e[i]}}}}function ee(e){if(!e._valueTracker){var i=Re(e)?"checked":"value";e._valueTracker=Fe(e,i,""+e[i])}}function Ke(e){if(!e)return!1;var i=e._valueTracker;if(!i)return!0;var r=i.getValue(),l="";return e&&(l=Re(e)?e.checked?"true":"false":e.value),e=l,e!==r?(i.setValue(e),!0):!1}function xn(e){if(e=e||(typeof document<"u"?document:void 0),typeof e>"u")return null;try{return e.activeElement||e.body}catch{return e.body}}var mn=/[\n"\\]/g;function Ne(e){return e.replace(mn,function(i){return"\\"+i.charCodeAt(0).toString(16)+" "})}function Pn(e,i,r,l,f,m,S,O){e.name="",S!=null&&typeof S!="function"&&typeof S!="symbol"&&typeof S!="boolean"?e.type=S:e.removeAttribute("type"),i!=null?S==="number"?(i===0&&e.value===""||e.value!=i)&&(e.value=""+Yt(i)):e.value!==""+Yt(i)&&(e.value=""+Yt(i)):S!=="submit"&&S!=="reset"||e.removeAttribute("value"),i!=null?kn(e,S,Yt(i)):r!=null?kn(e,S,Yt(r)):l!=null&&e.removeAttribute("value"),f==null&&m!=null&&(e.defaultChecked=!!m),f!=null&&(e.checked=f&&typeof f!="function"&&typeof f!="symbol"),O!=null&&typeof O!="function"&&typeof O!="symbol"&&typeof O!="boolean"?e.name=""+Yt(O):e.removeAttribute("name")}function Qt(e,i,r,l,f,m,S,O){if(m!=null&&typeof m!="function"&&typeof m!="symbol"&&typeof m!="boolean"&&(e.type=m),i!=null||r!=null){if(!(m!=="submit"&&m!=="reset"||i!=null)){ee(e);return}r=r!=null?""+Yt(r):"",i=i!=null?""+Yt(i):r,O||i===e.value||(e.value=i),e.defaultValue=i}l=l??f,l=typeof l!="function"&&typeof l!="symbol"&&!!l,e.checked=O?e.checked:!!l,e.defaultChecked=!!l,S!=null&&typeof S!="function"&&typeof S!="symbol"&&typeof S!="boolean"&&(e.name=S),ee(e)}function kn(e,i,r){i==="number"&&xn(e.ownerDocument)===e||e.defaultValue===""+r||(e.defaultValue=""+r)}function Oe(e,i,r,l){if(e=e.options,i){i={};for(var f=0;f<r.length;f++)i["$"+r[f]]=!0;for(r=0;r<e.length;r++)f=i.hasOwnProperty("$"+e[r].value),e[r].selected!==f&&(e[r].selected=f),f&&l&&(e[r].defaultSelected=!0)}else{for(r=""+Yt(r),i=null,f=0;f<e.length;f++){if(e[f].value===r){e[f].selected=!0,l&&(e[f].defaultSelected=!0);return}i!==null||e[f].disabled||(i=e[f])}i!==null&&(i.selected=!0)}}function hi(e,i,r){if(i!=null&&(i=""+Yt(i),i!==e.value&&(e.value=i),r==null)){e.defaultValue!==i&&(e.defaultValue=i);return}e.defaultValue=r!=null?""+Yt(r):""}function Ai(e,i,r,l){if(i==null){if(l!=null){if(r!=null)throw Error(a(92));if(k(l)){if(1<l.length)throw Error(a(93));l=l[0]}r=l}r==null&&(r=""),i=r}r=Yt(i),e.defaultValue=r,l=e.textContent,l===r&&l!==""&&l!==null&&(e.value=l),ee(e)}function di(e,i){if(i){var r=e.firstChild;if(r&&r===e.lastChild&&r.nodeType===3){r.nodeValue=i;return}}e.textContent=i}var $a=new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" "));function tn(e,i,r){var l=i.indexOf("--")===0;r==null||typeof r=="boolean"||r===""?l?e.setProperty(i,""):i==="float"?e.cssFloat="":e[i]="":l?e.setProperty(i,r):typeof r!="number"||r===0||$a.has(i)?i==="float"?e.cssFloat=r:e[i]=(""+r).trim():e[i]=r+"px"}function bn(e,i,r){if(i!=null&&typeof i!="object")throw Error(a(62));if(e=e.style,r!=null){for(var l in r)!r.hasOwnProperty(l)||i!=null&&i.hasOwnProperty(l)||(l.indexOf("--")===0?e.setProperty(l,""):l==="float"?e.cssFloat="":e[l]="");for(var f in i)l=i[f],i.hasOwnProperty(f)&&r[f]!==l&&tn(e,f,l)}else for(var m in i)i.hasOwnProperty(m)&&tn(e,m,i[m])}function Fi(e){if(e.indexOf("-")===-1)return!1;switch(e){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var fn=new Map([["acceptCharset","accept-charset"],["htmlFor","for"],["httpEquiv","http-equiv"],["crossOrigin","crossorigin"],["accentHeight","accent-height"],["alignmentBaseline","alignment-baseline"],["arabicForm","arabic-form"],["baselineShift","baseline-shift"],["capHeight","cap-height"],["clipPath","clip-path"],["clipRule","clip-rule"],["colorInterpolation","color-interpolation"],["colorInterpolationFilters","color-interpolation-filters"],["colorProfile","color-profile"],["colorRendering","color-rendering"],["dominantBaseline","dominant-baseline"],["enableBackground","enable-background"],["fillOpacity","fill-opacity"],["fillRule","fill-rule"],["floodColor","flood-color"],["floodOpacity","flood-opacity"],["fontFamily","font-family"],["fontSize","font-size"],["fontSizeAdjust","font-size-adjust"],["fontStretch","font-stretch"],["fontStyle","font-style"],["fontVariant","font-variant"],["fontWeight","font-weight"],["glyphName","glyph-name"],["glyphOrientationHorizontal","glyph-orientation-horizontal"],["glyphOrientationVertical","glyph-orientation-vertical"],["horizAdvX","horiz-adv-x"],["horizOriginX","horiz-origin-x"],["imageRendering","image-rendering"],["letterSpacing","letter-spacing"],["lightingColor","lighting-color"],["markerEnd","marker-end"],["markerMid","marker-mid"],["markerStart","marker-start"],["overlinePosition","overline-position"],["overlineThickness","overline-thickness"],["paintOrder","paint-order"],["panose-1","panose-1"],["pointerEvents","pointer-events"],["renderingIntent","rendering-intent"],["shapeRendering","shape-rendering"],["stopColor","stop-color"],["stopOpacity","stop-opacity"],["strikethroughPosition","strikethrough-position"],["strikethroughThickness","strikethrough-thickness"],["strokeDasharray","stroke-dasharray"],["strokeDashoffset","stroke-dashoffset"],["strokeLinecap","stroke-linecap"],["strokeLinejoin","stroke-linejoin"],["strokeMiterlimit","stroke-miterlimit"],["strokeOpacity","stroke-opacity"],["strokeWidth","stroke-width"],["textAnchor","text-anchor"],["textDecoration","text-decoration"],["textRendering","text-rendering"],["transformOrigin","transform-origin"],["underlinePosition","underline-position"],["underlineThickness","underline-thickness"],["unicodeBidi","unicode-bidi"],["unicodeRange","unicode-range"],["unitsPerEm","units-per-em"],["vAlphabetic","v-alphabetic"],["vHanging","v-hanging"],["vIdeographic","v-ideographic"],["vMathematical","v-mathematical"],["vectorEffect","vector-effect"],["vertAdvY","vert-adv-y"],["vertOriginX","vert-origin-x"],["vertOriginY","vert-origin-y"],["wordSpacing","word-spacing"],["writingMode","writing-mode"],["xmlnsXlink","xmlns:xlink"],["xHeight","x-height"]]),ua=/^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;function $i(e){return ua.test(""+e)?"javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')":e}function Hi(){}var ju=null;function $u(e){return e=e.target||e.srcElement||window,e.correspondingUseElement&&(e=e.correspondingUseElement),e.nodeType===3?e.parentNode:e}var pr=null,mr=null;function Mm(e){var i=an(e);if(i&&(e=i.stateNode)){var r=e[un]||null;t:switch(e=i.stateNode,i.type){case"input":if(Pn(e,r.value,r.defaultValue,r.defaultValue,r.checked,r.defaultChecked,r.type,r.name),i=r.name,r.type==="radio"&&i!=null){for(r=e;r.parentNode;)r=r.parentNode;for(r=r.querySelectorAll('input[name="'+Ne(""+i)+'"][type="radio"]'),i=0;i<r.length;i++){var l=r[i];if(l!==e&&l.form===e.form){var f=l[un]||null;if(!f)throw Error(a(90));Pn(l,f.value,f.defaultValue,f.defaultValue,f.checked,f.defaultChecked,f.type,f.name)}}for(i=0;i<r.length;i++)l=r[i],l.form===e.form&&Ke(l)}break t;case"textarea":hi(e,r.value,r.defaultValue);break t;case"select":i=r.value,i!=null&&Oe(e,!!r.multiple,i,!1)}}}var tf=!1;function ym(e,i,r){if(tf)return e(i,r);tf=!0;try{var l=e(i);return l}finally{if(tf=!1,(pr!==null||mr!==null)&&(wc(),pr&&(i=pr,e=mr,mr=pr=null,Mm(i),e)))for(i=0;i<e.length;i++)Mm(e[i])}}function Mo(e,i){var r=e.stateNode;if(r===null)return null;var l=r[un]||null;if(l===null)return null;r=l[i];t:switch(i){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(l=!l.disabled)||(e=e.type,l=!(e==="button"||e==="input"||e==="select"||e==="textarea")),e=!l;break t;default:e=!1}if(e)return null;if(r&&typeof r!="function")throw Error(a(231,i,typeof r));return r}var Sa=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),ef=!1;if(Sa)try{var yo={};Object.defineProperty(yo,"passive",{get:function(){ef=!0}}),window.addEventListener("test",yo,yo),window.removeEventListener("test",yo,yo)}catch{ef=!1}var ts=null,nf=null,Gl=null;function Sm(){if(Gl)return Gl;var e,i=nf,r=i.length,l,f="value"in ts?ts.value:ts.textContent,m=f.length;for(e=0;e<r&&i[e]===f[e];e++);var S=r-e;for(l=1;l<=S&&i[r-l]===f[m-l];l++);return Gl=f.slice(e,1<l?1-l:void 0)}function Vl(e){var i=e.keyCode;return"charCode"in e?(e=e.charCode,e===0&&i===13&&(e=13)):e=i,e===10&&(e=13),32<=e||e===13?e:0}function kl(){return!0}function bm(){return!1}function _i(e){function i(r,l,f,m,S){this._reactName=r,this._targetInst=f,this.type=l,this.nativeEvent=m,this.target=S,this.currentTarget=null;for(var O in e)e.hasOwnProperty(O)&&(r=e[O],this[O]=r?r(m):m[O]);return this.isDefaultPrevented=(m.defaultPrevented!=null?m.defaultPrevented:m.returnValue===!1)?kl:bm,this.isPropagationStopped=bm,this}return v(i.prototype,{preventDefault:function(){this.defaultPrevented=!0;var r=this.nativeEvent;r&&(r.preventDefault?r.preventDefault():typeof r.returnValue!="unknown"&&(r.returnValue=!1),this.isDefaultPrevented=kl)},stopPropagation:function(){var r=this.nativeEvent;r&&(r.stopPropagation?r.stopPropagation():typeof r.cancelBubble!="unknown"&&(r.cancelBubble=!0),this.isPropagationStopped=kl)},persist:function(){},isPersistent:kl}),i}var Ds={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(e){return e.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},Xl=_i(Ds),So=v({},Ds,{view:0,detail:0}),CM=_i(So),af,sf,bo,Wl=v({},So,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:of,button:0,buttons:0,relatedTarget:function(e){return e.relatedTarget===void 0?e.fromElement===e.srcElement?e.toElement:e.fromElement:e.relatedTarget},movementX:function(e){return"movementX"in e?e.movementX:(e!==bo&&(bo&&e.type==="mousemove"?(af=e.screenX-bo.screenX,sf=e.screenY-bo.screenY):sf=af=0,bo=e),af)},movementY:function(e){return"movementY"in e?e.movementY:sf}}),Em=_i(Wl),DM=v({},Wl,{dataTransfer:0}),UM=_i(DM),LM=v({},So,{relatedTarget:0}),rf=_i(LM),NM=v({},Ds,{animationName:0,elapsedTime:0,pseudoElement:0}),OM=_i(NM),PM=v({},Ds,{clipboardData:function(e){return"clipboardData"in e?e.clipboardData:window.clipboardData}}),zM=_i(PM),IM=v({},Ds,{data:0}),Tm=_i(IM),BM={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},FM={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},HM={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function GM(e){var i=this.nativeEvent;return i.getModifierState?i.getModifierState(e):(e=HM[e])?!!i[e]:!1}function of(){return GM}var VM=v({},So,{key:function(e){if(e.key){var i=BM[e.key]||e.key;if(i!=="Unidentified")return i}return e.type==="keypress"?(e=Vl(e),e===13?"Enter":String.fromCharCode(e)):e.type==="keydown"||e.type==="keyup"?FM[e.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:of,charCode:function(e){return e.type==="keypress"?Vl(e):0},keyCode:function(e){return e.type==="keydown"||e.type==="keyup"?e.keyCode:0},which:function(e){return e.type==="keypress"?Vl(e):e.type==="keydown"||e.type==="keyup"?e.keyCode:0}}),kM=_i(VM),XM=v({},Wl,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),Am=_i(XM),WM=v({},So,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:of}),qM=_i(WM),YM=v({},Ds,{propertyName:0,elapsedTime:0,pseudoElement:0}),ZM=_i(YM),KM=v({},Wl,{deltaX:function(e){return"deltaX"in e?e.deltaX:"wheelDeltaX"in e?-e.wheelDeltaX:0},deltaY:function(e){return"deltaY"in e?e.deltaY:"wheelDeltaY"in e?-e.wheelDeltaY:"wheelDelta"in e?-e.wheelDelta:0},deltaZ:0,deltaMode:0}),JM=_i(KM),QM=v({},Ds,{newState:0,oldState:0}),jM=_i(QM),$M=[9,13,27,32],lf=Sa&&"CompositionEvent"in window,Eo=null;Sa&&"documentMode"in document&&(Eo=document.documentMode);var ty=Sa&&"TextEvent"in window&&!Eo,wm=Sa&&(!lf||Eo&&8<Eo&&11>=Eo),Rm=" ",Cm=!1;function Dm(e,i){switch(e){case"keyup":return $M.indexOf(i.keyCode)!==-1;case"keydown":return i.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function Um(e){return e=e.detail,typeof e=="object"&&"data"in e?e.data:null}var gr=!1;function ey(e,i){switch(e){case"compositionend":return Um(i);case"keypress":return i.which!==32?null:(Cm=!0,Rm);case"textInput":return e=i.data,e===Rm&&Cm?null:e;default:return null}}function ny(e,i){if(gr)return e==="compositionend"||!lf&&Dm(e,i)?(e=Sm(),Gl=nf=ts=null,gr=!1,e):null;switch(e){case"paste":return null;case"keypress":if(!(i.ctrlKey||i.altKey||i.metaKey)||i.ctrlKey&&i.altKey){if(i.char&&1<i.char.length)return i.char;if(i.which)return String.fromCharCode(i.which)}return null;case"compositionend":return wm&&i.locale!=="ko"?null:i.data;default:return null}}var iy={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function Lm(e){var i=e&&e.nodeName&&e.nodeName.toLowerCase();return i==="input"?!!iy[e.type]:i==="textarea"}function Nm(e,i,r,l){pr?mr?mr.push(l):mr=[l]:pr=l,i=Oc(i,"onChange"),0<i.length&&(r=new Xl("onChange","change",null,r,l),e.push({event:r,listeners:i}))}var To=null,Ao=null;function ay(e){mv(e,0)}function ql(e){var i=Zn(e);if(Ke(i))return e}function Om(e,i){if(e==="change")return i}var Pm=!1;if(Sa){var cf;if(Sa){var uf="oninput"in document;if(!uf){var zm=document.createElement("div");zm.setAttribute("oninput","return;"),uf=typeof zm.oninput=="function"}cf=uf}else cf=!1;Pm=cf&&(!document.documentMode||9<document.documentMode)}function Im(){To&&(To.detachEvent("onpropertychange",Bm),Ao=To=null)}function Bm(e){if(e.propertyName==="value"&&ql(Ao)){var i=[];Nm(i,Ao,e,$u(e)),ym(ay,i)}}function sy(e,i,r){e==="focusin"?(Im(),To=i,Ao=r,To.attachEvent("onpropertychange",Bm)):e==="focusout"&&Im()}function ry(e){if(e==="selectionchange"||e==="keyup"||e==="keydown")return ql(Ao)}function oy(e,i){if(e==="click")return ql(i)}function ly(e,i){if(e==="input"||e==="change")return ql(i)}function cy(e,i){return e===i&&(e!==0||1/e===1/i)||e!==e&&i!==i}var wi=typeof Object.is=="function"?Object.is:cy;function wo(e,i){if(wi(e,i))return!0;if(typeof e!="object"||e===null||typeof i!="object"||i===null)return!1;var r=Object.keys(e),l=Object.keys(i);if(r.length!==l.length)return!1;for(l=0;l<r.length;l++){var f=r[l];if(!Xe.call(i,f)||!wi(e[f],i[f]))return!1}return!0}function Fm(e){for(;e&&e.firstChild;)e=e.firstChild;return e}function Hm(e,i){var r=Fm(e);e=0;for(var l;r;){if(r.nodeType===3){if(l=e+r.textContent.length,e<=i&&l>=i)return{node:r,offset:i-e};e=l}t:{for(;r;){if(r.nextSibling){r=r.nextSibling;break t}r=r.parentNode}r=void 0}r=Fm(r)}}function Gm(e,i){return e&&i?e===i?!0:e&&e.nodeType===3?!1:i&&i.nodeType===3?Gm(e,i.parentNode):"contains"in e?e.contains(i):e.compareDocumentPosition?!!(e.compareDocumentPosition(i)&16):!1:!1}function Vm(e){e=e!=null&&e.ownerDocument!=null&&e.ownerDocument.defaultView!=null?e.ownerDocument.defaultView:window;for(var i=xn(e.document);i instanceof e.HTMLIFrameElement;){try{var r=typeof i.contentWindow.location.href=="string"}catch{r=!1}if(r)e=i.contentWindow;else break;i=xn(e.document)}return i}function ff(e){var i=e&&e.nodeName&&e.nodeName.toLowerCase();return i&&(i==="input"&&(e.type==="text"||e.type==="search"||e.type==="tel"||e.type==="url"||e.type==="password")||i==="textarea"||e.contentEditable==="true")}var uy=Sa&&"documentMode"in document&&11>=document.documentMode,vr=null,hf=null,Ro=null,df=!1;function km(e,i,r){var l=r.window===r?r.document:r.nodeType===9?r:r.ownerDocument;df||vr==null||vr!==xn(l)||(l=vr,"selectionStart"in l&&ff(l)?l={start:l.selectionStart,end:l.selectionEnd}:(l=(l.ownerDocument&&l.ownerDocument.defaultView||window).getSelection(),l={anchorNode:l.anchorNode,anchorOffset:l.anchorOffset,focusNode:l.focusNode,focusOffset:l.focusOffset}),Ro&&wo(Ro,l)||(Ro=l,l=Oc(hf,"onSelect"),0<l.length&&(i=new Xl("onSelect","select",null,i,r),e.push({event:i,listeners:l}),i.target=vr)))}function Us(e,i){var r={};return r[e.toLowerCase()]=i.toLowerCase(),r["Webkit"+e]="webkit"+i,r["Moz"+e]="moz"+i,r}var _r={animationend:Us("Animation","AnimationEnd"),animationiteration:Us("Animation","AnimationIteration"),animationstart:Us("Animation","AnimationStart"),transitionrun:Us("Transition","TransitionRun"),transitionstart:Us("Transition","TransitionStart"),transitioncancel:Us("Transition","TransitionCancel"),transitionend:Us("Transition","TransitionEnd")},pf={},Xm={};Sa&&(Xm=document.createElement("div").style,"AnimationEvent"in window||(delete _r.animationend.animation,delete _r.animationiteration.animation,delete _r.animationstart.animation),"TransitionEvent"in window||delete _r.transitionend.transition);function Ls(e){if(pf[e])return pf[e];if(!_r[e])return e;var i=_r[e],r;for(r in i)if(i.hasOwnProperty(r)&&r in Xm)return pf[e]=i[r];return e}var Wm=Ls("animationend"),qm=Ls("animationiteration"),Ym=Ls("animationstart"),fy=Ls("transitionrun"),hy=Ls("transitionstart"),dy=Ls("transitioncancel"),Zm=Ls("transitionend"),Km=new Map,mf="abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");mf.push("scrollEnd");function ta(e,i){Km.set(e,i),D(i,[e])}var Yl=typeof reportError=="function"?reportError:function(e){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var i=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof e=="object"&&e!==null&&typeof e.message=="string"?String(e.message):String(e),error:e});if(!window.dispatchEvent(i))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",e);return}console.error(e)},Gi=[],xr=0,gf=0;function Zl(){for(var e=xr,i=gf=xr=0;i<e;){var r=Gi[i];Gi[i++]=null;var l=Gi[i];Gi[i++]=null;var f=Gi[i];Gi[i++]=null;var m=Gi[i];if(Gi[i++]=null,l!==null&&f!==null){var S=l.pending;S===null?f.next=f:(f.next=S.next,S.next=f),l.pending=f}m!==0&&Jm(r,f,m)}}function Kl(e,i,r,l){Gi[xr++]=e,Gi[xr++]=i,Gi[xr++]=r,Gi[xr++]=l,gf|=l,e.lanes|=l,e=e.alternate,e!==null&&(e.lanes|=l)}function vf(e,i,r,l){return Kl(e,i,r,l),Jl(e)}function Ns(e,i){return Kl(e,null,null,i),Jl(e)}function Jm(e,i,r){e.lanes|=r;var l=e.alternate;l!==null&&(l.lanes|=r);for(var f=!1,m=e.return;m!==null;)m.childLanes|=r,l=m.alternate,l!==null&&(l.childLanes|=r),m.tag===22&&(e=m.stateNode,e===null||e._visibility&1||(f=!0)),e=m,m=m.return;return e.tag===3?(m=e.stateNode,f&&i!==null&&(f=31-gt(r),e=m.hiddenUpdates,l=e[f],l===null?e[f]=[i]:l.push(i),i.lane=r|536870912),m):null}function Jl(e){if(50<Jo)throw Jo=0,Ah=null,Error(a(185));for(var i=e.return;i!==null;)e=i,i=e.return;return e.tag===3?e.stateNode:null}var Mr={};function py(e,i,r,l){this.tag=e,this.key=r,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.refCleanup=this.ref=null,this.pendingProps=i,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=l,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function Ri(e,i,r,l){return new py(e,i,r,l)}function _f(e){return e=e.prototype,!(!e||!e.isReactComponent)}function ba(e,i){var r=e.alternate;return r===null?(r=Ri(e.tag,i,e.key,e.mode),r.elementType=e.elementType,r.type=e.type,r.stateNode=e.stateNode,r.alternate=e,e.alternate=r):(r.pendingProps=i,r.type=e.type,r.flags=0,r.subtreeFlags=0,r.deletions=null),r.flags=e.flags&65011712,r.childLanes=e.childLanes,r.lanes=e.lanes,r.child=e.child,r.memoizedProps=e.memoizedProps,r.memoizedState=e.memoizedState,r.updateQueue=e.updateQueue,i=e.dependencies,r.dependencies=i===null?null:{lanes:i.lanes,firstContext:i.firstContext},r.sibling=e.sibling,r.index=e.index,r.ref=e.ref,r.refCleanup=e.refCleanup,r}function Qm(e,i){e.flags&=65011714;var r=e.alternate;return r===null?(e.childLanes=0,e.lanes=i,e.child=null,e.subtreeFlags=0,e.memoizedProps=null,e.memoizedState=null,e.updateQueue=null,e.dependencies=null,e.stateNode=null):(e.childLanes=r.childLanes,e.lanes=r.lanes,e.child=r.child,e.subtreeFlags=0,e.deletions=null,e.memoizedProps=r.memoizedProps,e.memoizedState=r.memoizedState,e.updateQueue=r.updateQueue,e.type=r.type,i=r.dependencies,e.dependencies=i===null?null:{lanes:i.lanes,firstContext:i.firstContext}),e}function Ql(e,i,r,l,f,m){var S=0;if(l=e,typeof e=="function")_f(e)&&(S=1);else if(typeof e=="string")S=xS(e,r,Ut.current)?26:e==="html"||e==="head"||e==="body"?27:5;else t:switch(e){case z:return e=Ri(31,r,i,f),e.elementType=z,e.lanes=m,e;case R:return Os(r.children,f,m,i);case y:S=8,f|=24;break;case M:return e=Ri(12,r,i,f|2),e.elementType=M,e.lanes=m,e;case U:return e=Ri(13,r,i,f),e.elementType=U,e.lanes=m,e;case L:return e=Ri(19,r,i,f),e.elementType=L,e.lanes=m,e;default:if(typeof e=="object"&&e!==null)switch(e.$$typeof){case P:S=10;break t;case C:S=9;break t;case E:S=11;break t;case N:S=14;break t;case T:S=16,l=null;break t}S=29,r=Error(a(130,e===null?"null":typeof e,"")),l=null}return i=Ri(S,r,i,f),i.elementType=e,i.type=l,i.lanes=m,i}function Os(e,i,r,l){return e=Ri(7,e,l,i),e.lanes=r,e}function xf(e,i,r){return e=Ri(6,e,null,i),e.lanes=r,e}function jm(e){var i=Ri(18,null,null,0);return i.stateNode=e,i}function Mf(e,i,r){return i=Ri(4,e.children!==null?e.children:[],e.key,i),i.lanes=r,i.stateNode={containerInfo:e.containerInfo,pendingChildren:null,implementation:e.implementation},i}var $m=new WeakMap;function Vi(e,i){if(typeof e=="object"&&e!==null){var r=$m.get(e);return r!==void 0?r:(i={value:e,source:i,stack:Ce(i)},$m.set(e,i),i)}return{value:e,source:i,stack:Ce(i)}}var yr=[],Sr=0,jl=null,Co=0,ki=[],Xi=0,es=null,fa=1,ha="";function Ea(e,i){yr[Sr++]=Co,yr[Sr++]=jl,jl=e,Co=i}function t0(e,i,r){ki[Xi++]=fa,ki[Xi++]=ha,ki[Xi++]=es,es=e;var l=fa;e=ha;var f=32-gt(l)-1;l&=~(1<<f),r+=1;var m=32-gt(i)+f;if(30<m){var S=f-f%5;m=(l&(1<<S)-1).toString(32),l>>=S,f-=S,fa=1<<32-gt(i)+f|r<<f|l,ha=m+e}else fa=1<<m|r<<f|l,ha=e}function yf(e){e.return!==null&&(Ea(e,1),t0(e,1,0))}function Sf(e){for(;e===jl;)jl=yr[--Sr],yr[Sr]=null,Co=yr[--Sr],yr[Sr]=null;for(;e===es;)es=ki[--Xi],ki[Xi]=null,ha=ki[--Xi],ki[Xi]=null,fa=ki[--Xi],ki[Xi]=null}function e0(e,i){ki[Xi++]=fa,ki[Xi++]=ha,ki[Xi++]=es,fa=i.id,ha=i.overflow,es=e}var ni=null,Mn=null,We=!1,ns=null,Wi=!1,bf=Error(a(519));function is(e){var i=Error(a(418,1<arguments.length&&arguments[1]!==void 0&&arguments[1]?"text":"HTML",""));throw Do(Vi(i,e)),bf}function n0(e){var i=e.stateNode,r=e.type,l=e.memoizedProps;switch(i[Ze]=e,i[un]=l,r){case"dialog":Ge("cancel",i),Ge("close",i);break;case"iframe":case"object":case"embed":Ge("load",i);break;case"video":case"audio":for(r=0;r<jo.length;r++)Ge(jo[r],i);break;case"source":Ge("error",i);break;case"img":case"image":case"link":Ge("error",i),Ge("load",i);break;case"details":Ge("toggle",i);break;case"input":Ge("invalid",i),Qt(i,l.value,l.defaultValue,l.checked,l.defaultChecked,l.type,l.name,!0);break;case"select":Ge("invalid",i);break;case"textarea":Ge("invalid",i),Ai(i,l.value,l.defaultValue,l.children)}r=l.children,typeof r!="string"&&typeof r!="number"&&typeof r!="bigint"||i.textContent===""+r||l.suppressHydrationWarning===!0||xv(i.textContent,r)?(l.popover!=null&&(Ge("beforetoggle",i),Ge("toggle",i)),l.onScroll!=null&&Ge("scroll",i),l.onScrollEnd!=null&&Ge("scrollend",i),l.onClick!=null&&(i.onclick=Hi),i=!0):i=!1,i||is(e,!0)}function i0(e){for(ni=e.return;ni;)switch(ni.tag){case 5:case 31:case 13:Wi=!1;return;case 27:case 3:Wi=!0;return;default:ni=ni.return}}function br(e){if(e!==ni)return!1;if(!We)return i0(e),We=!0,!1;var i=e.tag,r;if((r=i!==3&&i!==27)&&((r=i===5)&&(r=e.type,r=!(r!=="form"&&r!=="button")||Gh(e.type,e.memoizedProps)),r=!r),r&&Mn&&is(e),i0(e),i===13){if(e=e.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(a(317));Mn=Rv(e)}else if(i===31){if(e=e.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(a(317));Mn=Rv(e)}else i===27?(i=Mn,vs(e.type)?(e=qh,qh=null,Mn=e):Mn=i):Mn=ni?Yi(e.stateNode.nextSibling):null;return!0}function Ps(){Mn=ni=null,We=!1}function Ef(){var e=ns;return e!==null&&(Si===null?Si=e:Si.push.apply(Si,e),ns=null),e}function Do(e){ns===null?ns=[e]:ns.push(e)}var Tf=I(null),zs=null,Ta=null;function as(e,i,r){Tt(Tf,i._currentValue),i._currentValue=r}function Aa(e){e._currentValue=Tf.current,ct(Tf)}function Af(e,i,r){for(;e!==null;){var l=e.alternate;if((e.childLanes&i)!==i?(e.childLanes|=i,l!==null&&(l.childLanes|=i)):l!==null&&(l.childLanes&i)!==i&&(l.childLanes|=i),e===r)break;e=e.return}}function wf(e,i,r,l){var f=e.child;for(f!==null&&(f.return=e);f!==null;){var m=f.dependencies;if(m!==null){var S=f.child;m=m.firstContext;t:for(;m!==null;){var O=m;m=f;for(var K=0;K<i.length;K++)if(O.context===i[K]){m.lanes|=r,O=m.alternate,O!==null&&(O.lanes|=r),Af(m.return,r,e),l||(S=null);break t}m=O.next}}else if(f.tag===18){if(S=f.return,S===null)throw Error(a(341));S.lanes|=r,m=S.alternate,m!==null&&(m.lanes|=r),Af(S,r,e),S=null}else S=f.child;if(S!==null)S.return=f;else for(S=f;S!==null;){if(S===e){S=null;break}if(f=S.sibling,f!==null){f.return=S.return,S=f;break}S=S.return}f=S}}function Er(e,i,r,l){e=null;for(var f=i,m=!1;f!==null;){if(!m){if((f.flags&524288)!==0)m=!0;else if((f.flags&262144)!==0)break}if(f.tag===10){var S=f.alternate;if(S===null)throw Error(a(387));if(S=S.memoizedProps,S!==null){var O=f.type;wi(f.pendingProps.value,S.value)||(e!==null?e.push(O):e=[O])}}else if(f===ft.current){if(S=f.alternate,S===null)throw Error(a(387));S.memoizedState.memoizedState!==f.memoizedState.memoizedState&&(e!==null?e.push(il):e=[il])}f=f.return}e!==null&&wf(i,e,r,l),i.flags|=262144}function $l(e){for(e=e.firstContext;e!==null;){if(!wi(e.context._currentValue,e.memoizedValue))return!0;e=e.next}return!1}function Is(e){zs=e,Ta=null,e=e.dependencies,e!==null&&(e.firstContext=null)}function ii(e){return a0(zs,e)}function tc(e,i){return zs===null&&Is(e),a0(e,i)}function a0(e,i){var r=i._currentValue;if(i={context:i,memoizedValue:r,next:null},Ta===null){if(e===null)throw Error(a(308));Ta=i,e.dependencies={lanes:0,firstContext:i},e.flags|=524288}else Ta=Ta.next=i;return r}var my=typeof AbortController<"u"?AbortController:function(){var e=[],i=this.signal={aborted:!1,addEventListener:function(r,l){e.push(l)}};this.abort=function(){i.aborted=!0,e.forEach(function(r){return r()})}},gy=s.unstable_scheduleCallback,vy=s.unstable_NormalPriority,zn={$$typeof:P,Consumer:null,Provider:null,_currentValue:null,_currentValue2:null,_threadCount:0};function Rf(){return{controller:new my,data:new Map,refCount:0}}function Uo(e){e.refCount--,e.refCount===0&&gy(vy,function(){e.controller.abort()})}var Lo=null,Cf=0,Tr=0,Ar=null;function _y(e,i){if(Lo===null){var r=Lo=[];Cf=0,Tr=Lh(),Ar={status:"pending",value:void 0,then:function(l){r.push(l)}}}return Cf++,i.then(s0,s0),i}function s0(){if(--Cf===0&&Lo!==null){Ar!==null&&(Ar.status="fulfilled");var e=Lo;Lo=null,Tr=0,Ar=null;for(var i=0;i<e.length;i++)(0,e[i])()}}function xy(e,i){var r=[],l={status:"pending",value:null,reason:null,then:function(f){r.push(f)}};return e.then(function(){l.status="fulfilled",l.value=i;for(var f=0;f<r.length;f++)(0,r[f])(i)},function(f){for(l.status="rejected",l.reason=f,f=0;f<r.length;f++)(0,r[f])(void 0)}),l}var r0=H.S;H.S=function(e,i){kg=Se(),typeof i=="object"&&i!==null&&typeof i.then=="function"&&_y(e,i),r0!==null&&r0(e,i)};var Bs=I(null);function Df(){var e=Bs.current;return e!==null?e:gn.pooledCache}function ec(e,i){i===null?Tt(Bs,Bs.current):Tt(Bs,i.pool)}function o0(){var e=Df();return e===null?null:{parent:zn._currentValue,pool:e}}var wr=Error(a(460)),Uf=Error(a(474)),nc=Error(a(542)),ic={then:function(){}};function l0(e){return e=e.status,e==="fulfilled"||e==="rejected"}function c0(e,i,r){switch(r=e[r],r===void 0?e.push(i):r!==i&&(i.then(Hi,Hi),i=r),i.status){case"fulfilled":return i.value;case"rejected":throw e=i.reason,f0(e),e;default:if(typeof i.status=="string")i.then(Hi,Hi);else{if(e=gn,e!==null&&100<e.shellSuspendCounter)throw Error(a(482));e=i,e.status="pending",e.then(function(l){if(i.status==="pending"){var f=i;f.status="fulfilled",f.value=l}},function(l){if(i.status==="pending"){var f=i;f.status="rejected",f.reason=l}})}switch(i.status){case"fulfilled":return i.value;case"rejected":throw e=i.reason,f0(e),e}throw Hs=i,wr}}function Fs(e){try{var i=e._init;return i(e._payload)}catch(r){throw r!==null&&typeof r=="object"&&typeof r.then=="function"?(Hs=r,wr):r}}var Hs=null;function u0(){if(Hs===null)throw Error(a(459));var e=Hs;return Hs=null,e}function f0(e){if(e===wr||e===nc)throw Error(a(483))}var Rr=null,No=0;function ac(e){var i=No;return No+=1,Rr===null&&(Rr=[]),c0(Rr,e,i)}function Oo(e,i){i=i.props.ref,e.ref=i!==void 0?i:null}function sc(e,i){throw i.$$typeof===_?Error(a(525)):(e=Object.prototype.toString.call(i),Error(a(31,e==="[object Object]"?"object with keys {"+Object.keys(i).join(", ")+"}":e)))}function h0(e){function i(ut,tt){if(e){var vt=ut.deletions;vt===null?(ut.deletions=[tt],ut.flags|=16):vt.push(tt)}}function r(ut,tt){if(!e)return null;for(;tt!==null;)i(ut,tt),tt=tt.sibling;return null}function l(ut){for(var tt=new Map;ut!==null;)ut.key!==null?tt.set(ut.key,ut):tt.set(ut.index,ut),ut=ut.sibling;return tt}function f(ut,tt){return ut=ba(ut,tt),ut.index=0,ut.sibling=null,ut}function m(ut,tt,vt){return ut.index=vt,e?(vt=ut.alternate,vt!==null?(vt=vt.index,vt<tt?(ut.flags|=67108866,tt):vt):(ut.flags|=67108866,tt)):(ut.flags|=1048576,tt)}function S(ut){return e&&ut.alternate===null&&(ut.flags|=67108866),ut}function O(ut,tt,vt,Nt){return tt===null||tt.tag!==6?(tt=xf(vt,ut.mode,Nt),tt.return=ut,tt):(tt=f(tt,vt),tt.return=ut,tt)}function K(ut,tt,vt,Nt){var he=vt.type;return he===R?Dt(ut,tt,vt.props.children,Nt,vt.key):tt!==null&&(tt.elementType===he||typeof he=="object"&&he!==null&&he.$$typeof===T&&Fs(he)===tt.type)?(tt=f(tt,vt.props),Oo(tt,vt),tt.return=ut,tt):(tt=Ql(vt.type,vt.key,vt.props,null,ut.mode,Nt),Oo(tt,vt),tt.return=ut,tt)}function _t(ut,tt,vt,Nt){return tt===null||tt.tag!==4||tt.stateNode.containerInfo!==vt.containerInfo||tt.stateNode.implementation!==vt.implementation?(tt=Mf(vt,ut.mode,Nt),tt.return=ut,tt):(tt=f(tt,vt.children||[]),tt.return=ut,tt)}function Dt(ut,tt,vt,Nt,he){return tt===null||tt.tag!==7?(tt=Os(vt,ut.mode,Nt,he),tt.return=ut,tt):(tt=f(tt,vt),tt.return=ut,tt)}function Pt(ut,tt,vt){if(typeof tt=="string"&&tt!==""||typeof tt=="number"||typeof tt=="bigint")return tt=xf(""+tt,ut.mode,vt),tt.return=ut,tt;if(typeof tt=="object"&&tt!==null){switch(tt.$$typeof){case x:return vt=Ql(tt.type,tt.key,tt.props,null,ut.mode,vt),Oo(vt,tt),vt.return=ut,vt;case b:return tt=Mf(tt,ut.mode,vt),tt.return=ut,tt;case T:return tt=Fs(tt),Pt(ut,tt,vt)}if(k(tt)||$(tt))return tt=Os(tt,ut.mode,vt,null),tt.return=ut,tt;if(typeof tt.then=="function")return Pt(ut,ac(tt),vt);if(tt.$$typeof===P)return Pt(ut,tc(ut,tt),vt);sc(ut,tt)}return null}function St(ut,tt,vt,Nt){var he=tt!==null?tt.key:null;if(typeof vt=="string"&&vt!==""||typeof vt=="number"||typeof vt=="bigint")return he!==null?null:O(ut,tt,""+vt,Nt);if(typeof vt=="object"&&vt!==null){switch(vt.$$typeof){case x:return vt.key===he?K(ut,tt,vt,Nt):null;case b:return vt.key===he?_t(ut,tt,vt,Nt):null;case T:return vt=Fs(vt),St(ut,tt,vt,Nt)}if(k(vt)||$(vt))return he!==null?null:Dt(ut,tt,vt,Nt,null);if(typeof vt.then=="function")return St(ut,tt,ac(vt),Nt);if(vt.$$typeof===P)return St(ut,tt,tc(ut,vt),Nt);sc(ut,vt)}return null}function At(ut,tt,vt,Nt,he){if(typeof Nt=="string"&&Nt!==""||typeof Nt=="number"||typeof Nt=="bigint")return ut=ut.get(vt)||null,O(tt,ut,""+Nt,he);if(typeof Nt=="object"&&Nt!==null){switch(Nt.$$typeof){case x:return ut=ut.get(Nt.key===null?vt:Nt.key)||null,K(tt,ut,Nt,he);case b:return ut=ut.get(Nt.key===null?vt:Nt.key)||null,_t(tt,ut,Nt,he);case T:return Nt=Fs(Nt),At(ut,tt,vt,Nt,he)}if(k(Nt)||$(Nt))return ut=ut.get(vt)||null,Dt(tt,ut,Nt,he,null);if(typeof Nt.then=="function")return At(ut,tt,vt,ac(Nt),he);if(Nt.$$typeof===P)return At(ut,tt,vt,tc(tt,Nt),he);sc(tt,Nt)}return null}function ne(ut,tt,vt,Nt){for(var he=null,Qe=null,re=tt,Le=tt=0,ke=null;re!==null&&Le<vt.length;Le++){re.index>Le?(ke=re,re=null):ke=re.sibling;var je=St(ut,re,vt[Le],Nt);if(je===null){re===null&&(re=ke);break}e&&re&&je.alternate===null&&i(ut,re),tt=m(je,tt,Le),Qe===null?he=je:Qe.sibling=je,Qe=je,re=ke}if(Le===vt.length)return r(ut,re),We&&Ea(ut,Le),he;if(re===null){for(;Le<vt.length;Le++)re=Pt(ut,vt[Le],Nt),re!==null&&(tt=m(re,tt,Le),Qe===null?he=re:Qe.sibling=re,Qe=re);return We&&Ea(ut,Le),he}for(re=l(re);Le<vt.length;Le++)ke=At(re,ut,Le,vt[Le],Nt),ke!==null&&(e&&ke.alternate!==null&&re.delete(ke.key===null?Le:ke.key),tt=m(ke,tt,Le),Qe===null?he=ke:Qe.sibling=ke,Qe=ke);return e&&re.forEach(function(Ss){return i(ut,Ss)}),We&&Ea(ut,Le),he}function _e(ut,tt,vt,Nt){if(vt==null)throw Error(a(151));for(var he=null,Qe=null,re=tt,Le=tt=0,ke=null,je=vt.next();re!==null&&!je.done;Le++,je=vt.next()){re.index>Le?(ke=re,re=null):ke=re.sibling;var Ss=St(ut,re,je.value,Nt);if(Ss===null){re===null&&(re=ke);break}e&&re&&Ss.alternate===null&&i(ut,re),tt=m(Ss,tt,Le),Qe===null?he=Ss:Qe.sibling=Ss,Qe=Ss,re=ke}if(je.done)return r(ut,re),We&&Ea(ut,Le),he;if(re===null){for(;!je.done;Le++,je=vt.next())je=Pt(ut,je.value,Nt),je!==null&&(tt=m(je,tt,Le),Qe===null?he=je:Qe.sibling=je,Qe=je);return We&&Ea(ut,Le),he}for(re=l(re);!je.done;Le++,je=vt.next())je=At(re,ut,Le,je.value,Nt),je!==null&&(e&&je.alternate!==null&&re.delete(je.key===null?Le:je.key),tt=m(je,tt,Le),Qe===null?he=je:Qe.sibling=je,Qe=je);return e&&re.forEach(function(DS){return i(ut,DS)}),We&&Ea(ut,Le),he}function pn(ut,tt,vt,Nt){if(typeof vt=="object"&&vt!==null&&vt.type===R&&vt.key===null&&(vt=vt.props.children),typeof vt=="object"&&vt!==null){switch(vt.$$typeof){case x:t:{for(var he=vt.key;tt!==null;){if(tt.key===he){if(he=vt.type,he===R){if(tt.tag===7){r(ut,tt.sibling),Nt=f(tt,vt.props.children),Nt.return=ut,ut=Nt;break t}}else if(tt.elementType===he||typeof he=="object"&&he!==null&&he.$$typeof===T&&Fs(he)===tt.type){r(ut,tt.sibling),Nt=f(tt,vt.props),Oo(Nt,vt),Nt.return=ut,ut=Nt;break t}r(ut,tt);break}else i(ut,tt);tt=tt.sibling}vt.type===R?(Nt=Os(vt.props.children,ut.mode,Nt,vt.key),Nt.return=ut,ut=Nt):(Nt=Ql(vt.type,vt.key,vt.props,null,ut.mode,Nt),Oo(Nt,vt),Nt.return=ut,ut=Nt)}return S(ut);case b:t:{for(he=vt.key;tt!==null;){if(tt.key===he)if(tt.tag===4&&tt.stateNode.containerInfo===vt.containerInfo&&tt.stateNode.implementation===vt.implementation){r(ut,tt.sibling),Nt=f(tt,vt.children||[]),Nt.return=ut,ut=Nt;break t}else{r(ut,tt);break}else i(ut,tt);tt=tt.sibling}Nt=Mf(vt,ut.mode,Nt),Nt.return=ut,ut=Nt}return S(ut);case T:return vt=Fs(vt),pn(ut,tt,vt,Nt)}if(k(vt))return ne(ut,tt,vt,Nt);if($(vt)){if(he=$(vt),typeof he!="function")throw Error(a(150));return vt=he.call(vt),_e(ut,tt,vt,Nt)}if(typeof vt.then=="function")return pn(ut,tt,ac(vt),Nt);if(vt.$$typeof===P)return pn(ut,tt,tc(ut,vt),Nt);sc(ut,vt)}return typeof vt=="string"&&vt!==""||typeof vt=="number"||typeof vt=="bigint"?(vt=""+vt,tt!==null&&tt.tag===6?(r(ut,tt.sibling),Nt=f(tt,vt),Nt.return=ut,ut=Nt):(r(ut,tt),Nt=xf(vt,ut.mode,Nt),Nt.return=ut,ut=Nt),S(ut)):r(ut,tt)}return function(ut,tt,vt,Nt){try{No=0;var he=pn(ut,tt,vt,Nt);return Rr=null,he}catch(re){if(re===wr||re===nc)throw re;var Qe=Ri(29,re,null,ut.mode);return Qe.lanes=Nt,Qe.return=ut,Qe}finally{}}}var Gs=h0(!0),d0=h0(!1),ss=!1;function Lf(e){e.updateQueue={baseState:e.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,lanes:0,hiddenCallbacks:null},callbacks:null}}function Nf(e,i){e=e.updateQueue,i.updateQueue===e&&(i.updateQueue={baseState:e.baseState,firstBaseUpdate:e.firstBaseUpdate,lastBaseUpdate:e.lastBaseUpdate,shared:e.shared,callbacks:null})}function rs(e){return{lane:e,tag:0,payload:null,callback:null,next:null}}function os(e,i,r){var l=e.updateQueue;if(l===null)return null;if(l=l.shared,(en&2)!==0){var f=l.pending;return f===null?i.next=i:(i.next=f.next,f.next=i),l.pending=i,i=Jl(e),Jm(e,null,r),i}return Kl(e,l,i,r),Jl(e)}function Po(e,i,r){if(i=i.updateQueue,i!==null&&(i=i.shared,(r&4194048)!==0)){var l=i.lanes;l&=e.pendingLanes,r|=l,i.lanes=r,Me(e,r)}}function Of(e,i){var r=e.updateQueue,l=e.alternate;if(l!==null&&(l=l.updateQueue,r===l)){var f=null,m=null;if(r=r.firstBaseUpdate,r!==null){do{var S={lane:r.lane,tag:r.tag,payload:r.payload,callback:null,next:null};m===null?f=m=S:m=m.next=S,r=r.next}while(r!==null);m===null?f=m=i:m=m.next=i}else f=m=i;r={baseState:l.baseState,firstBaseUpdate:f,lastBaseUpdate:m,shared:l.shared,callbacks:l.callbacks},e.updateQueue=r;return}e=r.lastBaseUpdate,e===null?r.firstBaseUpdate=i:e.next=i,r.lastBaseUpdate=i}var Pf=!1;function zo(){if(Pf){var e=Ar;if(e!==null)throw e}}function Io(e,i,r,l){Pf=!1;var f=e.updateQueue;ss=!1;var m=f.firstBaseUpdate,S=f.lastBaseUpdate,O=f.shared.pending;if(O!==null){f.shared.pending=null;var K=O,_t=K.next;K.next=null,S===null?m=_t:S.next=_t,S=K;var Dt=e.alternate;Dt!==null&&(Dt=Dt.updateQueue,O=Dt.lastBaseUpdate,O!==S&&(O===null?Dt.firstBaseUpdate=_t:O.next=_t,Dt.lastBaseUpdate=K))}if(m!==null){var Pt=f.baseState;S=0,Dt=_t=K=null,O=m;do{var St=O.lane&-536870913,At=St!==O.lane;if(At?(Ve&St)===St:(l&St)===St){St!==0&&St===Tr&&(Pf=!0),Dt!==null&&(Dt=Dt.next={lane:0,tag:O.tag,payload:O.payload,callback:null,next:null});t:{var ne=e,_e=O;St=i;var pn=r;switch(_e.tag){case 1:if(ne=_e.payload,typeof ne=="function"){Pt=ne.call(pn,Pt,St);break t}Pt=ne;break t;case 3:ne.flags=ne.flags&-65537|128;case 0:if(ne=_e.payload,St=typeof ne=="function"?ne.call(pn,Pt,St):ne,St==null)break t;Pt=v({},Pt,St);break t;case 2:ss=!0}}St=O.callback,St!==null&&(e.flags|=64,At&&(e.flags|=8192),At=f.callbacks,At===null?f.callbacks=[St]:At.push(St))}else At={lane:St,tag:O.tag,payload:O.payload,callback:O.callback,next:null},Dt===null?(_t=Dt=At,K=Pt):Dt=Dt.next=At,S|=St;if(O=O.next,O===null){if(O=f.shared.pending,O===null)break;At=O,O=At.next,At.next=null,f.lastBaseUpdate=At,f.shared.pending=null}}while(!0);Dt===null&&(K=Pt),f.baseState=K,f.firstBaseUpdate=_t,f.lastBaseUpdate=Dt,m===null&&(f.shared.lanes=0),hs|=S,e.lanes=S,e.memoizedState=Pt}}function p0(e,i){if(typeof e!="function")throw Error(a(191,e));e.call(i)}function m0(e,i){var r=e.callbacks;if(r!==null)for(e.callbacks=null,e=0;e<r.length;e++)p0(r[e],i)}var Cr=I(null),rc=I(0);function g0(e,i){e=Pa,Tt(rc,e),Tt(Cr,i),Pa=e|i.baseLanes}function zf(){Tt(rc,Pa),Tt(Cr,Cr.current)}function If(){Pa=rc.current,ct(Cr),ct(rc)}var Ci=I(null),qi=null;function ls(e){var i=e.alternate;Tt(Dn,Dn.current&1),Tt(Ci,e),qi===null&&(i===null||Cr.current!==null||i.memoizedState!==null)&&(qi=e)}function Bf(e){Tt(Dn,Dn.current),Tt(Ci,e),qi===null&&(qi=e)}function v0(e){e.tag===22?(Tt(Dn,Dn.current),Tt(Ci,e),qi===null&&(qi=e)):cs()}function cs(){Tt(Dn,Dn.current),Tt(Ci,Ci.current)}function Di(e){ct(Ci),qi===e&&(qi=null),ct(Dn)}var Dn=I(0);function oc(e){for(var i=e;i!==null;){if(i.tag===13){var r=i.memoizedState;if(r!==null&&(r=r.dehydrated,r===null||Xh(r)||Wh(r)))return i}else if(i.tag===19&&(i.memoizedProps.revealOrder==="forwards"||i.memoizedProps.revealOrder==="backwards"||i.memoizedProps.revealOrder==="unstable_legacy-backwards"||i.memoizedProps.revealOrder==="together")){if((i.flags&128)!==0)return i}else if(i.child!==null){i.child.return=i,i=i.child;continue}if(i===e)break;for(;i.sibling===null;){if(i.return===null||i.return===e)return null;i=i.return}i.sibling.return=i.return,i=i.sibling}return null}var wa=0,De=null,hn=null,In=null,lc=!1,Dr=!1,Vs=!1,cc=0,Bo=0,Ur=null,My=0;function Rn(){throw Error(a(321))}function Ff(e,i){if(i===null)return!1;for(var r=0;r<i.length&&r<e.length;r++)if(!wi(e[r],i[r]))return!1;return!0}function Hf(e,i,r,l,f,m){return wa=m,De=i,i.memoizedState=null,i.updateQueue=null,i.lanes=0,H.H=e===null||e.memoizedState===null?tg:eh,Vs=!1,m=r(l,f),Vs=!1,Dr&&(m=x0(i,r,l,f)),_0(e),m}function _0(e){H.H=Go;var i=hn!==null&&hn.next!==null;if(wa=0,In=hn=De=null,lc=!1,Bo=0,Ur=null,i)throw Error(a(300));e===null||Bn||(e=e.dependencies,e!==null&&$l(e)&&(Bn=!0))}function x0(e,i,r,l){De=e;var f=0;do{if(Dr&&(Ur=null),Bo=0,Dr=!1,25<=f)throw Error(a(301));if(f+=1,In=hn=null,e.updateQueue!=null){var m=e.updateQueue;m.lastEffect=null,m.events=null,m.stores=null,m.memoCache!=null&&(m.memoCache.index=0)}H.H=eg,m=i(r,l)}while(Dr);return m}function yy(){var e=H.H,i=e.useState()[0];return i=typeof i.then=="function"?Fo(i):i,e=e.useState()[0],(hn!==null?hn.memoizedState:null)!==e&&(De.flags|=1024),i}function Gf(){var e=cc!==0;return cc=0,e}function Vf(e,i,r){i.updateQueue=e.updateQueue,i.flags&=-2053,e.lanes&=~r}function kf(e){if(lc){for(e=e.memoizedState;e!==null;){var i=e.queue;i!==null&&(i.pending=null),e=e.next}lc=!1}wa=0,In=hn=De=null,Dr=!1,Bo=cc=0,Ur=null}function pi(){var e={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return In===null?De.memoizedState=In=e:In=In.next=e,In}function Un(){if(hn===null){var e=De.alternate;e=e!==null?e.memoizedState:null}else e=hn.next;var i=In===null?De.memoizedState:In.next;if(i!==null)In=i,hn=e;else{if(e===null)throw De.alternate===null?Error(a(467)):Error(a(310));hn=e,e={memoizedState:hn.memoizedState,baseState:hn.baseState,baseQueue:hn.baseQueue,queue:hn.queue,next:null},In===null?De.memoizedState=In=e:In=In.next=e}return In}function uc(){return{lastEffect:null,events:null,stores:null,memoCache:null}}function Fo(e){var i=Bo;return Bo+=1,Ur===null&&(Ur=[]),e=c0(Ur,e,i),i=De,(In===null?i.memoizedState:In.next)===null&&(i=i.alternate,H.H=i===null||i.memoizedState===null?tg:eh),e}function fc(e){if(e!==null&&typeof e=="object"){if(typeof e.then=="function")return Fo(e);if(e.$$typeof===P)return ii(e)}throw Error(a(438,String(e)))}function Xf(e){var i=null,r=De.updateQueue;if(r!==null&&(i=r.memoCache),i==null){var l=De.alternate;l!==null&&(l=l.updateQueue,l!==null&&(l=l.memoCache,l!=null&&(i={data:l.data.map(function(f){return f.slice()}),index:0})))}if(i==null&&(i={data:[],index:0}),r===null&&(r=uc(),De.updateQueue=r),r.memoCache=i,r=i.data[i.index],r===void 0)for(r=i.data[i.index]=Array(e),l=0;l<e;l++)r[l]=W;return i.index++,r}function Ra(e,i){return typeof i=="function"?i(e):i}function hc(e){var i=Un();return Wf(i,hn,e)}function Wf(e,i,r){var l=e.queue;if(l===null)throw Error(a(311));l.lastRenderedReducer=r;var f=e.baseQueue,m=l.pending;if(m!==null){if(f!==null){var S=f.next;f.next=m.next,m.next=S}i.baseQueue=f=m,l.pending=null}if(m=e.baseState,f===null)e.memoizedState=m;else{i=f.next;var O=S=null,K=null,_t=i,Dt=!1;do{var Pt=_t.lane&-536870913;if(Pt!==_t.lane?(Ve&Pt)===Pt:(wa&Pt)===Pt){var St=_t.revertLane;if(St===0)K!==null&&(K=K.next={lane:0,revertLane:0,gesture:null,action:_t.action,hasEagerState:_t.hasEagerState,eagerState:_t.eagerState,next:null}),Pt===Tr&&(Dt=!0);else if((wa&St)===St){_t=_t.next,St===Tr&&(Dt=!0);continue}else Pt={lane:0,revertLane:_t.revertLane,gesture:null,action:_t.action,hasEagerState:_t.hasEagerState,eagerState:_t.eagerState,next:null},K===null?(O=K=Pt,S=m):K=K.next=Pt,De.lanes|=St,hs|=St;Pt=_t.action,Vs&&r(m,Pt),m=_t.hasEagerState?_t.eagerState:r(m,Pt)}else St={lane:Pt,revertLane:_t.revertLane,gesture:_t.gesture,action:_t.action,hasEagerState:_t.hasEagerState,eagerState:_t.eagerState,next:null},K===null?(O=K=St,S=m):K=K.next=St,De.lanes|=Pt,hs|=Pt;_t=_t.next}while(_t!==null&&_t!==i);if(K===null?S=m:K.next=O,!wi(m,e.memoizedState)&&(Bn=!0,Dt&&(r=Ar,r!==null)))throw r;e.memoizedState=m,e.baseState=S,e.baseQueue=K,l.lastRenderedState=m}return f===null&&(l.lanes=0),[e.memoizedState,l.dispatch]}function qf(e){var i=Un(),r=i.queue;if(r===null)throw Error(a(311));r.lastRenderedReducer=e;var l=r.dispatch,f=r.pending,m=i.memoizedState;if(f!==null){r.pending=null;var S=f=f.next;do m=e(m,S.action),S=S.next;while(S!==f);wi(m,i.memoizedState)||(Bn=!0),i.memoizedState=m,i.baseQueue===null&&(i.baseState=m),r.lastRenderedState=m}return[m,l]}function M0(e,i,r){var l=De,f=Un(),m=We;if(m){if(r===void 0)throw Error(a(407));r=r()}else r=i();var S=!wi((hn||f).memoizedState,r);if(S&&(f.memoizedState=r,Bn=!0),f=f.queue,Kf(b0.bind(null,l,f,e),[e]),f.getSnapshot!==i||S||In!==null&&In.memoizedState.tag&1){if(l.flags|=2048,Lr(9,{destroy:void 0},S0.bind(null,l,f,r,i),null),gn===null)throw Error(a(349));m||(wa&127)!==0||y0(l,i,r)}return r}function y0(e,i,r){e.flags|=16384,e={getSnapshot:i,value:r},i=De.updateQueue,i===null?(i=uc(),De.updateQueue=i,i.stores=[e]):(r=i.stores,r===null?i.stores=[e]:r.push(e))}function S0(e,i,r,l){i.value=r,i.getSnapshot=l,E0(i)&&T0(e)}function b0(e,i,r){return r(function(){E0(i)&&T0(e)})}function E0(e){var i=e.getSnapshot;e=e.value;try{var r=i();return!wi(e,r)}catch{return!0}}function T0(e){var i=Ns(e,2);i!==null&&bi(i,e,2)}function Yf(e){var i=pi();if(typeof e=="function"){var r=e;if(e=r(),Vs){zt(!0);try{r()}finally{zt(!1)}}}return i.memoizedState=i.baseState=e,i.queue={pending:null,lanes:0,dispatch:null,lastRenderedReducer:Ra,lastRenderedState:e},i}function A0(e,i,r,l){return e.baseState=r,Wf(e,hn,typeof l=="function"?l:Ra)}function Sy(e,i,r,l,f){if(mc(e))throw Error(a(485));if(e=i.action,e!==null){var m={payload:f,action:e,next:null,isTransition:!0,status:"pending",value:null,reason:null,listeners:[],then:function(S){m.listeners.push(S)}};H.T!==null?r(!0):m.isTransition=!1,l(m),r=i.pending,r===null?(m.next=i.pending=m,w0(i,m)):(m.next=r.next,i.pending=r.next=m)}}function w0(e,i){var r=i.action,l=i.payload,f=e.state;if(i.isTransition){var m=H.T,S={};H.T=S;try{var O=r(f,l),K=H.S;K!==null&&K(S,O),R0(e,i,O)}catch(_t){Zf(e,i,_t)}finally{m!==null&&S.types!==null&&(m.types=S.types),H.T=m}}else try{m=r(f,l),R0(e,i,m)}catch(_t){Zf(e,i,_t)}}function R0(e,i,r){r!==null&&typeof r=="object"&&typeof r.then=="function"?r.then(function(l){C0(e,i,l)},function(l){return Zf(e,i,l)}):C0(e,i,r)}function C0(e,i,r){i.status="fulfilled",i.value=r,D0(i),e.state=r,i=e.pending,i!==null&&(r=i.next,r===i?e.pending=null:(r=r.next,i.next=r,w0(e,r)))}function Zf(e,i,r){var l=e.pending;if(e.pending=null,l!==null){l=l.next;do i.status="rejected",i.reason=r,D0(i),i=i.next;while(i!==l)}e.action=null}function D0(e){e=e.listeners;for(var i=0;i<e.length;i++)(0,e[i])()}function U0(e,i){return i}function L0(e,i){if(We){var r=gn.formState;if(r!==null){t:{var l=De;if(We){if(Mn){e:{for(var f=Mn,m=Wi;f.nodeType!==8;){if(!m){f=null;break e}if(f=Yi(f.nextSibling),f===null){f=null;break e}}m=f.data,f=m==="F!"||m==="F"?f:null}if(f){Mn=Yi(f.nextSibling),l=f.data==="F!";break t}}is(l)}l=!1}l&&(i=r[0])}}return r=pi(),r.memoizedState=r.baseState=i,l={pending:null,lanes:0,dispatch:null,lastRenderedReducer:U0,lastRenderedState:i},r.queue=l,r=Q0.bind(null,De,l),l.dispatch=r,l=Yf(!1),m=th.bind(null,De,!1,l.queue),l=pi(),f={state:i,dispatch:null,action:e,pending:null},l.queue=f,r=Sy.bind(null,De,f,m,r),f.dispatch=r,l.memoizedState=e,[i,r,!1]}function N0(e){var i=Un();return O0(i,hn,e)}function O0(e,i,r){if(i=Wf(e,i,U0)[0],e=hc(Ra)[0],typeof i=="object"&&i!==null&&typeof i.then=="function")try{var l=Fo(i)}catch(S){throw S===wr?nc:S}else l=i;i=Un();var f=i.queue,m=f.dispatch;return r!==i.memoizedState&&(De.flags|=2048,Lr(9,{destroy:void 0},by.bind(null,f,r),null)),[l,m,e]}function by(e,i){e.action=i}function P0(e){var i=Un(),r=hn;if(r!==null)return O0(i,r,e);Un(),i=i.memoizedState,r=Un();var l=r.queue.dispatch;return r.memoizedState=e,[i,l,!1]}function Lr(e,i,r,l){return e={tag:e,create:r,deps:l,inst:i,next:null},i=De.updateQueue,i===null&&(i=uc(),De.updateQueue=i),r=i.lastEffect,r===null?i.lastEffect=e.next=e:(l=r.next,r.next=e,e.next=l,i.lastEffect=e),e}function z0(){return Un().memoizedState}function dc(e,i,r,l){var f=pi();De.flags|=e,f.memoizedState=Lr(1|i,{destroy:void 0},r,l===void 0?null:l)}function pc(e,i,r,l){var f=Un();l=l===void 0?null:l;var m=f.memoizedState.inst;hn!==null&&l!==null&&Ff(l,hn.memoizedState.deps)?f.memoizedState=Lr(i,m,r,l):(De.flags|=e,f.memoizedState=Lr(1|i,m,r,l))}function I0(e,i){dc(8390656,8,e,i)}function Kf(e,i){pc(2048,8,e,i)}function Ey(e){De.flags|=4;var i=De.updateQueue;if(i===null)i=uc(),De.updateQueue=i,i.events=[e];else{var r=i.events;r===null?i.events=[e]:r.push(e)}}function B0(e){var i=Un().memoizedState;return Ey({ref:i,nextImpl:e}),function(){if((en&2)!==0)throw Error(a(440));return i.impl.apply(void 0,arguments)}}function F0(e,i){return pc(4,2,e,i)}function H0(e,i){return pc(4,4,e,i)}function G0(e,i){if(typeof i=="function"){e=e();var r=i(e);return function(){typeof r=="function"?r():i(null)}}if(i!=null)return e=e(),i.current=e,function(){i.current=null}}function V0(e,i,r){r=r!=null?r.concat([e]):null,pc(4,4,G0.bind(null,i,e),r)}function Jf(){}function k0(e,i){var r=Un();i=i===void 0?null:i;var l=r.memoizedState;return i!==null&&Ff(i,l[1])?l[0]:(r.memoizedState=[e,i],e)}function X0(e,i){var r=Un();i=i===void 0?null:i;var l=r.memoizedState;if(i!==null&&Ff(i,l[1]))return l[0];if(l=e(),Vs){zt(!0);try{e()}finally{zt(!1)}}return r.memoizedState=[l,i],l}function Qf(e,i,r){return r===void 0||(wa&1073741824)!==0&&(Ve&261930)===0?e.memoizedState=i:(e.memoizedState=r,e=Wg(),De.lanes|=e,hs|=e,r)}function W0(e,i,r,l){return wi(r,i)?r:Cr.current!==null?(e=Qf(e,r,l),wi(e,i)||(Bn=!0),e):(wa&42)===0||(wa&1073741824)!==0&&(Ve&261930)===0?(Bn=!0,e.memoizedState=r):(e=Wg(),De.lanes|=e,hs|=e,i)}function q0(e,i,r,l,f){var m=Y.p;Y.p=m!==0&&8>m?m:8;var S=H.T,O={};H.T=O,th(e,!1,i,r);try{var K=f(),_t=H.S;if(_t!==null&&_t(O,K),K!==null&&typeof K=="object"&&typeof K.then=="function"){var Dt=xy(K,l);Ho(e,i,Dt,Ni(e))}else Ho(e,i,l,Ni(e))}catch(Pt){Ho(e,i,{then:function(){},status:"rejected",reason:Pt},Ni())}finally{Y.p=m,S!==null&&O.types!==null&&(S.types=O.types),H.T=S}}function Ty(){}function jf(e,i,r,l){if(e.tag!==5)throw Error(a(476));var f=Y0(e).queue;q0(e,f,i,it,r===null?Ty:function(){return Z0(e),r(l)})}function Y0(e){var i=e.memoizedState;if(i!==null)return i;i={memoizedState:it,baseState:it,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:Ra,lastRenderedState:it},next:null};var r={};return i.next={memoizedState:r,baseState:r,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:Ra,lastRenderedState:r},next:null},e.memoizedState=i,e=e.alternate,e!==null&&(e.memoizedState=i),i}function Z0(e){var i=Y0(e);i.next===null&&(i=e.alternate.memoizedState),Ho(e,i.next.queue,{},Ni())}function $f(){return ii(il)}function K0(){return Un().memoizedState}function J0(){return Un().memoizedState}function Ay(e){for(var i=e.return;i!==null;){switch(i.tag){case 24:case 3:var r=Ni();e=rs(r);var l=os(i,e,r);l!==null&&(bi(l,i,r),Po(l,i,r)),i={cache:Rf()},e.payload=i;return}i=i.return}}function wy(e,i,r){var l=Ni();r={lane:l,revertLane:0,gesture:null,action:r,hasEagerState:!1,eagerState:null,next:null},mc(e)?j0(i,r):(r=vf(e,i,r,l),r!==null&&(bi(r,e,l),$0(r,i,l)))}function Q0(e,i,r){var l=Ni();Ho(e,i,r,l)}function Ho(e,i,r,l){var f={lane:l,revertLane:0,gesture:null,action:r,hasEagerState:!1,eagerState:null,next:null};if(mc(e))j0(i,f);else{var m=e.alternate;if(e.lanes===0&&(m===null||m.lanes===0)&&(m=i.lastRenderedReducer,m!==null))try{var S=i.lastRenderedState,O=m(S,r);if(f.hasEagerState=!0,f.eagerState=O,wi(O,S))return Kl(e,i,f,0),gn===null&&Zl(),!1}catch{}finally{}if(r=vf(e,i,f,l),r!==null)return bi(r,e,l),$0(r,i,l),!0}return!1}function th(e,i,r,l){if(l={lane:2,revertLane:Lh(),gesture:null,action:l,hasEagerState:!1,eagerState:null,next:null},mc(e)){if(i)throw Error(a(479))}else i=vf(e,r,l,2),i!==null&&bi(i,e,2)}function mc(e){var i=e.alternate;return e===De||i!==null&&i===De}function j0(e,i){Dr=lc=!0;var r=e.pending;r===null?i.next=i:(i.next=r.next,r.next=i),e.pending=i}function $0(e,i,r){if((r&4194048)!==0){var l=i.lanes;l&=e.pendingLanes,r|=l,i.lanes=r,Me(e,r)}}var Go={readContext:ii,use:fc,useCallback:Rn,useContext:Rn,useEffect:Rn,useImperativeHandle:Rn,useLayoutEffect:Rn,useInsertionEffect:Rn,useMemo:Rn,useReducer:Rn,useRef:Rn,useState:Rn,useDebugValue:Rn,useDeferredValue:Rn,useTransition:Rn,useSyncExternalStore:Rn,useId:Rn,useHostTransitionStatus:Rn,useFormState:Rn,useActionState:Rn,useOptimistic:Rn,useMemoCache:Rn,useCacheRefresh:Rn};Go.useEffectEvent=Rn;var tg={readContext:ii,use:fc,useCallback:function(e,i){return pi().memoizedState=[e,i===void 0?null:i],e},useContext:ii,useEffect:I0,useImperativeHandle:function(e,i,r){r=r!=null?r.concat([e]):null,dc(4194308,4,G0.bind(null,i,e),r)},useLayoutEffect:function(e,i){return dc(4194308,4,e,i)},useInsertionEffect:function(e,i){dc(4,2,e,i)},useMemo:function(e,i){var r=pi();i=i===void 0?null:i;var l=e();if(Vs){zt(!0);try{e()}finally{zt(!1)}}return r.memoizedState=[l,i],l},useReducer:function(e,i,r){var l=pi();if(r!==void 0){var f=r(i);if(Vs){zt(!0);try{r(i)}finally{zt(!1)}}}else f=i;return l.memoizedState=l.baseState=f,e={pending:null,lanes:0,dispatch:null,lastRenderedReducer:e,lastRenderedState:f},l.queue=e,e=e.dispatch=wy.bind(null,De,e),[l.memoizedState,e]},useRef:function(e){var i=pi();return e={current:e},i.memoizedState=e},useState:function(e){e=Yf(e);var i=e.queue,r=Q0.bind(null,De,i);return i.dispatch=r,[e.memoizedState,r]},useDebugValue:Jf,useDeferredValue:function(e,i){var r=pi();return Qf(r,e,i)},useTransition:function(){var e=Yf(!1);return e=q0.bind(null,De,e.queue,!0,!1),pi().memoizedState=e,[!1,e]},useSyncExternalStore:function(e,i,r){var l=De,f=pi();if(We){if(r===void 0)throw Error(a(407));r=r()}else{if(r=i(),gn===null)throw Error(a(349));(Ve&127)!==0||y0(l,i,r)}f.memoizedState=r;var m={value:r,getSnapshot:i};return f.queue=m,I0(b0.bind(null,l,m,e),[e]),l.flags|=2048,Lr(9,{destroy:void 0},S0.bind(null,l,m,r,i),null),r},useId:function(){var e=pi(),i=gn.identifierPrefix;if(We){var r=ha,l=fa;r=(l&~(1<<32-gt(l)-1)).toString(32)+r,i="_"+i+"R_"+r,r=cc++,0<r&&(i+="H"+r.toString(32)),i+="_"}else r=My++,i="_"+i+"r_"+r.toString(32)+"_";return e.memoizedState=i},useHostTransitionStatus:$f,useFormState:L0,useActionState:L0,useOptimistic:function(e){var i=pi();i.memoizedState=i.baseState=e;var r={pending:null,lanes:0,dispatch:null,lastRenderedReducer:null,lastRenderedState:null};return i.queue=r,i=th.bind(null,De,!0,r),r.dispatch=i,[e,i]},useMemoCache:Xf,useCacheRefresh:function(){return pi().memoizedState=Ay.bind(null,De)},useEffectEvent:function(e){var i=pi(),r={impl:e};return i.memoizedState=r,function(){if((en&2)!==0)throw Error(a(440));return r.impl.apply(void 0,arguments)}}},eh={readContext:ii,use:fc,useCallback:k0,useContext:ii,useEffect:Kf,useImperativeHandle:V0,useInsertionEffect:F0,useLayoutEffect:H0,useMemo:X0,useReducer:hc,useRef:z0,useState:function(){return hc(Ra)},useDebugValue:Jf,useDeferredValue:function(e,i){var r=Un();return W0(r,hn.memoizedState,e,i)},useTransition:function(){var e=hc(Ra)[0],i=Un().memoizedState;return[typeof e=="boolean"?e:Fo(e),i]},useSyncExternalStore:M0,useId:K0,useHostTransitionStatus:$f,useFormState:N0,useActionState:N0,useOptimistic:function(e,i){var r=Un();return A0(r,hn,e,i)},useMemoCache:Xf,useCacheRefresh:J0};eh.useEffectEvent=B0;var eg={readContext:ii,use:fc,useCallback:k0,useContext:ii,useEffect:Kf,useImperativeHandle:V0,useInsertionEffect:F0,useLayoutEffect:H0,useMemo:X0,useReducer:qf,useRef:z0,useState:function(){return qf(Ra)},useDebugValue:Jf,useDeferredValue:function(e,i){var r=Un();return hn===null?Qf(r,e,i):W0(r,hn.memoizedState,e,i)},useTransition:function(){var e=qf(Ra)[0],i=Un().memoizedState;return[typeof e=="boolean"?e:Fo(e),i]},useSyncExternalStore:M0,useId:K0,useHostTransitionStatus:$f,useFormState:P0,useActionState:P0,useOptimistic:function(e,i){var r=Un();return hn!==null?A0(r,hn,e,i):(r.baseState=e,[e,r.queue.dispatch])},useMemoCache:Xf,useCacheRefresh:J0};eg.useEffectEvent=B0;function nh(e,i,r,l){i=e.memoizedState,r=r(l,i),r=r==null?i:v({},i,r),e.memoizedState=r,e.lanes===0&&(e.updateQueue.baseState=r)}var ih={enqueueSetState:function(e,i,r){e=e._reactInternals;var l=Ni(),f=rs(l);f.payload=i,r!=null&&(f.callback=r),i=os(e,f,l),i!==null&&(bi(i,e,l),Po(i,e,l))},enqueueReplaceState:function(e,i,r){e=e._reactInternals;var l=Ni(),f=rs(l);f.tag=1,f.payload=i,r!=null&&(f.callback=r),i=os(e,f,l),i!==null&&(bi(i,e,l),Po(i,e,l))},enqueueForceUpdate:function(e,i){e=e._reactInternals;var r=Ni(),l=rs(r);l.tag=2,i!=null&&(l.callback=i),i=os(e,l,r),i!==null&&(bi(i,e,r),Po(i,e,r))}};function ng(e,i,r,l,f,m,S){return e=e.stateNode,typeof e.shouldComponentUpdate=="function"?e.shouldComponentUpdate(l,m,S):i.prototype&&i.prototype.isPureReactComponent?!wo(r,l)||!wo(f,m):!0}function ig(e,i,r,l){e=i.state,typeof i.componentWillReceiveProps=="function"&&i.componentWillReceiveProps(r,l),typeof i.UNSAFE_componentWillReceiveProps=="function"&&i.UNSAFE_componentWillReceiveProps(r,l),i.state!==e&&ih.enqueueReplaceState(i,i.state,null)}function ks(e,i){var r=i;if("ref"in i){r={};for(var l in i)l!=="ref"&&(r[l]=i[l])}if(e=e.defaultProps){r===i&&(r=v({},r));for(var f in e)r[f]===void 0&&(r[f]=e[f])}return r}function ag(e){Yl(e)}function sg(e){console.error(e)}function rg(e){Yl(e)}function gc(e,i){try{var r=e.onUncaughtError;r(i.value,{componentStack:i.stack})}catch(l){setTimeout(function(){throw l})}}function og(e,i,r){try{var l=e.onCaughtError;l(r.value,{componentStack:r.stack,errorBoundary:i.tag===1?i.stateNode:null})}catch(f){setTimeout(function(){throw f})}}function ah(e,i,r){return r=rs(r),r.tag=3,r.payload={element:null},r.callback=function(){gc(e,i)},r}function lg(e){return e=rs(e),e.tag=3,e}function cg(e,i,r,l){var f=r.type.getDerivedStateFromError;if(typeof f=="function"){var m=l.value;e.payload=function(){return f(m)},e.callback=function(){og(i,r,l)}}var S=r.stateNode;S!==null&&typeof S.componentDidCatch=="function"&&(e.callback=function(){og(i,r,l),typeof f!="function"&&(ds===null?ds=new Set([this]):ds.add(this));var O=l.stack;this.componentDidCatch(l.value,{componentStack:O!==null?O:""})})}function Ry(e,i,r,l,f){if(r.flags|=32768,l!==null&&typeof l=="object"&&typeof l.then=="function"){if(i=r.alternate,i!==null&&Er(i,r,f,!0),r=Ci.current,r!==null){switch(r.tag){case 31:case 13:return qi===null?Rc():r.alternate===null&&Cn===0&&(Cn=3),r.flags&=-257,r.flags|=65536,r.lanes=f,l===ic?r.flags|=16384:(i=r.updateQueue,i===null?r.updateQueue=new Set([l]):i.add(l),Ch(e,l,f)),!1;case 22:return r.flags|=65536,l===ic?r.flags|=16384:(i=r.updateQueue,i===null?(i={transitions:null,markerInstances:null,retryQueue:new Set([l])},r.updateQueue=i):(r=i.retryQueue,r===null?i.retryQueue=new Set([l]):r.add(l)),Ch(e,l,f)),!1}throw Error(a(435,r.tag))}return Ch(e,l,f),Rc(),!1}if(We)return i=Ci.current,i!==null?((i.flags&65536)===0&&(i.flags|=256),i.flags|=65536,i.lanes=f,l!==bf&&(e=Error(a(422),{cause:l}),Do(Vi(e,r)))):(l!==bf&&(i=Error(a(423),{cause:l}),Do(Vi(i,r))),e=e.current.alternate,e.flags|=65536,f&=-f,e.lanes|=f,l=Vi(l,r),f=ah(e.stateNode,l,f),Of(e,f),Cn!==4&&(Cn=2)),!1;var m=Error(a(520),{cause:l});if(m=Vi(m,r),Ko===null?Ko=[m]:Ko.push(m),Cn!==4&&(Cn=2),i===null)return!0;l=Vi(l,r),r=i;do{switch(r.tag){case 3:return r.flags|=65536,e=f&-f,r.lanes|=e,e=ah(r.stateNode,l,e),Of(r,e),!1;case 1:if(i=r.type,m=r.stateNode,(r.flags&128)===0&&(typeof i.getDerivedStateFromError=="function"||m!==null&&typeof m.componentDidCatch=="function"&&(ds===null||!ds.has(m))))return r.flags|=65536,f&=-f,r.lanes|=f,f=lg(f),cg(f,e,r,l),Of(r,f),!1}r=r.return}while(r!==null);return!1}var sh=Error(a(461)),Bn=!1;function ai(e,i,r,l){i.child=e===null?d0(i,null,r,l):Gs(i,e.child,r,l)}function ug(e,i,r,l,f){r=r.render;var m=i.ref;if("ref"in l){var S={};for(var O in l)O!=="ref"&&(S[O]=l[O])}else S=l;return Is(i),l=Hf(e,i,r,S,m,f),O=Gf(),e!==null&&!Bn?(Vf(e,i,f),Ca(e,i,f)):(We&&O&&yf(i),i.flags|=1,ai(e,i,l,f),i.child)}function fg(e,i,r,l,f){if(e===null){var m=r.type;return typeof m=="function"&&!_f(m)&&m.defaultProps===void 0&&r.compare===null?(i.tag=15,i.type=m,hg(e,i,m,l,f)):(e=Ql(r.type,null,l,i,i.mode,f),e.ref=i.ref,e.return=i,i.child=e)}if(m=e.child,!dh(e,f)){var S=m.memoizedProps;if(r=r.compare,r=r!==null?r:wo,r(S,l)&&e.ref===i.ref)return Ca(e,i,f)}return i.flags|=1,e=ba(m,l),e.ref=i.ref,e.return=i,i.child=e}function hg(e,i,r,l,f){if(e!==null){var m=e.memoizedProps;if(wo(m,l)&&e.ref===i.ref)if(Bn=!1,i.pendingProps=l=m,dh(e,f))(e.flags&131072)!==0&&(Bn=!0);else return i.lanes=e.lanes,Ca(e,i,f)}return rh(e,i,r,l,f)}function dg(e,i,r,l){var f=l.children,m=e!==null?e.memoizedState:null;if(e===null&&i.stateNode===null&&(i.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),l.mode==="hidden"){if((i.flags&128)!==0){if(m=m!==null?m.baseLanes|r:r,e!==null){for(l=i.child=e.child,f=0;l!==null;)f=f|l.lanes|l.childLanes,l=l.sibling;l=f&~m}else l=0,i.child=null;return pg(e,i,m,r,l)}if((r&536870912)!==0)i.memoizedState={baseLanes:0,cachePool:null},e!==null&&ec(i,m!==null?m.cachePool:null),m!==null?g0(i,m):zf(),v0(i);else return l=i.lanes=536870912,pg(e,i,m!==null?m.baseLanes|r:r,r,l)}else m!==null?(ec(i,m.cachePool),g0(i,m),cs(),i.memoizedState=null):(e!==null&&ec(i,null),zf(),cs());return ai(e,i,f,r),i.child}function Vo(e,i){return e!==null&&e.tag===22||i.stateNode!==null||(i.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),i.sibling}function pg(e,i,r,l,f){var m=Df();return m=m===null?null:{parent:zn._currentValue,pool:m},i.memoizedState={baseLanes:r,cachePool:m},e!==null&&ec(i,null),zf(),v0(i),e!==null&&Er(e,i,l,!0),i.childLanes=f,null}function vc(e,i){return i=xc({mode:i.mode,children:i.children},e.mode),i.ref=e.ref,e.child=i,i.return=e,i}function mg(e,i,r){return Gs(i,e.child,null,r),e=vc(i,i.pendingProps),e.flags|=2,Di(i),i.memoizedState=null,e}function Cy(e,i,r){var l=i.pendingProps,f=(i.flags&128)!==0;if(i.flags&=-129,e===null){if(We){if(l.mode==="hidden")return e=vc(i,l),i.lanes=536870912,Vo(null,e);if(Bf(i),(e=Mn)?(e=wv(e,Wi),e=e!==null&&e.data==="&"?e:null,e!==null&&(i.memoizedState={dehydrated:e,treeContext:es!==null?{id:fa,overflow:ha}:null,retryLane:536870912,hydrationErrors:null},r=jm(e),r.return=i,i.child=r,ni=i,Mn=null)):e=null,e===null)throw is(i);return i.lanes=536870912,null}return vc(i,l)}var m=e.memoizedState;if(m!==null){var S=m.dehydrated;if(Bf(i),f)if(i.flags&256)i.flags&=-257,i=mg(e,i,r);else if(i.memoizedState!==null)i.child=e.child,i.flags|=128,i=null;else throw Error(a(558));else if(Bn||Er(e,i,r,!1),f=(r&e.childLanes)!==0,Bn||f){if(l=gn,l!==null&&(S=be(l,r),S!==0&&S!==m.retryLane))throw m.retryLane=S,Ns(e,S),bi(l,e,S),sh;Rc(),i=mg(e,i,r)}else e=m.treeContext,Mn=Yi(S.nextSibling),ni=i,We=!0,ns=null,Wi=!1,e!==null&&e0(i,e),i=vc(i,l),i.flags|=4096;return i}return e=ba(e.child,{mode:l.mode,children:l.children}),e.ref=i.ref,i.child=e,e.return=i,e}function _c(e,i){var r=i.ref;if(r===null)e!==null&&e.ref!==null&&(i.flags|=4194816);else{if(typeof r!="function"&&typeof r!="object")throw Error(a(284));(e===null||e.ref!==r)&&(i.flags|=4194816)}}function rh(e,i,r,l,f){return Is(i),r=Hf(e,i,r,l,void 0,f),l=Gf(),e!==null&&!Bn?(Vf(e,i,f),Ca(e,i,f)):(We&&l&&yf(i),i.flags|=1,ai(e,i,r,f),i.child)}function gg(e,i,r,l,f,m){return Is(i),i.updateQueue=null,r=x0(i,l,r,f),_0(e),l=Gf(),e!==null&&!Bn?(Vf(e,i,m),Ca(e,i,m)):(We&&l&&yf(i),i.flags|=1,ai(e,i,r,m),i.child)}function vg(e,i,r,l,f){if(Is(i),i.stateNode===null){var m=Mr,S=r.contextType;typeof S=="object"&&S!==null&&(m=ii(S)),m=new r(l,m),i.memoizedState=m.state!==null&&m.state!==void 0?m.state:null,m.updater=ih,i.stateNode=m,m._reactInternals=i,m=i.stateNode,m.props=l,m.state=i.memoizedState,m.refs={},Lf(i),S=r.contextType,m.context=typeof S=="object"&&S!==null?ii(S):Mr,m.state=i.memoizedState,S=r.getDerivedStateFromProps,typeof S=="function"&&(nh(i,r,S,l),m.state=i.memoizedState),typeof r.getDerivedStateFromProps=="function"||typeof m.getSnapshotBeforeUpdate=="function"||typeof m.UNSAFE_componentWillMount!="function"&&typeof m.componentWillMount!="function"||(S=m.state,typeof m.componentWillMount=="function"&&m.componentWillMount(),typeof m.UNSAFE_componentWillMount=="function"&&m.UNSAFE_componentWillMount(),S!==m.state&&ih.enqueueReplaceState(m,m.state,null),Io(i,l,m,f),zo(),m.state=i.memoizedState),typeof m.componentDidMount=="function"&&(i.flags|=4194308),l=!0}else if(e===null){m=i.stateNode;var O=i.memoizedProps,K=ks(r,O);m.props=K;var _t=m.context,Dt=r.contextType;S=Mr,typeof Dt=="object"&&Dt!==null&&(S=ii(Dt));var Pt=r.getDerivedStateFromProps;Dt=typeof Pt=="function"||typeof m.getSnapshotBeforeUpdate=="function",O=i.pendingProps!==O,Dt||typeof m.UNSAFE_componentWillReceiveProps!="function"&&typeof m.componentWillReceiveProps!="function"||(O||_t!==S)&&ig(i,m,l,S),ss=!1;var St=i.memoizedState;m.state=St,Io(i,l,m,f),zo(),_t=i.memoizedState,O||St!==_t||ss?(typeof Pt=="function"&&(nh(i,r,Pt,l),_t=i.memoizedState),(K=ss||ng(i,r,K,l,St,_t,S))?(Dt||typeof m.UNSAFE_componentWillMount!="function"&&typeof m.componentWillMount!="function"||(typeof m.componentWillMount=="function"&&m.componentWillMount(),typeof m.UNSAFE_componentWillMount=="function"&&m.UNSAFE_componentWillMount()),typeof m.componentDidMount=="function"&&(i.flags|=4194308)):(typeof m.componentDidMount=="function"&&(i.flags|=4194308),i.memoizedProps=l,i.memoizedState=_t),m.props=l,m.state=_t,m.context=S,l=K):(typeof m.componentDidMount=="function"&&(i.flags|=4194308),l=!1)}else{m=i.stateNode,Nf(e,i),S=i.memoizedProps,Dt=ks(r,S),m.props=Dt,Pt=i.pendingProps,St=m.context,_t=r.contextType,K=Mr,typeof _t=="object"&&_t!==null&&(K=ii(_t)),O=r.getDerivedStateFromProps,(_t=typeof O=="function"||typeof m.getSnapshotBeforeUpdate=="function")||typeof m.UNSAFE_componentWillReceiveProps!="function"&&typeof m.componentWillReceiveProps!="function"||(S!==Pt||St!==K)&&ig(i,m,l,K),ss=!1,St=i.memoizedState,m.state=St,Io(i,l,m,f),zo();var At=i.memoizedState;S!==Pt||St!==At||ss||e!==null&&e.dependencies!==null&&$l(e.dependencies)?(typeof O=="function"&&(nh(i,r,O,l),At=i.memoizedState),(Dt=ss||ng(i,r,Dt,l,St,At,K)||e!==null&&e.dependencies!==null&&$l(e.dependencies))?(_t||typeof m.UNSAFE_componentWillUpdate!="function"&&typeof m.componentWillUpdate!="function"||(typeof m.componentWillUpdate=="function"&&m.componentWillUpdate(l,At,K),typeof m.UNSAFE_componentWillUpdate=="function"&&m.UNSAFE_componentWillUpdate(l,At,K)),typeof m.componentDidUpdate=="function"&&(i.flags|=4),typeof m.getSnapshotBeforeUpdate=="function"&&(i.flags|=1024)):(typeof m.componentDidUpdate!="function"||S===e.memoizedProps&&St===e.memoizedState||(i.flags|=4),typeof m.getSnapshotBeforeUpdate!="function"||S===e.memoizedProps&&St===e.memoizedState||(i.flags|=1024),i.memoizedProps=l,i.memoizedState=At),m.props=l,m.state=At,m.context=K,l=Dt):(typeof m.componentDidUpdate!="function"||S===e.memoizedProps&&St===e.memoizedState||(i.flags|=4),typeof m.getSnapshotBeforeUpdate!="function"||S===e.memoizedProps&&St===e.memoizedState||(i.flags|=1024),l=!1)}return m=l,_c(e,i),l=(i.flags&128)!==0,m||l?(m=i.stateNode,r=l&&typeof r.getDerivedStateFromError!="function"?null:m.render(),i.flags|=1,e!==null&&l?(i.child=Gs(i,e.child,null,f),i.child=Gs(i,null,r,f)):ai(e,i,r,f),i.memoizedState=m.state,e=i.child):e=Ca(e,i,f),e}function _g(e,i,r,l){return Ps(),i.flags|=256,ai(e,i,r,l),i.child}var oh={dehydrated:null,treeContext:null,retryLane:0,hydrationErrors:null};function lh(e){return{baseLanes:e,cachePool:o0()}}function ch(e,i,r){return e=e!==null?e.childLanes&~r:0,i&&(e|=Li),e}function xg(e,i,r){var l=i.pendingProps,f=!1,m=(i.flags&128)!==0,S;if((S=m)||(S=e!==null&&e.memoizedState===null?!1:(Dn.current&2)!==0),S&&(f=!0,i.flags&=-129),S=(i.flags&32)!==0,i.flags&=-33,e===null){if(We){if(f?ls(i):cs(),(e=Mn)?(e=wv(e,Wi),e=e!==null&&e.data!=="&"?e:null,e!==null&&(i.memoizedState={dehydrated:e,treeContext:es!==null?{id:fa,overflow:ha}:null,retryLane:536870912,hydrationErrors:null},r=jm(e),r.return=i,i.child=r,ni=i,Mn=null)):e=null,e===null)throw is(i);return Wh(e)?i.lanes=32:i.lanes=536870912,null}var O=l.children;return l=l.fallback,f?(cs(),f=i.mode,O=xc({mode:"hidden",children:O},f),l=Os(l,f,r,null),O.return=i,l.return=i,O.sibling=l,i.child=O,l=i.child,l.memoizedState=lh(r),l.childLanes=ch(e,S,r),i.memoizedState=oh,Vo(null,l)):(ls(i),uh(i,O))}var K=e.memoizedState;if(K!==null&&(O=K.dehydrated,O!==null)){if(m)i.flags&256?(ls(i),i.flags&=-257,i=fh(e,i,r)):i.memoizedState!==null?(cs(),i.child=e.child,i.flags|=128,i=null):(cs(),O=l.fallback,f=i.mode,l=xc({mode:"visible",children:l.children},f),O=Os(O,f,r,null),O.flags|=2,l.return=i,O.return=i,l.sibling=O,i.child=l,Gs(i,e.child,null,r),l=i.child,l.memoizedState=lh(r),l.childLanes=ch(e,S,r),i.memoizedState=oh,i=Vo(null,l));else if(ls(i),Wh(O)){if(S=O.nextSibling&&O.nextSibling.dataset,S)var _t=S.dgst;S=_t,l=Error(a(419)),l.stack="",l.digest=S,Do({value:l,source:null,stack:null}),i=fh(e,i,r)}else if(Bn||Er(e,i,r,!1),S=(r&e.childLanes)!==0,Bn||S){if(S=gn,S!==null&&(l=be(S,r),l!==0&&l!==K.retryLane))throw K.retryLane=l,Ns(e,l),bi(S,e,l),sh;Xh(O)||Rc(),i=fh(e,i,r)}else Xh(O)?(i.flags|=192,i.child=e.child,i=null):(e=K.treeContext,Mn=Yi(O.nextSibling),ni=i,We=!0,ns=null,Wi=!1,e!==null&&e0(i,e),i=uh(i,l.children),i.flags|=4096);return i}return f?(cs(),O=l.fallback,f=i.mode,K=e.child,_t=K.sibling,l=ba(K,{mode:"hidden",children:l.children}),l.subtreeFlags=K.subtreeFlags&65011712,_t!==null?O=ba(_t,O):(O=Os(O,f,r,null),O.flags|=2),O.return=i,l.return=i,l.sibling=O,i.child=l,Vo(null,l),l=i.child,O=e.child.memoizedState,O===null?O=lh(r):(f=O.cachePool,f!==null?(K=zn._currentValue,f=f.parent!==K?{parent:K,pool:K}:f):f=o0(),O={baseLanes:O.baseLanes|r,cachePool:f}),l.memoizedState=O,l.childLanes=ch(e,S,r),i.memoizedState=oh,Vo(e.child,l)):(ls(i),r=e.child,e=r.sibling,r=ba(r,{mode:"visible",children:l.children}),r.return=i,r.sibling=null,e!==null&&(S=i.deletions,S===null?(i.deletions=[e],i.flags|=16):S.push(e)),i.child=r,i.memoizedState=null,r)}function uh(e,i){return i=xc({mode:"visible",children:i},e.mode),i.return=e,e.child=i}function xc(e,i){return e=Ri(22,e,null,i),e.lanes=0,e}function fh(e,i,r){return Gs(i,e.child,null,r),e=uh(i,i.pendingProps.children),e.flags|=2,i.memoizedState=null,e}function Mg(e,i,r){e.lanes|=i;var l=e.alternate;l!==null&&(l.lanes|=i),Af(e.return,i,r)}function hh(e,i,r,l,f,m){var S=e.memoizedState;S===null?e.memoizedState={isBackwards:i,rendering:null,renderingStartTime:0,last:l,tail:r,tailMode:f,treeForkCount:m}:(S.isBackwards=i,S.rendering=null,S.renderingStartTime=0,S.last=l,S.tail=r,S.tailMode=f,S.treeForkCount=m)}function yg(e,i,r){var l=i.pendingProps,f=l.revealOrder,m=l.tail;l=l.children;var S=Dn.current,O=(S&2)!==0;if(O?(S=S&1|2,i.flags|=128):S&=1,Tt(Dn,S),ai(e,i,l,r),l=We?Co:0,!O&&e!==null&&(e.flags&128)!==0)t:for(e=i.child;e!==null;){if(e.tag===13)e.memoizedState!==null&&Mg(e,r,i);else if(e.tag===19)Mg(e,r,i);else if(e.child!==null){e.child.return=e,e=e.child;continue}if(e===i)break t;for(;e.sibling===null;){if(e.return===null||e.return===i)break t;e=e.return}e.sibling.return=e.return,e=e.sibling}switch(f){case"forwards":for(r=i.child,f=null;r!==null;)e=r.alternate,e!==null&&oc(e)===null&&(f=r),r=r.sibling;r=f,r===null?(f=i.child,i.child=null):(f=r.sibling,r.sibling=null),hh(i,!1,f,r,m,l);break;case"backwards":case"unstable_legacy-backwards":for(r=null,f=i.child,i.child=null;f!==null;){if(e=f.alternate,e!==null&&oc(e)===null){i.child=f;break}e=f.sibling,f.sibling=r,r=f,f=e}hh(i,!0,r,null,m,l);break;case"together":hh(i,!1,null,null,void 0,l);break;default:i.memoizedState=null}return i.child}function Ca(e,i,r){if(e!==null&&(i.dependencies=e.dependencies),hs|=i.lanes,(r&i.childLanes)===0)if(e!==null){if(Er(e,i,r,!1),(r&i.childLanes)===0)return null}else return null;if(e!==null&&i.child!==e.child)throw Error(a(153));if(i.child!==null){for(e=i.child,r=ba(e,e.pendingProps),i.child=r,r.return=i;e.sibling!==null;)e=e.sibling,r=r.sibling=ba(e,e.pendingProps),r.return=i;r.sibling=null}return i.child}function dh(e,i){return(e.lanes&i)!==0?!0:(e=e.dependencies,!!(e!==null&&$l(e)))}function Dy(e,i,r){switch(i.tag){case 3:Et(i,i.stateNode.containerInfo),as(i,zn,e.memoizedState.cache),Ps();break;case 27:case 5:$t(i);break;case 4:Et(i,i.stateNode.containerInfo);break;case 10:as(i,i.type,i.memoizedProps.value);break;case 31:if(i.memoizedState!==null)return i.flags|=128,Bf(i),null;break;case 13:var l=i.memoizedState;if(l!==null)return l.dehydrated!==null?(ls(i),i.flags|=128,null):(r&i.child.childLanes)!==0?xg(e,i,r):(ls(i),e=Ca(e,i,r),e!==null?e.sibling:null);ls(i);break;case 19:var f=(e.flags&128)!==0;if(l=(r&i.childLanes)!==0,l||(Er(e,i,r,!1),l=(r&i.childLanes)!==0),f){if(l)return yg(e,i,r);i.flags|=128}if(f=i.memoizedState,f!==null&&(f.rendering=null,f.tail=null,f.lastEffect=null),Tt(Dn,Dn.current),l)break;return null;case 22:return i.lanes=0,dg(e,i,r,i.pendingProps);case 24:as(i,zn,e.memoizedState.cache)}return Ca(e,i,r)}function Sg(e,i,r){if(e!==null)if(e.memoizedProps!==i.pendingProps)Bn=!0;else{if(!dh(e,r)&&(i.flags&128)===0)return Bn=!1,Dy(e,i,r);Bn=(e.flags&131072)!==0}else Bn=!1,We&&(i.flags&1048576)!==0&&t0(i,Co,i.index);switch(i.lanes=0,i.tag){case 16:t:{var l=i.pendingProps;if(e=Fs(i.elementType),i.type=e,typeof e=="function")_f(e)?(l=ks(e,l),i.tag=1,i=vg(null,i,e,l,r)):(i.tag=0,i=rh(null,i,e,l,r));else{if(e!=null){var f=e.$$typeof;if(f===E){i.tag=11,i=ug(null,i,e,l,r);break t}else if(f===N){i.tag=14,i=fg(null,i,e,l,r);break t}}throw i=X(e)||e,Error(a(306,i,""))}}return i;case 0:return rh(e,i,i.type,i.pendingProps,r);case 1:return l=i.type,f=ks(l,i.pendingProps),vg(e,i,l,f,r);case 3:t:{if(Et(i,i.stateNode.containerInfo),e===null)throw Error(a(387));l=i.pendingProps;var m=i.memoizedState;f=m.element,Nf(e,i),Io(i,l,null,r);var S=i.memoizedState;if(l=S.cache,as(i,zn,l),l!==m.cache&&wf(i,[zn],r,!0),zo(),l=S.element,m.isDehydrated)if(m={element:l,isDehydrated:!1,cache:S.cache},i.updateQueue.baseState=m,i.memoizedState=m,i.flags&256){i=_g(e,i,l,r);break t}else if(l!==f){f=Vi(Error(a(424)),i),Do(f),i=_g(e,i,l,r);break t}else{switch(e=i.stateNode.containerInfo,e.nodeType){case 9:e=e.body;break;default:e=e.nodeName==="HTML"?e.ownerDocument.body:e}for(Mn=Yi(e.firstChild),ni=i,We=!0,ns=null,Wi=!0,r=d0(i,null,l,r),i.child=r;r;)r.flags=r.flags&-3|4096,r=r.sibling}else{if(Ps(),l===f){i=Ca(e,i,r);break t}ai(e,i,l,r)}i=i.child}return i;case 26:return _c(e,i),e===null?(r=Nv(i.type,null,i.pendingProps,null))?i.memoizedState=r:We||(r=i.type,e=i.pendingProps,l=Pc(Bt.current).createElement(r),l[Ze]=i,l[un]=e,si(l,r,e),$e(l),i.stateNode=l):i.memoizedState=Nv(i.type,e.memoizedProps,i.pendingProps,e.memoizedState),null;case 27:return $t(i),e===null&&We&&(l=i.stateNode=Dv(i.type,i.pendingProps,Bt.current),ni=i,Wi=!0,f=Mn,vs(i.type)?(qh=f,Mn=Yi(l.firstChild)):Mn=f),ai(e,i,i.pendingProps.children,r),_c(e,i),e===null&&(i.flags|=4194304),i.child;case 5:return e===null&&We&&((f=l=Mn)&&(l=rS(l,i.type,i.pendingProps,Wi),l!==null?(i.stateNode=l,ni=i,Mn=Yi(l.firstChild),Wi=!1,f=!0):f=!1),f||is(i)),$t(i),f=i.type,m=i.pendingProps,S=e!==null?e.memoizedProps:null,l=m.children,Gh(f,m)?l=null:S!==null&&Gh(f,S)&&(i.flags|=32),i.memoizedState!==null&&(f=Hf(e,i,yy,null,null,r),il._currentValue=f),_c(e,i),ai(e,i,l,r),i.child;case 6:return e===null&&We&&((e=r=Mn)&&(r=oS(r,i.pendingProps,Wi),r!==null?(i.stateNode=r,ni=i,Mn=null,e=!0):e=!1),e||is(i)),null;case 13:return xg(e,i,r);case 4:return Et(i,i.stateNode.containerInfo),l=i.pendingProps,e===null?i.child=Gs(i,null,l,r):ai(e,i,l,r),i.child;case 11:return ug(e,i,i.type,i.pendingProps,r);case 7:return ai(e,i,i.pendingProps,r),i.child;case 8:return ai(e,i,i.pendingProps.children,r),i.child;case 12:return ai(e,i,i.pendingProps.children,r),i.child;case 10:return l=i.pendingProps,as(i,i.type,l.value),ai(e,i,l.children,r),i.child;case 9:return f=i.type._context,l=i.pendingProps.children,Is(i),f=ii(f),l=l(f),i.flags|=1,ai(e,i,l,r),i.child;case 14:return fg(e,i,i.type,i.pendingProps,r);case 15:return hg(e,i,i.type,i.pendingProps,r);case 19:return yg(e,i,r);case 31:return Cy(e,i,r);case 22:return dg(e,i,r,i.pendingProps);case 24:return Is(i),l=ii(zn),e===null?(f=Df(),f===null&&(f=gn,m=Rf(),f.pooledCache=m,m.refCount++,m!==null&&(f.pooledCacheLanes|=r),f=m),i.memoizedState={parent:l,cache:f},Lf(i),as(i,zn,f)):((e.lanes&r)!==0&&(Nf(e,i),Io(i,null,null,r),zo()),f=e.memoizedState,m=i.memoizedState,f.parent!==l?(f={parent:l,cache:l},i.memoizedState=f,i.lanes===0&&(i.memoizedState=i.updateQueue.baseState=f),as(i,zn,l)):(l=m.cache,as(i,zn,l),l!==f.cache&&wf(i,[zn],r,!0))),ai(e,i,i.pendingProps.children,r),i.child;case 29:throw i.pendingProps}throw Error(a(156,i.tag))}function Da(e){e.flags|=4}function ph(e,i,r,l,f){if((i=(e.mode&32)!==0)&&(i=!1),i){if(e.flags|=16777216,(f&335544128)===f)if(e.stateNode.complete)e.flags|=8192;else if(Kg())e.flags|=8192;else throw Hs=ic,Uf}else e.flags&=-16777217}function bg(e,i){if(i.type!=="stylesheet"||(i.state.loading&4)!==0)e.flags&=-16777217;else if(e.flags|=16777216,!Bv(i))if(Kg())e.flags|=8192;else throw Hs=ic,Uf}function Mc(e,i){i!==null&&(e.flags|=4),e.flags&16384&&(i=e.tag!==22?st():536870912,e.lanes|=i,zr|=i)}function ko(e,i){if(!We)switch(e.tailMode){case"hidden":i=e.tail;for(var r=null;i!==null;)i.alternate!==null&&(r=i),i=i.sibling;r===null?e.tail=null:r.sibling=null;break;case"collapsed":r=e.tail;for(var l=null;r!==null;)r.alternate!==null&&(l=r),r=r.sibling;l===null?i||e.tail===null?e.tail=null:e.tail.sibling=null:l.sibling=null}}function yn(e){var i=e.alternate!==null&&e.alternate.child===e.child,r=0,l=0;if(i)for(var f=e.child;f!==null;)r|=f.lanes|f.childLanes,l|=f.subtreeFlags&65011712,l|=f.flags&65011712,f.return=e,f=f.sibling;else for(f=e.child;f!==null;)r|=f.lanes|f.childLanes,l|=f.subtreeFlags,l|=f.flags,f.return=e,f=f.sibling;return e.subtreeFlags|=l,e.childLanes=r,i}function Uy(e,i,r){var l=i.pendingProps;switch(Sf(i),i.tag){case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return yn(i),null;case 1:return yn(i),null;case 3:return r=i.stateNode,l=null,e!==null&&(l=e.memoizedState.cache),i.memoizedState.cache!==l&&(i.flags|=2048),Aa(zn),Ft(),r.pendingContext&&(r.context=r.pendingContext,r.pendingContext=null),(e===null||e.child===null)&&(br(i)?Da(i):e===null||e.memoizedState.isDehydrated&&(i.flags&256)===0||(i.flags|=1024,Ef())),yn(i),null;case 26:var f=i.type,m=i.memoizedState;return e===null?(Da(i),m!==null?(yn(i),bg(i,m)):(yn(i),ph(i,f,null,l,r))):m?m!==e.memoizedState?(Da(i),yn(i),bg(i,m)):(yn(i),i.flags&=-16777217):(e=e.memoizedProps,e!==l&&Da(i),yn(i),ph(i,f,e,l,r)),null;case 27:if(Xt(i),r=Bt.current,f=i.type,e!==null&&i.stateNode!=null)e.memoizedProps!==l&&Da(i);else{if(!l){if(i.stateNode===null)throw Error(a(166));return yn(i),null}e=Ut.current,br(i)?n0(i):(e=Dv(f,l,r),i.stateNode=e,Da(i))}return yn(i),null;case 5:if(Xt(i),f=i.type,e!==null&&i.stateNode!=null)e.memoizedProps!==l&&Da(i);else{if(!l){if(i.stateNode===null)throw Error(a(166));return yn(i),null}if(m=Ut.current,br(i))n0(i);else{var S=Pc(Bt.current);switch(m){case 1:m=S.createElementNS("http://www.w3.org/2000/svg",f);break;case 2:m=S.createElementNS("http://www.w3.org/1998/Math/MathML",f);break;default:switch(f){case"svg":m=S.createElementNS("http://www.w3.org/2000/svg",f);break;case"math":m=S.createElementNS("http://www.w3.org/1998/Math/MathML",f);break;case"script":m=S.createElement("div"),m.innerHTML="<script><\/script>",m=m.removeChild(m.firstChild);break;case"select":m=typeof l.is=="string"?S.createElement("select",{is:l.is}):S.createElement("select"),l.multiple?m.multiple=!0:l.size&&(m.size=l.size);break;default:m=typeof l.is=="string"?S.createElement(f,{is:l.is}):S.createElement(f)}}m[Ze]=i,m[un]=l;t:for(S=i.child;S!==null;){if(S.tag===5||S.tag===6)m.appendChild(S.stateNode);else if(S.tag!==4&&S.tag!==27&&S.child!==null){S.child.return=S,S=S.child;continue}if(S===i)break t;for(;S.sibling===null;){if(S.return===null||S.return===i)break t;S=S.return}S.sibling.return=S.return,S=S.sibling}i.stateNode=m;t:switch(si(m,f,l),f){case"button":case"input":case"select":case"textarea":l=!!l.autoFocus;break t;case"img":l=!0;break t;default:l=!1}l&&Da(i)}}return yn(i),ph(i,i.type,e===null?null:e.memoizedProps,i.pendingProps,r),null;case 6:if(e&&i.stateNode!=null)e.memoizedProps!==l&&Da(i);else{if(typeof l!="string"&&i.stateNode===null)throw Error(a(166));if(e=Bt.current,br(i)){if(e=i.stateNode,r=i.memoizedProps,l=null,f=ni,f!==null)switch(f.tag){case 27:case 5:l=f.memoizedProps}e[Ze]=i,e=!!(e.nodeValue===r||l!==null&&l.suppressHydrationWarning===!0||xv(e.nodeValue,r)),e||is(i,!0)}else e=Pc(e).createTextNode(l),e[Ze]=i,i.stateNode=e}return yn(i),null;case 31:if(r=i.memoizedState,e===null||e.memoizedState!==null){if(l=br(i),r!==null){if(e===null){if(!l)throw Error(a(318));if(e=i.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(a(557));e[Ze]=i}else Ps(),(i.flags&128)===0&&(i.memoizedState=null),i.flags|=4;yn(i),e=!1}else r=Ef(),e!==null&&e.memoizedState!==null&&(e.memoizedState.hydrationErrors=r),e=!0;if(!e)return i.flags&256?(Di(i),i):(Di(i),null);if((i.flags&128)!==0)throw Error(a(558))}return yn(i),null;case 13:if(l=i.memoizedState,e===null||e.memoizedState!==null&&e.memoizedState.dehydrated!==null){if(f=br(i),l!==null&&l.dehydrated!==null){if(e===null){if(!f)throw Error(a(318));if(f=i.memoizedState,f=f!==null?f.dehydrated:null,!f)throw Error(a(317));f[Ze]=i}else Ps(),(i.flags&128)===0&&(i.memoizedState=null),i.flags|=4;yn(i),f=!1}else f=Ef(),e!==null&&e.memoizedState!==null&&(e.memoizedState.hydrationErrors=f),f=!0;if(!f)return i.flags&256?(Di(i),i):(Di(i),null)}return Di(i),(i.flags&128)!==0?(i.lanes=r,i):(r=l!==null,e=e!==null&&e.memoizedState!==null,r&&(l=i.child,f=null,l.alternate!==null&&l.alternate.memoizedState!==null&&l.alternate.memoizedState.cachePool!==null&&(f=l.alternate.memoizedState.cachePool.pool),m=null,l.memoizedState!==null&&l.memoizedState.cachePool!==null&&(m=l.memoizedState.cachePool.pool),m!==f&&(l.flags|=2048)),r!==e&&r&&(i.child.flags|=8192),Mc(i,i.updateQueue),yn(i),null);case 4:return Ft(),e===null&&zh(i.stateNode.containerInfo),yn(i),null;case 10:return Aa(i.type),yn(i),null;case 19:if(ct(Dn),l=i.memoizedState,l===null)return yn(i),null;if(f=(i.flags&128)!==0,m=l.rendering,m===null)if(f)ko(l,!1);else{if(Cn!==0||e!==null&&(e.flags&128)!==0)for(e=i.child;e!==null;){if(m=oc(e),m!==null){for(i.flags|=128,ko(l,!1),e=m.updateQueue,i.updateQueue=e,Mc(i,e),i.subtreeFlags=0,e=r,r=i.child;r!==null;)Qm(r,e),r=r.sibling;return Tt(Dn,Dn.current&1|2),We&&Ea(i,l.treeForkCount),i.child}e=e.sibling}l.tail!==null&&Se()>Tc&&(i.flags|=128,f=!0,ko(l,!1),i.lanes=4194304)}else{if(!f)if(e=oc(m),e!==null){if(i.flags|=128,f=!0,e=e.updateQueue,i.updateQueue=e,Mc(i,e),ko(l,!0),l.tail===null&&l.tailMode==="hidden"&&!m.alternate&&!We)return yn(i),null}else 2*Se()-l.renderingStartTime>Tc&&r!==536870912&&(i.flags|=128,f=!0,ko(l,!1),i.lanes=4194304);l.isBackwards?(m.sibling=i.child,i.child=m):(e=l.last,e!==null?e.sibling=m:i.child=m,l.last=m)}return l.tail!==null?(e=l.tail,l.rendering=e,l.tail=e.sibling,l.renderingStartTime=Se(),e.sibling=null,r=Dn.current,Tt(Dn,f?r&1|2:r&1),We&&Ea(i,l.treeForkCount),e):(yn(i),null);case 22:case 23:return Di(i),If(),l=i.memoizedState!==null,e!==null?e.memoizedState!==null!==l&&(i.flags|=8192):l&&(i.flags|=8192),l?(r&536870912)!==0&&(i.flags&128)===0&&(yn(i),i.subtreeFlags&6&&(i.flags|=8192)):yn(i),r=i.updateQueue,r!==null&&Mc(i,r.retryQueue),r=null,e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(r=e.memoizedState.cachePool.pool),l=null,i.memoizedState!==null&&i.memoizedState.cachePool!==null&&(l=i.memoizedState.cachePool.pool),l!==r&&(i.flags|=2048),e!==null&&ct(Bs),null;case 24:return r=null,e!==null&&(r=e.memoizedState.cache),i.memoizedState.cache!==r&&(i.flags|=2048),Aa(zn),yn(i),null;case 25:return null;case 30:return null}throw Error(a(156,i.tag))}function Ly(e,i){switch(Sf(i),i.tag){case 1:return e=i.flags,e&65536?(i.flags=e&-65537|128,i):null;case 3:return Aa(zn),Ft(),e=i.flags,(e&65536)!==0&&(e&128)===0?(i.flags=e&-65537|128,i):null;case 26:case 27:case 5:return Xt(i),null;case 31:if(i.memoizedState!==null){if(Di(i),i.alternate===null)throw Error(a(340));Ps()}return e=i.flags,e&65536?(i.flags=e&-65537|128,i):null;case 13:if(Di(i),e=i.memoizedState,e!==null&&e.dehydrated!==null){if(i.alternate===null)throw Error(a(340));Ps()}return e=i.flags,e&65536?(i.flags=e&-65537|128,i):null;case 19:return ct(Dn),null;case 4:return Ft(),null;case 10:return Aa(i.type),null;case 22:case 23:return Di(i),If(),e!==null&&ct(Bs),e=i.flags,e&65536?(i.flags=e&-65537|128,i):null;case 24:return Aa(zn),null;case 25:return null;default:return null}}function Eg(e,i){switch(Sf(i),i.tag){case 3:Aa(zn),Ft();break;case 26:case 27:case 5:Xt(i);break;case 4:Ft();break;case 31:i.memoizedState!==null&&Di(i);break;case 13:Di(i);break;case 19:ct(Dn);break;case 10:Aa(i.type);break;case 22:case 23:Di(i),If(),e!==null&&ct(Bs);break;case 24:Aa(zn)}}function Xo(e,i){try{var r=i.updateQueue,l=r!==null?r.lastEffect:null;if(l!==null){var f=l.next;r=f;do{if((r.tag&e)===e){l=void 0;var m=r.create,S=r.inst;l=m(),S.destroy=l}r=r.next}while(r!==f)}}catch(O){rn(i,i.return,O)}}function us(e,i,r){try{var l=i.updateQueue,f=l!==null?l.lastEffect:null;if(f!==null){var m=f.next;l=m;do{if((l.tag&e)===e){var S=l.inst,O=S.destroy;if(O!==void 0){S.destroy=void 0,f=i;var K=r,_t=O;try{_t()}catch(Dt){rn(f,K,Dt)}}}l=l.next}while(l!==m)}}catch(Dt){rn(i,i.return,Dt)}}function Tg(e){var i=e.updateQueue;if(i!==null){var r=e.stateNode;try{m0(i,r)}catch(l){rn(e,e.return,l)}}}function Ag(e,i,r){r.props=ks(e.type,e.memoizedProps),r.state=e.memoizedState;try{r.componentWillUnmount()}catch(l){rn(e,i,l)}}function Wo(e,i){try{var r=e.ref;if(r!==null){switch(e.tag){case 26:case 27:case 5:var l=e.stateNode;break;case 30:l=e.stateNode;break;default:l=e.stateNode}typeof r=="function"?e.refCleanup=r(l):r.current=l}}catch(f){rn(e,i,f)}}function da(e,i){var r=e.ref,l=e.refCleanup;if(r!==null)if(typeof l=="function")try{l()}catch(f){rn(e,i,f)}finally{e.refCleanup=null,e=e.alternate,e!=null&&(e.refCleanup=null)}else if(typeof r=="function")try{r(null)}catch(f){rn(e,i,f)}else r.current=null}function wg(e){var i=e.type,r=e.memoizedProps,l=e.stateNode;try{t:switch(i){case"button":case"input":case"select":case"textarea":r.autoFocus&&l.focus();break t;case"img":r.src?l.src=r.src:r.srcSet&&(l.srcset=r.srcSet)}}catch(f){rn(e,e.return,f)}}function mh(e,i,r){try{var l=e.stateNode;tS(l,e.type,r,i),l[un]=i}catch(f){rn(e,e.return,f)}}function Rg(e){return e.tag===5||e.tag===3||e.tag===26||e.tag===27&&vs(e.type)||e.tag===4}function gh(e){t:for(;;){for(;e.sibling===null;){if(e.return===null||Rg(e.return))return null;e=e.return}for(e.sibling.return=e.return,e=e.sibling;e.tag!==5&&e.tag!==6&&e.tag!==18;){if(e.tag===27&&vs(e.type)||e.flags&2||e.child===null||e.tag===4)continue t;e.child.return=e,e=e.child}if(!(e.flags&2))return e.stateNode}}function vh(e,i,r){var l=e.tag;if(l===5||l===6)e=e.stateNode,i?(r.nodeType===9?r.body:r.nodeName==="HTML"?r.ownerDocument.body:r).insertBefore(e,i):(i=r.nodeType===9?r.body:r.nodeName==="HTML"?r.ownerDocument.body:r,i.appendChild(e),r=r._reactRootContainer,r!=null||i.onclick!==null||(i.onclick=Hi));else if(l!==4&&(l===27&&vs(e.type)&&(r=e.stateNode,i=null),e=e.child,e!==null))for(vh(e,i,r),e=e.sibling;e!==null;)vh(e,i,r),e=e.sibling}function yc(e,i,r){var l=e.tag;if(l===5||l===6)e=e.stateNode,i?r.insertBefore(e,i):r.appendChild(e);else if(l!==4&&(l===27&&vs(e.type)&&(r=e.stateNode),e=e.child,e!==null))for(yc(e,i,r),e=e.sibling;e!==null;)yc(e,i,r),e=e.sibling}function Cg(e){var i=e.stateNode,r=e.memoizedProps;try{for(var l=e.type,f=i.attributes;f.length;)i.removeAttributeNode(f[0]);si(i,l,r),i[Ze]=e,i[un]=r}catch(m){rn(e,e.return,m)}}var Ua=!1,Fn=!1,_h=!1,Dg=typeof WeakSet=="function"?WeakSet:Set,Kn=null;function Ny(e,i){if(e=e.containerInfo,Fh=Vc,e=Vm(e),ff(e)){if("selectionStart"in e)var r={start:e.selectionStart,end:e.selectionEnd};else t:{r=(r=e.ownerDocument)&&r.defaultView||window;var l=r.getSelection&&r.getSelection();if(l&&l.rangeCount!==0){r=l.anchorNode;var f=l.anchorOffset,m=l.focusNode;l=l.focusOffset;try{r.nodeType,m.nodeType}catch{r=null;break t}var S=0,O=-1,K=-1,_t=0,Dt=0,Pt=e,St=null;e:for(;;){for(var At;Pt!==r||f!==0&&Pt.nodeType!==3||(O=S+f),Pt!==m||l!==0&&Pt.nodeType!==3||(K=S+l),Pt.nodeType===3&&(S+=Pt.nodeValue.length),(At=Pt.firstChild)!==null;)St=Pt,Pt=At;for(;;){if(Pt===e)break e;if(St===r&&++_t===f&&(O=S),St===m&&++Dt===l&&(K=S),(At=Pt.nextSibling)!==null)break;Pt=St,St=Pt.parentNode}Pt=At}r=O===-1||K===-1?null:{start:O,end:K}}else r=null}r=r||{start:0,end:0}}else r=null;for(Hh={focusedElem:e,selectionRange:r},Vc=!1,Kn=i;Kn!==null;)if(i=Kn,e=i.child,(i.subtreeFlags&1028)!==0&&e!==null)e.return=i,Kn=e;else for(;Kn!==null;){switch(i=Kn,m=i.alternate,e=i.flags,i.tag){case 0:if((e&4)!==0&&(e=i.updateQueue,e=e!==null?e.events:null,e!==null))for(r=0;r<e.length;r++)f=e[r],f.ref.impl=f.nextImpl;break;case 11:case 15:break;case 1:if((e&1024)!==0&&m!==null){e=void 0,r=i,f=m.memoizedProps,m=m.memoizedState,l=r.stateNode;try{var ne=ks(r.type,f);e=l.getSnapshotBeforeUpdate(ne,m),l.__reactInternalSnapshotBeforeUpdate=e}catch(_e){rn(r,r.return,_e)}}break;case 3:if((e&1024)!==0){if(e=i.stateNode.containerInfo,r=e.nodeType,r===9)kh(e);else if(r===1)switch(e.nodeName){case"HEAD":case"HTML":case"BODY":kh(e);break;default:e.textContent=""}}break;case 5:case 26:case 27:case 6:case 4:case 17:break;default:if((e&1024)!==0)throw Error(a(163))}if(e=i.sibling,e!==null){e.return=i.return,Kn=e;break}Kn=i.return}}function Ug(e,i,r){var l=r.flags;switch(r.tag){case 0:case 11:case 15:Na(e,r),l&4&&Xo(5,r);break;case 1:if(Na(e,r),l&4)if(e=r.stateNode,i===null)try{e.componentDidMount()}catch(S){rn(r,r.return,S)}else{var f=ks(r.type,i.memoizedProps);i=i.memoizedState;try{e.componentDidUpdate(f,i,e.__reactInternalSnapshotBeforeUpdate)}catch(S){rn(r,r.return,S)}}l&64&&Tg(r),l&512&&Wo(r,r.return);break;case 3:if(Na(e,r),l&64&&(e=r.updateQueue,e!==null)){if(i=null,r.child!==null)switch(r.child.tag){case 27:case 5:i=r.child.stateNode;break;case 1:i=r.child.stateNode}try{m0(e,i)}catch(S){rn(r,r.return,S)}}break;case 27:i===null&&l&4&&Cg(r);case 26:case 5:Na(e,r),i===null&&l&4&&wg(r),l&512&&Wo(r,r.return);break;case 12:Na(e,r);break;case 31:Na(e,r),l&4&&Og(e,r);break;case 13:Na(e,r),l&4&&Pg(e,r),l&64&&(e=r.memoizedState,e!==null&&(e=e.dehydrated,e!==null&&(r=Vy.bind(null,r),lS(e,r))));break;case 22:if(l=r.memoizedState!==null||Ua,!l){i=i!==null&&i.memoizedState!==null||Fn,f=Ua;var m=Fn;Ua=l,(Fn=i)&&!m?Oa(e,r,(r.subtreeFlags&8772)!==0):Na(e,r),Ua=f,Fn=m}break;case 30:break;default:Na(e,r)}}function Lg(e){var i=e.alternate;i!==null&&(e.alternate=null,Lg(i)),e.child=null,e.deletions=null,e.sibling=null,e.tag===5&&(i=e.stateNode,i!==null&&fe(i)),e.stateNode=null,e.return=null,e.dependencies=null,e.memoizedProps=null,e.memoizedState=null,e.pendingProps=null,e.stateNode=null,e.updateQueue=null}var En=null,xi=!1;function La(e,i,r){for(r=r.child;r!==null;)Ng(e,i,r),r=r.sibling}function Ng(e,i,r){if(xt&&typeof xt.onCommitFiberUnmount=="function")try{xt.onCommitFiberUnmount(yt,r)}catch{}switch(r.tag){case 26:Fn||da(r,i),La(e,i,r),r.memoizedState?r.memoizedState.count--:r.stateNode&&(r=r.stateNode,r.parentNode.removeChild(r));break;case 27:Fn||da(r,i);var l=En,f=xi;vs(r.type)&&(En=r.stateNode,xi=!1),La(e,i,r),tl(r.stateNode),En=l,xi=f;break;case 5:Fn||da(r,i);case 6:if(l=En,f=xi,En=null,La(e,i,r),En=l,xi=f,En!==null)if(xi)try{(En.nodeType===9?En.body:En.nodeName==="HTML"?En.ownerDocument.body:En).removeChild(r.stateNode)}catch(m){rn(r,i,m)}else try{En.removeChild(r.stateNode)}catch(m){rn(r,i,m)}break;case 18:En!==null&&(xi?(e=En,Tv(e.nodeType===9?e.body:e.nodeName==="HTML"?e.ownerDocument.body:e,r.stateNode),Xr(e)):Tv(En,r.stateNode));break;case 4:l=En,f=xi,En=r.stateNode.containerInfo,xi=!0,La(e,i,r),En=l,xi=f;break;case 0:case 11:case 14:case 15:us(2,r,i),Fn||us(4,r,i),La(e,i,r);break;case 1:Fn||(da(r,i),l=r.stateNode,typeof l.componentWillUnmount=="function"&&Ag(r,i,l)),La(e,i,r);break;case 21:La(e,i,r);break;case 22:Fn=(l=Fn)||r.memoizedState!==null,La(e,i,r),Fn=l;break;default:La(e,i,r)}}function Og(e,i){if(i.memoizedState===null&&(e=i.alternate,e!==null&&(e=e.memoizedState,e!==null))){e=e.dehydrated;try{Xr(e)}catch(r){rn(i,i.return,r)}}}function Pg(e,i){if(i.memoizedState===null&&(e=i.alternate,e!==null&&(e=e.memoizedState,e!==null&&(e=e.dehydrated,e!==null))))try{Xr(e)}catch(r){rn(i,i.return,r)}}function Oy(e){switch(e.tag){case 31:case 13:case 19:var i=e.stateNode;return i===null&&(i=e.stateNode=new Dg),i;case 22:return e=e.stateNode,i=e._retryCache,i===null&&(i=e._retryCache=new Dg),i;default:throw Error(a(435,e.tag))}}function Sc(e,i){var r=Oy(e);i.forEach(function(l){if(!r.has(l)){r.add(l);var f=ky.bind(null,e,l);l.then(f,f)}})}function Mi(e,i){var r=i.deletions;if(r!==null)for(var l=0;l<r.length;l++){var f=r[l],m=e,S=i,O=S;t:for(;O!==null;){switch(O.tag){case 27:if(vs(O.type)){En=O.stateNode,xi=!1;break t}break;case 5:En=O.stateNode,xi=!1;break t;case 3:case 4:En=O.stateNode.containerInfo,xi=!0;break t}O=O.return}if(En===null)throw Error(a(160));Ng(m,S,f),En=null,xi=!1,m=f.alternate,m!==null&&(m.return=null),f.return=null}if(i.subtreeFlags&13886)for(i=i.child;i!==null;)zg(i,e),i=i.sibling}var ea=null;function zg(e,i){var r=e.alternate,l=e.flags;switch(e.tag){case 0:case 11:case 14:case 15:Mi(i,e),yi(e),l&4&&(us(3,e,e.return),Xo(3,e),us(5,e,e.return));break;case 1:Mi(i,e),yi(e),l&512&&(Fn||r===null||da(r,r.return)),l&64&&Ua&&(e=e.updateQueue,e!==null&&(l=e.callbacks,l!==null&&(r=e.shared.hiddenCallbacks,e.shared.hiddenCallbacks=r===null?l:r.concat(l))));break;case 26:var f=ea;if(Mi(i,e),yi(e),l&512&&(Fn||r===null||da(r,r.return)),l&4){var m=r!==null?r.memoizedState:null;if(l=e.memoizedState,r===null)if(l===null)if(e.stateNode===null){t:{l=e.type,r=e.memoizedProps,f=f.ownerDocument||f;e:switch(l){case"title":m=f.getElementsByTagName("title")[0],(!m||m[ue]||m[Ze]||m.namespaceURI==="http://www.w3.org/2000/svg"||m.hasAttribute("itemprop"))&&(m=f.createElement(l),f.head.insertBefore(m,f.querySelector("head > title"))),si(m,l,r),m[Ze]=e,$e(m),l=m;break t;case"link":var S=zv("link","href",f).get(l+(r.href||""));if(S){for(var O=0;O<S.length;O++)if(m=S[O],m.getAttribute("href")===(r.href==null||r.href===""?null:r.href)&&m.getAttribute("rel")===(r.rel==null?null:r.rel)&&m.getAttribute("title")===(r.title==null?null:r.title)&&m.getAttribute("crossorigin")===(r.crossOrigin==null?null:r.crossOrigin)){S.splice(O,1);break e}}m=f.createElement(l),si(m,l,r),f.head.appendChild(m);break;case"meta":if(S=zv("meta","content",f).get(l+(r.content||""))){for(O=0;O<S.length;O++)if(m=S[O],m.getAttribute("content")===(r.content==null?null:""+r.content)&&m.getAttribute("name")===(r.name==null?null:r.name)&&m.getAttribute("property")===(r.property==null?null:r.property)&&m.getAttribute("http-equiv")===(r.httpEquiv==null?null:r.httpEquiv)&&m.getAttribute("charset")===(r.charSet==null?null:r.charSet)){S.splice(O,1);break e}}m=f.createElement(l),si(m,l,r),f.head.appendChild(m);break;default:throw Error(a(468,l))}m[Ze]=e,$e(m),l=m}e.stateNode=l}else Iv(f,e.type,e.stateNode);else e.stateNode=Pv(f,l,e.memoizedProps);else m!==l?(m===null?r.stateNode!==null&&(r=r.stateNode,r.parentNode.removeChild(r)):m.count--,l===null?Iv(f,e.type,e.stateNode):Pv(f,l,e.memoizedProps)):l===null&&e.stateNode!==null&&mh(e,e.memoizedProps,r.memoizedProps)}break;case 27:Mi(i,e),yi(e),l&512&&(Fn||r===null||da(r,r.return)),r!==null&&l&4&&mh(e,e.memoizedProps,r.memoizedProps);break;case 5:if(Mi(i,e),yi(e),l&512&&(Fn||r===null||da(r,r.return)),e.flags&32){f=e.stateNode;try{di(f,"")}catch(ne){rn(e,e.return,ne)}}l&4&&e.stateNode!=null&&(f=e.memoizedProps,mh(e,f,r!==null?r.memoizedProps:f)),l&1024&&(_h=!0);break;case 6:if(Mi(i,e),yi(e),l&4){if(e.stateNode===null)throw Error(a(162));l=e.memoizedProps,r=e.stateNode;try{r.nodeValue=l}catch(ne){rn(e,e.return,ne)}}break;case 3:if(Bc=null,f=ea,ea=zc(i.containerInfo),Mi(i,e),ea=f,yi(e),l&4&&r!==null&&r.memoizedState.isDehydrated)try{Xr(i.containerInfo)}catch(ne){rn(e,e.return,ne)}_h&&(_h=!1,Ig(e));break;case 4:l=ea,ea=zc(e.stateNode.containerInfo),Mi(i,e),yi(e),ea=l;break;case 12:Mi(i,e),yi(e);break;case 31:Mi(i,e),yi(e),l&4&&(l=e.updateQueue,l!==null&&(e.updateQueue=null,Sc(e,l)));break;case 13:Mi(i,e),yi(e),e.child.flags&8192&&e.memoizedState!==null!=(r!==null&&r.memoizedState!==null)&&(Ec=Se()),l&4&&(l=e.updateQueue,l!==null&&(e.updateQueue=null,Sc(e,l)));break;case 22:f=e.memoizedState!==null;var K=r!==null&&r.memoizedState!==null,_t=Ua,Dt=Fn;if(Ua=_t||f,Fn=Dt||K,Mi(i,e),Fn=Dt,Ua=_t,yi(e),l&8192)t:for(i=e.stateNode,i._visibility=f?i._visibility&-2:i._visibility|1,f&&(r===null||K||Ua||Fn||Xs(e)),r=null,i=e;;){if(i.tag===5||i.tag===26){if(r===null){K=r=i;try{if(m=K.stateNode,f)S=m.style,typeof S.setProperty=="function"?S.setProperty("display","none","important"):S.display="none";else{O=K.stateNode;var Pt=K.memoizedProps.style,St=Pt!=null&&Pt.hasOwnProperty("display")?Pt.display:null;O.style.display=St==null||typeof St=="boolean"?"":(""+St).trim()}}catch(ne){rn(K,K.return,ne)}}}else if(i.tag===6){if(r===null){K=i;try{K.stateNode.nodeValue=f?"":K.memoizedProps}catch(ne){rn(K,K.return,ne)}}}else if(i.tag===18){if(r===null){K=i;try{var At=K.stateNode;f?Av(At,!0):Av(K.stateNode,!1)}catch(ne){rn(K,K.return,ne)}}}else if((i.tag!==22&&i.tag!==23||i.memoizedState===null||i===e)&&i.child!==null){i.child.return=i,i=i.child;continue}if(i===e)break t;for(;i.sibling===null;){if(i.return===null||i.return===e)break t;r===i&&(r=null),i=i.return}r===i&&(r=null),i.sibling.return=i.return,i=i.sibling}l&4&&(l=e.updateQueue,l!==null&&(r=l.retryQueue,r!==null&&(l.retryQueue=null,Sc(e,r))));break;case 19:Mi(i,e),yi(e),l&4&&(l=e.updateQueue,l!==null&&(e.updateQueue=null,Sc(e,l)));break;case 30:break;case 21:break;default:Mi(i,e),yi(e)}}function yi(e){var i=e.flags;if(i&2){try{for(var r,l=e.return;l!==null;){if(Rg(l)){r=l;break}l=l.return}if(r==null)throw Error(a(160));switch(r.tag){case 27:var f=r.stateNode,m=gh(e);yc(e,m,f);break;case 5:var S=r.stateNode;r.flags&32&&(di(S,""),r.flags&=-33);var O=gh(e);yc(e,O,S);break;case 3:case 4:var K=r.stateNode.containerInfo,_t=gh(e);vh(e,_t,K);break;default:throw Error(a(161))}}catch(Dt){rn(e,e.return,Dt)}e.flags&=-3}i&4096&&(e.flags&=-4097)}function Ig(e){if(e.subtreeFlags&1024)for(e=e.child;e!==null;){var i=e;Ig(i),i.tag===5&&i.flags&1024&&i.stateNode.reset(),e=e.sibling}}function Na(e,i){if(i.subtreeFlags&8772)for(i=i.child;i!==null;)Ug(e,i.alternate,i),i=i.sibling}function Xs(e){for(e=e.child;e!==null;){var i=e;switch(i.tag){case 0:case 11:case 14:case 15:us(4,i,i.return),Xs(i);break;case 1:da(i,i.return);var r=i.stateNode;typeof r.componentWillUnmount=="function"&&Ag(i,i.return,r),Xs(i);break;case 27:tl(i.stateNode);case 26:case 5:da(i,i.return),Xs(i);break;case 22:i.memoizedState===null&&Xs(i);break;case 30:Xs(i);break;default:Xs(i)}e=e.sibling}}function Oa(e,i,r){for(r=r&&(i.subtreeFlags&8772)!==0,i=i.child;i!==null;){var l=i.alternate,f=e,m=i,S=m.flags;switch(m.tag){case 0:case 11:case 15:Oa(f,m,r),Xo(4,m);break;case 1:if(Oa(f,m,r),l=m,f=l.stateNode,typeof f.componentDidMount=="function")try{f.componentDidMount()}catch(_t){rn(l,l.return,_t)}if(l=m,f=l.updateQueue,f!==null){var O=l.stateNode;try{var K=f.shared.hiddenCallbacks;if(K!==null)for(f.shared.hiddenCallbacks=null,f=0;f<K.length;f++)p0(K[f],O)}catch(_t){rn(l,l.return,_t)}}r&&S&64&&Tg(m),Wo(m,m.return);break;case 27:Cg(m);case 26:case 5:Oa(f,m,r),r&&l===null&&S&4&&wg(m),Wo(m,m.return);break;case 12:Oa(f,m,r);break;case 31:Oa(f,m,r),r&&S&4&&Og(f,m);break;case 13:Oa(f,m,r),r&&S&4&&Pg(f,m);break;case 22:m.memoizedState===null&&Oa(f,m,r),Wo(m,m.return);break;case 30:break;default:Oa(f,m,r)}i=i.sibling}}function xh(e,i){var r=null;e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(r=e.memoizedState.cachePool.pool),e=null,i.memoizedState!==null&&i.memoizedState.cachePool!==null&&(e=i.memoizedState.cachePool.pool),e!==r&&(e!=null&&e.refCount++,r!=null&&Uo(r))}function Mh(e,i){e=null,i.alternate!==null&&(e=i.alternate.memoizedState.cache),i=i.memoizedState.cache,i!==e&&(i.refCount++,e!=null&&Uo(e))}function na(e,i,r,l){if(i.subtreeFlags&10256)for(i=i.child;i!==null;)Bg(e,i,r,l),i=i.sibling}function Bg(e,i,r,l){var f=i.flags;switch(i.tag){case 0:case 11:case 15:na(e,i,r,l),f&2048&&Xo(9,i);break;case 1:na(e,i,r,l);break;case 3:na(e,i,r,l),f&2048&&(e=null,i.alternate!==null&&(e=i.alternate.memoizedState.cache),i=i.memoizedState.cache,i!==e&&(i.refCount++,e!=null&&Uo(e)));break;case 12:if(f&2048){na(e,i,r,l),e=i.stateNode;try{var m=i.memoizedProps,S=m.id,O=m.onPostCommit;typeof O=="function"&&O(S,i.alternate===null?"mount":"update",e.passiveEffectDuration,-0)}catch(K){rn(i,i.return,K)}}else na(e,i,r,l);break;case 31:na(e,i,r,l);break;case 13:na(e,i,r,l);break;case 23:break;case 22:m=i.stateNode,S=i.alternate,i.memoizedState!==null?m._visibility&2?na(e,i,r,l):qo(e,i):m._visibility&2?na(e,i,r,l):(m._visibility|=2,Nr(e,i,r,l,(i.subtreeFlags&10256)!==0||!1)),f&2048&&xh(S,i);break;case 24:na(e,i,r,l),f&2048&&Mh(i.alternate,i);break;default:na(e,i,r,l)}}function Nr(e,i,r,l,f){for(f=f&&((i.subtreeFlags&10256)!==0||!1),i=i.child;i!==null;){var m=e,S=i,O=r,K=l,_t=S.flags;switch(S.tag){case 0:case 11:case 15:Nr(m,S,O,K,f),Xo(8,S);break;case 23:break;case 22:var Dt=S.stateNode;S.memoizedState!==null?Dt._visibility&2?Nr(m,S,O,K,f):qo(m,S):(Dt._visibility|=2,Nr(m,S,O,K,f)),f&&_t&2048&&xh(S.alternate,S);break;case 24:Nr(m,S,O,K,f),f&&_t&2048&&Mh(S.alternate,S);break;default:Nr(m,S,O,K,f)}i=i.sibling}}function qo(e,i){if(i.subtreeFlags&10256)for(i=i.child;i!==null;){var r=e,l=i,f=l.flags;switch(l.tag){case 22:qo(r,l),f&2048&&xh(l.alternate,l);break;case 24:qo(r,l),f&2048&&Mh(l.alternate,l);break;default:qo(r,l)}i=i.sibling}}var Yo=8192;function Or(e,i,r){if(e.subtreeFlags&Yo)for(e=e.child;e!==null;)Fg(e,i,r),e=e.sibling}function Fg(e,i,r){switch(e.tag){case 26:Or(e,i,r),e.flags&Yo&&e.memoizedState!==null&&MS(r,ea,e.memoizedState,e.memoizedProps);break;case 5:Or(e,i,r);break;case 3:case 4:var l=ea;ea=zc(e.stateNode.containerInfo),Or(e,i,r),ea=l;break;case 22:e.memoizedState===null&&(l=e.alternate,l!==null&&l.memoizedState!==null?(l=Yo,Yo=16777216,Or(e,i,r),Yo=l):Or(e,i,r));break;default:Or(e,i,r)}}function Hg(e){var i=e.alternate;if(i!==null&&(e=i.child,e!==null)){i.child=null;do i=e.sibling,e.sibling=null,e=i;while(e!==null)}}function Zo(e){var i=e.deletions;if((e.flags&16)!==0){if(i!==null)for(var r=0;r<i.length;r++){var l=i[r];Kn=l,Vg(l,e)}Hg(e)}if(e.subtreeFlags&10256)for(e=e.child;e!==null;)Gg(e),e=e.sibling}function Gg(e){switch(e.tag){case 0:case 11:case 15:Zo(e),e.flags&2048&&us(9,e,e.return);break;case 3:Zo(e);break;case 12:Zo(e);break;case 22:var i=e.stateNode;e.memoizedState!==null&&i._visibility&2&&(e.return===null||e.return.tag!==13)?(i._visibility&=-3,bc(e)):Zo(e);break;default:Zo(e)}}function bc(e){var i=e.deletions;if((e.flags&16)!==0){if(i!==null)for(var r=0;r<i.length;r++){var l=i[r];Kn=l,Vg(l,e)}Hg(e)}for(e=e.child;e!==null;){switch(i=e,i.tag){case 0:case 11:case 15:us(8,i,i.return),bc(i);break;case 22:r=i.stateNode,r._visibility&2&&(r._visibility&=-3,bc(i));break;default:bc(i)}e=e.sibling}}function Vg(e,i){for(;Kn!==null;){var r=Kn;switch(r.tag){case 0:case 11:case 15:us(8,r,i);break;case 23:case 22:if(r.memoizedState!==null&&r.memoizedState.cachePool!==null){var l=r.memoizedState.cachePool.pool;l!=null&&l.refCount++}break;case 24:Uo(r.memoizedState.cache)}if(l=r.child,l!==null)l.return=r,Kn=l;else t:for(r=e;Kn!==null;){l=Kn;var f=l.sibling,m=l.return;if(Lg(l),l===r){Kn=null;break t}if(f!==null){f.return=m,Kn=f;break t}Kn=m}}}var Py={getCacheForType:function(e){var i=ii(zn),r=i.data.get(e);return r===void 0&&(r=e(),i.data.set(e,r)),r},cacheSignal:function(){return ii(zn).controller.signal}},zy=typeof WeakMap=="function"?WeakMap:Map,en=0,gn=null,He=null,Ve=0,sn=0,Ui=null,fs=!1,Pr=!1,yh=!1,Pa=0,Cn=0,hs=0,Ws=0,Sh=0,Li=0,zr=0,Ko=null,Si=null,bh=!1,Ec=0,kg=0,Tc=1/0,Ac=null,ds=null,Xn=0,ps=null,Ir=null,za=0,Eh=0,Th=null,Xg=null,Jo=0,Ah=null;function Ni(){return(en&2)!==0&&Ve!==0?Ve&-Ve:H.T!==null?Lh():Gn()}function Wg(){if(Li===0)if((Ve&536870912)===0||We){var e=at;at<<=1,(at&3932160)===0&&(at=262144),Li=e}else Li=536870912;return e=Ci.current,e!==null&&(e.flags|=32),Li}function bi(e,i,r){(e===gn&&(sn===2||sn===9)||e.cancelPendingCommit!==null)&&(Br(e,0),ms(e,Ve,Li,!1)),It(e,r),((en&2)===0||e!==gn)&&(e===gn&&((en&2)===0&&(Ws|=r),Cn===4&&ms(e,Ve,Li,!1)),pa(e))}function qg(e,i,r){if((en&6)!==0)throw Error(a(327));var l=!r&&(i&127)===0&&(i&e.expiredLanes)===0||nt(e,i),f=l?Fy(e,i):Rh(e,i,!0),m=l;do{if(f===0){Pr&&!l&&ms(e,i,0,!1);break}else{if(r=e.current.alternate,m&&!Iy(r)){f=Rh(e,i,!1),m=!1;continue}if(f===2){if(m=i,e.errorRecoveryDisabledLanes&m)var S=0;else S=e.pendingLanes&-536870913,S=S!==0?S:S&536870912?536870912:0;if(S!==0){i=S;t:{var O=e;f=Ko;var K=O.current.memoizedState.isDehydrated;if(K&&(Br(O,S).flags|=256),S=Rh(O,S,!1),S!==2){if(yh&&!K){O.errorRecoveryDisabledLanes|=m,Ws|=m,f=4;break t}m=Si,Si=f,m!==null&&(Si===null?Si=m:Si.push.apply(Si,m))}f=S}if(m=!1,f!==2)continue}}if(f===1){Br(e,0),ms(e,i,0,!0);break}t:{switch(l=e,m=f,m){case 0:case 1:throw Error(a(345));case 4:if((i&4194048)!==i)break;case 6:ms(l,i,Li,!fs);break t;case 2:Si=null;break;case 3:case 5:break;default:throw Error(a(329))}if((i&62914560)===i&&(f=Ec+300-Se(),10<f)){if(ms(l,i,Li,!fs),V(l,0,!0)!==0)break t;za=i,l.timeoutHandle=bv(Yg.bind(null,l,r,Si,Ac,bh,i,Li,Ws,zr,fs,m,"Throttled",-0,0),f);break t}Yg(l,r,Si,Ac,bh,i,Li,Ws,zr,fs,m,null,-0,0)}}break}while(!0);pa(e)}function Yg(e,i,r,l,f,m,S,O,K,_t,Dt,Pt,St,At){if(e.timeoutHandle=-1,Pt=i.subtreeFlags,Pt&8192||(Pt&16785408)===16785408){Pt={stylesheets:null,count:0,imgCount:0,imgBytes:0,suspenseyImages:[],waitingForImages:!0,waitingForViewTransition:!1,unsuspend:Hi},Fg(i,m,Pt);var ne=(m&62914560)===m?Ec-Se():(m&4194048)===m?kg-Se():0;if(ne=yS(Pt,ne),ne!==null){za=m,e.cancelPendingCommit=ne(ev.bind(null,e,i,m,r,l,f,S,O,K,Dt,Pt,null,St,At)),ms(e,m,S,!_t);return}}ev(e,i,m,r,l,f,S,O,K)}function Iy(e){for(var i=e;;){var r=i.tag;if((r===0||r===11||r===15)&&i.flags&16384&&(r=i.updateQueue,r!==null&&(r=r.stores,r!==null)))for(var l=0;l<r.length;l++){var f=r[l],m=f.getSnapshot;f=f.value;try{if(!wi(m(),f))return!1}catch{return!1}}if(r=i.child,i.subtreeFlags&16384&&r!==null)r.return=i,i=r;else{if(i===e)break;for(;i.sibling===null;){if(i.return===null||i.return===e)return!0;i=i.return}i.sibling.return=i.return,i=i.sibling}}return!0}function ms(e,i,r,l){i&=~Sh,i&=~Ws,e.suspendedLanes|=i,e.pingedLanes&=~i,l&&(e.warmLanes|=i),l=e.expirationTimes;for(var f=i;0<f;){var m=31-gt(f),S=1<<m;l[m]=-1,f&=~S}r!==0&&se(e,r,i)}function wc(){return(en&6)===0?(Qo(0),!1):!0}function wh(){if(He!==null){if(sn===0)var e=He.return;else e=He,Ta=zs=null,kf(e),Rr=null,No=0,e=He;for(;e!==null;)Eg(e.alternate,e),e=e.return;He=null}}function Br(e,i){var r=e.timeoutHandle;r!==-1&&(e.timeoutHandle=-1,iS(r)),r=e.cancelPendingCommit,r!==null&&(e.cancelPendingCommit=null,r()),za=0,wh(),gn=e,He=r=ba(e.current,null),Ve=i,sn=0,Ui=null,fs=!1,Pr=nt(e,i),yh=!1,zr=Li=Sh=Ws=hs=Cn=0,Si=Ko=null,bh=!1,(i&8)!==0&&(i|=i&32);var l=e.entangledLanes;if(l!==0)for(e=e.entanglements,l&=i;0<l;){var f=31-gt(l),m=1<<f;i|=e[f],l&=~m}return Pa=i,Zl(),r}function Zg(e,i){De=null,H.H=Go,i===wr||i===nc?(i=u0(),sn=3):i===Uf?(i=u0(),sn=4):sn=i===sh?8:i!==null&&typeof i=="object"&&typeof i.then=="function"?6:1,Ui=i,He===null&&(Cn=1,gc(e,Vi(i,e.current)))}function Kg(){var e=Ci.current;return e===null?!0:(Ve&4194048)===Ve?qi===null:(Ve&62914560)===Ve||(Ve&536870912)!==0?e===qi:!1}function Jg(){var e=H.H;return H.H=Go,e===null?Go:e}function Qg(){var e=H.A;return H.A=Py,e}function Rc(){Cn=4,fs||(Ve&4194048)!==Ve&&Ci.current!==null||(Pr=!0),(hs&134217727)===0&&(Ws&134217727)===0||gn===null||ms(gn,Ve,Li,!1)}function Rh(e,i,r){var l=en;en|=2;var f=Jg(),m=Qg();(gn!==e||Ve!==i)&&(Ac=null,Br(e,i)),i=!1;var S=Cn;t:do try{if(sn!==0&&He!==null){var O=He,K=Ui;switch(sn){case 8:wh(),S=6;break t;case 3:case 2:case 9:case 6:Ci.current===null&&(i=!0);var _t=sn;if(sn=0,Ui=null,Fr(e,O,K,_t),r&&Pr){S=0;break t}break;default:_t=sn,sn=0,Ui=null,Fr(e,O,K,_t)}}By(),S=Cn;break}catch(Dt){Zg(e,Dt)}while(!0);return i&&e.shellSuspendCounter++,Ta=zs=null,en=l,H.H=f,H.A=m,He===null&&(gn=null,Ve=0,Zl()),S}function By(){for(;He!==null;)jg(He)}function Fy(e,i){var r=en;en|=2;var l=Jg(),f=Qg();gn!==e||Ve!==i?(Ac=null,Tc=Se()+500,Br(e,i)):Pr=nt(e,i);t:do try{if(sn!==0&&He!==null){i=He;var m=Ui;e:switch(sn){case 1:sn=0,Ui=null,Fr(e,i,m,1);break;case 2:case 9:if(l0(m)){sn=0,Ui=null,$g(i);break}i=function(){sn!==2&&sn!==9||gn!==e||(sn=7),pa(e)},m.then(i,i);break t;case 3:sn=7;break t;case 4:sn=5;break t;case 7:l0(m)?(sn=0,Ui=null,$g(i)):(sn=0,Ui=null,Fr(e,i,m,7));break;case 5:var S=null;switch(He.tag){case 26:S=He.memoizedState;case 5:case 27:var O=He;if(S?Bv(S):O.stateNode.complete){sn=0,Ui=null;var K=O.sibling;if(K!==null)He=K;else{var _t=O.return;_t!==null?(He=_t,Cc(_t)):He=null}break e}}sn=0,Ui=null,Fr(e,i,m,5);break;case 6:sn=0,Ui=null,Fr(e,i,m,6);break;case 8:wh(),Cn=6;break t;default:throw Error(a(462))}}Hy();break}catch(Dt){Zg(e,Dt)}while(!0);return Ta=zs=null,H.H=l,H.A=f,en=r,He!==null?0:(gn=null,Ve=0,Zl(),Cn)}function Hy(){for(;He!==null&&!Ue();)jg(He)}function jg(e){var i=Sg(e.alternate,e,Pa);e.memoizedProps=e.pendingProps,i===null?Cc(e):He=i}function $g(e){var i=e,r=i.alternate;switch(i.tag){case 15:case 0:i=gg(r,i,i.pendingProps,i.type,void 0,Ve);break;case 11:i=gg(r,i,i.pendingProps,i.type.render,i.ref,Ve);break;case 5:kf(i);default:Eg(r,i),i=He=Qm(i,Pa),i=Sg(r,i,Pa)}e.memoizedProps=e.pendingProps,i===null?Cc(e):He=i}function Fr(e,i,r,l){Ta=zs=null,kf(i),Rr=null,No=0;var f=i.return;try{if(Ry(e,f,i,r,Ve)){Cn=1,gc(e,Vi(r,e.current)),He=null;return}}catch(m){if(f!==null)throw He=f,m;Cn=1,gc(e,Vi(r,e.current)),He=null;return}i.flags&32768?(We||l===1?e=!0:Pr||(Ve&536870912)!==0?e=!1:(fs=e=!0,(l===2||l===9||l===3||l===6)&&(l=Ci.current,l!==null&&l.tag===13&&(l.flags|=16384))),tv(i,e)):Cc(i)}function Cc(e){var i=e;do{if((i.flags&32768)!==0){tv(i,fs);return}e=i.return;var r=Uy(i.alternate,i,Pa);if(r!==null){He=r;return}if(i=i.sibling,i!==null){He=i;return}He=i=e}while(i!==null);Cn===0&&(Cn=5)}function tv(e,i){do{var r=Ly(e.alternate,e);if(r!==null){r.flags&=32767,He=r;return}if(r=e.return,r!==null&&(r.flags|=32768,r.subtreeFlags=0,r.deletions=null),!i&&(e=e.sibling,e!==null)){He=e;return}He=e=r}while(e!==null);Cn=6,He=null}function ev(e,i,r,l,f,m,S,O,K){e.cancelPendingCommit=null;do Dc();while(Xn!==0);if((en&6)!==0)throw Error(a(327));if(i!==null){if(i===e.current)throw Error(a(177));if(m=i.lanes|i.childLanes,m|=gf,te(e,r,m,S,O,K),e===gn&&(He=gn=null,Ve=0),Ir=i,ps=e,za=r,Eh=m,Th=f,Xg=l,(i.subtreeFlags&10256)!==0||(i.flags&10256)!==0?(e.callbackNode=null,e.callbackPriority=0,Xy(et,function(){return rv(),null})):(e.callbackNode=null,e.callbackPriority=0),l=(i.flags&13878)!==0,(i.subtreeFlags&13878)!==0||l){l=H.T,H.T=null,f=Y.p,Y.p=2,S=en,en|=4;try{Ny(e,i,r)}finally{en=S,Y.p=f,H.T=l}}Xn=1,nv(),iv(),av()}}function nv(){if(Xn===1){Xn=0;var e=ps,i=Ir,r=(i.flags&13878)!==0;if((i.subtreeFlags&13878)!==0||r){r=H.T,H.T=null;var l=Y.p;Y.p=2;var f=en;en|=4;try{zg(i,e);var m=Hh,S=Vm(e.containerInfo),O=m.focusedElem,K=m.selectionRange;if(S!==O&&O&&O.ownerDocument&&Gm(O.ownerDocument.documentElement,O)){if(K!==null&&ff(O)){var _t=K.start,Dt=K.end;if(Dt===void 0&&(Dt=_t),"selectionStart"in O)O.selectionStart=_t,O.selectionEnd=Math.min(Dt,O.value.length);else{var Pt=O.ownerDocument||document,St=Pt&&Pt.defaultView||window;if(St.getSelection){var At=St.getSelection(),ne=O.textContent.length,_e=Math.min(K.start,ne),pn=K.end===void 0?_e:Math.min(K.end,ne);!At.extend&&_e>pn&&(S=pn,pn=_e,_e=S);var ut=Hm(O,_e),tt=Hm(O,pn);if(ut&&tt&&(At.rangeCount!==1||At.anchorNode!==ut.node||At.anchorOffset!==ut.offset||At.focusNode!==tt.node||At.focusOffset!==tt.offset)){var vt=Pt.createRange();vt.setStart(ut.node,ut.offset),At.removeAllRanges(),_e>pn?(At.addRange(vt),At.extend(tt.node,tt.offset)):(vt.setEnd(tt.node,tt.offset),At.addRange(vt))}}}}for(Pt=[],At=O;At=At.parentNode;)At.nodeType===1&&Pt.push({element:At,left:At.scrollLeft,top:At.scrollTop});for(typeof O.focus=="function"&&O.focus(),O=0;O<Pt.length;O++){var Nt=Pt[O];Nt.element.scrollLeft=Nt.left,Nt.element.scrollTop=Nt.top}}Vc=!!Fh,Hh=Fh=null}finally{en=f,Y.p=l,H.T=r}}e.current=i,Xn=2}}function iv(){if(Xn===2){Xn=0;var e=ps,i=Ir,r=(i.flags&8772)!==0;if((i.subtreeFlags&8772)!==0||r){r=H.T,H.T=null;var l=Y.p;Y.p=2;var f=en;en|=4;try{Ug(e,i.alternate,i)}finally{en=f,Y.p=l,H.T=r}}Xn=3}}function av(){if(Xn===4||Xn===3){Xn=0,j();var e=ps,i=Ir,r=za,l=Xg;(i.subtreeFlags&10256)!==0||(i.flags&10256)!==0?Xn=5:(Xn=0,Ir=ps=null,sv(e,e.pendingLanes));var f=e.pendingLanes;if(f===0&&(ds=null),cn(r),i=i.stateNode,xt&&typeof xt.onCommitFiberRoot=="function")try{xt.onCommitFiberRoot(yt,i,void 0,(i.current.flags&128)===128)}catch{}if(l!==null){i=H.T,f=Y.p,Y.p=2,H.T=null;try{for(var m=e.onRecoverableError,S=0;S<l.length;S++){var O=l[S];m(O.value,{componentStack:O.stack})}}finally{H.T=i,Y.p=f}}(za&3)!==0&&Dc(),pa(e),f=e.pendingLanes,(r&261930)!==0&&(f&42)!==0?e===Ah?Jo++:(Jo=0,Ah=e):Jo=0,Qo(0)}}function sv(e,i){(e.pooledCacheLanes&=i)===0&&(i=e.pooledCache,i!=null&&(e.pooledCache=null,Uo(i)))}function Dc(){return nv(),iv(),av(),rv()}function rv(){if(Xn!==5)return!1;var e=ps,i=Eh;Eh=0;var r=cn(za),l=H.T,f=Y.p;try{Y.p=32>r?32:r,H.T=null,r=Th,Th=null;var m=ps,S=za;if(Xn=0,Ir=ps=null,za=0,(en&6)!==0)throw Error(a(331));var O=en;if(en|=4,Gg(m.current),Bg(m,m.current,S,r),en=O,Qo(0,!1),xt&&typeof xt.onPostCommitFiberRoot=="function")try{xt.onPostCommitFiberRoot(yt,m)}catch{}return!0}finally{Y.p=f,H.T=l,sv(e,i)}}function ov(e,i,r){i=Vi(r,i),i=ah(e.stateNode,i,2),e=os(e,i,2),e!==null&&(It(e,2),pa(e))}function rn(e,i,r){if(e.tag===3)ov(e,e,r);else for(;i!==null;){if(i.tag===3){ov(i,e,r);break}else if(i.tag===1){var l=i.stateNode;if(typeof i.type.getDerivedStateFromError=="function"||typeof l.componentDidCatch=="function"&&(ds===null||!ds.has(l))){e=Vi(r,e),r=lg(2),l=os(i,r,2),l!==null&&(cg(r,l,i,e),It(l,2),pa(l));break}}i=i.return}}function Ch(e,i,r){var l=e.pingCache;if(l===null){l=e.pingCache=new zy;var f=new Set;l.set(i,f)}else f=l.get(i),f===void 0&&(f=new Set,l.set(i,f));f.has(r)||(yh=!0,f.add(r),e=Gy.bind(null,e,i,r),i.then(e,e))}function Gy(e,i,r){var l=e.pingCache;l!==null&&l.delete(i),e.pingedLanes|=e.suspendedLanes&r,e.warmLanes&=~r,gn===e&&(Ve&r)===r&&(Cn===4||Cn===3&&(Ve&62914560)===Ve&&300>Se()-Ec?(en&2)===0&&Br(e,0):Sh|=r,zr===Ve&&(zr=0)),pa(e)}function lv(e,i){i===0&&(i=st()),e=Ns(e,i),e!==null&&(It(e,i),pa(e))}function Vy(e){var i=e.memoizedState,r=0;i!==null&&(r=i.retryLane),lv(e,r)}function ky(e,i){var r=0;switch(e.tag){case 31:case 13:var l=e.stateNode,f=e.memoizedState;f!==null&&(r=f.retryLane);break;case 19:l=e.stateNode;break;case 22:l=e.stateNode._retryCache;break;default:throw Error(a(314))}l!==null&&l.delete(i),lv(e,r)}function Xy(e,i){return Be(e,i)}var Uc=null,Hr=null,Dh=!1,Lc=!1,Uh=!1,gs=0;function pa(e){e!==Hr&&e.next===null&&(Hr===null?Uc=Hr=e:Hr=Hr.next=e),Lc=!0,Dh||(Dh=!0,qy())}function Qo(e,i){if(!Uh&&Lc){Uh=!0;do for(var r=!1,l=Uc;l!==null;){if(e!==0){var f=l.pendingLanes;if(f===0)var m=0;else{var S=l.suspendedLanes,O=l.pingedLanes;m=(1<<31-gt(42|e)+1)-1,m&=f&~(S&~O),m=m&201326741?m&201326741|1:m?m|2:0}m!==0&&(r=!0,hv(l,m))}else m=Ve,m=V(l,l===gn?m:0,l.cancelPendingCommit!==null||l.timeoutHandle!==-1),(m&3)===0||nt(l,m)||(r=!0,hv(l,m));l=l.next}while(r);Uh=!1}}function Wy(){cv()}function cv(){Lc=Dh=!1;var e=0;gs!==0&&nS()&&(e=gs);for(var i=Se(),r=null,l=Uc;l!==null;){var f=l.next,m=uv(l,i);m===0?(l.next=null,r===null?Uc=f:r.next=f,f===null&&(Hr=r)):(r=l,(e!==0||(m&3)!==0)&&(Lc=!0)),l=f}Xn!==0&&Xn!==5||Qo(e),gs!==0&&(gs=0)}function uv(e,i){for(var r=e.suspendedLanes,l=e.pingedLanes,f=e.expirationTimes,m=e.pendingLanes&-62914561;0<m;){var S=31-gt(m),O=1<<S,K=f[S];K===-1?((O&r)===0||(O&l)!==0)&&(f[S]=ot(O,i)):K<=i&&(e.expiredLanes|=O),m&=~O}if(i=gn,r=Ve,r=V(e,e===i?r:0,e.cancelPendingCommit!==null||e.timeoutHandle!==-1),l=e.callbackNode,r===0||e===i&&(sn===2||sn===9)||e.cancelPendingCommit!==null)return l!==null&&l!==null&&ie(l),e.callbackNode=null,e.callbackPriority=0;if((r&3)===0||nt(e,r)){if(i=r&-r,i===e.callbackPriority)return i;switch(l!==null&&ie(l),cn(r)){case 2:case 8:r=A;break;case 32:r=et;break;case 268435456:r=Mt;break;default:r=et}return l=fv.bind(null,e),r=Be(r,l),e.callbackPriority=i,e.callbackNode=r,i}return l!==null&&l!==null&&ie(l),e.callbackPriority=2,e.callbackNode=null,2}function fv(e,i){if(Xn!==0&&Xn!==5)return e.callbackNode=null,e.callbackPriority=0,null;var r=e.callbackNode;if(Dc()&&e.callbackNode!==r)return null;var l=Ve;return l=V(e,e===gn?l:0,e.cancelPendingCommit!==null||e.timeoutHandle!==-1),l===0?null:(qg(e,l,i),uv(e,Se()),e.callbackNode!=null&&e.callbackNode===r?fv.bind(null,e):null)}function hv(e,i){if(Dc())return null;qg(e,i,!0)}function qy(){aS(function(){(en&6)!==0?Be(F,Wy):cv()})}function Lh(){if(gs===0){var e=Tr;e===0&&(e=Z,Z<<=1,(Z&261888)===0&&(Z=256)),gs=e}return gs}function dv(e){return e==null||typeof e=="symbol"||typeof e=="boolean"?null:typeof e=="function"?e:$i(""+e)}function pv(e,i){var r=i.ownerDocument.createElement("input");return r.name=i.name,r.value=i.value,e.id&&r.setAttribute("form",e.id),i.parentNode.insertBefore(r,i),e=new FormData(e),r.parentNode.removeChild(r),e}function Yy(e,i,r,l,f){if(i==="submit"&&r&&r.stateNode===f){var m=dv((f[un]||null).action),S=l.submitter;S&&(i=(i=S[un]||null)?dv(i.formAction):S.getAttribute("formAction"),i!==null&&(m=i,S=null));var O=new Xl("action","action",null,l,f);e.push({event:O,listeners:[{instance:null,listener:function(){if(l.defaultPrevented){if(gs!==0){var K=S?pv(f,S):new FormData(f);jf(r,{pending:!0,data:K,method:f.method,action:m},null,K)}}else typeof m=="function"&&(O.preventDefault(),K=S?pv(f,S):new FormData(f),jf(r,{pending:!0,data:K,method:f.method,action:m},m,K))},currentTarget:f}]})}}for(var Nh=0;Nh<mf.length;Nh++){var Oh=mf[Nh],Zy=Oh.toLowerCase(),Ky=Oh[0].toUpperCase()+Oh.slice(1);ta(Zy,"on"+Ky)}ta(Wm,"onAnimationEnd"),ta(qm,"onAnimationIteration"),ta(Ym,"onAnimationStart"),ta("dblclick","onDoubleClick"),ta("focusin","onFocus"),ta("focusout","onBlur"),ta(fy,"onTransitionRun"),ta(hy,"onTransitionStart"),ta(dy,"onTransitionCancel"),ta(Zm,"onTransitionEnd"),Q("onMouseEnter",["mouseout","mouseover"]),Q("onMouseLeave",["mouseout","mouseover"]),Q("onPointerEnter",["pointerout","pointerover"]),Q("onPointerLeave",["pointerout","pointerover"]),D("onChange","change click focusin focusout input keydown keyup selectionchange".split(" ")),D("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")),D("onBeforeInput",["compositionend","keypress","textInput","paste"]),D("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" ")),D("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" ")),D("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var jo="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),Jy=new Set("beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(jo));function mv(e,i){i=(i&4)!==0;for(var r=0;r<e.length;r++){var l=e[r],f=l.event;l=l.listeners;t:{var m=void 0;if(i)for(var S=l.length-1;0<=S;S--){var O=l[S],K=O.instance,_t=O.currentTarget;if(O=O.listener,K!==m&&f.isPropagationStopped())break t;m=O,f.currentTarget=_t;try{m(f)}catch(Dt){Yl(Dt)}f.currentTarget=null,m=K}else for(S=0;S<l.length;S++){if(O=l[S],K=O.instance,_t=O.currentTarget,O=O.listener,K!==m&&f.isPropagationStopped())break t;m=O,f.currentTarget=_t;try{m(f)}catch(Dt){Yl(Dt)}f.currentTarget=null,m=K}}}}function Ge(e,i){var r=i[ca];r===void 0&&(r=i[ca]=new Set);var l=e+"__bubble";r.has(l)||(gv(i,e,2,!1),r.add(l))}function Ph(e,i,r){var l=0;i&&(l|=4),gv(r,e,l,i)}var Nc="_reactListening"+Math.random().toString(36).slice(2);function zh(e){if(!e[Nc]){e[Nc]=!0,ja.forEach(function(r){r!=="selectionchange"&&(Jy.has(r)||Ph(r,!1,e),Ph(r,!0,e))});var i=e.nodeType===9?e:e.ownerDocument;i===null||i[Nc]||(i[Nc]=!0,Ph("selectionchange",!1,i))}}function gv(e,i,r,l){switch(Wv(i)){case 2:var f=ES;break;case 8:f=TS;break;default:f=Qh}r=f.bind(null,i,r,e),f=void 0,!ef||i!=="touchstart"&&i!=="touchmove"&&i!=="wheel"||(f=!0),l?f!==void 0?e.addEventListener(i,r,{capture:!0,passive:f}):e.addEventListener(i,r,!0):f!==void 0?e.addEventListener(i,r,{passive:f}):e.addEventListener(i,r,!1)}function Ih(e,i,r,l,f){var m=l;if((i&1)===0&&(i&2)===0&&l!==null)t:for(;;){if(l===null)return;var S=l.tag;if(S===3||S===4){var O=l.stateNode.containerInfo;if(O===f)break;if(S===4)for(S=l.return;S!==null;){var K=S.tag;if((K===3||K===4)&&S.stateNode.containerInfo===f)return;S=S.return}for(;O!==null;){if(S=ve(O),S===null)return;if(K=S.tag,K===5||K===6||K===26||K===27){l=m=S;continue t}O=O.parentNode}}l=l.return}ym(function(){var _t=m,Dt=$u(r),Pt=[];t:{var St=Km.get(e);if(St!==void 0){var At=Xl,ne=e;switch(e){case"keypress":if(Vl(r)===0)break t;case"keydown":case"keyup":At=kM;break;case"focusin":ne="focus",At=rf;break;case"focusout":ne="blur",At=rf;break;case"beforeblur":case"afterblur":At=rf;break;case"click":if(r.button===2)break t;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":At=Em;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":At=UM;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":At=qM;break;case Wm:case qm:case Ym:At=OM;break;case Zm:At=ZM;break;case"scroll":case"scrollend":At=CM;break;case"wheel":At=JM;break;case"copy":case"cut":case"paste":At=zM;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":At=Am;break;case"toggle":case"beforetoggle":At=jM}var _e=(i&4)!==0,pn=!_e&&(e==="scroll"||e==="scrollend"),ut=_e?St!==null?St+"Capture":null:St;_e=[];for(var tt=_t,vt;tt!==null;){var Nt=tt;if(vt=Nt.stateNode,Nt=Nt.tag,Nt!==5&&Nt!==26&&Nt!==27||vt===null||ut===null||(Nt=Mo(tt,ut),Nt!=null&&_e.push($o(tt,Nt,vt))),pn)break;tt=tt.return}0<_e.length&&(St=new At(St,ne,null,r,Dt),Pt.push({event:St,listeners:_e}))}}if((i&7)===0){t:{if(St=e==="mouseover"||e==="pointerover",At=e==="mouseout"||e==="pointerout",St&&r!==ju&&(ne=r.relatedTarget||r.fromElement)&&(ve(ne)||ne[Vn]))break t;if((At||St)&&(St=Dt.window===Dt?Dt:(St=Dt.ownerDocument)?St.defaultView||St.parentWindow:window,At?(ne=r.relatedTarget||r.toElement,At=_t,ne=ne?ve(ne):null,ne!==null&&(pn=c(ne),_e=ne.tag,ne!==pn||_e!==5&&_e!==27&&_e!==6)&&(ne=null)):(At=null,ne=_t),At!==ne)){if(_e=Em,Nt="onMouseLeave",ut="onMouseEnter",tt="mouse",(e==="pointerout"||e==="pointerover")&&(_e=Am,Nt="onPointerLeave",ut="onPointerEnter",tt="pointer"),pn=At==null?St:Zn(At),vt=ne==null?St:Zn(ne),St=new _e(Nt,tt+"leave",At,r,Dt),St.target=pn,St.relatedTarget=vt,Nt=null,ve(Dt)===_t&&(_e=new _e(ut,tt+"enter",ne,r,Dt),_e.target=vt,_e.relatedTarget=pn,Nt=_e),pn=Nt,At&&ne)e:{for(_e=Qy,ut=At,tt=ne,vt=0,Nt=ut;Nt;Nt=_e(Nt))vt++;Nt=0;for(var he=tt;he;he=_e(he))Nt++;for(;0<vt-Nt;)ut=_e(ut),vt--;for(;0<Nt-vt;)tt=_e(tt),Nt--;for(;vt--;){if(ut===tt||tt!==null&&ut===tt.alternate){_e=ut;break e}ut=_e(ut),tt=_e(tt)}_e=null}else _e=null;At!==null&&vv(Pt,St,At,_e,!1),ne!==null&&pn!==null&&vv(Pt,pn,ne,_e,!0)}}t:{if(St=_t?Zn(_t):window,At=St.nodeName&&St.nodeName.toLowerCase(),At==="select"||At==="input"&&St.type==="file")var Qe=Om;else if(Lm(St))if(Pm)Qe=ly;else{Qe=ry;var re=sy}else At=St.nodeName,!At||At.toLowerCase()!=="input"||St.type!=="checkbox"&&St.type!=="radio"?_t&&Fi(_t.elementType)&&(Qe=Om):Qe=oy;if(Qe&&(Qe=Qe(e,_t))){Nm(Pt,Qe,r,Dt);break t}re&&re(e,St,_t),e==="focusout"&&_t&&St.type==="number"&&_t.memoizedProps.value!=null&&kn(St,"number",St.value)}switch(re=_t?Zn(_t):window,e){case"focusin":(Lm(re)||re.contentEditable==="true")&&(vr=re,hf=_t,Ro=null);break;case"focusout":Ro=hf=vr=null;break;case"mousedown":df=!0;break;case"contextmenu":case"mouseup":case"dragend":df=!1,km(Pt,r,Dt);break;case"selectionchange":if(uy)break;case"keydown":case"keyup":km(Pt,r,Dt)}var Le;if(lf)t:{switch(e){case"compositionstart":var ke="onCompositionStart";break t;case"compositionend":ke="onCompositionEnd";break t;case"compositionupdate":ke="onCompositionUpdate";break t}ke=void 0}else gr?Dm(e,r)&&(ke="onCompositionEnd"):e==="keydown"&&r.keyCode===229&&(ke="onCompositionStart");ke&&(wm&&r.locale!=="ko"&&(gr||ke!=="onCompositionStart"?ke==="onCompositionEnd"&&gr&&(Le=Sm()):(ts=Dt,nf="value"in ts?ts.value:ts.textContent,gr=!0)),re=Oc(_t,ke),0<re.length&&(ke=new Tm(ke,e,null,r,Dt),Pt.push({event:ke,listeners:re}),Le?ke.data=Le:(Le=Um(r),Le!==null&&(ke.data=Le)))),(Le=ty?ey(e,r):ny(e,r))&&(ke=Oc(_t,"onBeforeInput"),0<ke.length&&(re=new Tm("onBeforeInput","beforeinput",null,r,Dt),Pt.push({event:re,listeners:ke}),re.data=Le)),Yy(Pt,e,_t,r,Dt)}mv(Pt,i)})}function $o(e,i,r){return{instance:e,listener:i,currentTarget:r}}function Oc(e,i){for(var r=i+"Capture",l=[];e!==null;){var f=e,m=f.stateNode;if(f=f.tag,f!==5&&f!==26&&f!==27||m===null||(f=Mo(e,r),f!=null&&l.unshift($o(e,f,m)),f=Mo(e,i),f!=null&&l.push($o(e,f,m))),e.tag===3)return l;e=e.return}return[]}function Qy(e){if(e===null)return null;do e=e.return;while(e&&e.tag!==5&&e.tag!==27);return e||null}function vv(e,i,r,l,f){for(var m=i._reactName,S=[];r!==null&&r!==l;){var O=r,K=O.alternate,_t=O.stateNode;if(O=O.tag,K!==null&&K===l)break;O!==5&&O!==26&&O!==27||_t===null||(K=_t,f?(_t=Mo(r,m),_t!=null&&S.unshift($o(r,_t,K))):f||(_t=Mo(r,m),_t!=null&&S.push($o(r,_t,K)))),r=r.return}S.length!==0&&e.push({event:i,listeners:S})}var jy=/\r\n?/g,$y=/\u0000|\uFFFD/g;function _v(e){return(typeof e=="string"?e:""+e).replace(jy,`
`).replace($y,"")}function xv(e,i){return i=_v(i),_v(e)===i}function dn(e,i,r,l,f,m){switch(r){case"children":typeof l=="string"?i==="body"||i==="textarea"&&l===""||di(e,l):(typeof l=="number"||typeof l=="bigint")&&i!=="body"&&di(e,""+l);break;case"className":Gt(e,"class",l);break;case"tabIndex":Gt(e,"tabindex",l);break;case"dir":case"role":case"viewBox":case"width":case"height":Gt(e,r,l);break;case"style":bn(e,l,m);break;case"data":if(i!=="object"){Gt(e,"data",l);break}case"src":case"href":if(l===""&&(i!=="a"||r!=="href")){e.removeAttribute(r);break}if(l==null||typeof l=="function"||typeof l=="symbol"||typeof l=="boolean"){e.removeAttribute(r);break}l=$i(""+l),e.setAttribute(r,l);break;case"action":case"formAction":if(typeof l=="function"){e.setAttribute(r,"javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')");break}else typeof m=="function"&&(r==="formAction"?(i!=="input"&&dn(e,i,"name",f.name,f,null),dn(e,i,"formEncType",f.formEncType,f,null),dn(e,i,"formMethod",f.formMethod,f,null),dn(e,i,"formTarget",f.formTarget,f,null)):(dn(e,i,"encType",f.encType,f,null),dn(e,i,"method",f.method,f,null),dn(e,i,"target",f.target,f,null)));if(l==null||typeof l=="symbol"||typeof l=="boolean"){e.removeAttribute(r);break}l=$i(""+l),e.setAttribute(r,l);break;case"onClick":l!=null&&(e.onclick=Hi);break;case"onScroll":l!=null&&Ge("scroll",e);break;case"onScrollEnd":l!=null&&Ge("scrollend",e);break;case"dangerouslySetInnerHTML":if(l!=null){if(typeof l!="object"||!("__html"in l))throw Error(a(61));if(r=l.__html,r!=null){if(f.children!=null)throw Error(a(60));e.innerHTML=r}}break;case"multiple":e.multiple=l&&typeof l!="function"&&typeof l!="symbol";break;case"muted":e.muted=l&&typeof l!="function"&&typeof l!="symbol";break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"defaultValue":case"defaultChecked":case"innerHTML":case"ref":break;case"autoFocus":break;case"xlinkHref":if(l==null||typeof l=="function"||typeof l=="boolean"||typeof l=="symbol"){e.removeAttribute("xlink:href");break}r=$i(""+l),e.setAttributeNS("http://www.w3.org/1999/xlink","xlink:href",r);break;case"contentEditable":case"spellCheck":case"draggable":case"value":case"autoReverse":case"externalResourcesRequired":case"focusable":case"preserveAlpha":l!=null&&typeof l!="function"&&typeof l!="symbol"?e.setAttribute(r,""+l):e.removeAttribute(r);break;case"inert":case"allowFullScreen":case"async":case"autoPlay":case"controls":case"default":case"defer":case"disabled":case"disablePictureInPicture":case"disableRemotePlayback":case"formNoValidate":case"hidden":case"loop":case"noModule":case"noValidate":case"open":case"playsInline":case"readOnly":case"required":case"reversed":case"scoped":case"seamless":case"itemScope":l&&typeof l!="function"&&typeof l!="symbol"?e.setAttribute(r,""):e.removeAttribute(r);break;case"capture":case"download":l===!0?e.setAttribute(r,""):l!==!1&&l!=null&&typeof l!="function"&&typeof l!="symbol"?e.setAttribute(r,l):e.removeAttribute(r);break;case"cols":case"rows":case"size":case"span":l!=null&&typeof l!="function"&&typeof l!="symbol"&&!isNaN(l)&&1<=l?e.setAttribute(r,l):e.removeAttribute(r);break;case"rowSpan":case"start":l==null||typeof l=="function"||typeof l=="symbol"||isNaN(l)?e.removeAttribute(r):e.setAttribute(r,l);break;case"popover":Ge("beforetoggle",e),Ge("toggle",e),Jt(e,"popover",l);break;case"xlinkActuate":Zt(e,"http://www.w3.org/1999/xlink","xlink:actuate",l);break;case"xlinkArcrole":Zt(e,"http://www.w3.org/1999/xlink","xlink:arcrole",l);break;case"xlinkRole":Zt(e,"http://www.w3.org/1999/xlink","xlink:role",l);break;case"xlinkShow":Zt(e,"http://www.w3.org/1999/xlink","xlink:show",l);break;case"xlinkTitle":Zt(e,"http://www.w3.org/1999/xlink","xlink:title",l);break;case"xlinkType":Zt(e,"http://www.w3.org/1999/xlink","xlink:type",l);break;case"xmlBase":Zt(e,"http://www.w3.org/XML/1998/namespace","xml:base",l);break;case"xmlLang":Zt(e,"http://www.w3.org/XML/1998/namespace","xml:lang",l);break;case"xmlSpace":Zt(e,"http://www.w3.org/XML/1998/namespace","xml:space",l);break;case"is":Jt(e,"is",l);break;case"innerText":case"textContent":break;default:(!(2<r.length)||r[0]!=="o"&&r[0]!=="O"||r[1]!=="n"&&r[1]!=="N")&&(r=fn.get(r)||r,Jt(e,r,l))}}function Bh(e,i,r,l,f,m){switch(r){case"style":bn(e,l,m);break;case"dangerouslySetInnerHTML":if(l!=null){if(typeof l!="object"||!("__html"in l))throw Error(a(61));if(r=l.__html,r!=null){if(f.children!=null)throw Error(a(60));e.innerHTML=r}}break;case"children":typeof l=="string"?di(e,l):(typeof l=="number"||typeof l=="bigint")&&di(e,""+l);break;case"onScroll":l!=null&&Ge("scroll",e);break;case"onScrollEnd":l!=null&&Ge("scrollend",e);break;case"onClick":l!=null&&(e.onclick=Hi);break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"innerHTML":case"ref":break;case"innerText":case"textContent":break;default:if(!fi.hasOwnProperty(r))t:{if(r[0]==="o"&&r[1]==="n"&&(f=r.endsWith("Capture"),i=r.slice(2,f?r.length-7:void 0),m=e[un]||null,m=m!=null?m[r]:null,typeof m=="function"&&e.removeEventListener(i,m,f),typeof l=="function")){typeof m!="function"&&m!==null&&(r in e?e[r]=null:e.hasAttribute(r)&&e.removeAttribute(r)),e.addEventListener(i,l,f);break t}r in e?e[r]=l:l===!0?e.setAttribute(r,""):Jt(e,r,l)}}}function si(e,i,r){switch(i){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"img":Ge("error",e),Ge("load",e);var l=!1,f=!1,m;for(m in r)if(r.hasOwnProperty(m)){var S=r[m];if(S!=null)switch(m){case"src":l=!0;break;case"srcSet":f=!0;break;case"children":case"dangerouslySetInnerHTML":throw Error(a(137,i));default:dn(e,i,m,S,r,null)}}f&&dn(e,i,"srcSet",r.srcSet,r,null),l&&dn(e,i,"src",r.src,r,null);return;case"input":Ge("invalid",e);var O=m=S=f=null,K=null,_t=null;for(l in r)if(r.hasOwnProperty(l)){var Dt=r[l];if(Dt!=null)switch(l){case"name":f=Dt;break;case"type":S=Dt;break;case"checked":K=Dt;break;case"defaultChecked":_t=Dt;break;case"value":m=Dt;break;case"defaultValue":O=Dt;break;case"children":case"dangerouslySetInnerHTML":if(Dt!=null)throw Error(a(137,i));break;default:dn(e,i,l,Dt,r,null)}}Qt(e,m,O,K,_t,S,f,!1);return;case"select":Ge("invalid",e),l=S=m=null;for(f in r)if(r.hasOwnProperty(f)&&(O=r[f],O!=null))switch(f){case"value":m=O;break;case"defaultValue":S=O;break;case"multiple":l=O;default:dn(e,i,f,O,r,null)}i=m,r=S,e.multiple=!!l,i!=null?Oe(e,!!l,i,!1):r!=null&&Oe(e,!!l,r,!0);return;case"textarea":Ge("invalid",e),m=f=l=null;for(S in r)if(r.hasOwnProperty(S)&&(O=r[S],O!=null))switch(S){case"value":l=O;break;case"defaultValue":f=O;break;case"children":m=O;break;case"dangerouslySetInnerHTML":if(O!=null)throw Error(a(91));break;default:dn(e,i,S,O,r,null)}Ai(e,l,f,m);return;case"option":for(K in r)if(r.hasOwnProperty(K)&&(l=r[K],l!=null))switch(K){case"selected":e.selected=l&&typeof l!="function"&&typeof l!="symbol";break;default:dn(e,i,K,l,r,null)}return;case"dialog":Ge("beforetoggle",e),Ge("toggle",e),Ge("cancel",e),Ge("close",e);break;case"iframe":case"object":Ge("load",e);break;case"video":case"audio":for(l=0;l<jo.length;l++)Ge(jo[l],e);break;case"image":Ge("error",e),Ge("load",e);break;case"details":Ge("toggle",e);break;case"embed":case"source":case"link":Ge("error",e),Ge("load",e);case"area":case"base":case"br":case"col":case"hr":case"keygen":case"meta":case"param":case"track":case"wbr":case"menuitem":for(_t in r)if(r.hasOwnProperty(_t)&&(l=r[_t],l!=null))switch(_t){case"children":case"dangerouslySetInnerHTML":throw Error(a(137,i));default:dn(e,i,_t,l,r,null)}return;default:if(Fi(i)){for(Dt in r)r.hasOwnProperty(Dt)&&(l=r[Dt],l!==void 0&&Bh(e,i,Dt,l,r,void 0));return}}for(O in r)r.hasOwnProperty(O)&&(l=r[O],l!=null&&dn(e,i,O,l,r,null))}function tS(e,i,r,l){switch(i){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"input":var f=null,m=null,S=null,O=null,K=null,_t=null,Dt=null;for(At in r){var Pt=r[At];if(r.hasOwnProperty(At)&&Pt!=null)switch(At){case"checked":break;case"value":break;case"defaultValue":K=Pt;default:l.hasOwnProperty(At)||dn(e,i,At,null,l,Pt)}}for(var St in l){var At=l[St];if(Pt=r[St],l.hasOwnProperty(St)&&(At!=null||Pt!=null))switch(St){case"type":m=At;break;case"name":f=At;break;case"checked":_t=At;break;case"defaultChecked":Dt=At;break;case"value":S=At;break;case"defaultValue":O=At;break;case"children":case"dangerouslySetInnerHTML":if(At!=null)throw Error(a(137,i));break;default:At!==Pt&&dn(e,i,St,At,l,Pt)}}Pn(e,S,O,K,_t,Dt,m,f);return;case"select":At=S=O=St=null;for(m in r)if(K=r[m],r.hasOwnProperty(m)&&K!=null)switch(m){case"value":break;case"multiple":At=K;default:l.hasOwnProperty(m)||dn(e,i,m,null,l,K)}for(f in l)if(m=l[f],K=r[f],l.hasOwnProperty(f)&&(m!=null||K!=null))switch(f){case"value":St=m;break;case"defaultValue":O=m;break;case"multiple":S=m;default:m!==K&&dn(e,i,f,m,l,K)}i=O,r=S,l=At,St!=null?Oe(e,!!r,St,!1):!!l!=!!r&&(i!=null?Oe(e,!!r,i,!0):Oe(e,!!r,r?[]:"",!1));return;case"textarea":At=St=null;for(O in r)if(f=r[O],r.hasOwnProperty(O)&&f!=null&&!l.hasOwnProperty(O))switch(O){case"value":break;case"children":break;default:dn(e,i,O,null,l,f)}for(S in l)if(f=l[S],m=r[S],l.hasOwnProperty(S)&&(f!=null||m!=null))switch(S){case"value":St=f;break;case"defaultValue":At=f;break;case"children":break;case"dangerouslySetInnerHTML":if(f!=null)throw Error(a(91));break;default:f!==m&&dn(e,i,S,f,l,m)}hi(e,St,At);return;case"option":for(var ne in r)if(St=r[ne],r.hasOwnProperty(ne)&&St!=null&&!l.hasOwnProperty(ne))switch(ne){case"selected":e.selected=!1;break;default:dn(e,i,ne,null,l,St)}for(K in l)if(St=l[K],At=r[K],l.hasOwnProperty(K)&&St!==At&&(St!=null||At!=null))switch(K){case"selected":e.selected=St&&typeof St!="function"&&typeof St!="symbol";break;default:dn(e,i,K,St,l,At)}return;case"img":case"link":case"area":case"base":case"br":case"col":case"embed":case"hr":case"keygen":case"meta":case"param":case"source":case"track":case"wbr":case"menuitem":for(var _e in r)St=r[_e],r.hasOwnProperty(_e)&&St!=null&&!l.hasOwnProperty(_e)&&dn(e,i,_e,null,l,St);for(_t in l)if(St=l[_t],At=r[_t],l.hasOwnProperty(_t)&&St!==At&&(St!=null||At!=null))switch(_t){case"children":case"dangerouslySetInnerHTML":if(St!=null)throw Error(a(137,i));break;default:dn(e,i,_t,St,l,At)}return;default:if(Fi(i)){for(var pn in r)St=r[pn],r.hasOwnProperty(pn)&&St!==void 0&&!l.hasOwnProperty(pn)&&Bh(e,i,pn,void 0,l,St);for(Dt in l)St=l[Dt],At=r[Dt],!l.hasOwnProperty(Dt)||St===At||St===void 0&&At===void 0||Bh(e,i,Dt,St,l,At);return}}for(var ut in r)St=r[ut],r.hasOwnProperty(ut)&&St!=null&&!l.hasOwnProperty(ut)&&dn(e,i,ut,null,l,St);for(Pt in l)St=l[Pt],At=r[Pt],!l.hasOwnProperty(Pt)||St===At||St==null&&At==null||dn(e,i,Pt,St,l,At)}function Mv(e){switch(e){case"css":case"script":case"font":case"img":case"image":case"input":case"link":return!0;default:return!1}}function eS(){if(typeof performance.getEntriesByType=="function"){for(var e=0,i=0,r=performance.getEntriesByType("resource"),l=0;l<r.length;l++){var f=r[l],m=f.transferSize,S=f.initiatorType,O=f.duration;if(m&&O&&Mv(S)){for(S=0,O=f.responseEnd,l+=1;l<r.length;l++){var K=r[l],_t=K.startTime;if(_t>O)break;var Dt=K.transferSize,Pt=K.initiatorType;Dt&&Mv(Pt)&&(K=K.responseEnd,S+=Dt*(K<O?1:(O-_t)/(K-_t)))}if(--l,i+=8*(m+S)/(f.duration/1e3),e++,10<e)break}}if(0<e)return i/e/1e6}return navigator.connection&&(e=navigator.connection.downlink,typeof e=="number")?e:5}var Fh=null,Hh=null;function Pc(e){return e.nodeType===9?e:e.ownerDocument}function yv(e){switch(e){case"http://www.w3.org/2000/svg":return 1;case"http://www.w3.org/1998/Math/MathML":return 2;default:return 0}}function Sv(e,i){if(e===0)switch(i){case"svg":return 1;case"math":return 2;default:return 0}return e===1&&i==="foreignObject"?0:e}function Gh(e,i){return e==="textarea"||e==="noscript"||typeof i.children=="string"||typeof i.children=="number"||typeof i.children=="bigint"||typeof i.dangerouslySetInnerHTML=="object"&&i.dangerouslySetInnerHTML!==null&&i.dangerouslySetInnerHTML.__html!=null}var Vh=null;function nS(){var e=window.event;return e&&e.type==="popstate"?e===Vh?!1:(Vh=e,!0):(Vh=null,!1)}var bv=typeof setTimeout=="function"?setTimeout:void 0,iS=typeof clearTimeout=="function"?clearTimeout:void 0,Ev=typeof Promise=="function"?Promise:void 0,aS=typeof queueMicrotask=="function"?queueMicrotask:typeof Ev<"u"?function(e){return Ev.resolve(null).then(e).catch(sS)}:bv;function sS(e){setTimeout(function(){throw e})}function vs(e){return e==="head"}function Tv(e,i){var r=i,l=0;do{var f=r.nextSibling;if(e.removeChild(r),f&&f.nodeType===8)if(r=f.data,r==="/$"||r==="/&"){if(l===0){e.removeChild(f),Xr(i);return}l--}else if(r==="$"||r==="$?"||r==="$~"||r==="$!"||r==="&")l++;else if(r==="html")tl(e.ownerDocument.documentElement);else if(r==="head"){r=e.ownerDocument.head,tl(r);for(var m=r.firstChild;m;){var S=m.nextSibling,O=m.nodeName;m[ue]||O==="SCRIPT"||O==="STYLE"||O==="LINK"&&m.rel.toLowerCase()==="stylesheet"||r.removeChild(m),m=S}}else r==="body"&&tl(e.ownerDocument.body);r=f}while(r);Xr(i)}function Av(e,i){var r=e;e=0;do{var l=r.nextSibling;if(r.nodeType===1?i?(r._stashedDisplay=r.style.display,r.style.display="none"):(r.style.display=r._stashedDisplay||"",r.getAttribute("style")===""&&r.removeAttribute("style")):r.nodeType===3&&(i?(r._stashedText=r.nodeValue,r.nodeValue=""):r.nodeValue=r._stashedText||""),l&&l.nodeType===8)if(r=l.data,r==="/$"){if(e===0)break;e--}else r!=="$"&&r!=="$?"&&r!=="$~"&&r!=="$!"||e++;r=l}while(r)}function kh(e){var i=e.firstChild;for(i&&i.nodeType===10&&(i=i.nextSibling);i;){var r=i;switch(i=i.nextSibling,r.nodeName){case"HTML":case"HEAD":case"BODY":kh(r),fe(r);continue;case"SCRIPT":case"STYLE":continue;case"LINK":if(r.rel.toLowerCase()==="stylesheet")continue}e.removeChild(r)}}function rS(e,i,r,l){for(;e.nodeType===1;){var f=r;if(e.nodeName.toLowerCase()!==i.toLowerCase()){if(!l&&(e.nodeName!=="INPUT"||e.type!=="hidden"))break}else if(l){if(!e[ue])switch(i){case"meta":if(!e.hasAttribute("itemprop"))break;return e;case"link":if(m=e.getAttribute("rel"),m==="stylesheet"&&e.hasAttribute("data-precedence"))break;if(m!==f.rel||e.getAttribute("href")!==(f.href==null||f.href===""?null:f.href)||e.getAttribute("crossorigin")!==(f.crossOrigin==null?null:f.crossOrigin)||e.getAttribute("title")!==(f.title==null?null:f.title))break;return e;case"style":if(e.hasAttribute("data-precedence"))break;return e;case"script":if(m=e.getAttribute("src"),(m!==(f.src==null?null:f.src)||e.getAttribute("type")!==(f.type==null?null:f.type)||e.getAttribute("crossorigin")!==(f.crossOrigin==null?null:f.crossOrigin))&&m&&e.hasAttribute("async")&&!e.hasAttribute("itemprop"))break;return e;default:return e}}else if(i==="input"&&e.type==="hidden"){var m=f.name==null?null:""+f.name;if(f.type==="hidden"&&e.getAttribute("name")===m)return e}else return e;if(e=Yi(e.nextSibling),e===null)break}return null}function oS(e,i,r){if(i==="")return null;for(;e.nodeType!==3;)if((e.nodeType!==1||e.nodeName!=="INPUT"||e.type!=="hidden")&&!r||(e=Yi(e.nextSibling),e===null))return null;return e}function wv(e,i){for(;e.nodeType!==8;)if((e.nodeType!==1||e.nodeName!=="INPUT"||e.type!=="hidden")&&!i||(e=Yi(e.nextSibling),e===null))return null;return e}function Xh(e){return e.data==="$?"||e.data==="$~"}function Wh(e){return e.data==="$!"||e.data==="$?"&&e.ownerDocument.readyState!=="loading"}function lS(e,i){var r=e.ownerDocument;if(e.data==="$~")e._reactRetry=i;else if(e.data!=="$?"||r.readyState!=="loading")i();else{var l=function(){i(),r.removeEventListener("DOMContentLoaded",l)};r.addEventListener("DOMContentLoaded",l),e._reactRetry=l}}function Yi(e){for(;e!=null;e=e.nextSibling){var i=e.nodeType;if(i===1||i===3)break;if(i===8){if(i=e.data,i==="$"||i==="$!"||i==="$?"||i==="$~"||i==="&"||i==="F!"||i==="F")break;if(i==="/$"||i==="/&")return null}}return e}var qh=null;function Rv(e){e=e.nextSibling;for(var i=0;e;){if(e.nodeType===8){var r=e.data;if(r==="/$"||r==="/&"){if(i===0)return Yi(e.nextSibling);i--}else r!=="$"&&r!=="$!"&&r!=="$?"&&r!=="$~"&&r!=="&"||i++}e=e.nextSibling}return null}function Cv(e){e=e.previousSibling;for(var i=0;e;){if(e.nodeType===8){var r=e.data;if(r==="$"||r==="$!"||r==="$?"||r==="$~"||r==="&"){if(i===0)return e;i--}else r!=="/$"&&r!=="/&"||i++}e=e.previousSibling}return null}function Dv(e,i,r){switch(i=Pc(r),e){case"html":if(e=i.documentElement,!e)throw Error(a(452));return e;case"head":if(e=i.head,!e)throw Error(a(453));return e;case"body":if(e=i.body,!e)throw Error(a(454));return e;default:throw Error(a(451))}}function tl(e){for(var i=e.attributes;i.length;)e.removeAttributeNode(i[0]);fe(e)}var Zi=new Map,Uv=new Set;function zc(e){return typeof e.getRootNode=="function"?e.getRootNode():e.nodeType===9?e:e.ownerDocument}var Ia=Y.d;Y.d={f:cS,r:uS,D:fS,C:hS,L:dS,m:pS,X:gS,S:mS,M:vS};function cS(){var e=Ia.f(),i=wc();return e||i}function uS(e){var i=an(e);i!==null&&i.tag===5&&i.type==="form"?Z0(i):Ia.r(e)}var Gr=typeof document>"u"?null:document;function Lv(e,i,r){var l=Gr;if(l&&typeof i=="string"&&i){var f=Ne(i);f='link[rel="'+e+'"][href="'+f+'"]',typeof r=="string"&&(f+='[crossorigin="'+r+'"]'),Uv.has(f)||(Uv.add(f),e={rel:e,crossOrigin:r,href:i},l.querySelector(f)===null&&(i=l.createElement("link"),si(i,"link",e),$e(i),l.head.appendChild(i)))}}function fS(e){Ia.D(e),Lv("dns-prefetch",e,null)}function hS(e,i){Ia.C(e,i),Lv("preconnect",e,i)}function dS(e,i,r){Ia.L(e,i,r);var l=Gr;if(l&&e&&i){var f='link[rel="preload"][as="'+Ne(i)+'"]';i==="image"&&r&&r.imageSrcSet?(f+='[imagesrcset="'+Ne(r.imageSrcSet)+'"]',typeof r.imageSizes=="string"&&(f+='[imagesizes="'+Ne(r.imageSizes)+'"]')):f+='[href="'+Ne(e)+'"]';var m=f;switch(i){case"style":m=Vr(e);break;case"script":m=kr(e)}Zi.has(m)||(e=v({rel:"preload",href:i==="image"&&r&&r.imageSrcSet?void 0:e,as:i},r),Zi.set(m,e),l.querySelector(f)!==null||i==="style"&&l.querySelector(el(m))||i==="script"&&l.querySelector(nl(m))||(i=l.createElement("link"),si(i,"link",e),$e(i),l.head.appendChild(i)))}}function pS(e,i){Ia.m(e,i);var r=Gr;if(r&&e){var l=i&&typeof i.as=="string"?i.as:"script",f='link[rel="modulepreload"][as="'+Ne(l)+'"][href="'+Ne(e)+'"]',m=f;switch(l){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":m=kr(e)}if(!Zi.has(m)&&(e=v({rel:"modulepreload",href:e},i),Zi.set(m,e),r.querySelector(f)===null)){switch(l){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":if(r.querySelector(nl(m)))return}l=r.createElement("link"),si(l,"link",e),$e(l),r.head.appendChild(l)}}}function mS(e,i,r){Ia.S(e,i,r);var l=Gr;if(l&&e){var f=wn(l).hoistableStyles,m=Vr(e);i=i||"default";var S=f.get(m);if(!S){var O={loading:0,preload:null};if(S=l.querySelector(el(m)))O.loading=5;else{e=v({rel:"stylesheet",href:e,"data-precedence":i},r),(r=Zi.get(m))&&Yh(e,r);var K=S=l.createElement("link");$e(K),si(K,"link",e),K._p=new Promise(function(_t,Dt){K.onload=_t,K.onerror=Dt}),K.addEventListener("load",function(){O.loading|=1}),K.addEventListener("error",function(){O.loading|=2}),O.loading|=4,Ic(S,i,l)}S={type:"stylesheet",instance:S,count:1,state:O},f.set(m,S)}}}function gS(e,i){Ia.X(e,i);var r=Gr;if(r&&e){var l=wn(r).hoistableScripts,f=kr(e),m=l.get(f);m||(m=r.querySelector(nl(f)),m||(e=v({src:e,async:!0},i),(i=Zi.get(f))&&Zh(e,i),m=r.createElement("script"),$e(m),si(m,"link",e),r.head.appendChild(m)),m={type:"script",instance:m,count:1,state:null},l.set(f,m))}}function vS(e,i){Ia.M(e,i);var r=Gr;if(r&&e){var l=wn(r).hoistableScripts,f=kr(e),m=l.get(f);m||(m=r.querySelector(nl(f)),m||(e=v({src:e,async:!0,type:"module"},i),(i=Zi.get(f))&&Zh(e,i),m=r.createElement("script"),$e(m),si(m,"link",e),r.head.appendChild(m)),m={type:"script",instance:m,count:1,state:null},l.set(f,m))}}function Nv(e,i,r,l){var f=(f=Bt.current)?zc(f):null;if(!f)throw Error(a(446));switch(e){case"meta":case"title":return null;case"style":return typeof r.precedence=="string"&&typeof r.href=="string"?(i=Vr(r.href),r=wn(f).hoistableStyles,l=r.get(i),l||(l={type:"style",instance:null,count:0,state:null},r.set(i,l)),l):{type:"void",instance:null,count:0,state:null};case"link":if(r.rel==="stylesheet"&&typeof r.href=="string"&&typeof r.precedence=="string"){e=Vr(r.href);var m=wn(f).hoistableStyles,S=m.get(e);if(S||(f=f.ownerDocument||f,S={type:"stylesheet",instance:null,count:0,state:{loading:0,preload:null}},m.set(e,S),(m=f.querySelector(el(e)))&&!m._p&&(S.instance=m,S.state.loading=5),Zi.has(e)||(r={rel:"preload",as:"style",href:r.href,crossOrigin:r.crossOrigin,integrity:r.integrity,media:r.media,hrefLang:r.hrefLang,referrerPolicy:r.referrerPolicy},Zi.set(e,r),m||_S(f,e,r,S.state))),i&&l===null)throw Error(a(528,""));return S}if(i&&l!==null)throw Error(a(529,""));return null;case"script":return i=r.async,r=r.src,typeof r=="string"&&i&&typeof i!="function"&&typeof i!="symbol"?(i=kr(r),r=wn(f).hoistableScripts,l=r.get(i),l||(l={type:"script",instance:null,count:0,state:null},r.set(i,l)),l):{type:"void",instance:null,count:0,state:null};default:throw Error(a(444,e))}}function Vr(e){return'href="'+Ne(e)+'"'}function el(e){return'link[rel="stylesheet"]['+e+"]"}function Ov(e){return v({},e,{"data-precedence":e.precedence,precedence:null})}function _S(e,i,r,l){e.querySelector('link[rel="preload"][as="style"]['+i+"]")?l.loading=1:(i=e.createElement("link"),l.preload=i,i.addEventListener("load",function(){return l.loading|=1}),i.addEventListener("error",function(){return l.loading|=2}),si(i,"link",r),$e(i),e.head.appendChild(i))}function kr(e){return'[src="'+Ne(e)+'"]'}function nl(e){return"script[async]"+e}function Pv(e,i,r){if(i.count++,i.instance===null)switch(i.type){case"style":var l=e.querySelector('style[data-href~="'+Ne(r.href)+'"]');if(l)return i.instance=l,$e(l),l;var f=v({},r,{"data-href":r.href,"data-precedence":r.precedence,href:null,precedence:null});return l=(e.ownerDocument||e).createElement("style"),$e(l),si(l,"style",f),Ic(l,r.precedence,e),i.instance=l;case"stylesheet":f=Vr(r.href);var m=e.querySelector(el(f));if(m)return i.state.loading|=4,i.instance=m,$e(m),m;l=Ov(r),(f=Zi.get(f))&&Yh(l,f),m=(e.ownerDocument||e).createElement("link"),$e(m);var S=m;return S._p=new Promise(function(O,K){S.onload=O,S.onerror=K}),si(m,"link",l),i.state.loading|=4,Ic(m,r.precedence,e),i.instance=m;case"script":return m=kr(r.src),(f=e.querySelector(nl(m)))?(i.instance=f,$e(f),f):(l=r,(f=Zi.get(m))&&(l=v({},r),Zh(l,f)),e=e.ownerDocument||e,f=e.createElement("script"),$e(f),si(f,"link",l),e.head.appendChild(f),i.instance=f);case"void":return null;default:throw Error(a(443,i.type))}else i.type==="stylesheet"&&(i.state.loading&4)===0&&(l=i.instance,i.state.loading|=4,Ic(l,r.precedence,e));return i.instance}function Ic(e,i,r){for(var l=r.querySelectorAll('link[rel="stylesheet"][data-precedence],style[data-precedence]'),f=l.length?l[l.length-1]:null,m=f,S=0;S<l.length;S++){var O=l[S];if(O.dataset.precedence===i)m=O;else if(m!==f)break}m?m.parentNode.insertBefore(e,m.nextSibling):(i=r.nodeType===9?r.head:r,i.insertBefore(e,i.firstChild))}function Yh(e,i){e.crossOrigin==null&&(e.crossOrigin=i.crossOrigin),e.referrerPolicy==null&&(e.referrerPolicy=i.referrerPolicy),e.title==null&&(e.title=i.title)}function Zh(e,i){e.crossOrigin==null&&(e.crossOrigin=i.crossOrigin),e.referrerPolicy==null&&(e.referrerPolicy=i.referrerPolicy),e.integrity==null&&(e.integrity=i.integrity)}var Bc=null;function zv(e,i,r){if(Bc===null){var l=new Map,f=Bc=new Map;f.set(r,l)}else f=Bc,l=f.get(r),l||(l=new Map,f.set(r,l));if(l.has(e))return l;for(l.set(e,null),r=r.getElementsByTagName(e),f=0;f<r.length;f++){var m=r[f];if(!(m[ue]||m[Ze]||e==="link"&&m.getAttribute("rel")==="stylesheet")&&m.namespaceURI!=="http://www.w3.org/2000/svg"){var S=m.getAttribute(i)||"";S=e+S;var O=l.get(S);O?O.push(m):l.set(S,[m])}}return l}function Iv(e,i,r){e=e.ownerDocument||e,e.head.insertBefore(r,i==="title"?e.querySelector("head > title"):null)}function xS(e,i,r){if(r===1||i.itemProp!=null)return!1;switch(e){case"meta":case"title":return!0;case"style":if(typeof i.precedence!="string"||typeof i.href!="string"||i.href==="")break;return!0;case"link":if(typeof i.rel!="string"||typeof i.href!="string"||i.href===""||i.onLoad||i.onError)break;switch(i.rel){case"stylesheet":return e=i.disabled,typeof i.precedence=="string"&&e==null;default:return!0}case"script":if(i.async&&typeof i.async!="function"&&typeof i.async!="symbol"&&!i.onLoad&&!i.onError&&i.src&&typeof i.src=="string")return!0}return!1}function Bv(e){return!(e.type==="stylesheet"&&(e.state.loading&3)===0)}function MS(e,i,r,l){if(r.type==="stylesheet"&&(typeof l.media!="string"||matchMedia(l.media).matches!==!1)&&(r.state.loading&4)===0){if(r.instance===null){var f=Vr(l.href),m=i.querySelector(el(f));if(m){i=m._p,i!==null&&typeof i=="object"&&typeof i.then=="function"&&(e.count++,e=Fc.bind(e),i.then(e,e)),r.state.loading|=4,r.instance=m,$e(m);return}m=i.ownerDocument||i,l=Ov(l),(f=Zi.get(f))&&Yh(l,f),m=m.createElement("link"),$e(m);var S=m;S._p=new Promise(function(O,K){S.onload=O,S.onerror=K}),si(m,"link",l),r.instance=m}e.stylesheets===null&&(e.stylesheets=new Map),e.stylesheets.set(r,i),(i=r.state.preload)&&(r.state.loading&3)===0&&(e.count++,r=Fc.bind(e),i.addEventListener("load",r),i.addEventListener("error",r))}}var Kh=0;function yS(e,i){return e.stylesheets&&e.count===0&&Gc(e,e.stylesheets),0<e.count||0<e.imgCount?function(r){var l=setTimeout(function(){if(e.stylesheets&&Gc(e,e.stylesheets),e.unsuspend){var m=e.unsuspend;e.unsuspend=null,m()}},6e4+i);0<e.imgBytes&&Kh===0&&(Kh=62500*eS());var f=setTimeout(function(){if(e.waitingForImages=!1,e.count===0&&(e.stylesheets&&Gc(e,e.stylesheets),e.unsuspend)){var m=e.unsuspend;e.unsuspend=null,m()}},(e.imgBytes>Kh?50:800)+i);return e.unsuspend=r,function(){e.unsuspend=null,clearTimeout(l),clearTimeout(f)}}:null}function Fc(){if(this.count--,this.count===0&&(this.imgCount===0||!this.waitingForImages)){if(this.stylesheets)Gc(this,this.stylesheets);else if(this.unsuspend){var e=this.unsuspend;this.unsuspend=null,e()}}}var Hc=null;function Gc(e,i){e.stylesheets=null,e.unsuspend!==null&&(e.count++,Hc=new Map,i.forEach(SS,e),Hc=null,Fc.call(e))}function SS(e,i){if(!(i.state.loading&4)){var r=Hc.get(e);if(r)var l=r.get(null);else{r=new Map,Hc.set(e,r);for(var f=e.querySelectorAll("link[data-precedence],style[data-precedence]"),m=0;m<f.length;m++){var S=f[m];(S.nodeName==="LINK"||S.getAttribute("media")!=="not all")&&(r.set(S.dataset.precedence,S),l=S)}l&&r.set(null,l)}f=i.instance,S=f.getAttribute("data-precedence"),m=r.get(S)||l,m===l&&r.set(null,f),r.set(S,f),this.count++,l=Fc.bind(this),f.addEventListener("load",l),f.addEventListener("error",l),m?m.parentNode.insertBefore(f,m.nextSibling):(e=e.nodeType===9?e.head:e,e.insertBefore(f,e.firstChild)),i.state.loading|=4}}var il={$$typeof:P,Provider:null,Consumer:null,_currentValue:it,_currentValue2:it,_threadCount:0};function bS(e,i,r,l,f,m,S,O,K){this.tag=1,this.containerInfo=e,this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.next=this.pendingContext=this.context=this.cancelPendingCommit=null,this.callbackPriority=0,this.expirationTimes=Ct(-1),this.entangledLanes=this.shellSuspendCounter=this.errorRecoveryDisabledLanes=this.expiredLanes=this.warmLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=Ct(0),this.hiddenUpdates=Ct(null),this.identifierPrefix=l,this.onUncaughtError=f,this.onCaughtError=m,this.onRecoverableError=S,this.pooledCache=null,this.pooledCacheLanes=0,this.formState=K,this.incompleteTransitions=new Map}function Fv(e,i,r,l,f,m,S,O,K,_t,Dt,Pt){return e=new bS(e,i,r,S,K,_t,Dt,Pt,O),i=1,m===!0&&(i|=24),m=Ri(3,null,null,i),e.current=m,m.stateNode=e,i=Rf(),i.refCount++,e.pooledCache=i,i.refCount++,m.memoizedState={element:l,isDehydrated:r,cache:i},Lf(m),e}function Hv(e){return e?(e=Mr,e):Mr}function Gv(e,i,r,l,f,m){f=Hv(f),l.context===null?l.context=f:l.pendingContext=f,l=rs(i),l.payload={element:r},m=m===void 0?null:m,m!==null&&(l.callback=m),r=os(e,l,i),r!==null&&(bi(r,e,i),Po(r,e,i))}function Vv(e,i){if(e=e.memoizedState,e!==null&&e.dehydrated!==null){var r=e.retryLane;e.retryLane=r!==0&&r<i?r:i}}function Jh(e,i){Vv(e,i),(e=e.alternate)&&Vv(e,i)}function kv(e){if(e.tag===13||e.tag===31){var i=Ns(e,67108864);i!==null&&bi(i,e,67108864),Jh(e,67108864)}}function Xv(e){if(e.tag===13||e.tag===31){var i=Ni();i=Te(i);var r=Ns(e,i);r!==null&&bi(r,e,i),Jh(e,i)}}var Vc=!0;function ES(e,i,r,l){var f=H.T;H.T=null;var m=Y.p;try{Y.p=2,Qh(e,i,r,l)}finally{Y.p=m,H.T=f}}function TS(e,i,r,l){var f=H.T;H.T=null;var m=Y.p;try{Y.p=8,Qh(e,i,r,l)}finally{Y.p=m,H.T=f}}function Qh(e,i,r,l){if(Vc){var f=jh(l);if(f===null)Ih(e,i,l,kc,r),qv(e,l);else if(wS(f,e,i,r,l))l.stopPropagation();else if(qv(e,l),i&4&&-1<AS.indexOf(e)){for(;f!==null;){var m=an(f);if(m!==null)switch(m.tag){case 3:if(m=m.stateNode,m.current.memoizedState.isDehydrated){var S=G(m.pendingLanes);if(S!==0){var O=m;for(O.pendingLanes|=2,O.entangledLanes|=2;S;){var K=1<<31-gt(S);O.entanglements[1]|=K,S&=~K}pa(m),(en&6)===0&&(Tc=Se()+500,Qo(0))}}break;case 31:case 13:O=Ns(m,2),O!==null&&bi(O,m,2),wc(),Jh(m,2)}if(m=jh(l),m===null&&Ih(e,i,l,kc,r),m===f)break;f=m}f!==null&&l.stopPropagation()}else Ih(e,i,l,null,r)}}function jh(e){return e=$u(e),$h(e)}var kc=null;function $h(e){if(kc=null,e=ve(e),e!==null){var i=c(e);if(i===null)e=null;else{var r=i.tag;if(r===13){if(e=u(i),e!==null)return e;e=null}else if(r===31){if(e=h(i),e!==null)return e;e=null}else if(r===3){if(i.stateNode.current.memoizedState.isDehydrated)return i.tag===3?i.stateNode.containerInfo:null;e=null}else i!==e&&(e=null)}}return kc=e,null}function Wv(e){switch(e){case"beforetoggle":case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"resize":case"seeked":case"submit":case"toggle":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 2;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"scroll":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 8;case"message":switch(Ee()){case F:return 2;case A:return 8;case et:case mt:return 32;case Mt:return 268435456;default:return 32}default:return 32}}var td=!1,_s=null,xs=null,Ms=null,al=new Map,sl=new Map,ys=[],AS="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(" ");function qv(e,i){switch(e){case"focusin":case"focusout":_s=null;break;case"dragenter":case"dragleave":xs=null;break;case"mouseover":case"mouseout":Ms=null;break;case"pointerover":case"pointerout":al.delete(i.pointerId);break;case"gotpointercapture":case"lostpointercapture":sl.delete(i.pointerId)}}function rl(e,i,r,l,f,m){return e===null||e.nativeEvent!==m?(e={blockedOn:i,domEventName:r,eventSystemFlags:l,nativeEvent:m,targetContainers:[f]},i!==null&&(i=an(i),i!==null&&kv(i)),e):(e.eventSystemFlags|=l,i=e.targetContainers,f!==null&&i.indexOf(f)===-1&&i.push(f),e)}function wS(e,i,r,l,f){switch(i){case"focusin":return _s=rl(_s,e,i,r,l,f),!0;case"dragenter":return xs=rl(xs,e,i,r,l,f),!0;case"mouseover":return Ms=rl(Ms,e,i,r,l,f),!0;case"pointerover":var m=f.pointerId;return al.set(m,rl(al.get(m)||null,e,i,r,l,f)),!0;case"gotpointercapture":return m=f.pointerId,sl.set(m,rl(sl.get(m)||null,e,i,r,l,f)),!0}return!1}function Yv(e){var i=ve(e.target);if(i!==null){var r=c(i);if(r!==null){if(i=r.tag,i===13){if(i=u(r),i!==null){e.blockedOn=i,ei(e.priority,function(){Xv(r)});return}}else if(i===31){if(i=h(r),i!==null){e.blockedOn=i,ei(e.priority,function(){Xv(r)});return}}else if(i===3&&r.stateNode.current.memoizedState.isDehydrated){e.blockedOn=r.tag===3?r.stateNode.containerInfo:null;return}}}e.blockedOn=null}function Xc(e){if(e.blockedOn!==null)return!1;for(var i=e.targetContainers;0<i.length;){var r=jh(e.nativeEvent);if(r===null){r=e.nativeEvent;var l=new r.constructor(r.type,r);ju=l,r.target.dispatchEvent(l),ju=null}else return i=an(r),i!==null&&kv(i),e.blockedOn=r,!1;i.shift()}return!0}function Zv(e,i,r){Xc(e)&&r.delete(i)}function RS(){td=!1,_s!==null&&Xc(_s)&&(_s=null),xs!==null&&Xc(xs)&&(xs=null),Ms!==null&&Xc(Ms)&&(Ms=null),al.forEach(Zv),sl.forEach(Zv)}function Wc(e,i){e.blockedOn===i&&(e.blockedOn=null,td||(td=!0,s.unstable_scheduleCallback(s.unstable_NormalPriority,RS)))}var qc=null;function Kv(e){qc!==e&&(qc=e,s.unstable_scheduleCallback(s.unstable_NormalPriority,function(){qc===e&&(qc=null);for(var i=0;i<e.length;i+=3){var r=e[i],l=e[i+1],f=e[i+2];if(typeof l!="function"){if($h(l||r)===null)continue;break}var m=an(r);m!==null&&(e.splice(i,3),i-=3,jf(m,{pending:!0,data:f,method:r.method,action:l},l,f))}}))}function Xr(e){function i(K){return Wc(K,e)}_s!==null&&Wc(_s,e),xs!==null&&Wc(xs,e),Ms!==null&&Wc(Ms,e),al.forEach(i),sl.forEach(i);for(var r=0;r<ys.length;r++){var l=ys[r];l.blockedOn===e&&(l.blockedOn=null)}for(;0<ys.length&&(r=ys[0],r.blockedOn===null);)Yv(r),r.blockedOn===null&&ys.shift();if(r=(e.ownerDocument||e).$$reactFormReplay,r!=null)for(l=0;l<r.length;l+=3){var f=r[l],m=r[l+1],S=f[un]||null;if(typeof m=="function")S||Kv(r);else if(S){var O=null;if(m&&m.hasAttribute("formAction")){if(f=m,S=m[un]||null)O=S.formAction;else if($h(f)!==null)continue}else O=S.action;typeof O=="function"?r[l+1]=O:(r.splice(l,3),l-=3),Kv(r)}}}function Jv(){function e(m){m.canIntercept&&m.info==="react-transition"&&m.intercept({handler:function(){return new Promise(function(S){return f=S})},focusReset:"manual",scroll:"manual"})}function i(){f!==null&&(f(),f=null),l||setTimeout(r,20)}function r(){if(!l&&!navigation.transition){var m=navigation.currentEntry;m&&m.url!=null&&navigation.navigate(m.url,{state:m.getState(),info:"react-transition",history:"replace"})}}if(typeof navigation=="object"){var l=!1,f=null;return navigation.addEventListener("navigate",e),navigation.addEventListener("navigatesuccess",i),navigation.addEventListener("navigateerror",i),setTimeout(r,100),function(){l=!0,navigation.removeEventListener("navigate",e),navigation.removeEventListener("navigatesuccess",i),navigation.removeEventListener("navigateerror",i),f!==null&&(f(),f=null)}}}function ed(e){this._internalRoot=e}Yc.prototype.render=ed.prototype.render=function(e){var i=this._internalRoot;if(i===null)throw Error(a(409));var r=i.current,l=Ni();Gv(r,l,e,i,null,null)},Yc.prototype.unmount=ed.prototype.unmount=function(){var e=this._internalRoot;if(e!==null){this._internalRoot=null;var i=e.containerInfo;Gv(e.current,2,null,e,null,null),wc(),i[Vn]=null}};function Yc(e){this._internalRoot=e}Yc.prototype.unstable_scheduleHydration=function(e){if(e){var i=Gn();e={blockedOn:null,target:e,priority:i};for(var r=0;r<ys.length&&i!==0&&i<ys[r].priority;r++);ys.splice(r,0,e),r===0&&Yv(e)}};var Qv=t.version;if(Qv!=="19.2.7")throw Error(a(527,Qv,"19.2.7"));Y.findDOMNode=function(e){var i=e._reactInternals;if(i===void 0)throw typeof e.render=="function"?Error(a(188)):(e=Object.keys(e).join(","),Error(a(268,e)));return e=d(i),e=e!==null?g(e):null,e=e===null?null:e.stateNode,e};var CS={bundleType:0,version:"19.2.7",rendererPackageName:"react-dom",currentDispatcherRef:H,reconcilerVersion:"19.2.7"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"){var Zc=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!Zc.isDisabled&&Zc.supportsFiber)try{yt=Zc.inject(CS),xt=Zc}catch{}}return vl.createRoot=function(e,i){if(!o(e))throw Error(a(299));var r=!1,l="",f=ag,m=sg,S=rg;return i!=null&&(i.unstable_strictMode===!0&&(r=!0),i.identifierPrefix!==void 0&&(l=i.identifierPrefix),i.onUncaughtError!==void 0&&(f=i.onUncaughtError),i.onCaughtError!==void 0&&(m=i.onCaughtError),i.onRecoverableError!==void 0&&(S=i.onRecoverableError)),i=Fv(e,1,!1,null,null,r,l,null,f,m,S,Jv),e[Vn]=i.current,zh(e),new ed(i)},vl.hydrateRoot=function(e,i,r){if(!o(e))throw Error(a(299));var l=!1,f="",m=ag,S=sg,O=rg,K=null;return r!=null&&(r.unstable_strictMode===!0&&(l=!0),r.identifierPrefix!==void 0&&(f=r.identifierPrefix),r.onUncaughtError!==void 0&&(m=r.onUncaughtError),r.onCaughtError!==void 0&&(S=r.onCaughtError),r.onRecoverableError!==void 0&&(O=r.onRecoverableError),r.formState!==void 0&&(K=r.formState)),i=Fv(e,1,!0,i,r??null,l,f,K,m,S,O,Jv),i.context=Hv(null),r=i.current,l=Ni(),l=Te(l),f=rs(l),f.callback=null,os(r,f,l),r=l,i.current.lanes=r,It(i,r),pa(i),e[Vn]=i.current,zh(e),new Yc(i)},vl.version="19.2.7",vl}var Tx;function sw(){if(Tx)return Hd.exports;Tx=1;function s(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(s)}catch(t){console.error(t)}}return s(),Hd.exports=aw(),Hd.exports}var rw=sw();class ow{constructor(t){this.options=t,this.holders=[],this.engine=null,this.canvas=null,this.status="loading",this.unsupported=!1,this.disposeTimer=0,this.observer=null,this.observed=null}acquire(t){return window.clearTimeout(this.disposeTimer),this.holders.push(t),this.ensureEngine(),this.attachTop(),t.onStatus(this.status),()=>this.release(t)}setRunning(t,n){t.running=n,this.top===t&&this.applyRunning()}get top(){return this.holders[this.holders.length-1]}configure(t){}drag(t,n,a){var o,c;this.top===t&&((c=(o=this.engine)==null?void 0:o.drag)==null||c.call(o,n,a))}releaseDrag(t){var n,a;this.top===t&&((a=(n=this.engine)==null?void 0:n.releaseDrag)==null||a.call(n))}release(t){var n,a;if(this.holders=this.holders.filter(o=>o!==t),this.holders.length){this.attachTop();return}(n=this.engine)==null||n.stop(),this.observe(null),(a=this.canvas)==null||a.remove(),this.disposeTimer=window.setTimeout(()=>this.teardown(),5e3)}setStatus(t){this.status=t;for(const n of this.holders)n.onStatus(t)}ensureEngine(){if(this.engine||this.unsupported)return;if(!this.options.isSupported()){this.unsupported=!0,this.setStatus("failed");return}const t=document.createElement("canvas");t.className=this.options.canvasClass,t.setAttribute("aria-hidden","true"),this.canvas=t;try{this.engine=this.options.create(t,()=>this.fail())}catch{this.fail();return}const n=this.engine;this.setStatus("loading"),this.configure(n),this.resize(),n.init().then(()=>{this.engine===n&&(n.renderFrame(0),this.setStatus("ready"),this.applyRunning())}).catch(()=>this.fail())}attachTop(){var n,a;const t=this.top;!t||!this.canvas||((a=(n=this.engine)==null?void 0:n.releaseDrag)==null||a.call(n),this.canvas.parentElement!==t.mount&&t.mount.appendChild(this.canvas),this.observe(t.mount),this.resize(),this.applyRunning())}observe(t){var n;this.observed!==t&&((n=this.observer)==null||n.disconnect(),this.observed=t,t&&(this.observer??(this.observer=new ResizeObserver(()=>this.resize())),this.observer.observe(t)))}resize(){var o,c;const t=(o=this.top)==null?void 0:o.mount;if(!t||!this.engine)return;const n=t.clientWidth||window.innerWidth,a=t.clientHeight||window.innerHeight;this.engine.setSize(n,a,window.devicePixelRatio||1),this.status==="ready"&&!((c=this.top)!=null&&c.running)&&this.engine.renderFrame(0)}applyRunning(){var t;!this.engine||this.status!=="ready"||((t=this.top)!=null&&t.running?this.engine.start():this.engine.stop())}fail(){this.teardown(),this.setStatus("failed")}teardown(){var t,n;window.clearTimeout(this.disposeTimer),this.observe(null),(t=this.engine)==null||t.dispose(),this.engine=null,(n=this.canvas)==null||n.remove(),this.canvas=null,this.status!=="failed"&&(this.status="loading")}}function lw(s){const[t,n]=Qn.useState(!1);return Qn.useEffect(()=>{const a=window.matchMedia("(prefers-reduced-motion: reduce)"),o=()=>n(s&&!document.hidden&&!a.matches&&!document.documentElement.classList.contains("reduce-motion")),c=new MutationObserver(o);return c.observe(document.documentElement,{attributes:!0,attributeFilter:["class"]}),a.addEventListener("change",o),document.addEventListener("visibilitychange",o),o(),()=>{c.disconnect(),a.removeEventListener("change",o),document.removeEventListener("visibilitychange",o)}},[s]),t}class cw extends ow{constructor(){super(...arguments),this.gestureCancellers=new Map}registerGesture(t,n){return this.gestureCancellers.set(t,n),()=>{this.gestureCancellers.delete(t)}}acquire(t){this.gestureCancellers.forEach(a=>a());const n=super.acquire(t);return()=>{this.gestureCancellers.forEach(a=>a()),n()}}owns(t){return this.top===t}interact(t,n,a,o=!1){var c;return this.top===t?((c=this.engine)==null?void 0:c.interact(n,a,o))??null:null}}const Ax=new Map;function uw(s,t){let n=Ax.get(s);return n||(n=new cw({canvasClass:"rain-shelter-canvas",isSupported:()=>typeof WebGL2RenderingContext<"u",create:(a,o)=>new dr(a,s,t,o)}),Ax.set(s,n)),n}const Xd={tent:["텐트 속 빗소리","텐트 입구 조절"],window:["비 오는 창가","유리에 빗방울 길 내기"],porch:["장마철 처마","돌확 물결 만들기"],storm:["여름 뇌우","차양 열림 조절"]};function Qu({active:s,onInteraction:t,static3D:n=!1,kind:a,builder:o}){const c=Qn.useRef(null),u=Qn.useRef(null),h=Qn.useRef(null),p=Qn.useRef(t);p.current=t;const[d,g]=Qn.useState("loading"),[v,_]=Qn.useState(null),b=lw(s)&&!n,R=uw(a,o);Qn.useEffect(()=>{if(!u.current)return;const C={mount:u.current,running:!1,onStatus:g};h.current=C;const P=R.acquire(C);return()=>{h.current=null,P()}},[R]),Qn.useEffect(()=>{h.current&&R.setRunning(h.current,b)},[R,b,d]);const y=(C,P,E=!1)=>{var N;const U=h.current;if(!U||!s||d!=="ready")return;const L=R.interact(U,C,P,E);L&&(_(L.value),(N=p.current)==null||N.call(p,L))},M=Qn.useRef(y);return M.current=y,Qn.useEffect(()=>{const C=c.current,P=h.current;if(!C||!P||!s||d!=="ready")return;const E=C.closest("[data-scene-surface]")??C,U='button, input, select, textarea, a[href], summary, label, [contenteditable]:not([contenteditable="false"]), [role="button"], [role="link"], [role="slider"], [role="switch"], [role="checkbox"], [role="radio"], [tabindex]:not([tabindex="-1"]), [data-scene-control], [data-scene-no-drag], [inert]';let L=null;const N=X=>{if(!L||X.pointerId!==L.id)return;if(!R.owns(P)){W();return}const k=X.clientX-L.x,H=X.clientY-L.y;if(Math.hypot(k,H)>8&&(L.moved=!0),L.moved&&b){C.dataset.look="drag";const Y=Math.max(1,Math.min(C.clientWidth,C.clientHeight));R.drag(P,k/Y,H/Y)}},T=(X,k=!0)=>{if(!L||X&&X.pointerId!==L.id)return;const H=L;L=null,delete C.dataset.look,R.releaseDrag(P),window.removeEventListener("pointermove",N),window.removeEventListener("pointerup",z),window.removeEventListener("pointercancel",W);const Y=(X==null?void 0:X.target)instanceof Element?X.target:null;if(!k&&X&&R.owns(P)&&!(Y!=null&&Y.closest(U))&&!H.moved&&Math.hypot(X.clientX-H.x,X.clientY-H.y)<=8){const it=C.getBoundingClientRect();X.clientX>=it.left&&X.clientX<=it.right&&X.clientY>=it.top&&X.clientY<=it.bottom&&M.current((X.clientX-it.left)/it.width*2-1,1-(X.clientY-it.top)/it.height*2)}},z=X=>T(X,!1),W=X=>T(X,!0),J=X=>{if(L||!R.owns(P)||!X.isPrimary||X.button!==0)return;const k=X.target instanceof Element?X.target:null;if(!k||k.closest(U)||!E.contains(k)||E!==C&&k.closest("[data-scene-surface]")!==E||!C.contains(k)&&!k.hasAttribute("data-scene-drag"))return;const H=C.getBoundingClientRect();X.clientX<H.left||X.clientX>H.right||X.clientY<H.top||X.clientY>H.bottom||(X.pointerType==="mouse"&&X.preventDefault(),L={id:X.pointerId,x:X.clientX,y:X.clientY,moved:!1},window.addEventListener("pointermove",N),window.addEventListener("pointerup",z),window.addEventListener("pointercancel",W))},$=()=>W(),lt=R.registerGesture(P,$);return E.addEventListener("pointerdown",J),window.addEventListener("blur",$),()=>{lt(),E.removeEventListener("pointerdown",J),window.removeEventListener("blur",$),W()}},[s,R,b,d]),nn.jsxs("div",{ref:c,className:`rain-shelter rain-shelter-${a}`,"data-world":a,"data-state":d,"data-motion":b?"running":"paused","data-interaction-value":v??"",role:"group","aria-label":`${Xd[a][0]} 3D 풍경`,children:[nn.jsx("div",{ref:u,className:"rain-shelter-mount"}),d==="ready"&&nn.jsxs("button",{className:"rain-shelter-action","aria-label":Xd[a][1],disabled:!s,onClick:()=>y(0,0,!0),children:[Xd[a][1],nn.jsx("span",{"aria-hidden":"true",children:" ↗"})]}),d==="loading"&&nn.jsx("span",{className:"rain-shelter-status",role:"status",children:"쉼터를 준비하고 있어요"}),d==="failed"&&nn.jsx("span",{className:"rain-shelter-status",role:"status",children:"이 환경에서 3D 풍경을 표시할 수 없습니다."})]})}function fw(s,t=!1){const n=s[0].index!==null,a=new Set(Object.keys(s[0].attributes)),o=new Set(Object.keys(s[0].morphAttributes)),c={},u={},h=s[0].morphTargetsRelative,p=new Ie;let d=0;for(let g=0;g<s.length;++g){const v=s[g];let _=0;if(n!==(v.index!==null))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+g+". All geometries must have compatible attributes; make sure index attribute exists among all geometries, or in none of them."),null;for(const x in v.attributes){if(!a.has(x))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+g+'. All geometries must have compatible attributes; make sure "'+x+'" attribute exists among all geometries, or in none of them.'),null;c[x]===void 0&&(c[x]=[]),c[x].push(v.attributes[x]),_++}if(_!==a.size)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+g+". Make sure all geometries have the same number of attributes."),null;if(h!==v.morphTargetsRelative)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+g+". .morphTargetsRelative must be consistent throughout all geometries."),null;for(const x in v.morphAttributes){if(!o.has(x))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+g+".  .morphAttributes must be consistent throughout all geometries."),null;u[x]===void 0&&(u[x]=[]),u[x].push(v.morphAttributes[x])}if(t){let x;if(n)x=v.index.count;else if(v.attributes.position!==void 0)x=v.attributes.position.count;else return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+g+". The geometry must have either an index or a position attribute"),null;p.addGroup(d,x,g),d+=x}}if(n){let g=0;const v=[];for(let _=0;_<s.length;++_){const x=s[_].index;for(let b=0;b<x.count;++b)v.push(x.getX(b)+g);g+=s[_].attributes.position.count}p.setIndex(v)}for(const g in c){const v=wx(c[g]);if(!v)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+g+" attribute."),null;p.setAttribute(g,v)}for(const g in u){const v=u[g][0].length;if(v!==0){p.morphAttributes=p.morphAttributes||{},p.morphAttributes[g]=[];for(let _=0;_<v;++_){const x=[];for(let R=0;R<u[g].length;++R)x.push(u[g][R][_]);const b=wx(x);if(!b)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+g+" morphAttribute."),null;p.morphAttributes[g].push(b)}}}return p}function wx(s){let t,n,a,o=-1,c=0;for(let d=0;d<s.length;++d){const g=s[d];if(t===void 0&&(t=g.array.constructor),t!==g.array.constructor)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.array must be of consistent array types across matching attributes."),null;if(n===void 0&&(n=g.itemSize),n!==g.itemSize)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.itemSize must be consistent across matching attributes."),null;if(a===void 0&&(a=g.normalized),a!==g.normalized)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.normalized must be consistent across matching attributes."),null;if(o===-1&&(o=g.gpuType),o!==g.gpuType)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.gpuType must be consistent across matching attributes."),null;c+=g.count*n}const u=new t(c),h=new ti(u,n,a);let p=0;for(let d=0;d<s.length;++d){const g=s[d];if(g.isInterleavedBufferAttribute){const v=p/n;for(let _=0,x=g.count;_<x;_++)for(let b=0;b<n;b++){const R=g.getComponent(_,b);h.setComponent(_+v,b,R)}}else u.set(g.array,p);p+=g.count*n}return o!==void 0&&(h.gpuType=o),h}function hw(s,t=1e-4){t=Math.max(t,Number.EPSILON);const n={},a=s.getIndex(),o=s.getAttribute("position"),c=a?a.count:o.count;let u=0;const h=Object.keys(s.attributes),p={},d={},g=[],v=["getX","getY","getZ","getW"],_=["setX","setY","setZ","setW"];for(let C=0,P=h.length;C<P;C++){const E=h[C],U=s.attributes[E];p[E]=new U.constructor(new U.array.constructor(U.count*U.itemSize),U.itemSize,U.normalized);const L=s.morphAttributes[E];L&&(d[E]||(d[E]=[]),L.forEach((N,T)=>{const z=new N.array.constructor(N.count*N.itemSize);d[E][T]=new N.constructor(z,N.itemSize,N.normalized)}))}const x=t*.5,b=Math.log10(1/t),R=Math.pow(10,b),y=x*R;for(let C=0;C<c;C++){const P=a?a.getX(C):C;let E="";for(let U=0,L=h.length;U<L;U++){const N=h[U],T=s.getAttribute(N),z=T.itemSize;for(let W=0;W<z;W++)E+=`${Math.trunc(T[v[W]](P)*R+y)},`}if(E in n)g.push(n[E]);else{for(let U=0,L=h.length;U<L;U++){const N=h[U],T=s.getAttribute(N),z=s.morphAttributes[N],W=T.itemSize,J=p[N],$=d[N];for(let lt=0;lt<W;lt++){const X=v[lt],k=_[lt];if(J[k](u,T[X](P)),z)for(let H=0,Y=z.length;H<Y;H++)$[H][k](u,z[H][X](P))}}n[E]=u,g.push(u),u++}}const M=s.clone();for(const C in s.attributes){const P=p[C];if(M.setAttribute(C,new P.constructor(P.array.slice(0,u*P.itemSize),P.itemSize,P.normalized)),C in d)for(let E=0;E<d[C].length;E++){const U=d[C][E];M.morphAttributes[C][E]=new U.constructor(U.array.slice(0,u*U.itemSize),U.itemSize,U.normalized)}}return M.setIndex(g),M}function pm(s){return()=>{s|=0,s=s+1831565813|0;let t=Math.imul(s^s>>>15,1|s);return t=t+Math.imul(t^t>>>7,61|t)^t,((t^t>>>14)>>>0)/4294967296}}function ka(s,t,n=.78){const a=document.createElement("canvas");a.width=a.height=512;const o=a.getContext("2d"),c=pm(s.charCodeAt(0)*67),u=o.createImageData(512,512);for(let d=0;d<512;d++)for(let g=0;g<512;g++){let v=220;if(s==="wood"){const x=4*Math.sin(d*.018)+1.7*Math.sin(d*.062);v+=Math.sin((g+x)*.28)*13+Math.sin((g+x)*1.19)*5+(c()-.5)*22}else s==="fabric"?v+=(g%4<2?9:-12)+(d%4<2?8:-10)+(c()-.5)*13:s==="leaf"?v+=Math.cos(g*.044)*9+(c()-.5)*10:v+=(c()-.5)*38+Math.sin(g*.063+Math.sin(d*.027)*3)*7+Math.cos(d*.071)*5;const _=(d*512+g)*4;u.data[_]=u.data[_+1]=u.data[_+2]=v,u.data[_+3]=255}if(o.putImageData(u,0,0),s==="wood")for(let d=0;d<34;d++){const g=c()*512;o.beginPath(),o.moveTo(g,0);for(let v=0;v<=512;v+=8)o.lineTo(g+3*Math.sin(v*.025+d),v);o.strokeStyle=`rgba(48,30,17,${.035+c()*.1})`,o.lineWidth=.5+c(),o.stroke()}const h=new rr(a);h.colorSpace=Ln,h.wrapS=h.wrapT=Ka,h.anisotropy=4;const p=h.clone();return p.colorSpace=Xa,new ge({color:t,map:h,bumpMap:p,bumpScale:s==="stone"?.028:s==="fabric"?.012:.017,roughness:n,metalness:0})}function dw(s,t={}){const{count:n=900,width:a=18,height:o=13,depth:c=22,z:u=-12,speed:h=7.5,color:p="#c8dadd",opacity:d=.25}=t,g=pm(711),v=new Float32Array(n*6),_=new Float32Array(n*2);for(let y=0;y<n;y++){const M=(g()-.5)*a,C=g()*o,P=u+(g()-.5)*c;for(let E=0;E<2;E++){const U=y*6+E*3;v[U]=M,v[U+1]=C,v[U+2]=P,_[y*2+E]=E}}const x=new Ie;x.setAttribute("position",new ti(v,3)),x.setAttribute("aEnd",new ti(_,1));const b=new ui({transparent:!0,depthWrite:!1,uniforms:{uTime:{value:0},uColor:{value:new ce(p)},uOpacity:{value:d}},vertexShader:`attribute float aEnd; uniform float uTime; varying float vDepth; void main(){vec3 p=position;p.y=mod(p.y-uTime*${h.toFixed(3)}+10000.,${o.toFixed(3)})-.2;p.y+=aEnd*.18;p.x+=aEnd*.045;vec4 mv=modelViewMatrix*vec4(p,1.);vDepth=-mv.z;gl_Position=projectionMatrix*mv;}`,fragmentShader:`uniform vec3 uColor; uniform float uOpacity; varying float vDepth; void main(){gl_FragColor=vec4(uColor,uOpacity*clamp(1.-vDepth/70.,.1,1.)); #include <tonemapping_fragment>
 #include <colorspace_fragment>
}`.replace("; #include",`;
#include`)}),R=new sr(x,b);return R.frustumCulled=!1,R.name="outside-rain",s.add(R),{update(y){b.uniforms.uTime.value=y},mesh:R}}const pw=({scene:s,camera:t})=>{var wt,Lt;const n=pm(190719);s.background=new ce("#586d69"),s.fog=new vo("#677e78",.052),s.add(new qu("#b7d3d3","#343b2b",1.15));const a=new Yu("#c5e0df",1.8);a.position.set(-6,12,-10),s.add(a);const o=new Bl("#efd9b3",1.4,7,2);o.position.set(0,1.3,2),s.add(o);const c=(q,Z=512)=>{const at=document.createElement("canvas");at.width=at.height=Z;const w=at.getContext("2d");q(w);const G=new rr(at);return G.wrapS=G.wrapT=Ka,G.colorSpace=Ln,G.anisotropy=4,G},u=c(q=>{q.fillStyle="#bbb59f",q.fillRect(0,0,512,512);for(let Z=0;Z<512;Z+=2)q.strokeStyle=Z%4?"rgba(55,43,28,.08)":"rgba(247,228,177,.13)",q.beginPath(),q.moveTo(Z,0),q.lineTo(Z,512),q.stroke(),q.beginPath(),q.moveTo(0,Z),q.lineTo(512,Z),q.stroke();for(let Z=0;Z<5500;Z++)q.fillStyle=`rgba(32,29,21,${n()*.06})`,q.fillRect(n()*512,n()*512,1,1);for(let Z=0;Z<7;Z++){const at=n()*512,w=q.createLinearGradient(at-12,0,at+12,0);w.addColorStop(0,"rgba(50,41,28,0)"),w.addColorStop(.5,"rgba(50,41,28,.055)"),w.addColorStop(1,"rgba(240,226,179,0)"),q.fillStyle=w,q.fillRect(at-12,0,24,512)}});u.repeat.set(6,12);const h=new ge({map:u,color:"#d5d2b7",roughness:.94,side:vn,bumpMap:u,bumpScale:.006}),p=ka("fabric","#796444",.97),d=new ge({color:"#3e4947",metalness:.7,roughness:.38}),g=new ge({color:"#d3bd8c",roughness:.94}),v=(q,Z,at=0,w=0,G=0,V=s)=>{const nt=new le(q,Z);return nt.position.set(at,w,G),V.add(nt),nt},_=(q,Z,at,w=s,G=32)=>v(new zl(new Iu(q),G,Z,6,!1),at,0,0,0,w),x=new Ie,b=[],R=[],y=[],M=72,C=44,P=(q,Z)=>{const at=q*Math.PI,w=-1.72+Z*6.1,G=.052*Math.sin(Z*Math.PI)*Math.sin(at*19+Z*7)+.025*Math.sin(at*31+Z*17)*Math.sin(at);return new B(Math.cos(at)*(2.08+G),.025+Math.sin(at)*(2.12+G),w)};for(let q=0;q<=C;q++)for(let Z=0;Z<=M;Z++){const at=P(Z/M,q/C);b.push(at.x,at.y,at.z),R.push(Z/M,q/C)}for(let q=0;q<C;q++)for(let Z=0;Z<M;Z++){const at=q*(M+1)+Z,w=at+M+1;y.push(at,w,at+1,w,w+1,at+1)}x.setAttribute("position",new ae(b,3)),x.setAttribute("uv",new ae(R,2)),x.setIndex(y),x.computeVertexNormals(),v(x,h);for(const q of[0,.43,.88]){const Z=Array.from({length:45},(at,w)=>P(w/44,q));_(Z,.027,d),_(Z.map(at=>at.clone().add(new B(0,-.024,.034))),.017,p)}for(const q of[.16,.36,.65,.84])_(Array.from({length:26},(Z,at)=>P(q,at/25).multiply(new B(.993,.994,1))),.008,p);const E=v(new jn(4.17,6.35,10,18),ka("fabric","#514c38",.99),0,.018,1.27);E.rotation.x=-Math.PI/2;for(const q of[-1.85,1.85])_([new B(q,.055,-1.65),new B(q,.055,1),new B(q,.07,4.15)],.019,p);const U=new Ii;s.add(U);const L=[];for(const q of[-1,1]){const Z=new Ie,at=[],w=[],G=[],V=36,nt=20;for(let Me=0;Me<=V;Me++)for(let be=0;be<=nt;be++){const Te=Me/V,cn=be/nt,Gn=.035+Te*2.085,ei=2.09*Math.sqrt(Math.max(0,1-Te*Te)),On=.96*Math.pow(1-Te,.58)+.02,Ze=q*$s.lerp(On,Math.max(On,ei),cn),un=.085*Math.sin(cn*8*Math.PI+Te*5)*Math.sin(Math.PI*cn);at.push(Ze,Gn,-1.65+un+.05*Math.sin(Te*13)),w.push(cn,Te)}for(let Me=0;Me<V;Me++)for(let be=0;be<nt;be++){const Te=Me*(nt+1)+be,cn=Te+nt+1;G.push(Te,cn,Te+1,cn,cn+1,Te+1)}Z.setAttribute("position",new ae(at,3)),Z.setAttribute("uv",new ae(w,2)),Z.setIndex(G),Z.computeVertexNormals();const ot=v(Z,h,0,0,0,U);L.push(ot);const st=Array.from({length:40},(Me,be)=>{const Te=be/39;return new B(q*(.96*Math.pow(1-Te,.58)+.02),.035+Te*2.085,-1.585+.05*Math.sin(Te*13))}),Ct=_(st,.014,p,ot),It=new Ie,te=[];for(let Me=1;Me<st.length-1;Me++){const be=st[Me];te.push(be.x-.01,be.y,be.z+.02,be.x+.01,be.y+.007,be.z+.02)}It.setAttribute("position",new ae(te,3)),Ct.add(new sr(It,new ar({color:"#dbc697",transparent:!0,opacity:.8})));const se=v(new tr(.045,.011,6,18),g,q*1.09,.65,-1.48,ot);se.rotation.y=.3}for(const q of[-1,1])_([new B(q*1.95,.25,-1.72),new B(q*2.85,.04,-3.7)],.01,g),v(new Sn(.017,.022,.24,5),d,q*2.85,.03,-3.7).rotation.z=q*.25;const N=new Op;N.moveTo(-1.22,.03),N.lineTo(1.22,.03),N.quadraticCurveTo(.77,1.32,0,2.1),N.quadraticCurveTo(-.77,1.32,-1.22,.03);const T=v(new Bu(N),new qa({colorWrite:!1,depthWrite:!1,side:vn}),0,0,-1.57);T.name="tent-entrance-interaction";const z=ka("fabric","#294c50",.94);(wt=z.map)==null||wt.repeat.set(2,2),(Lt=z.bumpMap)==null||Lt.repeat.set(2,2),z.bumpScale=.004;const W=new Ie,J=[],$=[],lt=[],X=52,k=100,H=(q,Z,at=!1)=>{const w=-.78+Z*4,G=.54+.28*Math.sin(Z*Math.PI*.69),V=(q*2-1)*G,nt=Math.pow(Math.max(0,1-Math.pow(q*2-1,2)),.65),ot=at?-.004:.044*Math.pow(Math.sin(Z*Math.PI*13),2),st=.013*Math.sin(q*31+Z*17)*(1-nt);return new B(V-.03,.04+nt*(.245+.08*Z+ot)+st,w)};for(let q=0;q<=k;q++)for(let Z=0;Z<=X;Z++){const at=H(Z/X,q/k);J.push(at.x,at.y,at.z),$.push(Z/X*2,q/k*5)}for(let q=0;q<k;q++)for(let Z=0;Z<X;Z++){const at=q*(X+1)+Z,w=at+X+1;lt.push(at,w,at+1,w,w+1,at+1)}W.setAttribute("position",new ae(J,3)),W.setAttribute("uv",new ae($,2)),W.setIndex(lt),W.computeVertexNormals(),v(W,z);const Y=new ge({color:"#819590",roughness:1});for(let q=1;q<13;q++)_(Array.from({length:40},(Z,at)=>H(at/39,q/13,!0).add(new B(0,.004,0))),.0035,Y,s,39);_(Array.from({length:40},(q,Z)=>H(.975,Z/39).add(new B(.007,.008,0))),.012,p);const it=v(new jn(.85,.62,30,20),ka("fabric","#998363",1),-.49,.2,1.63),rt=it.geometry.attributes.position;for(let q=0;q<rt.count;q++)rt.setZ(q,.025*Math.sin(rt.getX(q)*35)+.02*Math.cos(rt.getY(q)*14));it.geometry.computeVertexNormals(),it.rotation.set(-Math.PI/2,.05,-.26);const ht=new Ii;ht.position.set(-.88,.027,.4),s.add(ht);const I=new ge({color:"#554b32",metalness:.78,roughness:.32}),ct=new ge({color:"#ffd48a",emissive:"#ffbd64",emissiveIntensity:1.9,roughness:.5}),Tt=new Il({color:"#faecd1",transparent:!0,opacity:.15,roughness:.12,metalness:.08,side:vn,depthWrite:!1});v(new Sn(.12,.155,.075,24),I,0,.055,0,ht),v(new Sn(.104,.11,.245,24,1,!0),Tt,0,.215,0,ht),v(new Sn(.047,.06,.175,20),ct,0,.19,0,ht),v(new Sn(.15,.13,.035,24),I,0,.352,0,ht),v(new Xu(.12,.075,24),I,0,.4,0,ht),v(new Sn(.038,.038,.028,16),I,0,.446,0,ht);for(let q=0;q<6;q++){const Z=q*Math.PI/3;_([new B(Math.cos(Z)*.125,.075,Math.sin(Z)*.125),new B(Math.cos(Z)*.132,.22,Math.sin(Z)*.132),new B(Math.cos(Z)*.121,.355,Math.sin(Z)*.121)],.009,I,ht,12)}_(Array.from({length:22},(q,Z)=>{const at=Z/21*Math.PI;return new B(Math.cos(at)*.13,.385+Math.sin(at)*.16,0)}),.009,I,ht,22);const Ut=new Bl("#ffce86",5.2,4.8,2);Ut.position.set(-.88,.26,.4),s.add(Ut);const Vt=c(q=>{const Z=q.createRadialGradient(256,256,15,256,256,250);Z.addColorStop(0,"rgba(0,0,0,.65)"),Z.addColorStop(.48,"rgba(0,0,0,.2)"),Z.addColorStop(1,"rgba(0,0,0,0)"),q.fillStyle=Z,q.fillRect(0,0,512,512)}),Bt=new qa({map:Vt,transparent:!0,depthWrite:!1}),ft=v(new jn(.8,.75),Bt,-.88,.031,.4);ft.rotation.x=-Math.PI/2;const Et=new jn(46,48,68,68),Ft=Et.attributes.position;for(let q=0;q<Ft.count;q++){const Z=Ft.getX(q),at=Ft.getY(q);Ft.setZ(q,.09*Math.sin(Z*.47)*Math.cos(at*.39)+.025*Math.sin(Z*2.4+at))}Et.computeVertexNormals();const $t=v(Et,ka("earth","#353c2b",.91),0,-.115,-19);$t.rotation.x=-Math.PI/2;const Xt=new ge({color:"#638379",roughness:.2,metalness:.33,transparent:!0,opacity:.64});for(let q=0;q<9;q++){const Z=new Op,at=.32+n()*.9,w=.25+n()*.8;for(let V=0;V<=30;V++){const nt=V/30*Math.PI*2,ot=1+.13*Math.sin(nt*3)+.1*Math.cos(nt*5),st=Math.cos(nt)*at*ot,Ct=Math.sin(nt)*w*ot;V?Z.lineTo(st,Ct):Z.moveTo(st,Ct)}const G=v(new Bu(Z),Xt,(n()-.5)*8,-.007,-3.1-n()*9);G.rotation.x=-Math.PI/2}const oe=ka("wood","#343d31",.99),Ye=ka("wood","#485244",.96),jt=new Ii;s.add(jt);const de=ka("leaf","#385644",.94);de.side=vn;const xe=new Ie,pe=[],Ce=[],Xe=[];for(let q=0;q<=8;q++)for(let Z=0;Z<3;Z++){const at=q/8,w=Z-1;pe.push(w*Math.sin(at*Math.PI)*.23,at-.5,Math.sin(at*Math.PI)*(.06-Math.abs(w)*.04)),Ce.push(Z/2,at)}for(let q=0;q<8;q++)for(let Z=0;Z<2;Z++){const at=q*3+Z;Xe.push(at,at+1,at+3,at+1,at+4,at+3)}xe.setAttribute("position",new ae(pe,3)),xe.setAttribute("uv",new ae(Ce,2)),xe.setIndex(Xe),xe.computeVertexNormals();const Be=new Nn(xe,de,8e3);Be.instanceMatrix.setUsage(qx),jt.add(Be);const ie=new An;let Ue=0;const j=(q,Z,at,w,G,V)=>{Ue>=8e3||(ie.position.set(q,Z,at),ie.rotation.set(.8+n()*1.1,n()*Math.PI*2,V),ie.scale.set(w,G,1),ie.updateMatrix(),Be.setMatrixAt(Ue++,ie.matrix))};for(let q=0;q<38;q++){let Z=(n()-.5)*34,at=-4.3-n()*29;q<5&&(Z=[-3.1,3.7,-1.7,1.4,-.45][q],at=[-5.5,-7.2,-10,-12,-20][q]);const w=7+n()*9,G=.13+n()*.26,V=v(new Sn(G*.38,G,w,13,12),q%3?oe:Ye,Z,w/2-.1,at,jt),nt=V.geometry.attributes.position;for(let ot=0;ot<nt.count;ot++){const st=nt.getY(ot),Ct=Math.atan2(nt.getZ(ot),nt.getX(ot)),It=1+.08*Math.sin(Ct*5+Math.sin(st*.8));nt.setX(ot,nt.getX(ot)*It+.055*Math.sin(st*1.2+q)),nt.setZ(ot,nt.getZ(ot)*It)}V.geometry.computeVertexNormals(),V.rotation.z=(n()-.5)*.09;for(let ot=0;ot<4;ot++){const st=n()*Math.PI*2;_([new B(Z,.23,at),new B(Z+Math.cos(st)*G*1.7,.025,at+Math.sin(st)*G*1.7),new B(Z+Math.cos(st)*G*3,-.04,at+Math.sin(st)*G*3)],G*.18,oe,jt,10)}for(let ot=0;ot<5;ot++){const st=n()*Math.PI*2,Ct=3.6+ot*w*.105,It=1.3+n()*1.6,te=new B(Z+Math.cos(st)*It,Ct+.38,at+Math.sin(st)*It);_([new B(Z,Ct,at),new B((Z+te.x)/2,Ct+.1,(at+te.z)/2),te],G*.17,oe,jt,10);for(let se=0;se<25;se++){const Me=.12+n()*.93;j($s.lerp(Z,te.x,Me)+(n()-.5)*.8,Ct+.4*Me+(n()-.5)*.45,$s.lerp(at,te.z,Me)+(n()-.5)*.8,.3+n()*.38,.34+n()*.45,st)}}}jt.updateMatrixWorld(!0);for(const q of[oe,Ye]){const Z=jt.children.filter(G=>G instanceof le&&!(G instanceof Nn)&&G.material===q),at=Z.map(G=>G.geometry.clone().applyMatrix4(G.matrix)),w=fw(at,!1);w&&v(w,q,0,0,0,jt);for(const G of Z)jt.remove(G),G.geometry.dispose();for(const G of at)G.dispose()}const Se=[];for(let q=0;q<28;q++){const Z=(n()-.5)*13,at=-2.8-n()*12;if(!(Math.abs(Z)<.55&&at>-5))for(let w=0;w<7;w++){const G=w/7*Math.PI*2+n()*.25,V=.6+n()*.65,nt=ot=>new B(Z+Math.cos(G)*V*ot,.025+Math.sin(ot*Math.PI*.85)*V*.68,at+Math.sin(G)*V*ot);for(let ot=1;ot<10;ot++){const st=nt(ot/10),Ct=nt((ot-1)/10);Se.push(st.x,st.y,st.z,Ct.x,Ct.y,Ct.z);for(const It of[-1,1]){const te=.15*Math.sin(ot/10*Math.PI)+.045;if(Ue<8e3){const se=new B(Math.cos(G+It*1.25),.25,Math.sin(G+It*1.25)).normalize();ie.position.set(st.x+se.x*te*.5,st.y,st.z+se.z*te*.5),ie.quaternion.setFromUnitVectors(new B(0,1,0),se),ie.scale.set(te*.85,te*1.6,1),ie.updateMatrix(),Be.setMatrixAt(Ue++,ie.matrix)}}}}}Be.count=Ue,Be.instanceMatrix.needsUpdate=!0;const Ee=new Ie;Ee.setAttribute("position",new ae(Se,3)),jt.add(new sr(Ee,new ar({color:"#526b40"})));const F=ka("stone","#454d42",.83),A=new Nn(new _o(1,1),F,60);s.add(A);for(let q=0;q<60;q++){ie.position.set((n()-.5)*18,-.08,-2.4-n()*18),ie.rotation.set(n(),n()*6.2,n());const Z=.06+n()*.22;ie.scale.set(Z*1.6,Z*.55,Z),ie.updateMatrix(),A.setMatrixAt(q,ie.matrix)}const et=v(new Sn(.18,.22,3.8,10),oe,-2.3,.18,-5.5);et.rotation.set(0,-.32,Math.PI/2);const mt=c(q=>{q.fillStyle="#948063",q.fillRect(0,0,512,512);for(let Z=0;Z<32;Z++)q.beginPath(),q.ellipse(249,265,6+Z*8.3,5+Z*7.7,.12,0,Math.PI*2),q.strokeStyle=`rgba(53,42,29,${.1+n()*.2})`,q.lineWidth=1+n()*2.5,q.stroke();q.strokeStyle="#443f30",q.lineWidth=3;for(let Z=0;Z<5;Z++){const at=n()*6.28;q.beginPath(),q.moveTo(256+Math.cos(at)*245,256+Math.sin(at)*245),q.lineTo(256+Math.cos(at+.1)*100,256+Math.sin(at+.1)*100),q.stroke()}}),Mt=v(new Cs(.216,20),new ge({map:mt,color:"#aaa18b",roughness:.92}),0,-1.905,0,et);Mt.rotation.x=Math.PI/2;const Ht=dw(s,{count:1400,width:29,height:17,depth:27,z:-16,speed:8.5,color:"#d0e1de",opacity:.29}),kt=new Il({color:"#c1ded4",metalness:.05,roughness:.06,transparent:!0,opacity:.63}),yt=new Nn(new Wu(1,6,5),kt,47);s.add(yt);for(let q=0;q<47;q++){const Z=.09+q/46*(Math.PI-.18),at=.01+n()*.012;ie.position.set(Math.cos(Z)*2.09,Math.sin(Z)*2.12,-1.75),ie.rotation.set(0,0,0),ie.scale.set(at,at*1.4,at),ie.updateMatrix(),yt.setMatrixAt(q,ie.matrix)}for(let q=0;q<2;q++){const Z=q?1:-1,at=new Nn(yt.geometry,kt,24);L[q].add(at);for(let w=0;w<24;w++){const G=.08+n()*.86,V=.007+n()*.006;ie.position.set(Z*(.96*Math.pow(1-G,.58)+.03+n()*.05),.035+G*2.085,-1.54+.05*Math.sin(G*13)),ie.rotation.set(0,0,0),ie.scale.set(V,V*1.7,V*.65),ie.updateMatrix(),at.setMatrixAt(w,ie.matrix)}}let xt=.68,zt=.68;const gt=new Zu;return{update(q,Z){xt=$s.damp(xt,zt,2.1,Z);const at=.8+xt*.38;L[0].scale.x=at,L[1].scale.x=at,L[0].position.x=-.1*xt,L[1].position.x=.1*xt,Ut.intensity=5.2+Math.sin(q*.71)*.055,Ht.update(q)},resize(q){const Z=q<.82;ht.position.set(Z?-.62:-.88,.027,Z?-.52:.4),Ut.position.set(ht.position.x,.26,ht.position.z),ft.position.set(ht.position.x,.031,ht.position.z),t.fov=Z?69:62,t.position.set(Z?0:.1,Z?.75:.78,Z?1.77:2.05),t.lookAt(Z?0:.02,Z?.84:.83,-6),t.updateProjectionMatrix()},interact(q,Z,at=!1,w=!1){return!at&&(gt.setFromCamera(new Ot(q,Z),t),!gt.intersectObjects([...L,T],!1)[0])?null:(zt=zt>.5?.2:.95,w&&(xt=zt),{action:"opening",value:zt})}}};function mw(s){return nn.jsx(Qu,{...s,kind:"tent",builder:pw})}function gw(s){const t=[],n=[],a=[],u=.13+s*.036,h=(s-1.5)*.025;for(let d=0;d<=20;d++){const g=d/20,v=Math.pow(Math.max(0,Math.sin(Math.PI*g)),.8),_=v*(.48-g*.1)*(1+.035*Math.sin(g*Math.PI*15));for(let x=0;x<=6;x++){const b=x/6*2-1,R=1+b*(.05+s*.012)*Math.sin(g*Math.PI);t.push(b*_*R+h*g*g,g-.025*b*b*v,.075*v-u*g*g+b*b*v*(.075+s*.008)+h*b*g+.012*Math.sin(g*4*Math.PI+s)*b*b),n.push(x/6,g)}}for(let d=0;d<20;d++)for(let g=0;g<6;g++){const v=d*7+g,_=v+6+1;a.push(v,v+1,_,v+1,_+1,_)}const p=new Ie;return p.setAttribute("position",new ae(t,3)),p.setAttribute("uv",new ae(n,2)),p.setIndex(a),p.computeVertexNormals(),p}function vw(s){const t=[],n=[],a=[];for(let h=0;h<=8;h++){const p=h/8,d=Math.pow(Math.max(0,Math.sin(Math.PI*p)),.55),g=d*(.41+p*.16);for(let v=0;v<=6;v++){const _=v/6*2-1;t.push(_*g*(1+.06*_*Math.sin(p*Math.PI+s))+(s-1.5)*.02*p*p,p+.02*_*Math.sin(p*Math.PI*2+s),(.06+s*.018)*_*_*d+.052*d-(.045+s*.02)*p*p+.021*_*Math.sin(p*Math.PI+s)),n.push(v/6,p)}}for(let h=0;h<8;h++)for(let p=0;p<6;p++){const d=h*7+p,g=d+6+1;a.push(d,d+1,g,d+1,g+1,g)}const u=new Ie;return u.setAttribute("position",new ae(t,3)),u.setAttribute("uv",new ae(n,2)),u.setIndex(a),u.computeVertexNormals(),u}function Rx(s){const t=s==="leaf",n=new ge({color:"#ffffff",roughness:t?.57:.76,side:vn});return n.defines={USE_UV:""},n.customProgramCacheKey=()=>`rain-garden-${s}-organic-v1`,n.onBeforeCompile=a=>{a.fragmentShader=a.fragmentShader.replace("#include <color_fragment>",t?`#include <color_fragment>
        float gardenMidrib = 1.0-smoothstep(0.006,0.021,abs(vUv.x-0.5));
        float gardenVeins = pow(max(0.0,cos((vUv.y-abs(vUv.x-0.5)*0.57)*73.0)),18.0);
        float gardenEdge = smoothstep(0.31,0.50,abs(vUv.x-0.5));
        diffuseColor.rgb *= 0.88+0.12*sin(vUv.y*3.14159)-gardenEdge*0.08;
        diffuseColor.rgb += vec3(0.065,0.075,0.021)*(gardenMidrib*0.60+gardenVeins*0.16);
        diffuseColor.rgb *= 0.78+0.22*smoothstep(0.0,0.23,vUv.y);`:`#include <color_fragment>
        float gardenVeins = pow(max(0.0,cos((vUv.x-0.5)*(14.0+vUv.y*22.0))),16.0);
        diffuseColor.rgb *= 0.79+0.17*vUv.y+gardenVeins*0.035;
        diffuseColor.rgb = mix(diffuseColor.rgb,diffuseColor.rgb*vec3(0.64,0.71,0.75),pow(1.0-vUv.y,3.0)*0.62);`),a.fragmentShader=a.fragmentShader.replace("#include <roughnessmap_fragment>",`#include <roughnessmap_fragment>
      roughnessFactor = clamp(roughnessFactor + 0.035*sin(vUv.y*23.0+vUv.x*11.0) + 0.018*cos(vUv.x*47.0-vUv.y*19.0),0.35,0.90);`),a.fragmentShader=a.fragmentShader.replace("#include <lights_fragment_end>",`#include <lights_fragment_end>
      #if NUM_DIR_LIGHTS > 0
        float gardenBacklight = pow(max(0.0,dot(-normal,directionalLights[0].direction)),1.7);
        float gardenThinEdge = smoothstep(0.20,0.49,abs(vUv.x-0.5));
        reflectedLight.directDiffuse += diffuseColor.rgb * directionalLights[0].color * gardenBacklight * (${t?"0.035+gardenThinEdge*0.055":"0.055+gardenThinEdge*0.060"});
      #endif`)},n}const Vp=s=>()=>(s=s*1664525+1013904223>>>0,s/4294967296);function _w(s,t,n){const a=document.createElement("canvas");a.width=a.height=512;const o=a.getContext("2d"),c=Vp(n);o.fillStyle=s,o.fillRect(0,0,512,512);for(let h=0;h<(t==="wood"?1600:2e4);h++){const p=c()*512,d=c()*512;o.fillStyle=`rgba(${c()<.5?"255,238,205":"24,31,20"},${c()*.16})`,t==="wood"?(o.beginPath(),o.ellipse(p,d,.12+c()*.55,18+c()*240,.015*Math.sin(p),0,Math.PI*2),o.fill()):o.fillRect(p,d,1+c()*4,1+c()*5)}if(t==="wood")for(let h=0;h<3;h++){const p=60+c()*370,d=c()*512;for(let g=3;g<25;g+=2)o.strokeStyle=`rgba(41,26,14,${.09-g*.002})`,o.beginPath(),o.ellipse(p,d,g*.32,g,-.06,0,Math.PI*2),o.stroke()}const u=new rr(a);return u.wrapS=u.wrapT=Ka,u.colorSpace=Ln,u.anisotropy=4,u}function xw(){const s=[],t=[],n=[];for(let c=0;c<=14;c++){const u=c/14,h=Math.pow(Math.sin(u*Math.PI),.75)*.45*(c%2?.87:1);for(let p=0;p<3;p++){const d=p-1;s.push(d*h,u,(d?-.055:.028)*Math.sin(u*Math.PI)+.12*u*u),t.push(p/2,u)}}for(let c=0;c<14;c++)for(let u=0;u<2;u++){const h=c*3+u,p=h+3;n.push(h,p,h+1,h+1,p,p+1)}const o=new Ie;return o.setAttribute("position",new ae(s,3)),o.setAttribute("uv",new ae(t,2)),o.setIndex(n),o.computeVertexNormals(),o}function Mw(){const s=[],t=[],n=[];for(let u=0;u<=7;u++){const h=u/7,p=Math.pow(Math.max(0,Math.sin(Math.PI*h)),.52)*(.44+h*.2);for(let d=0;d<=7;d++){const g=d/7*2-1;s.push(g*p,h,.055*Math.sin(h*Math.PI)+.065*g*g*h-.055*h*h),t.push(d/7,h)}}for(let u=0;u<7;u++)for(let h=0;h<7;h++){const p=u*8+h,d=p+7+1;n.push(p,d,p+1,d,d+1,p+1)}const c=new Ie;return c.setAttribute("position",new ae(s,3)),c.setAttribute("uv",new ae(t,2)),c.setIndex(n),c.computeVertexNormals(),c}const yw=({scene:s,camera:t,renderer:n})=>{const a=Vp(83059);s.background=new ce("#a6bab6"),s.fog=new vo("#b4c5bf",.021);const o=new Ii;s.add(o);const c=[],u=(gt,wt,Lt)=>{const q=_w(gt,wt,Lt);return c.push(q),q},h=u("#82745e","wood",13),p=new ge({map:h,color:"#c7c4b3",roughness:.68,bumpMap:h,bumpScale:.018}),d=h.clone();d.center.set(.5,.5),d.rotation=Math.PI/2,d.repeat.set(1,3),c.push(d);const g=new ge({map:d,color:"#c7c4b3",roughness:.65,bumpMap:d,bumpScale:.008}),v=new ge({map:h,color:"#67543c",roughness:.74,bumpMap:h,bumpScale:.012}),_=u("#434c33","earth",32);_.repeat.set(8,8);const x=new ge({map:_,roughness:.98,bumpMap:_,bumpScale:.07}),b=u("#78817a","stone",55),R=new ge({map:b,color:"#b5b6a7",roughness:.72,bumpMap:b,bumpScale:.042}),y=new ge({color:"#655b41",roughness:.42,metalness:.62}),M=Rx("leaf"),C=Rx("sepal"),P=[],E=(gt,wt,Lt,q,Z,at,w,G=s)=>{const V=new le(new Qa(gt,wt,Lt),w);return V.position.set(q,Z,at),V.castShadow=V.receiveShadow=!0,G.add(V),G===s&&P.push(V),V},U=(gt,wt,Lt,q,Z=o)=>{const at=new le(new Sn(Lt*.72,Lt,gt.distanceTo(wt),7),q);return at.position.copy(gt).add(wt).multiplyScalar(.5),at.quaternion.setFromUnitVectors(new B(0,1,0),wt.clone().sub(gt).normalize()),Z.add(at),at},L=new qu("#d8edf0","#748052",1.5);s.add(L);const N=new Yu("#e7f4f4",1.8);N.position.set(-3,7,2),N.castShadow=!0,N.shadow.mapSize.set(1024,1024),N.shadow.camera.left=-8,N.shadow.camera.right=8,N.shadow.camera.top=7,N.shadow.camera.bottom=-4,N.shadow.bias=-.002,N.shadow.normalBias=.035,N.shadow.radius=3,s.add(N);const T=new Bl("#ffdaa4",2.7,7,2);T.position.set(1.7,2.5,2.7),s.add(T),E(6.9,.18,.66,0,.57,.12,v),E(6.8,.11,1.15,0,.67,.44,g).geometry.translate(0,0,0),E(.26,3.9,.3,-3.02,2,.02,p),E(.26,3.9,.3,3.02,2,.02,p),E(6.3,.28,.35,0,3.67,.02,p),E(.13,2.82,.17,-.63,2.16,.08,p),E(5.8,.075,.15,0,2.93,.08,p);for(const gt of[-2.85,2.85])E(.035,2.94,.06,gt,2.14,.17,v);for(const gt of[.8,3.5])E(5.7,.035,.06,0,gt,.17,v);for(const gt of[-3.03,3.03,-.63])for(const wt of[.88,3.35]){const Lt=new le(new Sn(.022,.022,.006,10),v);Lt.rotation.x=Math.PI/2,Lt.position.set(gt,wt,.183),s.add(Lt)}E(.06,.19,.02,-.625,1.63,.18,y),E(.13,.025,.037,-.57,1.64,.205,y);const W=new ge({color:"#c9bfac",roughness:.96});E(2.5,5,.2,-4.4,2,.05,W),E(2.5,5,.2,4.4,2,.05,W),E(9,1.3,.2,0,-.11,.07,W);const J=[new Ot(.035,0),new Ot(.16,.016),new Ot(.24,.085),new Ot(.254,.13),new Ot(.24,.137),new Ot(.222,.09),new Ot(.148,.036),new Ot(.04,.025)],$=new ge({color:"#92a8a0",roughness:.29,metalness:.05}),lt=new le(new Hl(J,40),$);lt.position.set(.38,.733,.44),lt.receiveShadow=lt.castShadow=!0,s.add(lt);const X=new le(new Cs(.197,40),new Il({color:"#627f79",roughness:.08,metalness:.25,clearcoat:1,transparent:!0,opacity:.85}));X.rotation.x=-Math.PI/2,X.position.set(.38,.82,.44),s.add(X);for(let gt=0;gt<3;gt++){const wt=new le(Mw(),new ge({color:gt===1?"#a4a1d2":"#8da6d0",side:vn,roughness:.72}));wt.rotation.set(-Math.PI/2,0,a()*6.28),wt.scale.setScalar(.075),wt.position.set(.31+a()*.13,.822,.38+a()*.13),s.add(wt)}const k=new le(new jn(25,26,48,48),x),H=k.geometry.attributes.position;for(let gt=0;gt<H.count;gt++){const wt=H.getX(gt),Lt=H.getY(gt);H.setZ(gt,Math.sin(wt*1.2)*Math.cos(Lt*.55)*.1+Math.sin(wt*2.8+Lt)*.025)}k.geometry.computeVertexNormals(),k.rotation.x=-Math.PI/2,k.position.set(0,-.1,-10),k.receiveShadow=!0,o.add(k);for(let gt=0;gt<10;gt++){const wt=-1.3-gt*.91,Lt=-.18+Math.sin(gt*.63)*1.12,q=new Sn(.46+a()*.13,.5+a()*.12,.09+a()*.04,7),Z=new le(q,R);Z.position.set(Lt,-.012,wt),Z.rotation.y=a()*5,Z.scale.z=.65+a()*.21,Z.castShadow=Z.receiveShadow=!0,o.add(Z)}const Y=new ge({color:"#536746",roughness:.94}),it=xw(),rt=Vp(38291),ht=[],I=[],ct=new B(0,1.6,3.2);[[-1.36,-2.6,1.87,.535],[-3.6,-4,1.4,.61],[-1.8,-5.4,1.13,.56],[1.42,-2.7,1.44,.62],[3.2,-3.6,1.57,.555],[2.6,-5.8,1.16,.59]].forEach(([gt,wt,Lt,q],Z)=>{for(let at=0;at<7;at++){const w=at*2.39996+Z,G=.26+a()*.6,V=new B(gt+Math.cos(w)*G,Lt*(.63+a()*.38),wt+Math.sin(w)*G*.72),nt=new B(gt+(a()-.5)*.28,-.05,wt+(a()-.5)*.3);U(nt,V,.017+a()*.009,Y);for(let te=0;te<11;te++){const se=.17+te*.068,Me=nt.clone().lerp(V,se),be=new B(Math.cos(w+te*2.4)*.65,.2+a()*.38,Math.sin(w+te*2.4)*.5),Te=.34+a()*.32,cn=new Ei().setFromUnitVectors(new B(0,1,0),be.normalize());cn.multiply(new Ei().setFromAxisAngle(new B(0,1,0),a()*1.8-.9)),ht.push({pos:Me,q:cn,scale:new B(Te*(.72+rt()*.25),Te,Te),color:new ce().setHSL(.26+a()*.07,.33+a()*.16,.22+a()*.13)})}const ot=.2+a()*.11,st=ct.clone().sub(V).normalize().lerp(new B(0,1,0),.35).normalize(),Ct=new Ei().setFromUnitVectors(new B(0,0,1),st),It=Z===0||Z===3?45:32;for(let te=0;te<It;te++){const se=Math.acos(1-(te+.5)/(It+2)),Me=te*2.39996,be=new B(Math.sin(se)*Math.cos(Me),Math.sin(se)*Math.sin(Me),Math.cos(se)),Te=be.clone().multiplyScalar(ot*(.88+a()*.25));Te.x*=.92+rt()*.13,Te.y*=.82+rt()*.17,Te.z*=.75+rt()*.17,Te.applyQuaternion(Ct).add(V);const cn=new Ei().setFromUnitVectors(new B(0,0,1),be.clone().applyQuaternion(Ct)),Gn=a()*Math.PI*2,ei=.065+a()*.027,On=new ce().setHSL(q+.05+a()*.035,.4+a()*.22,.45+a()*.16);for(let Ze=0;Ze<4;Ze++){const un=cn.clone().multiply(new Ei().setFromAxisAngle(new B(0,0,1),Gn+Ze*Math.PI/2+(rt()-.5)*.19));un.multiply(new Ei().setFromAxisAngle(new B(1,0,0),(rt()-.5)*.22));const Vn=ei*(.83+rt()*.32);I.push({pos:Te,q:un,scale:new B(ei*(.84+rt()*.22),Vn,ei),color:On.clone().offsetHSL((rt()-.5)*.012,0,(rt()-.5)*.032)})}}}});const Ut=new Ii,Vt=new Ii;Ut.name="hydrangea-curved-leaves",Vt.name="hydrangea-irregular-sepals";const Bt=new An;for(const[gt,wt,Lt,q]of[[Ut,ht,gw,M],[Vt,I,vw,C]])for(let Z=0;Z<4;Z++){const at=wt.filter((G,V)=>V%4===Z),w=new Nn(Lt(Z),q,at.length);at.forEach((G,V)=>{Bt.position.copy(G.pos),Bt.quaternion.copy(G.q),Bt.scale.copy(G.scale),Bt.updateMatrix(),w.setMatrixAt(V,Bt.matrix),w.setColorAt(V,G.color)}),w.castShadow=w.receiveShadow=!0,gt.add(w)}o.add(Ut,Vt);const ft=u("#a8b2a1","stone",18);ft.repeat.set(5,1);const Et=new ge({map:ft,color:"#c4c8b7",roughness:.97,bumpMap:ft,bumpScale:.016});E(24,1.5,.23,0,.58,-11.5,Et,o);const Ft=E(24.3,.12,.64,0,1.37,-11.5,new ge({color:"#59675e",roughness:.88}),o);Ft.rotation.z=.002;const $t=new ge({color:"#7f9266",roughness:.76}),Xt=[];for(let gt=0;gt<29;gt++){const wt=-11+gt*.79+a()*.25,Lt=3.8+a()*3.8,q=-12.8-a()*3.4,Z=new B(wt,0,q),at=new B(wt+(a()-.5)*1.1,Lt,q+a()*.8);U(Z,at,.045+a()*.018,$t);for(let w=0;w<7;w++){const G=Z.clone().lerp(at,.42+w*.077),V=w%2?1:-1,nt=G.clone().add(new B(V*(.9+a()),.1+a()*.4,a()-.5));U(G,nt,.009,Y);for(let ot=0;ot<9;ot++)Bt.position.copy(G).lerp(nt,(ot+1)/10),Bt.quaternion.setFromUnitVectors(new B(0,1,0),new B(V*(ot%2?.2:.9),-.12-a()*.7,.4).normalize()),Bt.scale.set(.09,.48+a()*.23,.3),Bt.updateMatrix(),Xt.push(Bt.matrix.clone())}}const oe=new Nn(it,new ge({color:"#4f7355",roughness:.95,side:vn}),Xt.length);Xt.forEach((gt,wt)=>oe.setMatrixAt(wt,gt)),o.add(oe);const Ye=[],jt=[],de=new ge({map:h,color:"#58624c",roughness:.97,bumpMap:h,bumpScale:.025});for(const[gt,wt,Lt]of[[-9,-13,6.7],[-3.5,-13.8,7.4],[3.4,-14.3,7.2],[9.2,-12,7]]){const q=new B(gt,0,wt),Z=new B(gt+.45,Lt*.65,wt-.25);U(q,Z,.17,de);for(let at=0;at<9;at++){const w=at*2.4,G=1.1+a()*1.5,V=q.clone().lerp(Z,.5+a()*.43),nt=new B(gt+Math.cos(w)*G,Lt*(.57+a()*.43),wt+Math.sin(w)*G*.7);U(V,nt,.047,de);for(let ot=0;ot<76;ot++){const st=V.clone().lerp(nt,.42+a()*.71);st.x+=(a()-.5)*1.75,st.y+=(a()-.5)*.95,st.z+=(a()-.5)*1.45,Bt.position.copy(st),Bt.rotation.set(a()*1.7-.85,a()*2.2-1.1,a()*6.28);const Ct=.45+a()*.4;Bt.scale.set(Ct*.7,Ct,Ct),Bt.updateMatrix(),Ye.push(Bt.matrix.clone()),jt.push(new ce().setHSL(.25+a()*.05,.26+a()*.2,.15+a()*.12))}}}const xe=new Nn(it,new ge({color:"#e5ebd5",roughness:.88,side:vn}),Ye.length);Ye.forEach((gt,wt)=>{xe.setMatrixAt(wt,gt),xe.setColorAt(wt,jt[wt])}),xe.receiveShadow=!0,o.add(xe);const pe=[];for(let gt=0;gt<26;gt++){const wt=-1.6-a()*8,q=-.18+Math.sin((-wt-1.3)/.91*.63)*1.12+(gt%2?1:-1)*(.71+a()*1);for(let Z=0;Z<6;Z++){const at=Z*1.047+gt,w=new B(Math.cos(at),0,Math.sin(at));for(let G=1;G<=7;G++)for(const V of[-1,1]){const nt=G/8,ot=.17*Math.sin(nt*Math.PI);Bt.position.set(q+w.x*nt*.46,.02+Math.sin(nt*Math.PI*.7)*.35,wt+w.z*nt*.46);const st=new B(w.z*V,.1,-w.x*V);Bt.quaternion.setFromUnitVectors(new B(0,1,0),st.normalize()),Bt.scale.set(ot*.62,ot,ot),Bt.updateMatrix(),pe.push(Bt.matrix.clone())}}}const Ce=new Nn(it,new ge({color:"#657b43",side:vn,roughness:.83}),pe.length);pe.forEach((gt,wt)=>Ce.setMatrixAt(wt,gt)),Ce.receiveShadow=!0,o.add(Ce);const Xe=new _o(1,1),Be=[];for(let gt=0;gt<110;gt++){const wt=-1.35-a()*9,Lt=-.18+Math.sin((-wt-1.3)/.91*.63)*1.12;Bt.position.set(Lt+(a()-.5)*1.65,-.015,wt),Bt.rotation.set(a(),a()*6,a());const q=.025+a()*.055;Bt.scale.set(q*1.3,q*.55,q),Bt.updateMatrix(),Be.push(Bt.matrix.clone())}const ie=new Nn(Xe,R,Be.length);Be.forEach((gt,wt)=>ie.setMatrixAt(wt,gt)),ie.receiveShadow=!0,o.add(ie);const Ue=1e3,j=new Float32Array(Ue*6),Se=new Float32Array(Ue*3);for(let gt=0;gt<Ue;gt++)Se[gt*3]=a()*19-9.5,Se[gt*3+1]=a()*7,Se[gt*3+2]=-.8-a()*13;const Ee=new Ie;Ee.setAttribute("position",new ti(j,3));const F=new sr(Ee,new ar({color:"#d8e8e3",transparent:!0,opacity:.28,depthWrite:!1}));o.add(F);const A=q3(n),et={uScene:{value:null},uResolution:{value:new Ot(1,1)},uTime:{value:0},uTouch:{value:new Ot(-2,-2)},uTouchStrength:{value:0}},mt=new ui({uniforms:et,transparent:!1,depthWrite:!0,toneMapped:!0,vertexShader:"varying vec2 vUv; void main(){ vUv=uv; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0); }",fragmentShader:`
      uniform sampler2D uScene; uniform vec2 uResolution; uniform float uTime; uniform vec2 uTouch; uniform float uTouchStrength; varying vec2 vUv;
      float h(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
      vec3 drops(vec2 uv, vec2 density, float layer){
        vec2 p=uv*density; vec2 cell=floor(p); float seed=h(cell+layer);
        vec2 q=fract(p)-vec2(0.18+seed*0.60,0.24+h(cell+2.2)*0.5);
        float r=0.040+0.090*pow(h(cell+1.7),1.7); q.y*=0.80+seed*0.22;
        float d=length(q)/r; float mask=(1.0-smoothstep(0.76,1.0,d))*step(0.34,seed);
        // A shallow cap bends the real scene most at the rim; no opaque green bead fill.
        float curvature=sqrt(max(0.06,1.0-min(d*d,0.94)));
        return vec3(q*mask/(r*curvature),mask);
      }
      void main(){
        vec2 screenUv=gl_FragCoord.xy/uResolution;
        vec3 a=drops(vUv,vec2(38.0,22.0),0.0), b=drops(vUv,vec2(19.0,11.0),8.1);
        vec2 refractNormal=a.xy*0.0014+b.xy*0.0025;
        float stream=0.0; vec2 streamN=vec2(0.0);
        for(int i=0;i<7;i++){
          float fi=float(i); float seed=fract(sin(fi*72.13+9.8)*199.73);
          float head=1.1-fract(uTime*(0.027+seed*0.016)+seed)*1.3;
          float x=0.06+fi*0.147+sin(vUv.y*17.0+fi)*0.003;
          float dx=vUv.x-x; float tail=smoothstep(head-0.018,head+0.025,vUv.y)*(1.0-smoothstep(head+0.23,head+0.58,vUv.y));
          float s=exp(-pow(dx/0.0015,2.0))*tail;
          stream=max(stream,s); streamN.x+=sign(dx)*s*0.006;
          vec2 qp=(vUv-vec2(x,head))*vec2(1.0,0.66); float dd=length(qp)/0.009;
          float bead=1.0-smoothstep(0.72,1.0,dd); refractNormal+=qp*bead*0.72;
        }
        vec2 traceDelta=(vUv-uTouch)*vec2(1.5,1.0);
        float clear=exp(-dot(traceDelta,traceDelta)*135.0)*uTouchStrength;
        refractNormal=(refractNormal+streamN)*(1.0-clear*0.88);
        vec3 bg=texture2D(uScene,clamp(screenUv+refractNormal,vec2(0.002),vec2(0.998))).rgb;
        float fineHighlight=pow(max(0.0,(a.x+a.y*0.8)*0.52),5.0)*a.z;
        float largeHighlight=pow(max(0.0,(b.x+b.y*0.8)*0.52),5.0)*b.z;
        float edgeLight=min(0.075,fineHighlight*0.030+largeHighlight*0.048)+stream*0.027;
        float mist=(0.012+pow(1.0-vUv.y,3.0)*0.018)*(1.0-clear);
        bg=mix(bg,vec3(0.64,0.73,0.70),mist)+edgeLight*(1.0-clear);
        gl_FragColor=vec4(bg,1.0);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }`}),Mt=new le(new jn(5.72,2.69),mt);Mt.position.set(0,2.15,-.012),s.add(Mt);const Ht=new Zu,kt=new Ot;let yt=100,xt=0;return{resize:gt=>{t.fov=gt<.85?51:49,t.position.set(gt<.85?-.08:.12,gt<.85?1.42:1.47,gt<.85?3.15:3.05),t.lookAt(gt<.85?-.07:0,gt<.85?1.45:1.38,-3.5),t.updateProjectionMatrix()},update(gt,wt){xt=gt,yt+=wt,et.uTime.value=gt,et.uTouchStrength.value=Math.max(0,1-yt/8),o.rotation.y=Math.sin(gt*.19)*45e-5,oe.rotation.z=Math.sin(gt*.28)*.0025,xe.rotation.z=Math.sin(gt*.16)*9e-4,Ut.rotation.z=Math.sin(gt*.37)*.0017,Vt.rotation.z=Math.sin(gt*.37)*.0017;for(let Z=0;Z<Ue;Z++){const at=Z*6,w=Z*3,G=((Se[w+1]-gt*4.7)%7+7)%7;j[at]=Se[w]+G*.042,j[at+1]=G,j[at+2]=Se[w+2],j[at+3]=j[at]+.009,j[at+4]=G+.14,j[at+5]=j[at+2]}Ee.attributes.position.needsUpdate=!0,n.getDrawingBufferSize(kt);const Lt=A.ensure(Math.max(1,kt.x),Math.max(1,kt.y));et.uScene.value=Lt.texture,et.uResolution.value.copy(kt);const q=Mt.visible;try{Mt.visible=!1,X3(n,()=>{n.setRenderTarget(Lt,0,0),n.clear(),n.render(s,t)})}finally{Mt.visible=q}},interact(gt,wt,Lt){if(Lt)et.uTouch.value.set(.52,.43);else{Ht.setFromCamera(new Ot(gt,wt),t);const q=Ht.intersectObjects([Mt,...P],!1)[0];if(!(q!=null&&q.uv)||q.object!==Mt)return null;et.uTouch.value.copy(q.uv)}return yt=0,{action:"glass-trace",value:.65+Math.sin(xt)*.1}},dispose(){A.dispose(),c.forEach(gt=>gt.dispose())}}};function Sw(s){return nn.jsx(Qu,{...s,kind:"window",builder:yw})}const bw=({scene:s,camera:t,renderer:n})=>{let a=520731;const o=()=>(a=a*1664525+1013904223>>>0,a/4294967296),c=(w,G)=>w+o()*(G-w);s.background=new ce("#8faaa8"),s.fog=new vo("#839b94",.036),t.position.set(0,1.49,3.7),t.lookAt(.08,.92,-5),t.near=.035,t.far=90;const u=w=>{const G=document.createElement("canvas");G.width=512,G.height=512;const V=G.getContext("2d"),nt=V.createImageData(512,512);for(let st=0;st<512;st++)for(let Ct=0;Ct<512;Ct++){const It=w==="wood"?174+Math.sin(st*.71+Math.sin(Ct*.009)*1.3+Math.sin(st*.027)*2)*7+Math.sin(st*2.1+Ct*.002)*3+c(-5,5):153+Math.sin(Ct*.042+Math.sin(st*.029)*3)*12+Math.sin(st*.052-Ct*.027)*9+c(-19,19),te=(st*512+Ct)*4;nt.data[te]=It,nt.data[te+1]=It,nt.data[te+2]=It,nt.data[te+3]=255}if(V.putImageData(nt,0,0),w==="wood")for(let st=0;st<70;st++){const Ct=c(0,512);V.strokeStyle=`rgba(34,24,17,${c(.07,.19)})`,V.lineWidth=c(.4,1.3),V.beginPath(),V.moveTo(c(-90,180),Ct),V.bezierCurveTo(180,Ct-2,310,Ct+3,c(400,600),Ct+1),V.stroke()}const ot=new rr(G);return ot.wrapS=ot.wrapT=Ka,ot.colorSpace=Ln,ot.anisotropy=Math.min(8,n.capabilities.getMaxAnisotropy()),ot},h=u("wood"),p=u("stone"),d=u("soil");h.center.set(.5,.5),h.rotation=Math.PI/2;const g=new ge({color:"#8f7b5e",map:h,bumpMap:h,bumpScale:.014,roughness:.74}),v=new ge({color:"#5d4530",map:h,bumpMap:h,bumpScale:.028,roughness:.82}),_=new ge({color:"#a08561",map:h,roughness:.92}),x=new ge({color:"#a6afa6",map:p,bumpMap:p,bumpScale:.028,roughness:.88}),b=new ge({color:"#838e80",map:p,bumpMap:p,bumpScale:.024,roughness:.46}),R=new ge({color:"#596b3a",map:d,bumpMap:d,bumpScale:.09,roughness:1}),y=new ge({color:"#737e60",map:d,bumpMap:d,bumpScale:.07,roughness:.9}),M=new ge({color:"#353d30",roughness:1}),C=new ge({color:"#526337",roughness:.9}),P=new ge({color:"#655b46",map:h,bumpMap:h,bumpScale:.085,roughness:.9}),E=new qa({color:"#0c1b17",transparent:!0,opacity:.13,depthWrite:!1});s.add(new qu("#d4e2de","#777057",2.05));const U=new Yu("#e8e1c8",1.7);U.position.set(-8,13,-7),U.castShadow=!0,U.shadow.mapSize.set(1024,1024),U.shadow.camera.left=-12,U.shadow.camera.right=12,U.shadow.camera.top=12,U.shadow.camera.bottom=-12,U.shadow.camera.near=1,U.shadow.camera.far=40,U.shadow.bias=-.001,U.shadow.normalBias=.035,U.shadow.radius=3,s.add(U);const L=new Bl("#edcba0",5.5,9,2);L.position.set(-2.3,2.1,3.2),s.add(L);const N=(w,G,V,nt,ot,st,Ct)=>{const It=new le(new Qa(w,G,V),nt);return It.position.set(ot,st,Ct),It.castShadow=It.receiveShadow=!0,s.add(It),It},T=(w,G,V,nt,ot=V*.7,st=9)=>{const Ct=new le(new Sn(ot,V,w.distanceTo(G),st),nt);return Ct.position.copy(w).add(G).multiplyScalar(.5),Ct.quaternion.setFromUnitVectors(new B(0,1,0),G.clone().sub(w).normalize()),Ct.castShadow=Ct.receiveShadow=!0,s.add(Ct),Ct},z=new jn(70,60,42,42);z.rotateX(-Math.PI/2);const W=z.attributes.position;for(let w=0;w<W.count;w++){const G=W.getX(w),V=W.getZ(w);W.setY(w,-.23+Math.sin(G*.41)*Math.sin(V*.3)*.13)}z.computeVertexNormals();const J=new le(z,y);J.position.z=-20,J.receiveShadow=!0,s.add(J),N(14,.28,5.5,v,0,-.13,3);for(let w=0;w<31;w++){const G=N(.442,.12,5.45,w%6===0?_:g,-6.91+w*.462,.065+c(-.004,.004),3);G.rotation.z=c(-.001,.001)}N(14.3,.18,.18,v,0,.015,.26),N(14.1,.12,.31,g,0,-.055,.16),N(14.25,.14,.29,v,0,-.16,-.08);for(const w of[-4.5,1.35]){N(.34,3.03,.35,v,w,1.455,.54),N(.41,.1,.43,_,w,.16,.54),N(.48,.2,.48,x,w,-.015,.54),N(.64,.18,.46,g,w,2.53,.54);const G=N(.15,1.1,.19,g,w+(w<0?.32:-.32),2.27,.54);G.rotation.z=w<0?-.64:.64,N(.47,.1,.41,v,w,2.04,.54)}N(14.3,.3,.32,v,0,2.77,.54),N(14.6,.16,4.7,v,0,3.18,2.25);for(let w=0;w<17;w++){const G=N(.13,.18,5.8,w%3?g:_,-7.1+w*.9,2.93,1.9);G.rotation.x=-.065}const $=new ge({color:"#565951",roughness:.9,map:p,bumpMap:p,bumpScale:.025}),lt=new Sn(.17,.17,.55,10,1,!0,0,Math.PI);lt.rotateX(Math.PI/2);const X=new Nn(lt,$,53),k=new An;for(let w=0;w<53;w++)k.position.set(-7.2+w*.275,2.99+Math.pow((w-26)/26,2)*.16,-.22),k.rotation.set(0,0,0),k.updateMatrix(),X.setMatrixAt(w,k.matrix);X.castShadow=!0,s.add(X);const H=hw(new _o(1,3)),Y=H.attributes.position;for(let w=0;w<Y.count;w++){const G=Y.getX(w),V=Y.getY(w),nt=Y.getZ(w),ot=1+Math.sin(G*8+nt*4)*.08+Math.sin(V*13-G*3)*.035;Y.setXYZ(w,G*ot,V*ot,nt*ot)}H.computeVertexNormals();const it=new Nn(H,b,63);for(let w=0;w<63;w++){const G=w<11?-.8+Math.sin(w*.74)*1.1-w*.06:c(-12,12),V=w<11?-1.5-w*.77:c(-3,-19);k.position.set(G,-.095+(w<11?0:c(-.07,.08)),V),k.scale.set(w<11?c(.37,.56):c(.15,.61),w<11?c(.07,.12):c(.1,.27),w<11?c(.3,.48):c(.17,.7)),k.rotation.set(c(-.2,.2),c(0,6.28),c(-.1,.1)),k.updateMatrix(),it.setMatrixAt(w,k.matrix),it.setColorAt(w,new ce().setHSL(c(.12,.18),c(.05,.16),c(.46,.67)))}it.castShadow=it.receiveShadow=!0,s.add(it);const rt=new Nn(H,x,19),ht=new Nn(H,R,19);for(let w=0;w<19;w++){const G=w<7?-3.7+w*1.12:c(-13,13),V=w<7?-7.7-Math.sin(w)*1.7:c(-9,-24),nt=c(.35,.9);k.position.set(G,nt*.21-.12,V),k.scale.set(c(.65,1.3),nt,c(.5,1.05)),k.rotation.set(c(-.25,.25),c(0,6.28),c(-.2,.2)),k.updateMatrix(),rt.setMatrixAt(w,k.matrix),k.position.y+=nt*.16,k.scale.multiply(new B(.89,.86,.89)),k.updateMatrix(),ht.setMatrixAt(w,k.matrix)}rt.castShadow=rt.receiveShadow=!0,ht.castShadow=ht.receiveShadow=!0,s.add(rt,ht);const I=new Nn(H,x,94);for(let w=0;w<94;w++){const G=Math.floor(w/31);k.position.set(-15+w%31*1.03+G*.31,G*.35-.03,-16.2+Math.sin(w%31)*.13),k.scale.set(c(.49,.61),c(.21,.26),c(.39,.53)),k.rotation.set(c(-.04,.04),c(-.25,.25),c(-.08,.08)),k.updateMatrix(),I.setMatrixAt(w,k.matrix)}I.receiveShadow=!0,s.add(I);const ct=new Ie,Tt=[],Ut=[],Vt=[];for(let w=0;w<=8;w++){const G=w/8,V=Math.sin(Math.PI*G)*(.16+.055*G);for(const nt of[-1,0,1])Tt.push(nt*V,G,Math.sin(G*Math.PI)*.1+(nt===0?.025:0)),Ut.push((nt+1)*.5,G)}for(let w=0;w<8;w++)for(let G=0;G<2;G++){const V=w*3+G;Vt.push(V,V+1,V+3,V+1,V+4,V+3)}ct.setAttribute("position",new ae(Tt,3)),ct.setAttribute("uv",new ae(Ut,2)),ct.setIndex(Vt),ct.computeVertexNormals();const Bt=new ge({color:"#7f9c55",roughness:.72,side:vn}),ft=new Nn(ct,Bt,2280);let Et=0;const Ft=[[-2.1,-1.15,1.25],[2.15,-1.25,1.2],[-3.2,-2.6,1.45],[2.7,-3.4,1.3],[3.5,-5.9,1.4],[-4.5,-4.9,1.3],[-2.9,-8.2,1.1],[4.8,-9,1.6],[-5.5,-10,1.4],[6.5,-5,1.2],[1.9,-10,1],[-7.1,-7.2,1.4]];for(const[w,G,V]of Ft)for(let nt=0;nt<7;nt++){const ot=nt/7*Math.PI*2+c(-.24,.24),st=V*c(.7,1.1),Ct=[];for(let se=0;se<5;se++){const Me=se/4;Ct.push(new B(w+Math.cos(ot)*Me*st,-.1+Math.sin(Me*Math.PI*.8)*st*.67,G+Math.sin(ot)*Me*st))}const It=new Iu(Ct),te=new le(new zl(It,10,.008,3,!1),C);s.add(te);for(let se=1;se<=12;se++){const Me=se/13,be=It.getPoint(Me),Te=Math.sin(Me*Math.PI)*st*.36;for(const cn of[-1,1]){const Gn=new B(Math.cos(ot)*.2+Math.sin(ot)*cn,.12,Math.sin(ot)*.2-Math.cos(ot)*cn).normalize();k.position.copy(be),k.quaternion.setFromUnitVectors(new B(0,1,0),Gn),k.scale.set(.22*V,Te,.8),k.updateMatrix(),ft.setMatrixAt(Et,k.matrix),ft.setColorAt(Et++,new ce().setHSL(c(.2,.27),c(.25,.49),c(.29,.61)))}}}ft.count=Et,ft.receiveShadow=!0,s.add(ft);const $t=new Nn(ct,Bt,7800);let Xt=0;for(let w=0;w<17;w++){const G=w<2?w?5.4:-5.6:c(-18,18),V=w<2?-8.8:c(-16,-30),nt=c(3.8,9.3),ot=c(-.8,.8),st=c(-.55,.55),Ct=new B(G,-.25,V),It=new B(G+ot*.32,nt*.43,V+st*.3),te=new B(G+ot,nt*.86,V+st);T(Ct,It,c(.14,.26),P,.105,11),T(It,te,.105,P,.031,9);for(let se=0;se<6;se++){const Me=se*2.39+w*.8,be=nt*c(.38,.78),Te=c(1.1,2.9),cn=new B(G+ot*be/nt,be,V+st*be/nt),Gn=new B(G+Math.cos(Me)*Te*.6,be+c(.12,.55),V+Math.sin(Me)*Te*.6),ei=new B(G+Math.cos(Me)*Te,be+c(.5,1.5),V+Math.sin(Me)*Te);T(cn,Gn,.055,P,.034,8),T(Gn,ei,.034,P,.008,6);for(let On=0;On<64;On++){const Ze=Math.sqrt(o())*1.32,un=c(0,Math.PI*2);k.position.copy(ei).add(new B(Math.cos(un)*Ze,c(-.44,.66),Math.sin(un)*Ze)),k.rotation.set(c(.5,2.4),c(0,Math.PI*2),c(0,Math.PI*2)),k.scale.set(c(.5,.9),c(.3,.61),1),k.updateMatrix(),$t.setMatrixAt(Xt,k.matrix),$t.setColorAt(Xt++,new ce().setHSL(c(.22,.31),c(.17,.31),c(.32,.58)))}}}for(let w=0;w<18;w++){const G=c(-16,16),V=c(-13,-24),nt=c(.8,2.5);T(new B(G,-.15,V),new B(G+.11,nt,V-.09),.034,P,.008,6);for(let ot=0;ot<64;ot++){const st=c(0,Math.PI*2),Ct=Math.sqrt(o())*c(.45,1.15);k.position.set(G+Math.cos(st)*Ct,nt*.53+c(-.3,.7),V+Math.sin(st)*Ct),k.rotation.set(c(.7,2.2),c(0,6.28),c(0,6.28)),k.scale.set(.7,c(.3,.63),1),k.updateMatrix(),$t.setMatrixAt(Xt,k.matrix),$t.setColorAt(Xt++,new ce().setHSL(c(.22,.29),c(.23,.37),c(.3,.51)))}}$t.count=Xt,$t.receiveShadow=!0,s.add($t);for(let w=0;w<3;w++){const G=new jn(95,34,58,22);G.rotateX(-Math.PI/2);const V=G.attributes.position;for(let ot=0;ot<V.count;ot++){const st=V.getX(ot),Ct=V.getZ(ot),It=4.3+w*1.1+Math.sin(st*.073+w*1.7)*1.6+Math.sin(st*.19+w)*.64,te=Math.max(0,Math.sin((Ct+17)/34*Math.PI));V.setY(ot,-.7+te*It+Math.sin(st*.37+Ct*.19)*.16)}G.computeVertexNormals();const nt=new le(G,new ge({color:w===0?"#66795b":w===1?"#78927f":"#92a79a",roughness:1}));nt.position.z=-35-w*16,s.add(nt)}const oe=new Ii;oe.position.set(.64,-.13,-.03),s.add(oe);const Ye=[new Ot(.09,0),new Ot(.37,.025),new Ot(.55,.11),new Ot(.65,.25),new Ot(.715,.49),new Ot(.7,.63),new Ot(.665,.67),new Ot(.588,.665),new Ot(.55,.6),new Ot(.51,.37),new Ot(.39,.23),new Ot(.1,.19),new Ot(0,.19)],jt=new Hl(Ye,72),de=jt.attributes.position;for(let w=0;w<de.count;w++){const G=de.getX(w),V=de.getY(w),nt=de.getZ(w),ot=Math.atan2(G,nt),st=Math.sin(ot*7+.4)*.012+Math.sin(ot*13-.7)*.004;de.setXYZ(w,G*(1+st),V+Math.sin(ot*5)*.008*Math.min(V,1),nt*(1+st))}jt.computeVertexNormals();const xe=new le(jt,x);xe.castShadow=xe.receiveShadow=!0,oe.add(xe);const pe=new le(H,b);pe.position.set(.64,-.2,-.03),pe.scale.set(.65,.13,.54),s.add(pe);const Ce=new le(new Cs(.85,48),E);Ce.rotation.x=-Math.PI/2,Ce.position.set(.64,-.201,-.03),s.add(Ce);const Xe=new ge({color:"#9a9166",map:h,roughness:.73});T(new B(1.26,-.13,-.4),new B(1.26,.89,-.4),.036,Xe,.034,12);const Be=new B(1.48,.9,-.33),ie=new B(.91,.81,-.12);T(Be,ie,.054,Xe,.057,14);const Ue=new le(new Cs(.042,20),M);Ue.position.copy(ie),Ue.quaternion.setFromUnitVectors(new B(0,0,1),ie.clone().sub(Be).normalize()),s.add(Ue);const j=new ge({color:"#464330",roughness:1});for(let w=0;w<3;w++){const G=new le(new tr(.059,.007,5,16),j);G.position.set(1.24-w*.015,.867-w*.002,-.242+w*.005),G.rotation.set(0,1.22,1.73),s.add(G)}const Se={uTime:{value:0},uTouch:{value:new Ot(.12,-.05)},uTouchTime:{value:-100}},Ee=new ui({uniforms:Se,side:vn,vertexShader:`
      uniform float uTime; uniform vec2 uTouch; uniform float uTouchTime;
      varying vec2 vP; varying vec3 vWorld; varying vec3 vNormal;
      float ripple(vec2 p,vec2 o,float age,float amp){float d=length(p-o);return sin(d*56.-age*11.)*exp(-pow((d-age*.27)*9.,2.))*exp(-age*.65)*amp;}
      float surface(vec2 p){float h=sin(p.x*14.+uTime*.58)*sin(p.y*13.-uTime*.65)*.00025;
        for(int i=0;i<7;i++){float f=float(i);float age=mod(uTime*.87+f*.471,3.6);vec2 c=vec2(sin(f*12.4),cos(f*8.7))*.39;h+=ripple(p,c,age,.0004);}
        h+=ripple(p,vec2(.27,-.09),mod(uTime*1.5,2.5),.00065);
        float age=uTime-uTouchTime;if(age>=0.&&age<8.)h+=ripple(p,uTouch,age,.0045);
        return h;}
      void main(){vP=position.xy;float h=surface(position.xy);vec3 p=position+vec3(0.,0.,h);vec4 w=modelMatrix*vec4(p,1.);vWorld=w.xyz;
        float e=.004;float dx=surface(position.xy+vec2(e,0.))-surface(position.xy-vec2(e,0.));float dy=surface(position.xy+vec2(0.,e))-surface(position.xy-vec2(0.,e));
        vNormal=normalize(mat3(modelMatrix)*normalize(vec3(-dx/(2.*e),-dy/(2.*e),1.)));gl_Position=projectionMatrix*viewMatrix*w;}
    `,fragmentShader:`
      varying vec2 vP; varying vec3 vWorld; varying vec3 vNormal;
      void main(){vec3 n=normalize(vNormal);vec3 v=normalize(cameraPosition-vWorld);vec3 r=reflect(-v,n);float f=.04+.72*pow(1.-max(dot(n,v),0.),4.);
        vec3 deep=vec3(.012,.035,.026);vec3 sky=mix(vec3(.035,.06,.044),vec3(.18,.22,.19),smoothstep(-.05,.6,r.y));
        float branch=sin(r.x*8.+r.z*2.)*sin(r.z*7.-r.x*3.);sky*=mix(.83,1.,smoothstep(-.1,.2,branch+r.y*.6));
        vec3 c=mix(deep,sky,.12+f*.5);float glint=pow(max(dot(reflect(normalize(vec3(-.4,-1.,.3)),n),v),0.),65.);c+=vec3(.63,.68,.60)*glint*.06;
        float edge=smoothstep(.39,.558,length(vP));c*=1.-edge*.18;gl_FragColor=vec4(c,1.);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }
    `}),F=new le(new Cs(.562,96),Ee);F.rotation.x=-Math.PI/2,F.position.y=.581,oe.add(F);const A=new jn(1.124,1.124,64,64),et=[],mt=A.attributes.position,Mt=A.index;for(let w=0;w<Mt.count;w+=3){const G=Mt.getX(w),V=Mt.getX(w+1),nt=Mt.getX(w+2);[G,V,nt].every(ot=>Math.hypot(mt.getX(ot),mt.getY(ot))<.557)&&et.push(G,V,nt)}A.setIndex(et),F.geometry.dispose(),F.geometry=A;const Ht=new Il({color:"#b4d1cc",transparent:!0,opacity:.34,roughness:.14,metalness:.08,depthWrite:!1});for(const[w,G,V]of[[-3.5,-.33,.015],[-1.74,-.3,.012],[2.5,-.34,.018],[4.4,-.35,.019],[.91,-.12,.009]]){const nt=w===.91?.8:2.96,ot=w===.91?.46:-.13,st=new Iu([new B(w,nt,G),new B(w+.012,nt*.67,G+.015),new B(w+.025,(nt+ot)*.37,G+.036),new B(w+.012,ot,G+.045)]),Ct=new zl(st,18,V,5,!1);s.add(new le(Ct,Ht))}const kt=1550,yt=new Float32Array(kt*6),xt=[];for(let w=0;w<kt;w++)xt.push(c(-17,17),c(0,9),c(-24,-.45),c(.7,1.35));const zt=new Ie;zt.setAttribute("position",new ti(yt,3));const gt=new sr(zt,new ar({color:"#c3d4d0",transparent:!0,opacity:.26,depthWrite:!1}));gt.frustumCulled=!1,s.add(gt);const wt=new Ie,Lt=new Float32Array(165);wt.setAttribute("position",new ti(Lt,3));const q=new eb(wt,new $x({color:"#cbdfd5",size:.018,transparent:!0,opacity:.51,depthWrite:!1}));q.frustumCulled=!1,s.add(q);const Z=new Zu;let at=0;return{resize(w){t.fov=w<.8?61:52,t.position.set(w<.8?.68:0,w<.8?1.42:1.49,w<.8?3.3:3.7),t.lookAt(w<.8?.56:.08,w<.8?1:.92,-5),t.updateProjectionMatrix()},update(w){at=w,Se.uTime.value=w;for(let G=0;G<kt;G++){const V=G*4,nt=G*6,ot=((xt[V+1]-w*4.9*xt[V+3])%9+9)%9-.25,st=xt[V]+Math.sin(w*.16+xt[V+2])*.02;yt[nt]=st,yt[nt+1]=ot,yt[nt+2]=xt[V+2],yt[nt+3]=st+.023,yt[nt+4]=ot+.16*xt[V+3],yt[nt+5]=xt[V+2]-.008}zt.attributes.position.needsUpdate=!0;for(let G=0;G<55;G++){const V=(w*.9+G*.371)%1,nt=[-3.5,-1.74,2.5,4.4,.91][G%5],ot=G*2.4;Lt[G*3]=nt+Math.cos(ot)*V*.095,Lt[G*3+1]=(G%5===4?.459:-.12)+Math.sin(V*Math.PI)*.045,Lt[G*3+2]=(G%5===4?-.12:-.3)+Math.sin(ot)*V*.07}wt.attributes.position.needsUpdate=!0,$t.rotation.z=Math.sin(w*.22)*.0016,ft.rotation.y=Math.sin(w*.31)*.0014,Ht.opacity=.34+Math.sin(w*1.3)*.025},interact(w,G,V=!1){Z.setFromCamera(new Ot(w,G),t),s.updateMatrixWorld(!0);const nt=V?null:Z.intersectObject(F,!1)[0];if(!V&&!nt)return null;if(nt){const ot=F.worldToLocal(nt.point.clone());Se.uTouch.value.set(ot.x,ot.y)}else Se.uTouch.value.set(-.08,.06);return Se.uTouchTime.value=at,{action:"basin-ripple",value:.55}}}};function Ew(s){return nn.jsx(Qu,{...s,kind:"porch",builder:bw})}const Cu=s=>()=>(s=Math.imul(s,1664525)+1013904223|0,(s>>>0)/4294967296);function so(s,t,n=.85){const a=Cu(9187+s.length),o=document.createElement("canvas");o.width=o.height=256;const c=o.getContext("2d");c.fillStyle="#bcb9b0",c.fillRect(0,0,256,256);const u=c.getImageData(0,0,256,256);for(let p=0;p<256;p++)for(let d=0;d<256;d++){const g=s==="timber"?Math.sin(p*.39+Math.sin(d*.019)*3)*12+Math.sin(p*1.8)*5:s==="canvas"?(d%3===0?9:0)+(p%3===0?-11:0):Math.sin(d*.055)*Math.sin(p*.091)*6,v=174+a()*43+g,_=(p*256+d)*4;u.data[_]=v,u.data[_+1]=v-2,u.data[_+2]=v-6,u.data[_+3]=255}if(c.putImageData(u,0,0),s==="timber"){for(let p=0;p<65;p++){c.strokeStyle=`rgba(52,38,24,${.06+a()*.1})`,c.lineWidth=.4+a()*1.1,c.beginPath();const d=a()*256;c.moveTo(0,d),c.bezierCurveTo(80,d-5,150,d+5,256,d+a()*9-4),c.stroke()}for(let p=0;p<4;p++){const d=a()*256,g=a()*256;for(let v=0;v<7;v++)c.strokeStyle=`rgba(43,29,21,${.13-v*.013})`,c.beginPath(),c.ellipse(d,g,5+v*4,1.8+v*1.25,0,0,Math.PI*2),c.stroke()}}const h=new rr(o);return h.colorSpace=Ln,h.wrapS=h.wrapT=Ka,h.repeat.set(s==="timber"?2:3,s==="timber"?1:3),new ge({color:t,map:h,bumpMap:h,bumpScale:s==="timber"?.022:.009,roughness:n})}const Tw=`varying vec3 vWorld;
void main(){vWorld=(modelMatrix*vec4(position,1.)).xyz;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}`,wM=`
float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453123);}
float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash(i),hash(i+vec2(1,0)),f.x),mix(hash(i+vec2(0,1)),hash(i+vec2(1,1)),f.x),f.y);}
float fbm(vec2 p){float n=0.,a=.5;mat2 m=mat2(.80,-.60,.60,.80);for(int i=0;i<5;i++){n+=a*noise(p);p=m*p*2.03+13.7;a*=.5;}return n;}
`,Aw=`uniform float uTime;varying vec3 vWorld;
${wM}
void main(){
 vec3 d=normalize(vWorld-cameraPosition);float h=max(d.y,0.);
 vec3 sky=mix(vec3(.57,.65,.65),vec3(.24,.32,.37),pow(h,.47));
 vec2 p=d.xz/max(d.y+.35,.13);p=p*1.18+vec2(uTime*.002,0.);
 float broad=fbm(p*.61+vec2(4.1,13.));
 float fold=fbm(p*2.1+vec2(broad*2.,-uTime*.003));
 float billow=fbm(p*4.8+fold*2.);
 float cover=smoothstep(.25,.72,broad*.57+fold*.35+billow*.08);
 vec3 cloud=mix(vec3(.15,.205,.24),vec3(.44,.50,.52),smoothstep(.3,.75,fold));
 float side=clamp(-d.x*.50+.40,0.,1.);
 cloud+=vec3(.085,.09,.078)*side*smoothstep(.52,.70,fold);
 sky=mix(sky,cloud,cover*.97*smoothstep(-.20,.085,d.y));
 float underside=smoothstep(.50,.70,fbm(p*.83+vec2(19.,5.)))*smoothstep(-.15,.16,d.y);
 sky=mix(sky,vec3(.17,.235,.275),underside*.45);
 float haze=1.-smoothstep(.0,.16,abs(d.y));
 sky=mix(sky,vec3(.60,.68,.66),haze*.19);
 gl_FragColor=vec4(sky,1.);
 #include <tonemapping_fragment>
 #include <colorspace_fragment>
}`;function Ji(s,t,n,a){const o=new le(new Qa(...t),a);return o.position.set(...n),o.castShadow=!0,o.receiveShadow=!0,s.add(o),o}function Cx(s,t,n,a,o,c=a){const u=new le(new Sn(c,a,t.distanceTo(n),9),o);return u.position.copy(t).lerp(n,.5),u.quaternion.setFromUnitVectors(new B(0,1,0),n.clone().sub(t).normalize()),s.add(u),u}const ww=({scene:s,camera:t})=>{const n=Cu(564932);s.background=new ce("#718687"),s.fog=new vo("#869e9a",.0085);const a=new ui({vertexShader:Tw,fragmentShader:Aw,uniforms:{uTime:{value:0}},side:vi,depthWrite:!1}),o=new le(new Wu(240,48,24),a);o.renderOrder=-10,s.add(o);const c=new qu("#cbdcda","#6f6b51",2.55);s.add(c);const u=new Yu("#e4eadc",1.9);u.position.set(-30,35,12),s.add(u);const h=new Bl("#ffbe79",5.5,7,2);h.position.set(-1.55,1.42,1.7),s.add(h);const p=so("timber",7693134,.85),d=so("timber",6510405,.43),g=so("timber",8746587,.79),v=so("clay",9854528,.74);so("stone",7368545,.89);const _=new ge({color:6639931,metalness:.72,roughness:.42}),x=so("canvas",9143145,.94);x.side=vn;const b=new ge({color:6582378,metalness:.58,roughness:.59}),R=new jn(230,215,90,76);R.rotateX(-Math.PI/2);const y=R.attributes.position,M=[],C=(Rt,Wt)=>-.5+Math.sin(Rt*.035+.5)*Math.sin(Wt*.019)*2.8+Math.sin(Rt*.072-Wt*.038)*1.1;for(let Rt=0;Rt<y.count;Rt++){const Wt=y.getX(Rt),me=y.getZ(Rt)-83;y.setY(Rt,C(Wt,me)),y.setZ(Rt,me);const ue=.5+.5*Math.sin(Wt*.097+me*.18+Math.sin(Wt*.11)),fe=new ce().lerpColors(new ce("#56674a"),new ce("#81916a"),ue*.58),ve=Math.pow(.5+.5*Math.cos(me*.67+Wt*.026),14)*.048;fe.offsetHSL(0,0,-ve),M.push(fe.r,fe.g,fe.b)}R.setAttribute("color",new ae(M,3)),R.computeVertexNormals();const P=new le(R,new ge({vertexColors:!0,roughness:1}));P.receiveShadow=!0,s.add(P);for(let Rt=0;Rt<3;Rt++){const Wt=-88-Rt*25,me=[],ue=[];for(let ve=0;ve<=80;ve++){const an=-190+ve*4.75,Zn=4.2+Math.sin(ve*.13+Rt*2)*3.5+Math.sin(ve*.35+Rt)*1.25+Rt*1.4;if(me.push(an,Zn,Wt,an,-9,Wt),ve<80){const wn=ve*2;ue.push(wn,wn+1,wn+2,wn+1,wn+3,wn+2)}}const fe=new Ie;fe.setAttribute("position",new ae(me,3)),fe.setIndex(ue),fe.computeVertexNormals(),s.add(new le(fe,new ge({color:[4940368,6584170,7966082][Rt],roughness:1,side:vn})))}const E=document.createElement("canvas");E.width=E.height=256;const U=E.getContext("2d");U.fillStyle="#bdc3a9",U.fillRect(0,0,256,256);for(let Rt=0;Rt<6e3;Rt++){const Wt=.025+n()*.11;U.fillStyle=n()<.58?`rgba(49,65,32,${Wt})`:`rgba(230,225,165,${Wt})`,U.beginPath(),U.ellipse(n()*256,n()*256,1+n()*8,1+n()*3,n()*3,0,Math.PI*2),U.fill()}const L=new rr(E);L.colorSpace=Ln,L.wrapS=L.wrapT=Ka,L.repeat.set(30,26),P.material.map=L,P.material.bumpMap=L,P.material.bumpScale=.045;const N=Cu(68124),T=new Ie,z=[],W=[],J=[];for(let Rt=0;Rt<12;Rt++){const Wt=N()*Math.PI*2,me=Math.sqrt(N())*.23,ue=Math.cos(Wt)*me,fe=Math.sin(Wt)*me,ve=.24+N()*.4,an=.12+N()*.27,Zn=.009+N()*.012,wn=(N()-.5)*1.5,$e=.78+N()*.22,ja=z.length/3;for(let fi=0;fi<=5;fi++){const D=fi/5,Q=Wt+wn*D,bt=ue+Math.cos(Wt)*D*D*an,pt=fe+Math.sin(Wt)*D*D*an,dt=Zn*Math.pow(1-D,.72)*(.68+Math.sin(D*Math.PI)*.55),qt=ve*(D-.13*D*D*D),Jt=Math.sin(D*Math.PI)*Zn*.4;for(let Gt=-1;Gt<=1;Gt++){const Zt=Gt===0?Jt:0;z.push(bt+Math.cos(Q+Math.PI/2)*dt*Gt+Math.cos(Q)*Zt,qt,pt+Math.sin(Q+Math.PI/2)*dt*Gt+Math.sin(Q)*Zt);const Yt=(.43+.5*Math.pow(D,.58))*$e*(Gt===0?1:.84);J.push(Yt,Yt,Yt)}if(fi<5){const Gt=ja+fi*3;W.push(Gt,Gt+1,Gt+3,Gt+1,Gt+4,Gt+3,Gt+1,Gt+2,Gt+4,Gt+2,Gt+5,Gt+4)}}}T.setAttribute("position",new ae(z,3)),T.setAttribute("color",new ae(J,3)),T.setIndex(W),T.computeVertexNormals();const $=new ge({color:16777215,vertexColors:!0,roughness:.73,side:vn}),lt={value:0};$.onBeforeCompile=Rt=>{Rt.uniforms.uGrassTime=lt,Rt.vertexShader=`uniform float uGrassTime;
`+Rt.vertexShader,Rt.vertexShader=Rt.vertexShader.replace("#include <begin_vertex>",`#include <begin_vertex>
      float bx = instanceMatrix[3].x; float bz=instanceMatrix[3].z;
      transformed.x += sin(uGrassTime*.65+bx*.15+bz*.11)*pow(max(position.y,0.),2.)*.19;
      transformed.z += sin(uGrassTime*.49+bz*.16)*pow(max(position.y,0.),2.)*.09;`)};const X=new Nn(T,$,4200),k=new An,H=new ce,Y=Array.from({length:145},()=>({x:(N()-.5)*79,z:-3.3-Math.pow(N(),1.65)*67,radius:.65+N()*2.7,tone:N()}));for(let Rt=0;Rt<4200;Rt++){const Wt=Y[Rt%Y.length],me=N()*Math.PI*2,ue=Math.pow(N(),.65)*Wt.radius,fe=Wt.x+Math.cos(me)*ue,ve=Math.min(-3,Wt.z+Math.sin(me)*ue*.73),an=.6+N()*1.05;k.position.set(fe,C(fe,ve)+.025,ve),k.rotation.set((N()-.5)*.12,N()*Math.PI*2,(N()-.5)*.12),k.scale.set(an*(.8+N()*.34),an,an),k.updateMatrix(),X.setMatrixAt(Rt,k.matrix),H.setHSL(.205+N()*.055,.26+N()*.23,.28+Wt.tone*.075+N()*.045,Ln),X.setColorAt(Rt,H)}X.frustumCulled=!1,X.name="wet-field-tussocks",s.add(X);const it=Cu(90123),rt=new _o(1,4),ht=rt.attributes.position,I=rt.attributes.normal,ct=[],Tt=(Rt,Wt,me)=>1+Math.sin(Rt*5.1+me*3.7)*.12+Math.sin(Wt*7.8+Rt*4.3)*.08+Math.cos(me*13.1-Wt*10.4)*.045+Math.sin(Rt*24+Wt*21+me*18)*.019,Ut=new B,Vt=new B,Bt=new B,ft=new B(0,1,0),Et=new B,Ft=new B;for(let Rt=0;Rt<ht.count;Rt++){Ut.fromBufferAttribute(ht,Rt).normalize();const Wt=Tt(Ut.x,Ut.y,Ut.z);ht.setXYZ(Rt,Ut.x*Wt,Ut.y*Wt,Ut.z*Wt),Vt.crossVectors(Math.abs(Ut.y)>.95?new B(1,0,0):ft,Ut).normalize(),Bt.crossVectors(Ut,Vt).normalize(),Et.copy(Ut).addScaledVector(Vt,.002).normalize(),Ft.copy(Ut).addScaledVector(Bt,.002).normalize(),Et.multiplyScalar(Tt(Et.x,Et.y,Et.z)).sub(Ut.clone().multiplyScalar(Wt)),Ft.multiplyScalar(Tt(Ft.x,Ft.y,Ft.z)).sub(Ut.clone().multiplyScalar(Wt)),Vt.crossVectors(Et,Ft).normalize(),I.setXYZ(Rt,Vt.x,Vt.y,Vt.z);const me=.76+.1*Math.sin(Ut.x*39+Ut.z*31)*Math.cos(Ut.y*35)+.1*Ut.y+.035*Math.sin(Ut.x*73-Ut.y*61+Ut.z*52);ct.push(me,me,me)}rt.setAttribute("color",new ae(ct,3));const $t=83,Xt=new Nn(rt,new ge({color:16777215,vertexColors:!0,roughness:.93}),$t*3),oe=new Nn(new Sn(.1,.18,1,7),new ge({color:5132609}),$t);for(let Rt=0;Rt<$t;Rt++){const Wt=Rt>=55,me=Wt?Rt-55:Rt,ue=Wt?-88+me*6.4+it()*4:-87+me*3.4+it()*2,fe=Wt?-88-it()*13:-62+Math.sin(me*.33)*7+(it()-.5)*7,ve=(Wt?2.8:2.2)+it()*(Wt?3.1:2.7),an=C(ue,fe);k.position.set(ue,an+ve*.35,fe),k.rotation.set(0,it()*.4,(it()-.5)*.07),k.scale.set(1,ve*.7,1),k.updateMatrix(),oe.setMatrixAt(Rt,k.matrix);const Zn=.82+it()*.55,wn=(it()-.5)*.36;for(let $e=0;$e<3;$e++){const ja=$e===0?0:$e===1?-1:1,fi=$e===0?1:.48+it()*.23;k.position.set(ue+ve*(wn+ja*(.24+it()*.1)),an+ve*($e===0?.82:.56+it()*.15),fe+(it()-.5)*ve*.42),k.rotation.set(it()*.7,it()*Math.PI*2,(it()-.5)*.7),k.scale.set(ve*.39*Zn*fi,ve*(.39+it()*.15)*fi,ve*(.34+it()*.11)*fi),k.updateMatrix(),Xt.setMatrixAt(Rt*3+$e,k.matrix),H.setHSL(.24+it()*.035,Wt?.17:.27,(Wt?.28:.245)+it()*.075,Ln),Xt.setColorAt(Rt*3+$e,H)}}Xt.name="layered-shelterbelt-crowns",s.add(Xt,oe);for(let Rt=0;Rt<60+4200*7+1430;Rt++)n();Ji(s,[6.8,.24,6.8],[0,-.19,1.55],p);for(let Rt=0;Rt<19;Rt++){const Wt=Ji(s,[.346,.1,6.8],[-3.22+Rt*.357,-.025+n()*.006,1.55],Rt%4===0?g:d);Wt.rotation.y=(n()-.5)*.002}Ji(s,[6.9,.24,.2],[0,-.04,-1.88],g);const Ye=[[-2.85,-1.13],[2.85,-1.13],[-2.85,4.2],[2.85,4.2]];for(const[Rt,Wt]of Ye){Ji(s,[.21,3.38,.23],[Rt,1.59,Wt],p),Ji(s,[.25,.18,.27],[Rt,.15,Wt],g);const me=Ji(s,[.13,1,.13],[Rt-Math.sign(Rt)*.26,2.75,Wt],g);me.rotation.z=Math.sign(Rt)*-.54;for(const ue of[.56,2.45]){const fe=new le(new Sn(.018,.018,.01,9),_);fe.rotation.x=Math.PI/2,fe.position.set(Rt,ue,Wt+.124),s.add(fe)}}Ji(s,[6.15,.25,.27],[0,3.19,-1.13],p),Ji(s,[6.15,.25,.27],[0,3.57,4.2],p);for(let Rt=0;Rt<7;Rt++){const Wt=Ji(s,[.14,.18,6.15],[-2.75+Rt*.916,3.42,1.4],g);Wt.rotation.x=.063}const jt=new jn(6.6,6.4,120,1);jt.rotateX(-Math.PI/2);const de=jt.attributes.position;for(let Rt=0;Rt<de.count;Rt++)de.setY(Rt,Math.sin(de.getX(Rt)*31)*.032+de.getZ(Rt)*.064);jt.computeVertexNormals();const xe=new le(jt,b);xe.material.side=vn,xe.position.set(0,3.58,1.35),s.add(xe);const pe=new le(new Sn(.095,.095,6.55,14,1,!0,0,Math.PI),b);pe.rotation.z=Math.PI/2,pe.position.set(0,3.12,-1.87),s.add(pe);const Ce=new jn(5.66,1,64,14),Xe=Ce.attributes.position;for(let Rt=0;Rt<Xe.count;Rt++)Xe.setZ(Rt,Math.sin(Xe.getX(Rt)*12.5)*.016+.035*Math.sin((Xe.getY(Rt)+.5)*Math.PI));Ce.computeVertexNormals();const Be=new le(Ce,x);Be.position.set(0,2.85,-1.32),s.add(Be);const ie=Ji(s,[5.74,.055,.06],[0,2.6,-1.32],g),Ue=new le(new Sn(.11,.11,5.72,20),x);Ue.rotation.z=Math.PI/2,Ue.position.set(0,3.03,-1.32),s.add(Ue);const j=new ge({color:10917752,roughness:1}),Se=Cx(s,new B(.84,3.04,-1.24),new B(.84,1.64,-1.24),.012,j),Ee=new le(new tr(.06,.012,6,24),j);Ee.scale.y=1.75,Ee.position.set(.84,1.58,-1.24),s.add(Ee);const F=new le(new Qa(.5,1.8,.4),new qa({visible:!1}));F.position.set(.84,2.15,-1.24),s.add(F);let A=.82,et=.82;const mt=[new Ot(.21,0),new Ot(.28,.08),new Ot(.4,.4),new Ot(.42,.62),new Ot(.34,.84),new Ot(.29,.89),new Ot(.3,.96),new Ot(.34,.99),new Ot(.35,1.03),new Ot(.3,1.06),new Ot(.26,1.01),new Ot(.255,.9),new Ot(.3,.77)],Mt=new le(new Hl(mt,56),v);Mt.position.set(1.11,.025,.25),Mt.castShadow=!0,Mt.receiveShadow=!0,s.add(Mt);const Ht=new le(new Cs(.29,40),new ge({color:3419171,roughness:.9}));Ht.rotation.x=-Math.PI/2,Ht.position.set(1.11,.79,.25),s.add(Ht);const kt=[];for(const Rt of[.13,.75,.94]){const Wt=new le(new tr(Rt===.75?.368:Rt===.94?.292:.3,.007,4,56),v);Wt.rotation.x=Math.PI/2,Wt.position.set(1.11,Rt+.025,.25),s.add(Wt),kt.push(Wt)}const yt=new le(new Sn(.52,.46,.07,40),v);yt.position.set(1.11,.067,.25),s.add(yt);const xt=new Ii;xt.position.set(-1.6,.06,1.35),Ji(xt,[.66,.08,.45],[0,.53,0],g);for(const Rt of[-.23,.23])for(const Wt of[-.13,.13]){const me=Ji(xt,[.07,.51,.08],[Rt,.27,Wt],p);me.rotation.z=-Math.sign(Rt)*.11}s.add(xt);const zt=new Ii;zt.position.set(-1.6,.65,1.35);const gt=new le(new Sn(.16,.18,.08,32),_);zt.add(gt);const wt=new le(new Sn(.12,.135,.27,32,1,!0),new Il({color:15326650,roughness:.1,transparent:!0,opacity:.2,side:vn,metalness:.12}));wt.position.y=.17,zt.add(wt);const Lt=new le(new Sn(.032,.042,.19,12),new qa({color:16766365}));Lt.position.y=.13,zt.add(Lt);const q=new le(new Xu(.19,.13,32),_);q.position.y=.38,zt.add(q);for(let Rt=0;Rt<4;Rt++){const Wt=Rt*Math.PI/2;Cx(zt,new B(Math.cos(Wt)*.145,.04,Math.sin(Wt)*.145),new B(Math.cos(Wt)*.145,.33,Math.sin(Wt)*.145),.014,_)}const Z=new le(new tr(.115,.009,5,24,Math.PI),_);Z.position.y=.46,zt.add(Z),s.add(zt);const at=[];for(const[Rt,Wt,me,ue]of[[-32,-69,31,.28],[20,-95,54,.28],[-1,-45,19,.12],[48,-56,24,.26],[-58,-112,44,.33]]){const fe=new ui({transparent:!0,depthWrite:!1,side:vn,uniforms:{uTime:{value:0},uOpacity:{value:ue},uLayer:{value:-Wt/112}},vertexShader:"varying vec2 vUv;void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}",fragmentShader:`varying vec2 vUv;uniform float uTime;uniform float uOpacity;uniform float uLayer;${wM}
      void main(){
        float drift=uTime*.019;
        float x=vUv.x+vUv.y*.17;
        float broad=fbm(vec2(x*7.+uLayer*11.,vUv.y*.65-drift));
        float streak=fbm(vec2(x*43.+broad*.7,vUv.y*1.4-drift*1.6));
        float threads=noise(vec2(x*147.+uLayer*5.,vUv.y*2.5-drift*2.));
        float edge=smoothstep(0.,.21,vUv.x)*(1.-smoothstep(.78,1.,vUv.x));
        float base=smoothstep(0.,.085,vUv.y)*(1.-smoothstep(.42,1.,vUv.y));
        float veil=smoothstep(.25,.77,broad)*(.55+streak*.33+threads*.12);
        float a=(.18+veil*.82)*edge*base*uOpacity;
        vec3 rainTone=mix(vec3(.46,.57,.55),vec3(.65,.73,.71),uLayer);
        gl_FragColor=vec4(rainTone,a);
        #include <colorspace_fragment>
      }`.replace(";#include",`;
#include`)}),ve=new le(new jn(me,30),fe);ve.position.set(Rt,13.1,Wt),ve.renderOrder=2,s.add(ve),at.push(fe)}const w=1350,G=new Ie,V=new Float32Array(w*6),nt=[];for(let Rt=0;Rt<w;Rt++)nt.push((n()-.5)*64,n()*16,-2.35-n()*54,.3+n()*.38);G.setAttribute("position",new ti(V,3));const ot=new sr(G,new ar({color:13360346,transparent:!0,opacity:.23,depthWrite:!1}));ot.frustumCulled=!1,ot.renderOrder=3,s.add(ot);const st=new Ie,Ct=new Float32Array(276),It=[];for(let Rt=0;Rt<46;Rt++)It.push((n()-.5)*6.45,n()*3.1,.06+n()*.13);st.setAttribute("position",new ti(Ct,3));const te=new sr(st,new ar({color:13359302,transparent:!0,opacity:.39,depthWrite:!1}));te.frustumCulled=!1,s.add(te);const se=new om(.017,.031,14),Me=new qa({color:11781560,transparent:!0,opacity:.065,depthWrite:!1,side:vn}),be=new Nn(se,Me,36);s.add(be);const Te=document.createElement("canvas");Te.width=Te.height=128;const cn=Te.getContext("2d"),Gn=cn.createRadialGradient(64,64,7,64,64,64);Gn.addColorStop(0,"rgba(19,22,18,0.52)"),Gn.addColorStop(.45,"rgba(19,22,18,0.29)"),Gn.addColorStop(1,"rgba(19,22,18,0)"),cn.fillStyle=Gn,cn.fillRect(0,0,128,128);const ei=new rr(Te),On=new qa({map:ei,transparent:!0,depthWrite:!1,polygonOffset:!0,polygonOffsetFactor:-1}),Ze=[];for(const[Rt,Wt,me,ue]of[[1.11,.25,1.4,1.2],[-1.6,1.35,1.1,.86],[-2.85,-1.13,.74,.7],[2.85,-1.13,.74,.7]]){const fe=new le(new jn(me,ue),On);fe.rotation.x=-Math.PI/2,fe.position.set(Rt,.033,Wt),s.add(fe),Ze.push(fe)}const un=new Zu;function Vn(Rt,Wt){a.uniforms.uTime.value=Rt,lt.value=Rt;for(const ue of at)ue.uniforms.uTime.value=Rt;A+=(et-A)*Math.min(1,Wt*2);const me=.18+(1-A)*.86;Be.scale.y=me,Be.position.y=3.02-me*.5,ie.position.y=3.02-me,Be.rotation.y=Math.sin(Rt*.31)*.003;for(let ue=0;ue<w;ue++){const fe=ue*4,ve=ue*6,an=(nt[fe+1]-Rt*6.4)%16,Zn=an<0?an+16:an,wn=nt[fe]+Zn*.078;V[ve]=wn,V[ve+1]=Zn-.8,V[ve+2]=nt[fe+2],V[ve+3]=wn+.031,V[ve+4]=Zn+nt[fe+3]-.8,V[ve+5]=nt[fe+2]+.018}G.attributes.position.needsUpdate=!0;for(let ue=0;ue<46;ue++){const fe=ue*3,ve=ue*6,an=((It[fe+1]-Rt*3.35)%3.1+3.1)%3.1;Ct[ve]=It[fe],Ct[ve+1]=an,Ct[ve+2]=-1.91,Ct[ve+3]=It[fe]+.003,Ct[ve+4]=an+It[fe+2],Ct[ve+5]=-1.92}st.attributes.position.needsUpdate=!0;for(let ue=0;ue<36;ue++){const fe=(Rt*.41+ue*.317)%1;k.position.set(It[ue*3],.033,-1.66-ue*.618%1*.16),k.rotation.set(-Math.PI/2,0,0),k.scale.setScalar(.25+fe*1.1),k.updateMatrix(),be.setMatrixAt(ue,k.matrix)}be.instanceMatrix.needsUpdate=!0}function ca(Rt){t.position.set(Rt<.8?.12:0,1.48,2.45);const Wt=Rt<.8,me=Wt?.61:1.11,ue=Wt?-.28:.25;Mt.position.set(me,.025,ue),Ht.position.set(me,.79,ue),yt.position.set(me,.067,ue);for(const fe of kt)fe.position.x=me,fe.position.z=ue;xt.position.set(Wt?-.39:-1.6,.06,Wt?-.05:1.35),zt.position.set(Wt?-.39:-1.6,.65,Wt?-.05:1.35),Ze[0].position.set(me,.033,ue),Ze[1].position.set(Wt?-.39:-1.6,.033,Wt?-.05:1.35),h.position.set(Wt?-.39:-1.55,1.2,Wt?-.05:1.7),t.fov=Rt<.8?62:56,t.near=.08,t.far=420,t.lookAt(Rt<.8?-.1:0,Rt<.8?1.78:1.9,-27),t.updateProjectionMatrix()}return Vn(0,0),ca(t.aspect),{update:Vn,resize:ca,interact(Rt,Wt,me=!1,ue=!1){return un.setFromCamera(new Ot(Rt,Wt),t),!me&&un.intersectObjects([F,Be,ie,Se,Ee],!1).length===0?null:(et=et>.6?.26:.9,ue&&(A=et),{action:"awning",value:et})}}};function Rw(s){return nn.jsx(Qu,{...s,kind:"storm",builder:ww})}const RM={tent:mw,window:Sw,porch:Ew,storm:Rw},kp=new URLSearchParams(window.location.search),Wd=kp.get("world"),qd=Wd&&Wd in RM?Wd:"tent";function Cw(){const[s,t]=Qn.useState(kp.get("paused")!=="1"),[n,a]=Qn.useState(!0),[o,c]=Qn.useState(!1),[u,h]=Qn.useState(kp.get("static3D")==="1"),[p,d]=Qn.useState([]),[g,v]=Qn.useState(0),_=R=>d(y=>[...y.slice(-49),R]),x=RM[qd],b=nn.jsx(nn.Fragment,{children:nn.jsx("div",{className:"qa-drag-overlay","data-scene-drag":!0,"aria-label":"QA transparent player drag surface",children:nn.jsxs("div",{className:"qa-player-chrome","aria-label":"QA player chrome",children:[nn.jsx("button",{"data-qa-chrome-button":!0,onClick:()=>v(R=>R+1),children:"Player chrome"}),nn.jsx("input",{"data-qa-chrome-input":!0,type:"range","aria-label":"QA player volume",min:"0",max:"100",defaultValue:"50"})]})})});return nn.jsxs(nn.Fragment,{children:[nn.jsxs("main",{id:"qa-stage","data-world":qd,"data-mounted":n,"data-active":s,"data-static":u,children:[n&&nn.jsxs("div",{id:"qa-primary-holder",className:"qa-holder","data-scene-surface":!0,children:[nn.jsx(x,{active:s,static3D:u,onInteraction:_}),b]}),n&&o&&nn.jsxs("div",{id:"qa-second-holder",className:"qa-holder qa-second","data-scene-surface":!0,"aria-label":"QA second holder",children:[nn.jsx(x,{active:s,static3D:u,onInteraction:_}),b]})]}),nn.jsxs("aside",{id:"qa-controls","aria-label":"Isolated QA controls",children:[nn.jsx("strong",{children:qd}),nn.jsx("button",{id:"qa-active",onClick:()=>t(R=>!R),children:s?"Pause":"Resume"}),nn.jsx("button",{id:"qa-mounted",onClick:()=>{a(R=>!R),c(!1)},children:n?"Unmount":"Mount"}),nn.jsx("button",{id:"qa-second",disabled:!n,onClick:()=>c(R=>!R),children:o?"Close second holder":"Open second holder"}),nn.jsxs("button",{id:"qa-static",onClick:()=>h(R=>!R),children:["Static ",u?"on":"off"]}),nn.jsxs("output",{id:"qa-events","data-count":p.length,"data-chrome-clicks":g,"data-events":JSON.stringify(p),children:[p.length," interactions"]})]})]})}rw.createRoot(document.getElementById("root")).render(nn.jsx(Cw,{}));
