(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const o of document.querySelectorAll('link[rel="modulepreload"]'))a(o);new MutationObserver(o=>{for(const c of o)if(c.type==="childList")for(const u of c.addedNodes)u.tagName==="LINK"&&u.rel==="modulepreload"&&a(u)}).observe(document,{childList:!0,subtree:!0});function n(o){const c={};return o.integrity&&(c.integrity=o.integrity),o.referrerPolicy&&(c.referrerPolicy=o.referrerPolicy),o.crossOrigin==="use-credentials"?c.credentials="include":o.crossOrigin==="anonymous"?c.credentials="omit":c.credentials="same-origin",c}function a(o){if(o.ep)return;o.ep=!0;const c=n(o);fetch(o.href,c)}})();var Jh={exports:{}},il={};/**
 * @license React
 * react-jsx-runtime.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Hv;function py(){if(Hv)return il;Hv=1;var r=Symbol.for("react.transitional.element"),t=Symbol.for("react.fragment");function n(a,o,c){var u=null;if(c!==void 0&&(u=""+c),o.key!==void 0&&(u=""+o.key),"key"in o){c={};for(var h in o)h!=="key"&&(c[h]=o[h])}else c=o;return o=c.ref,{$$typeof:r,type:a,key:u,ref:o!==void 0?o:null,props:c}}return il.Fragment=t,il.jsx=n,il.jsxs=n,il}var Gv;function my(){return Gv||(Gv=1,Jh.exports=py()),Jh.exports}var je=my(),Qh={exports:{}},Me={};/**
 * @license React
 * react.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Vv;function gy(){if(Vv)return Me;Vv=1;var r=Symbol.for("react.transitional.element"),t=Symbol.for("react.portal"),n=Symbol.for("react.fragment"),a=Symbol.for("react.strict_mode"),o=Symbol.for("react.profiler"),c=Symbol.for("react.consumer"),u=Symbol.for("react.context"),h=Symbol.for("react.forward_ref"),m=Symbol.for("react.suspense"),p=Symbol.for("react.memo"),g=Symbol.for("react.lazy"),_=Symbol.for("react.activity"),v=Symbol.iterator;function x(I){return I===null||typeof I!="object"?null:(I=v&&I[v]||I["@@iterator"],typeof I=="function"?I:null)}var b={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},R=Object.assign,M={};function S(I,ct,At){this.props=I,this.context=ct,this.refs=M,this.updater=At||b}S.prototype.isReactComponent={},S.prototype.setState=function(I,ct){if(typeof I!="object"&&typeof I!="function"&&I!=null)throw Error("takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,I,ct,"setState")},S.prototype.forceUpdate=function(I){this.updater.enqueueForceUpdate(this,I,"forceUpdate")};function C(){}C.prototype=S.prototype;function O(I,ct,At){this.props=I,this.context=ct,this.refs=M,this.updater=At||b}var E=O.prototype=new C;E.constructor=O,R(E,S.prototype),E.isPureReactComponent=!0;var U=Array.isArray;function L(){}var P={H:null,A:null,T:null,S:null},T=Object.prototype.hasOwnProperty;function z(I,ct,At){var It=At.ref;return{$$typeof:r,type:I,key:ct,ref:It!==void 0?It:null,props:At}}function W(I,ct){return z(I.type,ct,I.props)}function J(I){return typeof I=="object"&&I!==null&&I.$$typeof===r}function Q(I){var ct={"=":"=0",":":"=2"};return"$"+I.replace(/[=:]/g,function(At){return ct[At]})}var et=/\/+/g;function k(I,ct){return typeof I=="object"&&I!==null&&I.key!=null?Q(""+I.key):ct.toString(36)}function q(I){switch(I.status){case"fulfilled":return I.value;case"rejected":throw I.reason;default:switch(typeof I.status=="string"?I.then(L,L):(I.status="pending",I.then(function(ct){I.status==="pending"&&(I.status="fulfilled",I.value=ct)},function(ct){I.status==="pending"&&(I.status="rejected",I.reason=ct)})),I.status){case"fulfilled":return I.value;case"rejected":throw I.reason}}throw I}function F(I,ct,At,It,kt){var zt=typeof I;(zt==="undefined"||zt==="boolean")&&(I=null);var ut=!1;if(I===null)ut=!0;else switch(zt){case"bigint":case"string":case"number":ut=!0;break;case"object":switch(I.$$typeof){case r:case t:ut=!0;break;case g:return ut=I._init,F(ut(I._payload),ct,At,It,kt)}}if(ut)return kt=kt(I),ut=It===""?"."+k(I,0):It,U(kt)?(At="",ut!=null&&(At=ut.replace(et,"$&/")+"/"),F(kt,ct,At,"",function(ie){return ie})):kt!=null&&(J(kt)&&(kt=W(kt,At+(kt.key==null||I&&I.key===kt.key?"":(""+kt.key).replace(et,"$&/")+"/")+ut)),ct.push(kt)),1;ut=0;var Tt=It===""?".":It+":";if(U(I))for(var Ht=0;Ht<I.length;Ht++)It=I[Ht],zt=Tt+k(It,Ht),ut+=F(It,ct,At,zt,kt);else if(Ht=x(I),typeof Ht=="function")for(I=Ht.call(I),Ht=0;!(It=I.next()).done;)It=It.value,zt=Tt+k(It,Ht++),ut+=F(It,ct,At,zt,kt);else if(zt==="object"){if(typeof I.then=="function")return F(q(I),ct,At,It,kt);throw ct=String(I),Error("Objects are not valid as a React child (found: "+(ct==="[object Object]"?"object with keys {"+Object.keys(I).join(", ")+"}":ct)+"). If you meant to render a collection of children, use an array instead.")}return ut}function Z(I,ct,At){if(I==null)return I;var It=[],kt=0;return F(I,It,"","",function(zt){return ct.call(At,zt,kt++)}),It}function ht(I){if(I._status===-1){var ct=I._result;ct=ct(),ct.then(function(At){(I._status===0||I._status===-1)&&(I._status=1,I._result=At)},function(At){(I._status===0||I._status===-1)&&(I._status=2,I._result=At)}),I._status===-1&&(I._status=0,I._result=ct)}if(I._status===1)return I._result.default;throw I._result}var dt=typeof reportError=="function"?reportError:function(I){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var ct=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof I=="object"&&I!==null&&typeof I.message=="string"?String(I.message):String(I),error:I});if(!window.dispatchEvent(ct))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",I);return}console.error(I)},pt={map:Z,forEach:function(I,ct,At){Z(I,function(){ct.apply(this,arguments)},At)},count:function(I){var ct=0;return Z(I,function(){ct++}),ct},toArray:function(I){return Z(I,function(ct){return ct})||[]},only:function(I){if(!J(I))throw Error("React.Children.only expected to receive a single React element child.");return I}};return Me.Activity=_,Me.Children=pt,Me.Component=S,Me.Fragment=n,Me.Profiler=o,Me.PureComponent=O,Me.StrictMode=a,Me.Suspense=m,Me.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=P,Me.__COMPILER_RUNTIME={__proto__:null,c:function(I){return P.H.useMemoCache(I)}},Me.cache=function(I){return function(){return I.apply(null,arguments)}},Me.cacheSignal=function(){return null},Me.cloneElement=function(I,ct,At){if(I==null)throw Error("The argument must be a React element, but you passed "+I+".");var It=R({},I.props),kt=I.key;if(ct!=null)for(zt in ct.key!==void 0&&(kt=""+ct.key),ct)!T.call(ct,zt)||zt==="key"||zt==="__self"||zt==="__source"||zt==="ref"&&ct.ref===void 0||(It[zt]=ct[zt]);var zt=arguments.length-2;if(zt===1)It.children=At;else if(1<zt){for(var ut=Array(zt),Tt=0;Tt<zt;Tt++)ut[Tt]=arguments[Tt+2];It.children=ut}return z(I.type,kt,It)},Me.createContext=function(I){return I={$$typeof:u,_currentValue:I,_currentValue2:I,_threadCount:0,Provider:null,Consumer:null},I.Provider=I,I.Consumer={$$typeof:c,_context:I},I},Me.createElement=function(I,ct,At){var It,kt={},zt=null;if(ct!=null)for(It in ct.key!==void 0&&(zt=""+ct.key),ct)T.call(ct,It)&&It!=="key"&&It!=="__self"&&It!=="__source"&&(kt[It]=ct[It]);var ut=arguments.length-2;if(ut===1)kt.children=At;else if(1<ut){for(var Tt=Array(ut),Ht=0;Ht<ut;Ht++)Tt[Ht]=arguments[Ht+2];kt.children=Tt}if(I&&I.defaultProps)for(It in ut=I.defaultProps,ut)kt[It]===void 0&&(kt[It]=ut[It]);return z(I,zt,kt)},Me.createRef=function(){return{current:null}},Me.forwardRef=function(I){return{$$typeof:h,render:I}},Me.isValidElement=J,Me.lazy=function(I){return{$$typeof:g,_payload:{_status:-1,_result:I},_init:ht}},Me.memo=function(I,ct){return{$$typeof:p,type:I,compare:ct===void 0?null:ct}},Me.startTransition=function(I){var ct=P.T,At={};P.T=At;try{var It=I(),kt=P.S;kt!==null&&kt(At,It),typeof It=="object"&&It!==null&&typeof It.then=="function"&&It.then(L,dt)}catch(zt){dt(zt)}finally{ct!==null&&At.types!==null&&(ct.types=At.types),P.T=ct}},Me.unstable_useCacheRefresh=function(){return P.H.useCacheRefresh()},Me.use=function(I){return P.H.use(I)},Me.useActionState=function(I,ct,At){return P.H.useActionState(I,ct,At)},Me.useCallback=function(I,ct){return P.H.useCallback(I,ct)},Me.useContext=function(I){return P.H.useContext(I)},Me.useDebugValue=function(){},Me.useDeferredValue=function(I,ct){return P.H.useDeferredValue(I,ct)},Me.useEffect=function(I,ct){return P.H.useEffect(I,ct)},Me.useEffectEvent=function(I){return P.H.useEffectEvent(I)},Me.useId=function(){return P.H.useId()},Me.useImperativeHandle=function(I,ct,At){return P.H.useImperativeHandle(I,ct,At)},Me.useInsertionEffect=function(I,ct){return P.H.useInsertionEffect(I,ct)},Me.useLayoutEffect=function(I,ct){return P.H.useLayoutEffect(I,ct)},Me.useMemo=function(I,ct){return P.H.useMemo(I,ct)},Me.useOptimistic=function(I,ct){return P.H.useOptimistic(I,ct)},Me.useReducer=function(I,ct,At){return P.H.useReducer(I,ct,At)},Me.useRef=function(I){return P.H.useRef(I)},Me.useState=function(I){return P.H.useState(I)},Me.useSyncExternalStore=function(I,ct,At){return P.H.useSyncExternalStore(I,ct,At)},Me.useTransition=function(){return P.H.useTransition()},Me.version="19.2.7",Me}var kv;function Op(){return kv||(kv=1,Qh.exports=gy()),Qh.exports}var Vn=Op(),jh={exports:{}},al={},$h={exports:{}},td={};/**
 * @license React
 * scheduler.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Xv;function vy(){return Xv||(Xv=1,(function(r){function t(F,Z){var ht=F.length;F.push(Z);t:for(;0<ht;){var dt=ht-1>>>1,pt=F[dt];if(0<o(pt,Z))F[dt]=Z,F[ht]=pt,ht=dt;else break t}}function n(F){return F.length===0?null:F[0]}function a(F){if(F.length===0)return null;var Z=F[0],ht=F.pop();if(ht!==Z){F[0]=ht;t:for(var dt=0,pt=F.length,I=pt>>>1;dt<I;){var ct=2*(dt+1)-1,At=F[ct],It=ct+1,kt=F[It];if(0>o(At,ht))It<pt&&0>o(kt,At)?(F[dt]=kt,F[It]=ht,dt=It):(F[dt]=At,F[ct]=ht,dt=ct);else if(It<pt&&0>o(kt,ht))F[dt]=kt,F[It]=ht,dt=It;else break t}}return Z}function o(F,Z){var ht=F.sortIndex-Z.sortIndex;return ht!==0?ht:F.id-Z.id}if(r.unstable_now=void 0,typeof performance=="object"&&typeof performance.now=="function"){var c=performance;r.unstable_now=function(){return c.now()}}else{var u=Date,h=u.now();r.unstable_now=function(){return u.now()-h}}var m=[],p=[],g=1,_=null,v=3,x=!1,b=!1,R=!1,M=!1,S=typeof setTimeout=="function"?setTimeout:null,C=typeof clearTimeout=="function"?clearTimeout:null,O=typeof setImmediate<"u"?setImmediate:null;function E(F){for(var Z=n(p);Z!==null;){if(Z.callback===null)a(p);else if(Z.startTime<=F)a(p),Z.sortIndex=Z.expirationTime,t(m,Z);else break;Z=n(p)}}function U(F){if(R=!1,E(F),!b)if(n(m)!==null)b=!0,L||(L=!0,Q());else{var Z=n(p);Z!==null&&q(U,Z.startTime-F)}}var L=!1,P=-1,T=5,z=-1;function W(){return M?!0:!(r.unstable_now()-z<T)}function J(){if(M=!1,L){var F=r.unstable_now();z=F;var Z=!0;try{t:{b=!1,R&&(R=!1,C(P),P=-1),x=!0;var ht=v;try{e:{for(E(F),_=n(m);_!==null&&!(_.expirationTime>F&&W());){var dt=_.callback;if(typeof dt=="function"){_.callback=null,v=_.priorityLevel;var pt=dt(_.expirationTime<=F);if(F=r.unstable_now(),typeof pt=="function"){_.callback=pt,E(F),Z=!0;break e}_===n(m)&&a(m),E(F)}else a(m);_=n(m)}if(_!==null)Z=!0;else{var I=n(p);I!==null&&q(U,I.startTime-F),Z=!1}}break t}finally{_=null,v=ht,x=!1}Z=void 0}}finally{Z?Q():L=!1}}}var Q;if(typeof O=="function")Q=function(){O(J)};else if(typeof MessageChannel<"u"){var et=new MessageChannel,k=et.port2;et.port1.onmessage=J,Q=function(){k.postMessage(null)}}else Q=function(){S(J,0)};function q(F,Z){P=S(function(){F(r.unstable_now())},Z)}r.unstable_IdlePriority=5,r.unstable_ImmediatePriority=1,r.unstable_LowPriority=4,r.unstable_NormalPriority=3,r.unstable_Profiling=null,r.unstable_UserBlockingPriority=2,r.unstable_cancelCallback=function(F){F.callback=null},r.unstable_forceFrameRate=function(F){0>F||125<F?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):T=0<F?Math.floor(1e3/F):5},r.unstable_getCurrentPriorityLevel=function(){return v},r.unstable_next=function(F){switch(v){case 1:case 2:case 3:var Z=3;break;default:Z=v}var ht=v;v=Z;try{return F()}finally{v=ht}},r.unstable_requestPaint=function(){M=!0},r.unstable_runWithPriority=function(F,Z){switch(F){case 1:case 2:case 3:case 4:case 5:break;default:F=3}var ht=v;v=F;try{return Z()}finally{v=ht}},r.unstable_scheduleCallback=function(F,Z,ht){var dt=r.unstable_now();switch(typeof ht=="object"&&ht!==null?(ht=ht.delay,ht=typeof ht=="number"&&0<ht?dt+ht:dt):ht=dt,F){case 1:var pt=-1;break;case 2:pt=250;break;case 5:pt=1073741823;break;case 4:pt=1e4;break;default:pt=5e3}return pt=ht+pt,F={id:g++,callback:Z,priorityLevel:F,startTime:ht,expirationTime:pt,sortIndex:-1},ht>dt?(F.sortIndex=ht,t(p,F),n(m)===null&&F===n(p)&&(R?(C(P),P=-1):R=!0,q(U,ht-dt))):(F.sortIndex=pt,t(m,F),b||x||(b=!0,L||(L=!0,Q()))),F},r.unstable_shouldYield=W,r.unstable_wrapCallback=function(F){var Z=v;return function(){var ht=v;v=Z;try{return F.apply(this,arguments)}finally{v=ht}}}})(td)),td}var Wv;function _y(){return Wv||(Wv=1,$h.exports=vy()),$h.exports}var ed={exports:{}},jn={};/**
 * @license React
 * react-dom.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var qv;function xy(){if(qv)return jn;qv=1;var r=Op();function t(m){var p="https://react.dev/errors/"+m;if(1<arguments.length){p+="?args[]="+encodeURIComponent(arguments[1]);for(var g=2;g<arguments.length;g++)p+="&args[]="+encodeURIComponent(arguments[g])}return"Minified React error #"+m+"; visit "+p+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function n(){}var a={d:{f:n,r:function(){throw Error(t(522))},D:n,C:n,L:n,m:n,X:n,S:n,M:n},p:0,findDOMNode:null},o=Symbol.for("react.portal");function c(m,p,g){var _=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:o,key:_==null?null:""+_,children:m,containerInfo:p,implementation:g}}var u=r.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;function h(m,p){if(m==="font")return"";if(typeof p=="string")return p==="use-credentials"?p:""}return jn.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=a,jn.createPortal=function(m,p){var g=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!p||p.nodeType!==1&&p.nodeType!==9&&p.nodeType!==11)throw Error(t(299));return c(m,p,null,g)},jn.flushSync=function(m){var p=u.T,g=a.p;try{if(u.T=null,a.p=2,m)return m()}finally{u.T=p,a.p=g,a.d.f()}},jn.preconnect=function(m,p){typeof m=="string"&&(p?(p=p.crossOrigin,p=typeof p=="string"?p==="use-credentials"?p:"":void 0):p=null,a.d.C(m,p))},jn.prefetchDNS=function(m){typeof m=="string"&&a.d.D(m)},jn.preinit=function(m,p){if(typeof m=="string"&&p&&typeof p.as=="string"){var g=p.as,_=h(g,p.crossOrigin),v=typeof p.integrity=="string"?p.integrity:void 0,x=typeof p.fetchPriority=="string"?p.fetchPriority:void 0;g==="style"?a.d.S(m,typeof p.precedence=="string"?p.precedence:void 0,{crossOrigin:_,integrity:v,fetchPriority:x}):g==="script"&&a.d.X(m,{crossOrigin:_,integrity:v,fetchPriority:x,nonce:typeof p.nonce=="string"?p.nonce:void 0})}},jn.preinitModule=function(m,p){if(typeof m=="string")if(typeof p=="object"&&p!==null){if(p.as==null||p.as==="script"){var g=h(p.as,p.crossOrigin);a.d.M(m,{crossOrigin:g,integrity:typeof p.integrity=="string"?p.integrity:void 0,nonce:typeof p.nonce=="string"?p.nonce:void 0})}}else p==null&&a.d.M(m)},jn.preload=function(m,p){if(typeof m=="string"&&typeof p=="object"&&p!==null&&typeof p.as=="string"){var g=p.as,_=h(g,p.crossOrigin);a.d.L(m,g,{crossOrigin:_,integrity:typeof p.integrity=="string"?p.integrity:void 0,nonce:typeof p.nonce=="string"?p.nonce:void 0,type:typeof p.type=="string"?p.type:void 0,fetchPriority:typeof p.fetchPriority=="string"?p.fetchPriority:void 0,referrerPolicy:typeof p.referrerPolicy=="string"?p.referrerPolicy:void 0,imageSrcSet:typeof p.imageSrcSet=="string"?p.imageSrcSet:void 0,imageSizes:typeof p.imageSizes=="string"?p.imageSizes:void 0,media:typeof p.media=="string"?p.media:void 0})}},jn.preloadModule=function(m,p){if(typeof m=="string")if(p){var g=h(p.as,p.crossOrigin);a.d.m(m,{as:typeof p.as=="string"&&p.as!=="script"?p.as:void 0,crossOrigin:g,integrity:typeof p.integrity=="string"?p.integrity:void 0})}else a.d.m(m)},jn.requestFormReset=function(m){a.d.r(m)},jn.unstable_batchedUpdates=function(m,p){return m(p)},jn.useFormState=function(m,p,g){return u.H.useFormState(m,p,g)},jn.useFormStatus=function(){return u.H.useHostTransitionStatus()},jn.version="19.2.7",jn}var Yv;function Sy(){if(Yv)return ed.exports;Yv=1;function r(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(r)}catch(t){console.error(t)}}return r(),ed.exports=xy(),ed.exports}/**
 * @license React
 * react-dom-client.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Zv;function My(){if(Zv)return al;Zv=1;var r=_y(),t=Op(),n=Sy();function a(e){var i="https://react.dev/errors/"+e;if(1<arguments.length){i+="?args[]="+encodeURIComponent(arguments[1]);for(var s=2;s<arguments.length;s++)i+="&args[]="+encodeURIComponent(arguments[s])}return"Minified React error #"+e+"; visit "+i+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function o(e){return!(!e||e.nodeType!==1&&e.nodeType!==9&&e.nodeType!==11)}function c(e){var i=e,s=e;if(e.alternate)for(;i.return;)i=i.return;else{e=i;do i=e,(i.flags&4098)!==0&&(s=i.return),e=i.return;while(e)}return i.tag===3?s:null}function u(e){if(e.tag===13){var i=e.memoizedState;if(i===null&&(e=e.alternate,e!==null&&(i=e.memoizedState)),i!==null)return i.dehydrated}return null}function h(e){if(e.tag===31){var i=e.memoizedState;if(i===null&&(e=e.alternate,e!==null&&(i=e.memoizedState)),i!==null)return i.dehydrated}return null}function m(e){if(c(e)!==e)throw Error(a(188))}function p(e){var i=e.alternate;if(!i){if(i=c(e),i===null)throw Error(a(188));return i!==e?null:e}for(var s=e,l=i;;){var f=s.return;if(f===null)break;var d=f.alternate;if(d===null){if(l=f.return,l!==null){s=l;continue}break}if(f.child===d.child){for(d=f.child;d;){if(d===s)return m(f),e;if(d===l)return m(f),i;d=d.sibling}throw Error(a(188))}if(s.return!==l.return)s=f,l=d;else{for(var y=!1,N=f.child;N;){if(N===s){y=!0,s=f,l=d;break}if(N===l){y=!0,l=f,s=d;break}N=N.sibling}if(!y){for(N=d.child;N;){if(N===s){y=!0,s=d,l=f;break}if(N===l){y=!0,l=d,s=f;break}N=N.sibling}if(!y)throw Error(a(189))}}if(s.alternate!==l)throw Error(a(190))}if(s.tag!==3)throw Error(a(188));return s.stateNode.current===s?e:i}function g(e){var i=e.tag;if(i===5||i===26||i===27||i===6)return e;for(e=e.child;e!==null;){if(i=g(e),i!==null)return i;e=e.sibling}return null}var _=Object.assign,v=Symbol.for("react.element"),x=Symbol.for("react.transitional.element"),b=Symbol.for("react.portal"),R=Symbol.for("react.fragment"),M=Symbol.for("react.strict_mode"),S=Symbol.for("react.profiler"),C=Symbol.for("react.consumer"),O=Symbol.for("react.context"),E=Symbol.for("react.forward_ref"),U=Symbol.for("react.suspense"),L=Symbol.for("react.suspense_list"),P=Symbol.for("react.memo"),T=Symbol.for("react.lazy"),z=Symbol.for("react.activity"),W=Symbol.for("react.memo_cache_sentinel"),J=Symbol.iterator;function Q(e){return e===null||typeof e!="object"?null:(e=J&&e[J]||e["@@iterator"],typeof e=="function"?e:null)}var et=Symbol.for("react.client.reference");function k(e){if(e==null)return null;if(typeof e=="function")return e.$$typeof===et?null:e.displayName||e.name||null;if(typeof e=="string")return e;switch(e){case R:return"Fragment";case S:return"Profiler";case M:return"StrictMode";case U:return"Suspense";case L:return"SuspenseList";case z:return"Activity"}if(typeof e=="object")switch(e.$$typeof){case b:return"Portal";case O:return e.displayName||"Context";case C:return(e._context.displayName||"Context")+".Consumer";case E:var i=e.render;return e=e.displayName,e||(e=i.displayName||i.name||"",e=e!==""?"ForwardRef("+e+")":"ForwardRef"),e;case P:return i=e.displayName||null,i!==null?i:k(e.type)||"Memo";case T:i=e._payload,e=e._init;try{return k(e(i))}catch{}}return null}var q=Array.isArray,F=t.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,Z=n.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,ht={pending:!1,data:null,method:null,action:null},dt=[],pt=-1;function I(e){return{current:e}}function ct(e){0>pt||(e.current=dt[pt],dt[pt]=null,pt--)}function At(e,i){pt++,dt[pt]=e.current,e.current=i}var It=I(null),kt=I(null),zt=I(null),ut=I(null);function Tt(e,i){switch(At(zt,i),At(kt,e),At(It,null),i.nodeType){case 9:case 11:e=(e=i.documentElement)&&(e=e.namespaceURI)?cv(e):0;break;default:if(e=i.tagName,i=i.namespaceURI)i=cv(i),e=uv(i,e);else switch(e){case"svg":e=1;break;case"math":e=2;break;default:e=0}}ct(It),At(It,e)}function Ht(){ct(It),ct(kt),ct(zt)}function ie(e){e.memoizedState!==null&&At(ut,e);var i=It.current,s=uv(i,e.type);i!==s&&(At(kt,e),At(It,s))}function qt(e){kt.current===e&&(ct(It),ct(kt)),ut.current===e&&(ct(ut),$o._currentValue=ht)}var re,Fe;function ee(e){if(re===void 0)try{throw Error()}catch(s){var i=s.stack.trim().match(/\n( *(at )?)/);re=i&&i[1]||"",Fe=-1<s.stack.indexOf(`
    at`)?" (<anonymous>)":-1<s.stack.indexOf("@")?"@unknown:0:0":""}return`
`+re+e+Fe}var de=!1;function xe(e,i){if(!e||de)return"";de=!0;var s=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{var l={DetermineComponentFrameRoot:function(){try{if(i){var Nt=function(){throw Error()};if(Object.defineProperty(Nt.prototype,"props",{set:function(){throw Error()}}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(Nt,[])}catch(wt){var yt=wt}Reflect.construct(e,[],Nt)}else{try{Nt.call()}catch(wt){yt=wt}e.call(Nt.prototype)}}else{try{throw Error()}catch(wt){yt=wt}(Nt=e())&&typeof Nt.catch=="function"&&Nt.catch(function(){})}}catch(wt){if(wt&&yt&&typeof wt.stack=="string")return[wt.stack,yt.stack]}return[null,null]}};l.DetermineComponentFrameRoot.displayName="DetermineComponentFrameRoot";var f=Object.getOwnPropertyDescriptor(l.DetermineComponentFrameRoot,"name");f&&f.configurable&&Object.defineProperty(l.DetermineComponentFrameRoot,"name",{value:"DetermineComponentFrameRoot"});var d=l.DetermineComponentFrameRoot(),y=d[0],N=d[1];if(y&&N){var K=y.split(`
`),xt=N.split(`
`);for(f=l=0;l<K.length&&!K[l].includes("DetermineComponentFrameRoot");)l++;for(;f<xt.length&&!xt[f].includes("DetermineComponentFrameRoot");)f++;if(l===K.length||f===xt.length)for(l=K.length-1,f=xt.length-1;1<=l&&0<=f&&K[l]!==xt[f];)f--;for(;1<=l&&0<=f;l--,f--)if(K[l]!==xt[f]){if(l!==1||f!==1)do if(l--,f--,0>f||K[l]!==xt[f]){var Dt=`
`+K[l].replace(" at new "," at ");return e.displayName&&Dt.includes("<anonymous>")&&(Dt=Dt.replace("<anonymous>",e.displayName)),Dt}while(1<=l&&0<=f);break}}}finally{de=!1,Error.prepareStackTrace=s}return(s=e?e.displayName||e.name:"")?ee(s):""}function fe(e,i){switch(e.tag){case 26:case 27:case 5:return ee(e.type);case 16:return ee("Lazy");case 13:return e.child!==i&&i!==null?ee("Suspense Fallback"):ee("Suspense");case 19:return ee("SuspenseList");case 0:case 15:return xe(e.type,!1);case 11:return xe(e.type.render,!1);case 1:return xe(e.type,!0);case 31:return ee("Activity");default:return""}}function be(e){try{var i="",s=null;do i+=fe(e,s),s=e,e=e.return;while(e);return i}catch(l){return`
Error generating stack: `+l.message+`
`+l.stack}}var ke=Object.prototype.hasOwnProperty,ze=r.unstable_scheduleCallback,ne=r.unstable_cancelCallback,Se=r.unstable_shouldYield,j=r.unstable_requestPaint,_e=r.unstable_now,Ee=r.unstable_getCurrentPriorityLevel,H=r.unstable_ImmediatePriority,A=r.unstable_UserBlockingPriority,at=r.unstable_NormalPriority,mt=r.unstable_LowPriority,bt=r.unstable_IdlePriority,Bt=r.log,Ft=r.unstable_setDisableYieldValue,Mt=null,St=null;function Ot(e){if(typeof Bt=="function"&&Ft(e),St&&typeof St.setStrictMode=="function")try{St.setStrictMode(Mt,e)}catch{}}var Xt=Math.clz32?Math.clz32:G,Wt=Math.log,ot=Math.LN2;function G(e){return e>>>=0,e===0?32:31-(Wt(e)/ot|0)|0}var Y=256,nt=262144,w=4194304;function V(e){var i=e&42;if(i!==0)return i;switch(e&-e){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:return 64;case 128:return 128;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:return e&261888;case 262144:case 524288:case 1048576:case 2097152:return e&3932160;case 4194304:case 8388608:case 16777216:case 33554432:return e&62914560;case 67108864:return 67108864;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 0;default:return e}}function X(e,i,s){var l=e.pendingLanes;if(l===0)return 0;var f=0,d=e.suspendedLanes,y=e.pingedLanes;e=e.warmLanes;var N=l&134217727;return N!==0?(l=N&~d,l!==0?f=V(l):(y&=N,y!==0?f=V(y):s||(s=N&~e,s!==0&&(f=V(s))))):(N=l&~d,N!==0?f=V(N):y!==0?f=V(y):s||(s=l&~e,s!==0&&(f=V(s)))),f===0?0:i!==0&&i!==f&&(i&d)===0&&(d=f&-f,s=i&-i,d>=s||d===32&&(s&4194048)!==0)?i:f}function st(e,i){return(e.pendingLanes&~(e.suspendedLanes&~e.pingedLanes)&i)===0}function rt(e,i){switch(e){case 1:case 2:case 4:case 8:case 64:return i+250;case 16:case 32:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return i+5e3;case 4194304:case 8388608:case 16777216:case 33554432:return-1;case 67108864:case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function it(){var e=w;return w<<=1,(w&62914560)===0&&(w=4194304),e}function Ct(e){for(var i=[],s=0;31>s;s++)i.push(e);return i}function Pt(e,i){e.pendingLanes|=i,i!==268435456&&(e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0)}function lt(e,i,s,l,f,d){var y=e.pendingLanes;e.pendingLanes=s,e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0,e.expiredLanes&=s,e.entangledLanes&=s,e.errorRecoveryDisabledLanes&=s,e.shellSuspendCounter=0;var N=e.entanglements,K=e.expirationTimes,xt=e.hiddenUpdates;for(s=y&~s;0<s;){var Dt=31-Xt(s),Nt=1<<Dt;N[Dt]=0,K[Dt]=-1;var yt=xt[Dt];if(yt!==null)for(xt[Dt]=null,Dt=0;Dt<yt.length;Dt++){var wt=yt[Dt];wt!==null&&(wt.lane&=-536870913)}s&=~Nt}l!==0&&Rt(e,l,0),d!==0&&f===0&&e.tag!==0&&(e.suspendedLanes|=d&~(y&~i))}function Rt(e,i,s){e.pendingLanes|=i,e.suspendedLanes&=~i;var l=31-Xt(i);e.entangledLanes|=i,e.entanglements[l]=e.entanglements[l]|1073741824|s&261930}function Gt(e,i){var s=e.entangledLanes|=i;for(e=e.entanglements;s;){var l=31-Xt(s),f=1<<l;f&i|e[l]&i&&(e[l]|=i),s&=~f}}function Vt(e,i){var s=i&-i;return s=(s&42)!==0?1:Yt(s),(s&(e.suspendedLanes|i))!==0?0:s}function Yt(e){switch(e){case 2:e=1;break;case 8:e=4;break;case 32:e=16;break;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:e=128;break;case 268435456:e=134217728;break;default:e=0}return e}function pe(e){return e&=-e,2<e?8<e?(e&134217727)!==0?32:268435456:8:2}function Ke(){var e=Z.p;return e!==0?e:(e=window.event,e===void 0?32:Nv(e.type))}function gn(e,i){var s=Z.p;try{return Z.p=e,i()}finally{Z.p=s}}var $e=Math.random().toString(36).slice(2),He="__reactFiber$"+$e,qe="__reactProps$"+$e,Tn="__reactContainer$"+$e,wi="__reactEvents$"+$e,ha="__reactListeners$"+$e,Gi="__reactHandles$"+$e,As="__reactResources$"+$e,qa="__reactMarker$"+$e;function Ya(e){delete e[He],delete e[qe],delete e[wi],delete e[ha],delete e[Gi]}function da(e){var i=e[He];if(i)return i;for(var s=e.parentNode;s;){if(i=s[Tn]||s[He]){if(s=i.alternate,i.child!==null||s!==null&&s.child!==null)for(e=vv(e);e!==null;){if(s=e[He])return s;e=vv(e)}return i}e=s,s=e.parentNode}return null}function pa(e){if(e=e[He]||e[Tn]){var i=e.tag;if(i===5||i===6||i===13||i===31||i===26||i===27||i===3)return e}return null}function ws(e){var i=e.tag;if(i===5||i===26||i===27||i===6)return e.stateNode;throw Error(a(33))}function Za(e){var i=e[As];return i||(i=e[As]={hoistableStyles:new Map,hoistableScripts:new Map}),i}function Rn(e){e[qa]=!0}var zl=new Set,mo={};function D(e,i){$(e,i),$(e+"Capture",i)}function $(e,i){for(mo[e]=i,e=0;e<i.length;e++)zl.add(i[e])}var Et=RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"),gt={},vt={};function Kt(e){return ke.call(vt,e)?!0:ke.call(gt,e)?!1:Et.test(e)?vt[e]=!0:(gt[e]=!0,!1)}function $t(e,i,s){if(Kt(i))if(s===null)e.removeAttribute(i);else{switch(typeof s){case"undefined":case"function":case"symbol":e.removeAttribute(i);return;case"boolean":var l=i.toLowerCase().slice(0,5);if(l!=="data-"&&l!=="aria-"){e.removeAttribute(i);return}}e.setAttribute(i,""+s)}}function Zt(e,i,s){if(s===null)e.removeAttribute(i);else{switch(typeof s){case"undefined":case"function":case"symbol":case"boolean":e.removeAttribute(i);return}e.setAttribute(i,""+s)}}function Qt(e,i,s,l){if(l===null)e.removeAttribute(s);else{switch(typeof l){case"undefined":case"function":case"symbol":case"boolean":e.removeAttribute(s);return}e.setAttributeNS(i,s,""+l)}}function jt(e){switch(typeof e){case"bigint":case"boolean":case"number":case"string":case"undefined":return e;case"object":return e;default:return""}}function Te(e){var i=e.type;return(e=e.nodeName)&&e.toLowerCase()==="input"&&(i==="checkbox"||i==="radio")}function Le(e,i,s){var l=Object.getOwnPropertyDescriptor(e.constructor.prototype,i);if(!e.hasOwnProperty(i)&&typeof l<"u"&&typeof l.get=="function"&&typeof l.set=="function"){var f=l.get,d=l.set;return Object.defineProperty(e,i,{configurable:!0,get:function(){return f.call(this)},set:function(y){s=""+y,d.call(this,y)}}),Object.defineProperty(e,i,{enumerable:l.enumerable}),{getValue:function(){return s},setValue:function(y){s=""+y},stopTracking:function(){e._valueTracker=null,delete e[i]}}}}function ae(e){if(!e._valueTracker){var i=Te(e)?"checked":"value";e._valueTracker=Le(e,i,""+e[i])}}function Xe(e){if(!e)return!1;var i=e._valueTracker;if(!i)return!0;var s=i.getValue(),l="";return e&&(l=Te(e)?e.checked?"true":"false":e.value),e=l,e!==s?(i.setValue(e),!0):!1}function hn(e){if(e=e||(typeof document<"u"?document:void 0),typeof e>"u")return null;try{return e.activeElement||e.body}catch{return e.body}}var un=/[\n"\\]/g;function Re(e){return e.replace(un,function(i){return"\\"+i.charCodeAt(0).toString(16)+" "})}function Cn(e,i,s,l,f,d,y,N){e.name="",y!=null&&typeof y!="function"&&typeof y!="symbol"&&typeof y!="boolean"?e.type=y:e.removeAttribute("type"),i!=null?y==="number"?(i===0&&e.value===""||e.value!=i)&&(e.value=""+jt(i)):e.value!==""+jt(i)&&(e.value=""+jt(i)):y!=="submit"&&y!=="reset"||e.removeAttribute("value"),i!=null?Pn(e,y,jt(i)):s!=null?Pn(e,y,jt(s)):l!=null&&e.removeAttribute("value"),f==null&&d!=null&&(e.defaultChecked=!!d),f!=null&&(e.checked=f&&typeof f!="function"&&typeof f!="symbol"),N!=null&&typeof N!="function"&&typeof N!="symbol"&&typeof N!="boolean"?e.name=""+jt(N):e.removeAttribute("name")}function te(e,i,s,l,f,d,y,N){if(d!=null&&typeof d!="function"&&typeof d!="symbol"&&typeof d!="boolean"&&(e.type=d),i!=null||s!=null){if(!(d!=="submit"&&d!=="reset"||i!=null)){ae(e);return}s=s!=null?""+jt(s):"",i=i!=null?""+jt(i):s,N||i===e.value||(e.value=i),e.defaultValue=i}l=l??f,l=typeof l!="function"&&typeof l!="symbol"&&!!l,e.checked=N?e.checked:!!l,e.defaultChecked=!!l,y!=null&&typeof y!="function"&&typeof y!="symbol"&&typeof y!="boolean"&&(e.name=y),ae(e)}function Pn(e,i,s){i==="number"&&hn(e.ownerDocument)===e||e.defaultValue===""+s||(e.defaultValue=""+s)}function Ce(e,i,s,l){if(e=e.options,i){i={};for(var f=0;f<s.length;f++)i["$"+s[f]]=!0;for(s=0;s<e.length;s++)f=i.hasOwnProperty("$"+e[s].value),e[s].selected!==f&&(e[s].selected=f),f&&l&&(e[s].defaultSelected=!0)}else{for(s=""+jt(s),i=null,f=0;f<e.length;f++){if(e[f].value===s){e[f].selected=!0,l&&(e[f].defaultSelected=!0);return}i!==null||e[f].disabled||(i=e[f])}i!==null&&(i.selected=!0)}}function ni(e,i,s){if(i!=null&&(i=""+jt(i),i!==e.value&&(e.value=i),s==null)){e.defaultValue!==i&&(e.defaultValue=i);return}e.defaultValue=s!=null?""+jt(s):""}function pi(e,i,s,l){if(i==null){if(l!=null){if(s!=null)throw Error(a(92));if(q(l)){if(1<l.length)throw Error(a(93));l=l[0]}s=l}s==null&&(s=""),i=s}s=jt(i),e.defaultValue=s,l=e.textContent,l===s&&l!==""&&l!==null&&(e.value=l),ae(e)}function ii(e,i){if(i){var s=e.firstChild;if(s&&s===e.lastChild&&s.nodeType===3){s.nodeValue=i;return}}e.textContent=i}var Ka=new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" "));function Je(e,i,s){var l=i.indexOf("--")===0;s==null||typeof s=="boolean"||s===""?l?e.setProperty(i,""):i==="float"?e.cssFloat="":e[i]="":l?e.setProperty(i,s):typeof s!="number"||s===0||Ka.has(i)?i==="float"?e.cssFloat=s:e[i]=(""+s).trim():e[i]=s+"px"}function vn(e,i,s){if(i!=null&&typeof i!="object")throw Error(a(62));if(e=e.style,s!=null){for(var l in s)!s.hasOwnProperty(l)||i!=null&&i.hasOwnProperty(l)||(l.indexOf("--")===0?e.setProperty(l,""):l==="float"?e.cssFloat="":e[l]="");for(var f in i)l=i[f],i.hasOwnProperty(f)&&s[f]!==l&&Je(e,f,l)}else for(var d in i)i.hasOwnProperty(d)&&Je(e,d,i[d])}function Ri(e){if(e.indexOf("-")===-1)return!1;switch(e){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var sn=new Map([["acceptCharset","accept-charset"],["htmlFor","for"],["httpEquiv","http-equiv"],["crossOrigin","crossorigin"],["accentHeight","accent-height"],["alignmentBaseline","alignment-baseline"],["arabicForm","arabic-form"],["baselineShift","baseline-shift"],["capHeight","cap-height"],["clipPath","clip-path"],["clipRule","clip-rule"],["colorInterpolation","color-interpolation"],["colorInterpolationFilters","color-interpolation-filters"],["colorProfile","color-profile"],["colorRendering","color-rendering"],["dominantBaseline","dominant-baseline"],["enableBackground","enable-background"],["fillOpacity","fill-opacity"],["fillRule","fill-rule"],["floodColor","flood-color"],["floodOpacity","flood-opacity"],["fontFamily","font-family"],["fontSize","font-size"],["fontSizeAdjust","font-size-adjust"],["fontStretch","font-stretch"],["fontStyle","font-style"],["fontVariant","font-variant"],["fontWeight","font-weight"],["glyphName","glyph-name"],["glyphOrientationHorizontal","glyph-orientation-horizontal"],["glyphOrientationVertical","glyph-orientation-vertical"],["horizAdvX","horiz-adv-x"],["horizOriginX","horiz-origin-x"],["imageRendering","image-rendering"],["letterSpacing","letter-spacing"],["lightingColor","lighting-color"],["markerEnd","marker-end"],["markerMid","marker-mid"],["markerStart","marker-start"],["overlinePosition","overline-position"],["overlineThickness","overline-thickness"],["paintOrder","paint-order"],["panose-1","panose-1"],["pointerEvents","pointer-events"],["renderingIntent","rendering-intent"],["shapeRendering","shape-rendering"],["stopColor","stop-color"],["stopOpacity","stop-opacity"],["strikethroughPosition","strikethrough-position"],["strikethroughThickness","strikethrough-thickness"],["strokeDasharray","stroke-dasharray"],["strokeDashoffset","stroke-dashoffset"],["strokeLinecap","stroke-linecap"],["strokeLinejoin","stroke-linejoin"],["strokeMiterlimit","stroke-miterlimit"],["strokeOpacity","stroke-opacity"],["strokeWidth","stroke-width"],["textAnchor","text-anchor"],["textDecoration","text-decoration"],["textRendering","text-rendering"],["transformOrigin","transform-origin"],["underlinePosition","underline-position"],["underlineThickness","underline-thickness"],["unicodeBidi","unicode-bidi"],["unicodeRange","unicode-range"],["unitsPerEm","units-per-em"],["vAlphabetic","v-alphabetic"],["vHanging","v-hanging"],["vIdeographic","v-ideographic"],["vMathematical","v-mathematical"],["vectorEffect","vector-effect"],["vertAdvY","vert-adv-y"],["vertOriginX","vert-origin-x"],["vertOriginY","vert-origin-y"],["wordSpacing","word-spacing"],["writingMode","writing-mode"],["xmlnsXlink","xmlns:xlink"],["xHeight","x-height"]]),ta=/^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;function Vi(e){return ta.test(""+e)?"javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')":e}function Ci(){}var qu=null;function Yu(e){return e=e.target||e.srcElement||window,e.correspondingUseElement&&(e=e.correspondingUseElement),e.nodeType===3?e.parentNode:e}var fr=null,hr=null;function lm(e){var i=pa(e);if(i&&(e=i.stateNode)){var s=e[qe]||null;t:switch(e=i.stateNode,i.type){case"input":if(Cn(e,s.value,s.defaultValue,s.defaultValue,s.checked,s.defaultChecked,s.type,s.name),i=s.name,s.type==="radio"&&i!=null){for(s=e;s.parentNode;)s=s.parentNode;for(s=s.querySelectorAll('input[name="'+Re(""+i)+'"][type="radio"]'),i=0;i<s.length;i++){var l=s[i];if(l!==e&&l.form===e.form){var f=l[qe]||null;if(!f)throw Error(a(90));Cn(l,f.value,f.defaultValue,f.defaultValue,f.checked,f.defaultChecked,f.type,f.name)}}for(i=0;i<s.length;i++)l=s[i],l.form===e.form&&Xe(l)}break t;case"textarea":ni(e,s.value,s.defaultValue);break t;case"select":i=s.value,i!=null&&Ce(e,!!s.multiple,i,!1)}}}var Zu=!1;function cm(e,i,s){if(Zu)return e(i,s);Zu=!0;try{var l=e(i);return l}finally{if(Zu=!1,(fr!==null||hr!==null)&&(bc(),fr&&(i=fr,e=hr,hr=fr=null,lm(i),e)))for(i=0;i<e.length;i++)lm(e[i])}}function go(e,i){var s=e.stateNode;if(s===null)return null;var l=s[qe]||null;if(l===null)return null;s=l[i];t:switch(i){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(l=!l.disabled)||(e=e.type,l=!(e==="button"||e==="input"||e==="select"||e==="textarea")),e=!l;break t;default:e=!1}if(e)return null;if(s&&typeof s!="function")throw Error(a(231,i,typeof s));return s}var ma=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),Ku=!1;if(ma)try{var vo={};Object.defineProperty(vo,"passive",{get:function(){Ku=!0}}),window.addEventListener("test",vo,vo),window.removeEventListener("test",vo,vo)}catch{Ku=!1}var Ja=null,Ju=null,Il=null;function um(){if(Il)return Il;var e,i=Ju,s=i.length,l,f="value"in Ja?Ja.value:Ja.textContent,d=f.length;for(e=0;e<s&&i[e]===f[e];e++);var y=s-e;for(l=1;l<=y&&i[s-l]===f[d-l];l++);return Il=f.slice(e,1<l?1-l:void 0)}function Bl(e){var i=e.keyCode;return"charCode"in e?(e=e.charCode,e===0&&i===13&&(e=13)):e=i,e===10&&(e=13),32<=e||e===13?e:0}function Fl(){return!0}function fm(){return!1}function li(e){function i(s,l,f,d,y){this._reactName=s,this._targetInst=f,this.type=l,this.nativeEvent=d,this.target=y,this.currentTarget=null;for(var N in e)e.hasOwnProperty(N)&&(s=e[N],this[N]=s?s(d):d[N]);return this.isDefaultPrevented=(d.defaultPrevented!=null?d.defaultPrevented:d.returnValue===!1)?Fl:fm,this.isPropagationStopped=fm,this}return _(i.prototype,{preventDefault:function(){this.defaultPrevented=!0;var s=this.nativeEvent;s&&(s.preventDefault?s.preventDefault():typeof s.returnValue!="unknown"&&(s.returnValue=!1),this.isDefaultPrevented=Fl)},stopPropagation:function(){var s=this.nativeEvent;s&&(s.stopPropagation?s.stopPropagation():typeof s.cancelBubble!="unknown"&&(s.cancelBubble=!0),this.isPropagationStopped=Fl)},persist:function(){},isPersistent:Fl}),i}var Rs={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(e){return e.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},Hl=li(Rs),_o=_({},Rs,{view:0,detail:0}),hS=li(_o),Qu,ju,xo,Gl=_({},_o,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:tf,button:0,buttons:0,relatedTarget:function(e){return e.relatedTarget===void 0?e.fromElement===e.srcElement?e.toElement:e.fromElement:e.relatedTarget},movementX:function(e){return"movementX"in e?e.movementX:(e!==xo&&(xo&&e.type==="mousemove"?(Qu=e.screenX-xo.screenX,ju=e.screenY-xo.screenY):ju=Qu=0,xo=e),Qu)},movementY:function(e){return"movementY"in e?e.movementY:ju}}),hm=li(Gl),dS=_({},Gl,{dataTransfer:0}),pS=li(dS),mS=_({},_o,{relatedTarget:0}),$u=li(mS),gS=_({},Rs,{animationName:0,elapsedTime:0,pseudoElement:0}),vS=li(gS),_S=_({},Rs,{clipboardData:function(e){return"clipboardData"in e?e.clipboardData:window.clipboardData}}),xS=li(_S),SS=_({},Rs,{data:0}),dm=li(SS),MS={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},yS={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},bS={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function ES(e){var i=this.nativeEvent;return i.getModifierState?i.getModifierState(e):(e=bS[e])?!!i[e]:!1}function tf(){return ES}var TS=_({},_o,{key:function(e){if(e.key){var i=MS[e.key]||e.key;if(i!=="Unidentified")return i}return e.type==="keypress"?(e=Bl(e),e===13?"Enter":String.fromCharCode(e)):e.type==="keydown"||e.type==="keyup"?yS[e.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:tf,charCode:function(e){return e.type==="keypress"?Bl(e):0},keyCode:function(e){return e.type==="keydown"||e.type==="keyup"?e.keyCode:0},which:function(e){return e.type==="keypress"?Bl(e):e.type==="keydown"||e.type==="keyup"?e.keyCode:0}}),AS=li(TS),wS=_({},Gl,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),pm=li(wS),RS=_({},_o,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:tf}),CS=li(RS),DS=_({},Rs,{propertyName:0,elapsedTime:0,pseudoElement:0}),US=li(DS),LS=_({},Gl,{deltaX:function(e){return"deltaX"in e?e.deltaX:"wheelDeltaX"in e?-e.wheelDeltaX:0},deltaY:function(e){return"deltaY"in e?e.deltaY:"wheelDeltaY"in e?-e.wheelDeltaY:"wheelDelta"in e?-e.wheelDelta:0},deltaZ:0,deltaMode:0}),NS=li(LS),OS=_({},Rs,{newState:0,oldState:0}),PS=li(OS),zS=[9,13,27,32],ef=ma&&"CompositionEvent"in window,So=null;ma&&"documentMode"in document&&(So=document.documentMode);var IS=ma&&"TextEvent"in window&&!So,mm=ma&&(!ef||So&&8<So&&11>=So),gm=" ",vm=!1;function _m(e,i){switch(e){case"keyup":return zS.indexOf(i.keyCode)!==-1;case"keydown":return i.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function xm(e){return e=e.detail,typeof e=="object"&&"data"in e?e.data:null}var dr=!1;function BS(e,i){switch(e){case"compositionend":return xm(i);case"keypress":return i.which!==32?null:(vm=!0,gm);case"textInput":return e=i.data,e===gm&&vm?null:e;default:return null}}function FS(e,i){if(dr)return e==="compositionend"||!ef&&_m(e,i)?(e=um(),Il=Ju=Ja=null,dr=!1,e):null;switch(e){case"paste":return null;case"keypress":if(!(i.ctrlKey||i.altKey||i.metaKey)||i.ctrlKey&&i.altKey){if(i.char&&1<i.char.length)return i.char;if(i.which)return String.fromCharCode(i.which)}return null;case"compositionend":return mm&&i.locale!=="ko"?null:i.data;default:return null}}var HS={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function Sm(e){var i=e&&e.nodeName&&e.nodeName.toLowerCase();return i==="input"?!!HS[e.type]:i==="textarea"}function Mm(e,i,s,l){fr?hr?hr.push(l):hr=[l]:fr=l,i=Dc(i,"onChange"),0<i.length&&(s=new Hl("onChange","change",null,s,l),e.push({event:s,listeners:i}))}var Mo=null,yo=null;function GS(e){iv(e,0)}function Vl(e){var i=ws(e);if(Xe(i))return e}function ym(e,i){if(e==="change")return i}var bm=!1;if(ma){var nf;if(ma){var af="oninput"in document;if(!af){var Em=document.createElement("div");Em.setAttribute("oninput","return;"),af=typeof Em.oninput=="function"}nf=af}else nf=!1;bm=nf&&(!document.documentMode||9<document.documentMode)}function Tm(){Mo&&(Mo.detachEvent("onpropertychange",Am),yo=Mo=null)}function Am(e){if(e.propertyName==="value"&&Vl(yo)){var i=[];Mm(i,yo,e,Yu(e)),cm(GS,i)}}function VS(e,i,s){e==="focusin"?(Tm(),Mo=i,yo=s,Mo.attachEvent("onpropertychange",Am)):e==="focusout"&&Tm()}function kS(e){if(e==="selectionchange"||e==="keyup"||e==="keydown")return Vl(yo)}function XS(e,i){if(e==="click")return Vl(i)}function WS(e,i){if(e==="input"||e==="change")return Vl(i)}function qS(e,i){return e===i&&(e!==0||1/e===1/i)||e!==e&&i!==i}var mi=typeof Object.is=="function"?Object.is:qS;function bo(e,i){if(mi(e,i))return!0;if(typeof e!="object"||e===null||typeof i!="object"||i===null)return!1;var s=Object.keys(e),l=Object.keys(i);if(s.length!==l.length)return!1;for(l=0;l<s.length;l++){var f=s[l];if(!ke.call(i,f)||!mi(e[f],i[f]))return!1}return!0}function wm(e){for(;e&&e.firstChild;)e=e.firstChild;return e}function Rm(e,i){var s=wm(e);e=0;for(var l;s;){if(s.nodeType===3){if(l=e+s.textContent.length,e<=i&&l>=i)return{node:s,offset:i-e};e=l}t:{for(;s;){if(s.nextSibling){s=s.nextSibling;break t}s=s.parentNode}s=void 0}s=wm(s)}}function Cm(e,i){return e&&i?e===i?!0:e&&e.nodeType===3?!1:i&&i.nodeType===3?Cm(e,i.parentNode):"contains"in e?e.contains(i):e.compareDocumentPosition?!!(e.compareDocumentPosition(i)&16):!1:!1}function Dm(e){e=e!=null&&e.ownerDocument!=null&&e.ownerDocument.defaultView!=null?e.ownerDocument.defaultView:window;for(var i=hn(e.document);i instanceof e.HTMLIFrameElement;){try{var s=typeof i.contentWindow.location.href=="string"}catch{s=!1}if(s)e=i.contentWindow;else break;i=hn(e.document)}return i}function sf(e){var i=e&&e.nodeName&&e.nodeName.toLowerCase();return i&&(i==="input"&&(e.type==="text"||e.type==="search"||e.type==="tel"||e.type==="url"||e.type==="password")||i==="textarea"||e.contentEditable==="true")}var YS=ma&&"documentMode"in document&&11>=document.documentMode,pr=null,rf=null,Eo=null,of=!1;function Um(e,i,s){var l=s.window===s?s.document:s.nodeType===9?s:s.ownerDocument;of||pr==null||pr!==hn(l)||(l=pr,"selectionStart"in l&&sf(l)?l={start:l.selectionStart,end:l.selectionEnd}:(l=(l.ownerDocument&&l.ownerDocument.defaultView||window).getSelection(),l={anchorNode:l.anchorNode,anchorOffset:l.anchorOffset,focusNode:l.focusNode,focusOffset:l.focusOffset}),Eo&&bo(Eo,l)||(Eo=l,l=Dc(rf,"onSelect"),0<l.length&&(i=new Hl("onSelect","select",null,i,s),e.push({event:i,listeners:l}),i.target=pr)))}function Cs(e,i){var s={};return s[e.toLowerCase()]=i.toLowerCase(),s["Webkit"+e]="webkit"+i,s["Moz"+e]="moz"+i,s}var mr={animationend:Cs("Animation","AnimationEnd"),animationiteration:Cs("Animation","AnimationIteration"),animationstart:Cs("Animation","AnimationStart"),transitionrun:Cs("Transition","TransitionRun"),transitionstart:Cs("Transition","TransitionStart"),transitioncancel:Cs("Transition","TransitionCancel"),transitionend:Cs("Transition","TransitionEnd")},lf={},Lm={};ma&&(Lm=document.createElement("div").style,"AnimationEvent"in window||(delete mr.animationend.animation,delete mr.animationiteration.animation,delete mr.animationstart.animation),"TransitionEvent"in window||delete mr.transitionend.transition);function Ds(e){if(lf[e])return lf[e];if(!mr[e])return e;var i=mr[e],s;for(s in i)if(i.hasOwnProperty(s)&&s in Lm)return lf[e]=i[s];return e}var Nm=Ds("animationend"),Om=Ds("animationiteration"),Pm=Ds("animationstart"),ZS=Ds("transitionrun"),KS=Ds("transitionstart"),JS=Ds("transitioncancel"),zm=Ds("transitionend"),Im=new Map,cf="abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");cf.push("scrollEnd");function ki(e,i){Im.set(e,i),D(i,[e])}var kl=typeof reportError=="function"?reportError:function(e){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var i=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof e=="object"&&e!==null&&typeof e.message=="string"?String(e.message):String(e),error:e});if(!window.dispatchEvent(i))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",e);return}console.error(e)},Di=[],gr=0,uf=0;function Xl(){for(var e=gr,i=uf=gr=0;i<e;){var s=Di[i];Di[i++]=null;var l=Di[i];Di[i++]=null;var f=Di[i];Di[i++]=null;var d=Di[i];if(Di[i++]=null,l!==null&&f!==null){var y=l.pending;y===null?f.next=f:(f.next=y.next,y.next=f),l.pending=f}d!==0&&Bm(s,f,d)}}function Wl(e,i,s,l){Di[gr++]=e,Di[gr++]=i,Di[gr++]=s,Di[gr++]=l,uf|=l,e.lanes|=l,e=e.alternate,e!==null&&(e.lanes|=l)}function ff(e,i,s,l){return Wl(e,i,s,l),ql(e)}function Us(e,i){return Wl(e,null,null,i),ql(e)}function Bm(e,i,s){e.lanes|=s;var l=e.alternate;l!==null&&(l.lanes|=s);for(var f=!1,d=e.return;d!==null;)d.childLanes|=s,l=d.alternate,l!==null&&(l.childLanes|=s),d.tag===22&&(e=d.stateNode,e===null||e._visibility&1||(f=!0)),e=d,d=d.return;return e.tag===3?(d=e.stateNode,f&&i!==null&&(f=31-Xt(s),e=d.hiddenUpdates,l=e[f],l===null?e[f]=[i]:l.push(i),i.lane=s|536870912),d):null}function ql(e){if(50<qo)throw qo=0,Sh=null,Error(a(185));for(var i=e.return;i!==null;)e=i,i=e.return;return e.tag===3?e.stateNode:null}var vr={};function QS(e,i,s,l){this.tag=e,this.key=s,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.refCleanup=this.ref=null,this.pendingProps=i,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=l,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function gi(e,i,s,l){return new QS(e,i,s,l)}function hf(e){return e=e.prototype,!(!e||!e.isReactComponent)}function ga(e,i){var s=e.alternate;return s===null?(s=gi(e.tag,i,e.key,e.mode),s.elementType=e.elementType,s.type=e.type,s.stateNode=e.stateNode,s.alternate=e,e.alternate=s):(s.pendingProps=i,s.type=e.type,s.flags=0,s.subtreeFlags=0,s.deletions=null),s.flags=e.flags&65011712,s.childLanes=e.childLanes,s.lanes=e.lanes,s.child=e.child,s.memoizedProps=e.memoizedProps,s.memoizedState=e.memoizedState,s.updateQueue=e.updateQueue,i=e.dependencies,s.dependencies=i===null?null:{lanes:i.lanes,firstContext:i.firstContext},s.sibling=e.sibling,s.index=e.index,s.ref=e.ref,s.refCleanup=e.refCleanup,s}function Fm(e,i){e.flags&=65011714;var s=e.alternate;return s===null?(e.childLanes=0,e.lanes=i,e.child=null,e.subtreeFlags=0,e.memoizedProps=null,e.memoizedState=null,e.updateQueue=null,e.dependencies=null,e.stateNode=null):(e.childLanes=s.childLanes,e.lanes=s.lanes,e.child=s.child,e.subtreeFlags=0,e.deletions=null,e.memoizedProps=s.memoizedProps,e.memoizedState=s.memoizedState,e.updateQueue=s.updateQueue,e.type=s.type,i=s.dependencies,e.dependencies=i===null?null:{lanes:i.lanes,firstContext:i.firstContext}),e}function Yl(e,i,s,l,f,d){var y=0;if(l=e,typeof e=="function")hf(e)&&(y=1);else if(typeof e=="string")y=ny(e,s,It.current)?26:e==="html"||e==="head"||e==="body"?27:5;else t:switch(e){case z:return e=gi(31,s,i,f),e.elementType=z,e.lanes=d,e;case R:return Ls(s.children,f,d,i);case M:y=8,f|=24;break;case S:return e=gi(12,s,i,f|2),e.elementType=S,e.lanes=d,e;case U:return e=gi(13,s,i,f),e.elementType=U,e.lanes=d,e;case L:return e=gi(19,s,i,f),e.elementType=L,e.lanes=d,e;default:if(typeof e=="object"&&e!==null)switch(e.$$typeof){case O:y=10;break t;case C:y=9;break t;case E:y=11;break t;case P:y=14;break t;case T:y=16,l=null;break t}y=29,s=Error(a(130,e===null?"null":typeof e,"")),l=null}return i=gi(y,s,i,f),i.elementType=e,i.type=l,i.lanes=d,i}function Ls(e,i,s,l){return e=gi(7,e,l,i),e.lanes=s,e}function df(e,i,s){return e=gi(6,e,null,i),e.lanes=s,e}function Hm(e){var i=gi(18,null,null,0);return i.stateNode=e,i}function pf(e,i,s){return i=gi(4,e.children!==null?e.children:[],e.key,i),i.lanes=s,i.stateNode={containerInfo:e.containerInfo,pendingChildren:null,implementation:e.implementation},i}var Gm=new WeakMap;function Ui(e,i){if(typeof e=="object"&&e!==null){var s=Gm.get(e);return s!==void 0?s:(i={value:e,source:i,stack:be(i)},Gm.set(e,i),i)}return{value:e,source:i,stack:be(i)}}var _r=[],xr=0,Zl=null,To=0,Li=[],Ni=0,Qa=null,ea=1,na="";function va(e,i){_r[xr++]=To,_r[xr++]=Zl,Zl=e,To=i}function Vm(e,i,s){Li[Ni++]=ea,Li[Ni++]=na,Li[Ni++]=Qa,Qa=e;var l=ea;e=na;var f=32-Xt(l)-1;l&=~(1<<f),s+=1;var d=32-Xt(i)+f;if(30<d){var y=f-f%5;d=(l&(1<<y)-1).toString(32),l>>=y,f-=y,ea=1<<32-Xt(i)+f|s<<f|l,na=d+e}else ea=1<<d|s<<f|l,na=e}function mf(e){e.return!==null&&(va(e,1),Vm(e,1,0))}function gf(e){for(;e===Zl;)Zl=_r[--xr],_r[xr]=null,To=_r[--xr],_r[xr]=null;for(;e===Qa;)Qa=Li[--Ni],Li[Ni]=null,na=Li[--Ni],Li[Ni]=null,ea=Li[--Ni],Li[Ni]=null}function km(e,i){Li[Ni++]=ea,Li[Ni++]=na,Li[Ni++]=Qa,ea=i.id,na=i.overflow,Qa=e}var Yn=null,dn=null,Ge=!1,ja=null,Oi=!1,vf=Error(a(519));function $a(e){var i=Error(a(418,1<arguments.length&&arguments[1]!==void 0&&arguments[1]?"text":"HTML",""));throw Ao(Ui(i,e)),vf}function Xm(e){var i=e.stateNode,s=e.type,l=e.memoizedProps;switch(i[He]=e,i[qe]=l,s){case"dialog":Pe("cancel",i),Pe("close",i);break;case"iframe":case"object":case"embed":Pe("load",i);break;case"video":case"audio":for(s=0;s<Zo.length;s++)Pe(Zo[s],i);break;case"source":Pe("error",i);break;case"img":case"image":case"link":Pe("error",i),Pe("load",i);break;case"details":Pe("toggle",i);break;case"input":Pe("invalid",i),te(i,l.value,l.defaultValue,l.checked,l.defaultChecked,l.type,l.name,!0);break;case"select":Pe("invalid",i);break;case"textarea":Pe("invalid",i),pi(i,l.value,l.defaultValue,l.children)}s=l.children,typeof s!="string"&&typeof s!="number"&&typeof s!="bigint"||i.textContent===""+s||l.suppressHydrationWarning===!0||ov(i.textContent,s)?(l.popover!=null&&(Pe("beforetoggle",i),Pe("toggle",i)),l.onScroll!=null&&Pe("scroll",i),l.onScrollEnd!=null&&Pe("scrollend",i),l.onClick!=null&&(i.onclick=Ci),i=!0):i=!1,i||$a(e,!0)}function Wm(e){for(Yn=e.return;Yn;)switch(Yn.tag){case 5:case 31:case 13:Oi=!1;return;case 27:case 3:Oi=!0;return;default:Yn=Yn.return}}function Sr(e){if(e!==Yn)return!1;if(!Ge)return Wm(e),Ge=!0,!1;var i=e.tag,s;if((s=i!==3&&i!==27)&&((s=i===5)&&(s=e.type,s=!(s!=="form"&&s!=="button")||Ph(e.type,e.memoizedProps)),s=!s),s&&dn&&$a(e),Wm(e),i===13){if(e=e.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(a(317));dn=gv(e)}else if(i===31){if(e=e.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(a(317));dn=gv(e)}else i===27?(i=dn,ds(e.type)?(e=Hh,Hh=null,dn=e):dn=i):dn=Yn?zi(e.stateNode.nextSibling):null;return!0}function Ns(){dn=Yn=null,Ge=!1}function _f(){var e=ja;return e!==null&&(hi===null?hi=e:hi.push.apply(hi,e),ja=null),e}function Ao(e){ja===null?ja=[e]:ja.push(e)}var xf=I(null),Os=null,_a=null;function ts(e,i,s){At(xf,i._currentValue),i._currentValue=s}function xa(e){e._currentValue=xf.current,ct(xf)}function Sf(e,i,s){for(;e!==null;){var l=e.alternate;if((e.childLanes&i)!==i?(e.childLanes|=i,l!==null&&(l.childLanes|=i)):l!==null&&(l.childLanes&i)!==i&&(l.childLanes|=i),e===s)break;e=e.return}}function Mf(e,i,s,l){var f=e.child;for(f!==null&&(f.return=e);f!==null;){var d=f.dependencies;if(d!==null){var y=f.child;d=d.firstContext;t:for(;d!==null;){var N=d;d=f;for(var K=0;K<i.length;K++)if(N.context===i[K]){d.lanes|=s,N=d.alternate,N!==null&&(N.lanes|=s),Sf(d.return,s,e),l||(y=null);break t}d=N.next}}else if(f.tag===18){if(y=f.return,y===null)throw Error(a(341));y.lanes|=s,d=y.alternate,d!==null&&(d.lanes|=s),Sf(y,s,e),y=null}else y=f.child;if(y!==null)y.return=f;else for(y=f;y!==null;){if(y===e){y=null;break}if(f=y.sibling,f!==null){f.return=y.return,y=f;break}y=y.return}f=y}}function Mr(e,i,s,l){e=null;for(var f=i,d=!1;f!==null;){if(!d){if((f.flags&524288)!==0)d=!0;else if((f.flags&262144)!==0)break}if(f.tag===10){var y=f.alternate;if(y===null)throw Error(a(387));if(y=y.memoizedProps,y!==null){var N=f.type;mi(f.pendingProps.value,y.value)||(e!==null?e.push(N):e=[N])}}else if(f===ut.current){if(y=f.alternate,y===null)throw Error(a(387));y.memoizedState.memoizedState!==f.memoizedState.memoizedState&&(e!==null?e.push($o):e=[$o])}f=f.return}e!==null&&Mf(i,e,s,l),i.flags|=262144}function Kl(e){for(e=e.firstContext;e!==null;){if(!mi(e.context._currentValue,e.memoizedValue))return!0;e=e.next}return!1}function Ps(e){Os=e,_a=null,e=e.dependencies,e!==null&&(e.firstContext=null)}function Zn(e){return qm(Os,e)}function Jl(e,i){return Os===null&&Ps(e),qm(e,i)}function qm(e,i){var s=i._currentValue;if(i={context:i,memoizedValue:s,next:null},_a===null){if(e===null)throw Error(a(308));_a=i,e.dependencies={lanes:0,firstContext:i},e.flags|=524288}else _a=_a.next=i;return s}var jS=typeof AbortController<"u"?AbortController:function(){var e=[],i=this.signal={aborted:!1,addEventListener:function(s,l){e.push(l)}};this.abort=function(){i.aborted=!0,e.forEach(function(s){return s()})}},$S=r.unstable_scheduleCallback,tM=r.unstable_NormalPriority,Dn={$$typeof:O,Consumer:null,Provider:null,_currentValue:null,_currentValue2:null,_threadCount:0};function yf(){return{controller:new jS,data:new Map,refCount:0}}function wo(e){e.refCount--,e.refCount===0&&$S(tM,function(){e.controller.abort()})}var Ro=null,bf=0,yr=0,br=null;function eM(e,i){if(Ro===null){var s=Ro=[];bf=0,yr=Ah(),br={status:"pending",value:void 0,then:function(l){s.push(l)}}}return bf++,i.then(Ym,Ym),i}function Ym(){if(--bf===0&&Ro!==null){br!==null&&(br.status="fulfilled");var e=Ro;Ro=null,yr=0,br=null;for(var i=0;i<e.length;i++)(0,e[i])()}}function nM(e,i){var s=[],l={status:"pending",value:null,reason:null,then:function(f){s.push(f)}};return e.then(function(){l.status="fulfilled",l.value=i;for(var f=0;f<s.length;f++)(0,s[f])(i)},function(f){for(l.status="rejected",l.reason=f,f=0;f<s.length;f++)(0,s[f])(void 0)}),l}var Zm=F.S;F.S=function(e,i){Ug=_e(),typeof i=="object"&&i!==null&&typeof i.then=="function"&&eM(e,i),Zm!==null&&Zm(e,i)};var zs=I(null);function Ef(){var e=zs.current;return e!==null?e:fn.pooledCache}function Ql(e,i){i===null?At(zs,zs.current):At(zs,i.pool)}function Km(){var e=Ef();return e===null?null:{parent:Dn._currentValue,pool:e}}var Er=Error(a(460)),Tf=Error(a(474)),jl=Error(a(542)),$l={then:function(){}};function Jm(e){return e=e.status,e==="fulfilled"||e==="rejected"}function Qm(e,i,s){switch(s=e[s],s===void 0?e.push(i):s!==i&&(i.then(Ci,Ci),i=s),i.status){case"fulfilled":return i.value;case"rejected":throw e=i.reason,$m(e),e;default:if(typeof i.status=="string")i.then(Ci,Ci);else{if(e=fn,e!==null&&100<e.shellSuspendCounter)throw Error(a(482));e=i,e.status="pending",e.then(function(l){if(i.status==="pending"){var f=i;f.status="fulfilled",f.value=l}},function(l){if(i.status==="pending"){var f=i;f.status="rejected",f.reason=l}})}switch(i.status){case"fulfilled":return i.value;case"rejected":throw e=i.reason,$m(e),e}throw Bs=i,Er}}function Is(e){try{var i=e._init;return i(e._payload)}catch(s){throw s!==null&&typeof s=="object"&&typeof s.then=="function"?(Bs=s,Er):s}}var Bs=null;function jm(){if(Bs===null)throw Error(a(459));var e=Bs;return Bs=null,e}function $m(e){if(e===Er||e===jl)throw Error(a(483))}var Tr=null,Co=0;function tc(e){var i=Co;return Co+=1,Tr===null&&(Tr=[]),Qm(Tr,e,i)}function Do(e,i){i=i.props.ref,e.ref=i!==void 0?i:null}function ec(e,i){throw i.$$typeof===v?Error(a(525)):(e=Object.prototype.toString.call(i),Error(a(31,e==="[object Object]"?"object with keys {"+Object.keys(i).join(", ")+"}":e)))}function t0(e){function i(ft,tt){if(e){var _t=ft.deletions;_t===null?(ft.deletions=[tt],ft.flags|=16):_t.push(tt)}}function s(ft,tt){if(!e)return null;for(;tt!==null;)i(ft,tt),tt=tt.sibling;return null}function l(ft){for(var tt=new Map;ft!==null;)ft.key!==null?tt.set(ft.key,ft):tt.set(ft.index,ft),ft=ft.sibling;return tt}function f(ft,tt){return ft=ga(ft,tt),ft.index=0,ft.sibling=null,ft}function d(ft,tt,_t){return ft.index=_t,e?(_t=ft.alternate,_t!==null?(_t=_t.index,_t<tt?(ft.flags|=67108866,tt):_t):(ft.flags|=67108866,tt)):(ft.flags|=1048576,tt)}function y(ft){return e&&ft.alternate===null&&(ft.flags|=67108866),ft}function N(ft,tt,_t,Ut){return tt===null||tt.tag!==6?(tt=df(_t,ft.mode,Ut),tt.return=ft,tt):(tt=f(tt,_t),tt.return=ft,tt)}function K(ft,tt,_t,Ut){var he=_t.type;return he===R?Dt(ft,tt,_t.props.children,Ut,_t.key):tt!==null&&(tt.elementType===he||typeof he=="object"&&he!==null&&he.$$typeof===T&&Is(he)===tt.type)?(tt=f(tt,_t.props),Do(tt,_t),tt.return=ft,tt):(tt=Yl(_t.type,_t.key,_t.props,null,ft.mode,Ut),Do(tt,_t),tt.return=ft,tt)}function xt(ft,tt,_t,Ut){return tt===null||tt.tag!==4||tt.stateNode.containerInfo!==_t.containerInfo||tt.stateNode.implementation!==_t.implementation?(tt=pf(_t,ft.mode,Ut),tt.return=ft,tt):(tt=f(tt,_t.children||[]),tt.return=ft,tt)}function Dt(ft,tt,_t,Ut,he){return tt===null||tt.tag!==7?(tt=Ls(_t,ft.mode,Ut,he),tt.return=ft,tt):(tt=f(tt,_t),tt.return=ft,tt)}function Nt(ft,tt,_t){if(typeof tt=="string"&&tt!==""||typeof tt=="number"||typeof tt=="bigint")return tt=df(""+tt,ft.mode,_t),tt.return=ft,tt;if(typeof tt=="object"&&tt!==null){switch(tt.$$typeof){case x:return _t=Yl(tt.type,tt.key,tt.props,null,ft.mode,_t),Do(_t,tt),_t.return=ft,_t;case b:return tt=pf(tt,ft.mode,_t),tt.return=ft,tt;case T:return tt=Is(tt),Nt(ft,tt,_t)}if(q(tt)||Q(tt))return tt=Ls(tt,ft.mode,_t,null),tt.return=ft,tt;if(typeof tt.then=="function")return Nt(ft,tc(tt),_t);if(tt.$$typeof===O)return Nt(ft,Jl(ft,tt),_t);ec(ft,tt)}return null}function yt(ft,tt,_t,Ut){var he=tt!==null?tt.key:null;if(typeof _t=="string"&&_t!==""||typeof _t=="number"||typeof _t=="bigint")return he!==null?null:N(ft,tt,""+_t,Ut);if(typeof _t=="object"&&_t!==null){switch(_t.$$typeof){case x:return _t.key===he?K(ft,tt,_t,Ut):null;case b:return _t.key===he?xt(ft,tt,_t,Ut):null;case T:return _t=Is(_t),yt(ft,tt,_t,Ut)}if(q(_t)||Q(_t))return he!==null?null:Dt(ft,tt,_t,Ut,null);if(typeof _t.then=="function")return yt(ft,tt,tc(_t),Ut);if(_t.$$typeof===O)return yt(ft,tt,Jl(ft,_t),Ut);ec(ft,_t)}return null}function wt(ft,tt,_t,Ut,he){if(typeof Ut=="string"&&Ut!==""||typeof Ut=="number"||typeof Ut=="bigint")return ft=ft.get(_t)||null,N(tt,ft,""+Ut,he);if(typeof Ut=="object"&&Ut!==null){switch(Ut.$$typeof){case x:return ft=ft.get(Ut.key===null?_t:Ut.key)||null,K(tt,ft,Ut,he);case b:return ft=ft.get(Ut.key===null?_t:Ut.key)||null,xt(tt,ft,Ut,he);case T:return Ut=Is(Ut),wt(ft,tt,_t,Ut,he)}if(q(Ut)||Q(Ut))return ft=ft.get(_t)||null,Dt(tt,ft,Ut,he,null);if(typeof Ut.then=="function")return wt(ft,tt,_t,tc(Ut),he);if(Ut.$$typeof===O)return wt(ft,tt,_t,Jl(tt,Ut),he);ec(tt,Ut)}return null}function se(ft,tt,_t,Ut){for(var he=null,Ye=null,oe=tt,we=tt=0,Be=null;oe!==null&&we<_t.length;we++){oe.index>we?(Be=oe,oe=null):Be=oe.sibling;var Ze=yt(ft,oe,_t[we],Ut);if(Ze===null){oe===null&&(oe=Be);break}e&&oe&&Ze.alternate===null&&i(ft,oe),tt=d(Ze,tt,we),Ye===null?he=Ze:Ye.sibling=Ze,Ye=Ze,oe=Be}if(we===_t.length)return s(ft,oe),Ge&&va(ft,we),he;if(oe===null){for(;we<_t.length;we++)oe=Nt(ft,_t[we],Ut),oe!==null&&(tt=d(oe,tt,we),Ye===null?he=oe:Ye.sibling=oe,Ye=oe);return Ge&&va(ft,we),he}for(oe=l(oe);we<_t.length;we++)Be=wt(oe,ft,we,_t[we],Ut),Be!==null&&(e&&Be.alternate!==null&&oe.delete(Be.key===null?we:Be.key),tt=d(Be,tt,we),Ye===null?he=Be:Ye.sibling=Be,Ye=Be);return e&&oe.forEach(function(_s){return i(ft,_s)}),Ge&&va(ft,we),he}function ge(ft,tt,_t,Ut){if(_t==null)throw Error(a(151));for(var he=null,Ye=null,oe=tt,we=tt=0,Be=null,Ze=_t.next();oe!==null&&!Ze.done;we++,Ze=_t.next()){oe.index>we?(Be=oe,oe=null):Be=oe.sibling;var _s=yt(ft,oe,Ze.value,Ut);if(_s===null){oe===null&&(oe=Be);break}e&&oe&&_s.alternate===null&&i(ft,oe),tt=d(_s,tt,we),Ye===null?he=_s:Ye.sibling=_s,Ye=_s,oe=Be}if(Ze.done)return s(ft,oe),Ge&&va(ft,we),he;if(oe===null){for(;!Ze.done;we++,Ze=_t.next())Ze=Nt(ft,Ze.value,Ut),Ze!==null&&(tt=d(Ze,tt,we),Ye===null?he=Ze:Ye.sibling=Ze,Ye=Ze);return Ge&&va(ft,we),he}for(oe=l(oe);!Ze.done;we++,Ze=_t.next())Ze=wt(oe,ft,we,Ze.value,Ut),Ze!==null&&(e&&Ze.alternate!==null&&oe.delete(Ze.key===null?we:Ze.key),tt=d(Ze,tt,we),Ye===null?he=Ze:Ye.sibling=Ze,Ye=Ze);return e&&oe.forEach(function(dy){return i(ft,dy)}),Ge&&va(ft,we),he}function ln(ft,tt,_t,Ut){if(typeof _t=="object"&&_t!==null&&_t.type===R&&_t.key===null&&(_t=_t.props.children),typeof _t=="object"&&_t!==null){switch(_t.$$typeof){case x:t:{for(var he=_t.key;tt!==null;){if(tt.key===he){if(he=_t.type,he===R){if(tt.tag===7){s(ft,tt.sibling),Ut=f(tt,_t.props.children),Ut.return=ft,ft=Ut;break t}}else if(tt.elementType===he||typeof he=="object"&&he!==null&&he.$$typeof===T&&Is(he)===tt.type){s(ft,tt.sibling),Ut=f(tt,_t.props),Do(Ut,_t),Ut.return=ft,ft=Ut;break t}s(ft,tt);break}else i(ft,tt);tt=tt.sibling}_t.type===R?(Ut=Ls(_t.props.children,ft.mode,Ut,_t.key),Ut.return=ft,ft=Ut):(Ut=Yl(_t.type,_t.key,_t.props,null,ft.mode,Ut),Do(Ut,_t),Ut.return=ft,ft=Ut)}return y(ft);case b:t:{for(he=_t.key;tt!==null;){if(tt.key===he)if(tt.tag===4&&tt.stateNode.containerInfo===_t.containerInfo&&tt.stateNode.implementation===_t.implementation){s(ft,tt.sibling),Ut=f(tt,_t.children||[]),Ut.return=ft,ft=Ut;break t}else{s(ft,tt);break}else i(ft,tt);tt=tt.sibling}Ut=pf(_t,ft.mode,Ut),Ut.return=ft,ft=Ut}return y(ft);case T:return _t=Is(_t),ln(ft,tt,_t,Ut)}if(q(_t))return se(ft,tt,_t,Ut);if(Q(_t)){if(he=Q(_t),typeof he!="function")throw Error(a(150));return _t=he.call(_t),ge(ft,tt,_t,Ut)}if(typeof _t.then=="function")return ln(ft,tt,tc(_t),Ut);if(_t.$$typeof===O)return ln(ft,tt,Jl(ft,_t),Ut);ec(ft,_t)}return typeof _t=="string"&&_t!==""||typeof _t=="number"||typeof _t=="bigint"?(_t=""+_t,tt!==null&&tt.tag===6?(s(ft,tt.sibling),Ut=f(tt,_t),Ut.return=ft,ft=Ut):(s(ft,tt),Ut=df(_t,ft.mode,Ut),Ut.return=ft,ft=Ut),y(ft)):s(ft,tt)}return function(ft,tt,_t,Ut){try{Co=0;var he=ln(ft,tt,_t,Ut);return Tr=null,he}catch(oe){if(oe===Er||oe===jl)throw oe;var Ye=gi(29,oe,null,ft.mode);return Ye.lanes=Ut,Ye.return=ft,Ye}finally{}}}var Fs=t0(!0),e0=t0(!1),es=!1;function Af(e){e.updateQueue={baseState:e.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,lanes:0,hiddenCallbacks:null},callbacks:null}}function wf(e,i){e=e.updateQueue,i.updateQueue===e&&(i.updateQueue={baseState:e.baseState,firstBaseUpdate:e.firstBaseUpdate,lastBaseUpdate:e.lastBaseUpdate,shared:e.shared,callbacks:null})}function ns(e){return{lane:e,tag:0,payload:null,callback:null,next:null}}function is(e,i,s){var l=e.updateQueue;if(l===null)return null;if(l=l.shared,(Qe&2)!==0){var f=l.pending;return f===null?i.next=i:(i.next=f.next,f.next=i),l.pending=i,i=ql(e),Bm(e,null,s),i}return Wl(e,l,i,s),ql(e)}function Uo(e,i,s){if(i=i.updateQueue,i!==null&&(i=i.shared,(s&4194048)!==0)){var l=i.lanes;l&=e.pendingLanes,s|=l,i.lanes=s,Gt(e,s)}}function Rf(e,i){var s=e.updateQueue,l=e.alternate;if(l!==null&&(l=l.updateQueue,s===l)){var f=null,d=null;if(s=s.firstBaseUpdate,s!==null){do{var y={lane:s.lane,tag:s.tag,payload:s.payload,callback:null,next:null};d===null?f=d=y:d=d.next=y,s=s.next}while(s!==null);d===null?f=d=i:d=d.next=i}else f=d=i;s={baseState:l.baseState,firstBaseUpdate:f,lastBaseUpdate:d,shared:l.shared,callbacks:l.callbacks},e.updateQueue=s;return}e=s.lastBaseUpdate,e===null?s.firstBaseUpdate=i:e.next=i,s.lastBaseUpdate=i}var Cf=!1;function Lo(){if(Cf){var e=br;if(e!==null)throw e}}function No(e,i,s,l){Cf=!1;var f=e.updateQueue;es=!1;var d=f.firstBaseUpdate,y=f.lastBaseUpdate,N=f.shared.pending;if(N!==null){f.shared.pending=null;var K=N,xt=K.next;K.next=null,y===null?d=xt:y.next=xt,y=K;var Dt=e.alternate;Dt!==null&&(Dt=Dt.updateQueue,N=Dt.lastBaseUpdate,N!==y&&(N===null?Dt.firstBaseUpdate=xt:N.next=xt,Dt.lastBaseUpdate=K))}if(d!==null){var Nt=f.baseState;y=0,Dt=xt=K=null,N=d;do{var yt=N.lane&-536870913,wt=yt!==N.lane;if(wt?(Ie&yt)===yt:(l&yt)===yt){yt!==0&&yt===yr&&(Cf=!0),Dt!==null&&(Dt=Dt.next={lane:0,tag:N.tag,payload:N.payload,callback:null,next:null});t:{var se=e,ge=N;yt=i;var ln=s;switch(ge.tag){case 1:if(se=ge.payload,typeof se=="function"){Nt=se.call(ln,Nt,yt);break t}Nt=se;break t;case 3:se.flags=se.flags&-65537|128;case 0:if(se=ge.payload,yt=typeof se=="function"?se.call(ln,Nt,yt):se,yt==null)break t;Nt=_({},Nt,yt);break t;case 2:es=!0}}yt=N.callback,yt!==null&&(e.flags|=64,wt&&(e.flags|=8192),wt=f.callbacks,wt===null?f.callbacks=[yt]:wt.push(yt))}else wt={lane:yt,tag:N.tag,payload:N.payload,callback:N.callback,next:null},Dt===null?(xt=Dt=wt,K=Nt):Dt=Dt.next=wt,y|=yt;if(N=N.next,N===null){if(N=f.shared.pending,N===null)break;wt=N,N=wt.next,wt.next=null,f.lastBaseUpdate=wt,f.shared.pending=null}}while(!0);Dt===null&&(K=Nt),f.baseState=K,f.firstBaseUpdate=xt,f.lastBaseUpdate=Dt,d===null&&(f.shared.lanes=0),ls|=y,e.lanes=y,e.memoizedState=Nt}}function n0(e,i){if(typeof e!="function")throw Error(a(191,e));e.call(i)}function i0(e,i){var s=e.callbacks;if(s!==null)for(e.callbacks=null,e=0;e<s.length;e++)n0(s[e],i)}var Ar=I(null),nc=I(0);function a0(e,i){e=Ra,At(nc,e),At(Ar,i),Ra=e|i.baseLanes}function Df(){At(nc,Ra),At(Ar,Ar.current)}function Uf(){Ra=nc.current,ct(Ar),ct(nc)}var vi=I(null),Pi=null;function as(e){var i=e.alternate;At(An,An.current&1),At(vi,e),Pi===null&&(i===null||Ar.current!==null||i.memoizedState!==null)&&(Pi=e)}function Lf(e){At(An,An.current),At(vi,e),Pi===null&&(Pi=e)}function s0(e){e.tag===22?(At(An,An.current),At(vi,e),Pi===null&&(Pi=e)):ss()}function ss(){At(An,An.current),At(vi,vi.current)}function _i(e){ct(vi),Pi===e&&(Pi=null),ct(An)}var An=I(0);function ic(e){for(var i=e;i!==null;){if(i.tag===13){var s=i.memoizedState;if(s!==null&&(s=s.dehydrated,s===null||Bh(s)||Fh(s)))return i}else if(i.tag===19&&(i.memoizedProps.revealOrder==="forwards"||i.memoizedProps.revealOrder==="backwards"||i.memoizedProps.revealOrder==="unstable_legacy-backwards"||i.memoizedProps.revealOrder==="together")){if((i.flags&128)!==0)return i}else if(i.child!==null){i.child.return=i,i=i.child;continue}if(i===e)break;for(;i.sibling===null;){if(i.return===null||i.return===e)return null;i=i.return}i.sibling.return=i.return,i=i.sibling}return null}var Sa=0,Ae=null,rn=null,Un=null,ac=!1,wr=!1,Hs=!1,sc=0,Oo=0,Rr=null,iM=0;function yn(){throw Error(a(321))}function Nf(e,i){if(i===null)return!1;for(var s=0;s<i.length&&s<e.length;s++)if(!mi(e[s],i[s]))return!1;return!0}function Of(e,i,s,l,f,d){return Sa=d,Ae=i,i.memoizedState=null,i.updateQueue=null,i.lanes=0,F.H=e===null||e.memoizedState===null?V0:Kf,Hs=!1,d=s(l,f),Hs=!1,wr&&(d=o0(i,s,l,f)),r0(e),d}function r0(e){F.H=Io;var i=rn!==null&&rn.next!==null;if(Sa=0,Un=rn=Ae=null,ac=!1,Oo=0,Rr=null,i)throw Error(a(300));e===null||Ln||(e=e.dependencies,e!==null&&Kl(e)&&(Ln=!0))}function o0(e,i,s,l){Ae=e;var f=0;do{if(wr&&(Rr=null),Oo=0,wr=!1,25<=f)throw Error(a(301));if(f+=1,Un=rn=null,e.updateQueue!=null){var d=e.updateQueue;d.lastEffect=null,d.events=null,d.stores=null,d.memoCache!=null&&(d.memoCache.index=0)}F.H=k0,d=i(s,l)}while(wr);return d}function aM(){var e=F.H,i=e.useState()[0];return i=typeof i.then=="function"?Po(i):i,e=e.useState()[0],(rn!==null?rn.memoizedState:null)!==e&&(Ae.flags|=1024),i}function Pf(){var e=sc!==0;return sc=0,e}function zf(e,i,s){i.updateQueue=e.updateQueue,i.flags&=-2053,e.lanes&=~s}function If(e){if(ac){for(e=e.memoizedState;e!==null;){var i=e.queue;i!==null&&(i.pending=null),e=e.next}ac=!1}Sa=0,Un=rn=Ae=null,wr=!1,Oo=sc=0,Rr=null}function ai(){var e={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return Un===null?Ae.memoizedState=Un=e:Un=Un.next=e,Un}function wn(){if(rn===null){var e=Ae.alternate;e=e!==null?e.memoizedState:null}else e=rn.next;var i=Un===null?Ae.memoizedState:Un.next;if(i!==null)Un=i,rn=e;else{if(e===null)throw Ae.alternate===null?Error(a(467)):Error(a(310));rn=e,e={memoizedState:rn.memoizedState,baseState:rn.baseState,baseQueue:rn.baseQueue,queue:rn.queue,next:null},Un===null?Ae.memoizedState=Un=e:Un=Un.next=e}return Un}function rc(){return{lastEffect:null,events:null,stores:null,memoCache:null}}function Po(e){var i=Oo;return Oo+=1,Rr===null&&(Rr=[]),e=Qm(Rr,e,i),i=Ae,(Un===null?i.memoizedState:Un.next)===null&&(i=i.alternate,F.H=i===null||i.memoizedState===null?V0:Kf),e}function oc(e){if(e!==null&&typeof e=="object"){if(typeof e.then=="function")return Po(e);if(e.$$typeof===O)return Zn(e)}throw Error(a(438,String(e)))}function Bf(e){var i=null,s=Ae.updateQueue;if(s!==null&&(i=s.memoCache),i==null){var l=Ae.alternate;l!==null&&(l=l.updateQueue,l!==null&&(l=l.memoCache,l!=null&&(i={data:l.data.map(function(f){return f.slice()}),index:0})))}if(i==null&&(i={data:[],index:0}),s===null&&(s=rc(),Ae.updateQueue=s),s.memoCache=i,s=i.data[i.index],s===void 0)for(s=i.data[i.index]=Array(e),l=0;l<e;l++)s[l]=W;return i.index++,s}function Ma(e,i){return typeof i=="function"?i(e):i}function lc(e){var i=wn();return Ff(i,rn,e)}function Ff(e,i,s){var l=e.queue;if(l===null)throw Error(a(311));l.lastRenderedReducer=s;var f=e.baseQueue,d=l.pending;if(d!==null){if(f!==null){var y=f.next;f.next=d.next,d.next=y}i.baseQueue=f=d,l.pending=null}if(d=e.baseState,f===null)e.memoizedState=d;else{i=f.next;var N=y=null,K=null,xt=i,Dt=!1;do{var Nt=xt.lane&-536870913;if(Nt!==xt.lane?(Ie&Nt)===Nt:(Sa&Nt)===Nt){var yt=xt.revertLane;if(yt===0)K!==null&&(K=K.next={lane:0,revertLane:0,gesture:null,action:xt.action,hasEagerState:xt.hasEagerState,eagerState:xt.eagerState,next:null}),Nt===yr&&(Dt=!0);else if((Sa&yt)===yt){xt=xt.next,yt===yr&&(Dt=!0);continue}else Nt={lane:0,revertLane:xt.revertLane,gesture:null,action:xt.action,hasEagerState:xt.hasEagerState,eagerState:xt.eagerState,next:null},K===null?(N=K=Nt,y=d):K=K.next=Nt,Ae.lanes|=yt,ls|=yt;Nt=xt.action,Hs&&s(d,Nt),d=xt.hasEagerState?xt.eagerState:s(d,Nt)}else yt={lane:Nt,revertLane:xt.revertLane,gesture:xt.gesture,action:xt.action,hasEagerState:xt.hasEagerState,eagerState:xt.eagerState,next:null},K===null?(N=K=yt,y=d):K=K.next=yt,Ae.lanes|=Nt,ls|=Nt;xt=xt.next}while(xt!==null&&xt!==i);if(K===null?y=d:K.next=N,!mi(d,e.memoizedState)&&(Ln=!0,Dt&&(s=br,s!==null)))throw s;e.memoizedState=d,e.baseState=y,e.baseQueue=K,l.lastRenderedState=d}return f===null&&(l.lanes=0),[e.memoizedState,l.dispatch]}function Hf(e){var i=wn(),s=i.queue;if(s===null)throw Error(a(311));s.lastRenderedReducer=e;var l=s.dispatch,f=s.pending,d=i.memoizedState;if(f!==null){s.pending=null;var y=f=f.next;do d=e(d,y.action),y=y.next;while(y!==f);mi(d,i.memoizedState)||(Ln=!0),i.memoizedState=d,i.baseQueue===null&&(i.baseState=d),s.lastRenderedState=d}return[d,l]}function l0(e,i,s){var l=Ae,f=wn(),d=Ge;if(d){if(s===void 0)throw Error(a(407));s=s()}else s=i();var y=!mi((rn||f).memoizedState,s);if(y&&(f.memoizedState=s,Ln=!0),f=f.queue,kf(f0.bind(null,l,f,e),[e]),f.getSnapshot!==i||y||Un!==null&&Un.memoizedState.tag&1){if(l.flags|=2048,Cr(9,{destroy:void 0},u0.bind(null,l,f,s,i),null),fn===null)throw Error(a(349));d||(Sa&127)!==0||c0(l,i,s)}return s}function c0(e,i,s){e.flags|=16384,e={getSnapshot:i,value:s},i=Ae.updateQueue,i===null?(i=rc(),Ae.updateQueue=i,i.stores=[e]):(s=i.stores,s===null?i.stores=[e]:s.push(e))}function u0(e,i,s,l){i.value=s,i.getSnapshot=l,h0(i)&&d0(e)}function f0(e,i,s){return s(function(){h0(i)&&d0(e)})}function h0(e){var i=e.getSnapshot;e=e.value;try{var s=i();return!mi(e,s)}catch{return!0}}function d0(e){var i=Us(e,2);i!==null&&di(i,e,2)}function Gf(e){var i=ai();if(typeof e=="function"){var s=e;if(e=s(),Hs){Ot(!0);try{s()}finally{Ot(!1)}}}return i.memoizedState=i.baseState=e,i.queue={pending:null,lanes:0,dispatch:null,lastRenderedReducer:Ma,lastRenderedState:e},i}function p0(e,i,s,l){return e.baseState=s,Ff(e,rn,typeof l=="function"?l:Ma)}function sM(e,i,s,l,f){if(fc(e))throw Error(a(485));if(e=i.action,e!==null){var d={payload:f,action:e,next:null,isTransition:!0,status:"pending",value:null,reason:null,listeners:[],then:function(y){d.listeners.push(y)}};F.T!==null?s(!0):d.isTransition=!1,l(d),s=i.pending,s===null?(d.next=i.pending=d,m0(i,d)):(d.next=s.next,i.pending=s.next=d)}}function m0(e,i){var s=i.action,l=i.payload,f=e.state;if(i.isTransition){var d=F.T,y={};F.T=y;try{var N=s(f,l),K=F.S;K!==null&&K(y,N),g0(e,i,N)}catch(xt){Vf(e,i,xt)}finally{d!==null&&y.types!==null&&(d.types=y.types),F.T=d}}else try{d=s(f,l),g0(e,i,d)}catch(xt){Vf(e,i,xt)}}function g0(e,i,s){s!==null&&typeof s=="object"&&typeof s.then=="function"?s.then(function(l){v0(e,i,l)},function(l){return Vf(e,i,l)}):v0(e,i,s)}function v0(e,i,s){i.status="fulfilled",i.value=s,_0(i),e.state=s,i=e.pending,i!==null&&(s=i.next,s===i?e.pending=null:(s=s.next,i.next=s,m0(e,s)))}function Vf(e,i,s){var l=e.pending;if(e.pending=null,l!==null){l=l.next;do i.status="rejected",i.reason=s,_0(i),i=i.next;while(i!==l)}e.action=null}function _0(e){e=e.listeners;for(var i=0;i<e.length;i++)(0,e[i])()}function x0(e,i){return i}function S0(e,i){if(Ge){var s=fn.formState;if(s!==null){t:{var l=Ae;if(Ge){if(dn){e:{for(var f=dn,d=Oi;f.nodeType!==8;){if(!d){f=null;break e}if(f=zi(f.nextSibling),f===null){f=null;break e}}d=f.data,f=d==="F!"||d==="F"?f:null}if(f){dn=zi(f.nextSibling),l=f.data==="F!";break t}}$a(l)}l=!1}l&&(i=s[0])}}return s=ai(),s.memoizedState=s.baseState=i,l={pending:null,lanes:0,dispatch:null,lastRenderedReducer:x0,lastRenderedState:i},s.queue=l,s=F0.bind(null,Ae,l),l.dispatch=s,l=Gf(!1),d=Zf.bind(null,Ae,!1,l.queue),l=ai(),f={state:i,dispatch:null,action:e,pending:null},l.queue=f,s=sM.bind(null,Ae,f,d,s),f.dispatch=s,l.memoizedState=e,[i,s,!1]}function M0(e){var i=wn();return y0(i,rn,e)}function y0(e,i,s){if(i=Ff(e,i,x0)[0],e=lc(Ma)[0],typeof i=="object"&&i!==null&&typeof i.then=="function")try{var l=Po(i)}catch(y){throw y===Er?jl:y}else l=i;i=wn();var f=i.queue,d=f.dispatch;return s!==i.memoizedState&&(Ae.flags|=2048,Cr(9,{destroy:void 0},rM.bind(null,f,s),null)),[l,d,e]}function rM(e,i){e.action=i}function b0(e){var i=wn(),s=rn;if(s!==null)return y0(i,s,e);wn(),i=i.memoizedState,s=wn();var l=s.queue.dispatch;return s.memoizedState=e,[i,l,!1]}function Cr(e,i,s,l){return e={tag:e,create:s,deps:l,inst:i,next:null},i=Ae.updateQueue,i===null&&(i=rc(),Ae.updateQueue=i),s=i.lastEffect,s===null?i.lastEffect=e.next=e:(l=s.next,s.next=e,e.next=l,i.lastEffect=e),e}function E0(){return wn().memoizedState}function cc(e,i,s,l){var f=ai();Ae.flags|=e,f.memoizedState=Cr(1|i,{destroy:void 0},s,l===void 0?null:l)}function uc(e,i,s,l){var f=wn();l=l===void 0?null:l;var d=f.memoizedState.inst;rn!==null&&l!==null&&Nf(l,rn.memoizedState.deps)?f.memoizedState=Cr(i,d,s,l):(Ae.flags|=e,f.memoizedState=Cr(1|i,d,s,l))}function T0(e,i){cc(8390656,8,e,i)}function kf(e,i){uc(2048,8,e,i)}function oM(e){Ae.flags|=4;var i=Ae.updateQueue;if(i===null)i=rc(),Ae.updateQueue=i,i.events=[e];else{var s=i.events;s===null?i.events=[e]:s.push(e)}}function A0(e){var i=wn().memoizedState;return oM({ref:i,nextImpl:e}),function(){if((Qe&2)!==0)throw Error(a(440));return i.impl.apply(void 0,arguments)}}function w0(e,i){return uc(4,2,e,i)}function R0(e,i){return uc(4,4,e,i)}function C0(e,i){if(typeof i=="function"){e=e();var s=i(e);return function(){typeof s=="function"?s():i(null)}}if(i!=null)return e=e(),i.current=e,function(){i.current=null}}function D0(e,i,s){s=s!=null?s.concat([e]):null,uc(4,4,C0.bind(null,i,e),s)}function Xf(){}function U0(e,i){var s=wn();i=i===void 0?null:i;var l=s.memoizedState;return i!==null&&Nf(i,l[1])?l[0]:(s.memoizedState=[e,i],e)}function L0(e,i){var s=wn();i=i===void 0?null:i;var l=s.memoizedState;if(i!==null&&Nf(i,l[1]))return l[0];if(l=e(),Hs){Ot(!0);try{e()}finally{Ot(!1)}}return s.memoizedState=[l,i],l}function Wf(e,i,s){return s===void 0||(Sa&1073741824)!==0&&(Ie&261930)===0?e.memoizedState=i:(e.memoizedState=s,e=Ng(),Ae.lanes|=e,ls|=e,s)}function N0(e,i,s,l){return mi(s,i)?s:Ar.current!==null?(e=Wf(e,s,l),mi(e,i)||(Ln=!0),e):(Sa&42)===0||(Sa&1073741824)!==0&&(Ie&261930)===0?(Ln=!0,e.memoizedState=s):(e=Ng(),Ae.lanes|=e,ls|=e,i)}function O0(e,i,s,l,f){var d=Z.p;Z.p=d!==0&&8>d?d:8;var y=F.T,N={};F.T=N,Zf(e,!1,i,s);try{var K=f(),xt=F.S;if(xt!==null&&xt(N,K),K!==null&&typeof K=="object"&&typeof K.then=="function"){var Dt=nM(K,l);zo(e,i,Dt,Mi(e))}else zo(e,i,l,Mi(e))}catch(Nt){zo(e,i,{then:function(){},status:"rejected",reason:Nt},Mi())}finally{Z.p=d,y!==null&&N.types!==null&&(y.types=N.types),F.T=y}}function lM(){}function qf(e,i,s,l){if(e.tag!==5)throw Error(a(476));var f=P0(e).queue;O0(e,f,i,ht,s===null?lM:function(){return z0(e),s(l)})}function P0(e){var i=e.memoizedState;if(i!==null)return i;i={memoizedState:ht,baseState:ht,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:Ma,lastRenderedState:ht},next:null};var s={};return i.next={memoizedState:s,baseState:s,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:Ma,lastRenderedState:s},next:null},e.memoizedState=i,e=e.alternate,e!==null&&(e.memoizedState=i),i}function z0(e){var i=P0(e);i.next===null&&(i=e.alternate.memoizedState),zo(e,i.next.queue,{},Mi())}function Yf(){return Zn($o)}function I0(){return wn().memoizedState}function B0(){return wn().memoizedState}function cM(e){for(var i=e.return;i!==null;){switch(i.tag){case 24:case 3:var s=Mi();e=ns(s);var l=is(i,e,s);l!==null&&(di(l,i,s),Uo(l,i,s)),i={cache:yf()},e.payload=i;return}i=i.return}}function uM(e,i,s){var l=Mi();s={lane:l,revertLane:0,gesture:null,action:s,hasEagerState:!1,eagerState:null,next:null},fc(e)?H0(i,s):(s=ff(e,i,s,l),s!==null&&(di(s,e,l),G0(s,i,l)))}function F0(e,i,s){var l=Mi();zo(e,i,s,l)}function zo(e,i,s,l){var f={lane:l,revertLane:0,gesture:null,action:s,hasEagerState:!1,eagerState:null,next:null};if(fc(e))H0(i,f);else{var d=e.alternate;if(e.lanes===0&&(d===null||d.lanes===0)&&(d=i.lastRenderedReducer,d!==null))try{var y=i.lastRenderedState,N=d(y,s);if(f.hasEagerState=!0,f.eagerState=N,mi(N,y))return Wl(e,i,f,0),fn===null&&Xl(),!1}catch{}finally{}if(s=ff(e,i,f,l),s!==null)return di(s,e,l),G0(s,i,l),!0}return!1}function Zf(e,i,s,l){if(l={lane:2,revertLane:Ah(),gesture:null,action:l,hasEagerState:!1,eagerState:null,next:null},fc(e)){if(i)throw Error(a(479))}else i=ff(e,s,l,2),i!==null&&di(i,e,2)}function fc(e){var i=e.alternate;return e===Ae||i!==null&&i===Ae}function H0(e,i){wr=ac=!0;var s=e.pending;s===null?i.next=i:(i.next=s.next,s.next=i),e.pending=i}function G0(e,i,s){if((s&4194048)!==0){var l=i.lanes;l&=e.pendingLanes,s|=l,i.lanes=s,Gt(e,s)}}var Io={readContext:Zn,use:oc,useCallback:yn,useContext:yn,useEffect:yn,useImperativeHandle:yn,useLayoutEffect:yn,useInsertionEffect:yn,useMemo:yn,useReducer:yn,useRef:yn,useState:yn,useDebugValue:yn,useDeferredValue:yn,useTransition:yn,useSyncExternalStore:yn,useId:yn,useHostTransitionStatus:yn,useFormState:yn,useActionState:yn,useOptimistic:yn,useMemoCache:yn,useCacheRefresh:yn};Io.useEffectEvent=yn;var V0={readContext:Zn,use:oc,useCallback:function(e,i){return ai().memoizedState=[e,i===void 0?null:i],e},useContext:Zn,useEffect:T0,useImperativeHandle:function(e,i,s){s=s!=null?s.concat([e]):null,cc(4194308,4,C0.bind(null,i,e),s)},useLayoutEffect:function(e,i){return cc(4194308,4,e,i)},useInsertionEffect:function(e,i){cc(4,2,e,i)},useMemo:function(e,i){var s=ai();i=i===void 0?null:i;var l=e();if(Hs){Ot(!0);try{e()}finally{Ot(!1)}}return s.memoizedState=[l,i],l},useReducer:function(e,i,s){var l=ai();if(s!==void 0){var f=s(i);if(Hs){Ot(!0);try{s(i)}finally{Ot(!1)}}}else f=i;return l.memoizedState=l.baseState=f,e={pending:null,lanes:0,dispatch:null,lastRenderedReducer:e,lastRenderedState:f},l.queue=e,e=e.dispatch=uM.bind(null,Ae,e),[l.memoizedState,e]},useRef:function(e){var i=ai();return e={current:e},i.memoizedState=e},useState:function(e){e=Gf(e);var i=e.queue,s=F0.bind(null,Ae,i);return i.dispatch=s,[e.memoizedState,s]},useDebugValue:Xf,useDeferredValue:function(e,i){var s=ai();return Wf(s,e,i)},useTransition:function(){var e=Gf(!1);return e=O0.bind(null,Ae,e.queue,!0,!1),ai().memoizedState=e,[!1,e]},useSyncExternalStore:function(e,i,s){var l=Ae,f=ai();if(Ge){if(s===void 0)throw Error(a(407));s=s()}else{if(s=i(),fn===null)throw Error(a(349));(Ie&127)!==0||c0(l,i,s)}f.memoizedState=s;var d={value:s,getSnapshot:i};return f.queue=d,T0(f0.bind(null,l,d,e),[e]),l.flags|=2048,Cr(9,{destroy:void 0},u0.bind(null,l,d,s,i),null),s},useId:function(){var e=ai(),i=fn.identifierPrefix;if(Ge){var s=na,l=ea;s=(l&~(1<<32-Xt(l)-1)).toString(32)+s,i="_"+i+"R_"+s,s=sc++,0<s&&(i+="H"+s.toString(32)),i+="_"}else s=iM++,i="_"+i+"r_"+s.toString(32)+"_";return e.memoizedState=i},useHostTransitionStatus:Yf,useFormState:S0,useActionState:S0,useOptimistic:function(e){var i=ai();i.memoizedState=i.baseState=e;var s={pending:null,lanes:0,dispatch:null,lastRenderedReducer:null,lastRenderedState:null};return i.queue=s,i=Zf.bind(null,Ae,!0,s),s.dispatch=i,[e,i]},useMemoCache:Bf,useCacheRefresh:function(){return ai().memoizedState=cM.bind(null,Ae)},useEffectEvent:function(e){var i=ai(),s={impl:e};return i.memoizedState=s,function(){if((Qe&2)!==0)throw Error(a(440));return s.impl.apply(void 0,arguments)}}},Kf={readContext:Zn,use:oc,useCallback:U0,useContext:Zn,useEffect:kf,useImperativeHandle:D0,useInsertionEffect:w0,useLayoutEffect:R0,useMemo:L0,useReducer:lc,useRef:E0,useState:function(){return lc(Ma)},useDebugValue:Xf,useDeferredValue:function(e,i){var s=wn();return N0(s,rn.memoizedState,e,i)},useTransition:function(){var e=lc(Ma)[0],i=wn().memoizedState;return[typeof e=="boolean"?e:Po(e),i]},useSyncExternalStore:l0,useId:I0,useHostTransitionStatus:Yf,useFormState:M0,useActionState:M0,useOptimistic:function(e,i){var s=wn();return p0(s,rn,e,i)},useMemoCache:Bf,useCacheRefresh:B0};Kf.useEffectEvent=A0;var k0={readContext:Zn,use:oc,useCallback:U0,useContext:Zn,useEffect:kf,useImperativeHandle:D0,useInsertionEffect:w0,useLayoutEffect:R0,useMemo:L0,useReducer:Hf,useRef:E0,useState:function(){return Hf(Ma)},useDebugValue:Xf,useDeferredValue:function(e,i){var s=wn();return rn===null?Wf(s,e,i):N0(s,rn.memoizedState,e,i)},useTransition:function(){var e=Hf(Ma)[0],i=wn().memoizedState;return[typeof e=="boolean"?e:Po(e),i]},useSyncExternalStore:l0,useId:I0,useHostTransitionStatus:Yf,useFormState:b0,useActionState:b0,useOptimistic:function(e,i){var s=wn();return rn!==null?p0(s,rn,e,i):(s.baseState=e,[e,s.queue.dispatch])},useMemoCache:Bf,useCacheRefresh:B0};k0.useEffectEvent=A0;function Jf(e,i,s,l){i=e.memoizedState,s=s(l,i),s=s==null?i:_({},i,s),e.memoizedState=s,e.lanes===0&&(e.updateQueue.baseState=s)}var Qf={enqueueSetState:function(e,i,s){e=e._reactInternals;var l=Mi(),f=ns(l);f.payload=i,s!=null&&(f.callback=s),i=is(e,f,l),i!==null&&(di(i,e,l),Uo(i,e,l))},enqueueReplaceState:function(e,i,s){e=e._reactInternals;var l=Mi(),f=ns(l);f.tag=1,f.payload=i,s!=null&&(f.callback=s),i=is(e,f,l),i!==null&&(di(i,e,l),Uo(i,e,l))},enqueueForceUpdate:function(e,i){e=e._reactInternals;var s=Mi(),l=ns(s);l.tag=2,i!=null&&(l.callback=i),i=is(e,l,s),i!==null&&(di(i,e,s),Uo(i,e,s))}};function X0(e,i,s,l,f,d,y){return e=e.stateNode,typeof e.shouldComponentUpdate=="function"?e.shouldComponentUpdate(l,d,y):i.prototype&&i.prototype.isPureReactComponent?!bo(s,l)||!bo(f,d):!0}function W0(e,i,s,l){e=i.state,typeof i.componentWillReceiveProps=="function"&&i.componentWillReceiveProps(s,l),typeof i.UNSAFE_componentWillReceiveProps=="function"&&i.UNSAFE_componentWillReceiveProps(s,l),i.state!==e&&Qf.enqueueReplaceState(i,i.state,null)}function Gs(e,i){var s=i;if("ref"in i){s={};for(var l in i)l!=="ref"&&(s[l]=i[l])}if(e=e.defaultProps){s===i&&(s=_({},s));for(var f in e)s[f]===void 0&&(s[f]=e[f])}return s}function q0(e){kl(e)}function Y0(e){console.error(e)}function Z0(e){kl(e)}function hc(e,i){try{var s=e.onUncaughtError;s(i.value,{componentStack:i.stack})}catch(l){setTimeout(function(){throw l})}}function K0(e,i,s){try{var l=e.onCaughtError;l(s.value,{componentStack:s.stack,errorBoundary:i.tag===1?i.stateNode:null})}catch(f){setTimeout(function(){throw f})}}function jf(e,i,s){return s=ns(s),s.tag=3,s.payload={element:null},s.callback=function(){hc(e,i)},s}function J0(e){return e=ns(e),e.tag=3,e}function Q0(e,i,s,l){var f=s.type.getDerivedStateFromError;if(typeof f=="function"){var d=l.value;e.payload=function(){return f(d)},e.callback=function(){K0(i,s,l)}}var y=s.stateNode;y!==null&&typeof y.componentDidCatch=="function"&&(e.callback=function(){K0(i,s,l),typeof f!="function"&&(cs===null?cs=new Set([this]):cs.add(this));var N=l.stack;this.componentDidCatch(l.value,{componentStack:N!==null?N:""})})}function fM(e,i,s,l,f){if(s.flags|=32768,l!==null&&typeof l=="object"&&typeof l.then=="function"){if(i=s.alternate,i!==null&&Mr(i,s,f,!0),s=vi.current,s!==null){switch(s.tag){case 31:case 13:return Pi===null?Ec():s.alternate===null&&bn===0&&(bn=3),s.flags&=-257,s.flags|=65536,s.lanes=f,l===$l?s.flags|=16384:(i=s.updateQueue,i===null?s.updateQueue=new Set([l]):i.add(l),bh(e,l,f)),!1;case 22:return s.flags|=65536,l===$l?s.flags|=16384:(i=s.updateQueue,i===null?(i={transitions:null,markerInstances:null,retryQueue:new Set([l])},s.updateQueue=i):(s=i.retryQueue,s===null?i.retryQueue=new Set([l]):s.add(l)),bh(e,l,f)),!1}throw Error(a(435,s.tag))}return bh(e,l,f),Ec(),!1}if(Ge)return i=vi.current,i!==null?((i.flags&65536)===0&&(i.flags|=256),i.flags|=65536,i.lanes=f,l!==vf&&(e=Error(a(422),{cause:l}),Ao(Ui(e,s)))):(l!==vf&&(i=Error(a(423),{cause:l}),Ao(Ui(i,s))),e=e.current.alternate,e.flags|=65536,f&=-f,e.lanes|=f,l=Ui(l,s),f=jf(e.stateNode,l,f),Rf(e,f),bn!==4&&(bn=2)),!1;var d=Error(a(520),{cause:l});if(d=Ui(d,s),Wo===null?Wo=[d]:Wo.push(d),bn!==4&&(bn=2),i===null)return!0;l=Ui(l,s),s=i;do{switch(s.tag){case 3:return s.flags|=65536,e=f&-f,s.lanes|=e,e=jf(s.stateNode,l,e),Rf(s,e),!1;case 1:if(i=s.type,d=s.stateNode,(s.flags&128)===0&&(typeof i.getDerivedStateFromError=="function"||d!==null&&typeof d.componentDidCatch=="function"&&(cs===null||!cs.has(d))))return s.flags|=65536,f&=-f,s.lanes|=f,f=J0(f),Q0(f,e,s,l),Rf(s,f),!1}s=s.return}while(s!==null);return!1}var $f=Error(a(461)),Ln=!1;function Kn(e,i,s,l){i.child=e===null?e0(i,null,s,l):Fs(i,e.child,s,l)}function j0(e,i,s,l,f){s=s.render;var d=i.ref;if("ref"in l){var y={};for(var N in l)N!=="ref"&&(y[N]=l[N])}else y=l;return Ps(i),l=Of(e,i,s,y,d,f),N=Pf(),e!==null&&!Ln?(zf(e,i,f),ya(e,i,f)):(Ge&&N&&mf(i),i.flags|=1,Kn(e,i,l,f),i.child)}function $0(e,i,s,l,f){if(e===null){var d=s.type;return typeof d=="function"&&!hf(d)&&d.defaultProps===void 0&&s.compare===null?(i.tag=15,i.type=d,tg(e,i,d,l,f)):(e=Yl(s.type,null,l,i,i.mode,f),e.ref=i.ref,e.return=i,i.child=e)}if(d=e.child,!oh(e,f)){var y=d.memoizedProps;if(s=s.compare,s=s!==null?s:bo,s(y,l)&&e.ref===i.ref)return ya(e,i,f)}return i.flags|=1,e=ga(d,l),e.ref=i.ref,e.return=i,i.child=e}function tg(e,i,s,l,f){if(e!==null){var d=e.memoizedProps;if(bo(d,l)&&e.ref===i.ref)if(Ln=!1,i.pendingProps=l=d,oh(e,f))(e.flags&131072)!==0&&(Ln=!0);else return i.lanes=e.lanes,ya(e,i,f)}return th(e,i,s,l,f)}function eg(e,i,s,l){var f=l.children,d=e!==null?e.memoizedState:null;if(e===null&&i.stateNode===null&&(i.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),l.mode==="hidden"){if((i.flags&128)!==0){if(d=d!==null?d.baseLanes|s:s,e!==null){for(l=i.child=e.child,f=0;l!==null;)f=f|l.lanes|l.childLanes,l=l.sibling;l=f&~d}else l=0,i.child=null;return ng(e,i,d,s,l)}if((s&536870912)!==0)i.memoizedState={baseLanes:0,cachePool:null},e!==null&&Ql(i,d!==null?d.cachePool:null),d!==null?a0(i,d):Df(),s0(i);else return l=i.lanes=536870912,ng(e,i,d!==null?d.baseLanes|s:s,s,l)}else d!==null?(Ql(i,d.cachePool),a0(i,d),ss(),i.memoizedState=null):(e!==null&&Ql(i,null),Df(),ss());return Kn(e,i,f,s),i.child}function Bo(e,i){return e!==null&&e.tag===22||i.stateNode!==null||(i.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),i.sibling}function ng(e,i,s,l,f){var d=Ef();return d=d===null?null:{parent:Dn._currentValue,pool:d},i.memoizedState={baseLanes:s,cachePool:d},e!==null&&Ql(i,null),Df(),s0(i),e!==null&&Mr(e,i,l,!0),i.childLanes=f,null}function dc(e,i){return i=mc({mode:i.mode,children:i.children},e.mode),i.ref=e.ref,e.child=i,i.return=e,i}function ig(e,i,s){return Fs(i,e.child,null,s),e=dc(i,i.pendingProps),e.flags|=2,_i(i),i.memoizedState=null,e}function hM(e,i,s){var l=i.pendingProps,f=(i.flags&128)!==0;if(i.flags&=-129,e===null){if(Ge){if(l.mode==="hidden")return e=dc(i,l),i.lanes=536870912,Bo(null,e);if(Lf(i),(e=dn)?(e=mv(e,Oi),e=e!==null&&e.data==="&"?e:null,e!==null&&(i.memoizedState={dehydrated:e,treeContext:Qa!==null?{id:ea,overflow:na}:null,retryLane:536870912,hydrationErrors:null},s=Hm(e),s.return=i,i.child=s,Yn=i,dn=null)):e=null,e===null)throw $a(i);return i.lanes=536870912,null}return dc(i,l)}var d=e.memoizedState;if(d!==null){var y=d.dehydrated;if(Lf(i),f)if(i.flags&256)i.flags&=-257,i=ig(e,i,s);else if(i.memoizedState!==null)i.child=e.child,i.flags|=128,i=null;else throw Error(a(558));else if(Ln||Mr(e,i,s,!1),f=(s&e.childLanes)!==0,Ln||f){if(l=fn,l!==null&&(y=Vt(l,s),y!==0&&y!==d.retryLane))throw d.retryLane=y,Us(e,y),di(l,e,y),$f;Ec(),i=ig(e,i,s)}else e=d.treeContext,dn=zi(y.nextSibling),Yn=i,Ge=!0,ja=null,Oi=!1,e!==null&&km(i,e),i=dc(i,l),i.flags|=4096;return i}return e=ga(e.child,{mode:l.mode,children:l.children}),e.ref=i.ref,i.child=e,e.return=i,e}function pc(e,i){var s=i.ref;if(s===null)e!==null&&e.ref!==null&&(i.flags|=4194816);else{if(typeof s!="function"&&typeof s!="object")throw Error(a(284));(e===null||e.ref!==s)&&(i.flags|=4194816)}}function th(e,i,s,l,f){return Ps(i),s=Of(e,i,s,l,void 0,f),l=Pf(),e!==null&&!Ln?(zf(e,i,f),ya(e,i,f)):(Ge&&l&&mf(i),i.flags|=1,Kn(e,i,s,f),i.child)}function ag(e,i,s,l,f,d){return Ps(i),i.updateQueue=null,s=o0(i,l,s,f),r0(e),l=Pf(),e!==null&&!Ln?(zf(e,i,d),ya(e,i,d)):(Ge&&l&&mf(i),i.flags|=1,Kn(e,i,s,d),i.child)}function sg(e,i,s,l,f){if(Ps(i),i.stateNode===null){var d=vr,y=s.contextType;typeof y=="object"&&y!==null&&(d=Zn(y)),d=new s(l,d),i.memoizedState=d.state!==null&&d.state!==void 0?d.state:null,d.updater=Qf,i.stateNode=d,d._reactInternals=i,d=i.stateNode,d.props=l,d.state=i.memoizedState,d.refs={},Af(i),y=s.contextType,d.context=typeof y=="object"&&y!==null?Zn(y):vr,d.state=i.memoizedState,y=s.getDerivedStateFromProps,typeof y=="function"&&(Jf(i,s,y,l),d.state=i.memoizedState),typeof s.getDerivedStateFromProps=="function"||typeof d.getSnapshotBeforeUpdate=="function"||typeof d.UNSAFE_componentWillMount!="function"&&typeof d.componentWillMount!="function"||(y=d.state,typeof d.componentWillMount=="function"&&d.componentWillMount(),typeof d.UNSAFE_componentWillMount=="function"&&d.UNSAFE_componentWillMount(),y!==d.state&&Qf.enqueueReplaceState(d,d.state,null),No(i,l,d,f),Lo(),d.state=i.memoizedState),typeof d.componentDidMount=="function"&&(i.flags|=4194308),l=!0}else if(e===null){d=i.stateNode;var N=i.memoizedProps,K=Gs(s,N);d.props=K;var xt=d.context,Dt=s.contextType;y=vr,typeof Dt=="object"&&Dt!==null&&(y=Zn(Dt));var Nt=s.getDerivedStateFromProps;Dt=typeof Nt=="function"||typeof d.getSnapshotBeforeUpdate=="function",N=i.pendingProps!==N,Dt||typeof d.UNSAFE_componentWillReceiveProps!="function"&&typeof d.componentWillReceiveProps!="function"||(N||xt!==y)&&W0(i,d,l,y),es=!1;var yt=i.memoizedState;d.state=yt,No(i,l,d,f),Lo(),xt=i.memoizedState,N||yt!==xt||es?(typeof Nt=="function"&&(Jf(i,s,Nt,l),xt=i.memoizedState),(K=es||X0(i,s,K,l,yt,xt,y))?(Dt||typeof d.UNSAFE_componentWillMount!="function"&&typeof d.componentWillMount!="function"||(typeof d.componentWillMount=="function"&&d.componentWillMount(),typeof d.UNSAFE_componentWillMount=="function"&&d.UNSAFE_componentWillMount()),typeof d.componentDidMount=="function"&&(i.flags|=4194308)):(typeof d.componentDidMount=="function"&&(i.flags|=4194308),i.memoizedProps=l,i.memoizedState=xt),d.props=l,d.state=xt,d.context=y,l=K):(typeof d.componentDidMount=="function"&&(i.flags|=4194308),l=!1)}else{d=i.stateNode,wf(e,i),y=i.memoizedProps,Dt=Gs(s,y),d.props=Dt,Nt=i.pendingProps,yt=d.context,xt=s.contextType,K=vr,typeof xt=="object"&&xt!==null&&(K=Zn(xt)),N=s.getDerivedStateFromProps,(xt=typeof N=="function"||typeof d.getSnapshotBeforeUpdate=="function")||typeof d.UNSAFE_componentWillReceiveProps!="function"&&typeof d.componentWillReceiveProps!="function"||(y!==Nt||yt!==K)&&W0(i,d,l,K),es=!1,yt=i.memoizedState,d.state=yt,No(i,l,d,f),Lo();var wt=i.memoizedState;y!==Nt||yt!==wt||es||e!==null&&e.dependencies!==null&&Kl(e.dependencies)?(typeof N=="function"&&(Jf(i,s,N,l),wt=i.memoizedState),(Dt=es||X0(i,s,Dt,l,yt,wt,K)||e!==null&&e.dependencies!==null&&Kl(e.dependencies))?(xt||typeof d.UNSAFE_componentWillUpdate!="function"&&typeof d.componentWillUpdate!="function"||(typeof d.componentWillUpdate=="function"&&d.componentWillUpdate(l,wt,K),typeof d.UNSAFE_componentWillUpdate=="function"&&d.UNSAFE_componentWillUpdate(l,wt,K)),typeof d.componentDidUpdate=="function"&&(i.flags|=4),typeof d.getSnapshotBeforeUpdate=="function"&&(i.flags|=1024)):(typeof d.componentDidUpdate!="function"||y===e.memoizedProps&&yt===e.memoizedState||(i.flags|=4),typeof d.getSnapshotBeforeUpdate!="function"||y===e.memoizedProps&&yt===e.memoizedState||(i.flags|=1024),i.memoizedProps=l,i.memoizedState=wt),d.props=l,d.state=wt,d.context=K,l=Dt):(typeof d.componentDidUpdate!="function"||y===e.memoizedProps&&yt===e.memoizedState||(i.flags|=4),typeof d.getSnapshotBeforeUpdate!="function"||y===e.memoizedProps&&yt===e.memoizedState||(i.flags|=1024),l=!1)}return d=l,pc(e,i),l=(i.flags&128)!==0,d||l?(d=i.stateNode,s=l&&typeof s.getDerivedStateFromError!="function"?null:d.render(),i.flags|=1,e!==null&&l?(i.child=Fs(i,e.child,null,f),i.child=Fs(i,null,s,f)):Kn(e,i,s,f),i.memoizedState=d.state,e=i.child):e=ya(e,i,f),e}function rg(e,i,s,l){return Ns(),i.flags|=256,Kn(e,i,s,l),i.child}var eh={dehydrated:null,treeContext:null,retryLane:0,hydrationErrors:null};function nh(e){return{baseLanes:e,cachePool:Km()}}function ih(e,i,s){return e=e!==null?e.childLanes&~s:0,i&&(e|=Si),e}function og(e,i,s){var l=i.pendingProps,f=!1,d=(i.flags&128)!==0,y;if((y=d)||(y=e!==null&&e.memoizedState===null?!1:(An.current&2)!==0),y&&(f=!0,i.flags&=-129),y=(i.flags&32)!==0,i.flags&=-33,e===null){if(Ge){if(f?as(i):ss(),(e=dn)?(e=mv(e,Oi),e=e!==null&&e.data!=="&"?e:null,e!==null&&(i.memoizedState={dehydrated:e,treeContext:Qa!==null?{id:ea,overflow:na}:null,retryLane:536870912,hydrationErrors:null},s=Hm(e),s.return=i,i.child=s,Yn=i,dn=null)):e=null,e===null)throw $a(i);return Fh(e)?i.lanes=32:i.lanes=536870912,null}var N=l.children;return l=l.fallback,f?(ss(),f=i.mode,N=mc({mode:"hidden",children:N},f),l=Ls(l,f,s,null),N.return=i,l.return=i,N.sibling=l,i.child=N,l=i.child,l.memoizedState=nh(s),l.childLanes=ih(e,y,s),i.memoizedState=eh,Bo(null,l)):(as(i),ah(i,N))}var K=e.memoizedState;if(K!==null&&(N=K.dehydrated,N!==null)){if(d)i.flags&256?(as(i),i.flags&=-257,i=sh(e,i,s)):i.memoizedState!==null?(ss(),i.child=e.child,i.flags|=128,i=null):(ss(),N=l.fallback,f=i.mode,l=mc({mode:"visible",children:l.children},f),N=Ls(N,f,s,null),N.flags|=2,l.return=i,N.return=i,l.sibling=N,i.child=l,Fs(i,e.child,null,s),l=i.child,l.memoizedState=nh(s),l.childLanes=ih(e,y,s),i.memoizedState=eh,i=Bo(null,l));else if(as(i),Fh(N)){if(y=N.nextSibling&&N.nextSibling.dataset,y)var xt=y.dgst;y=xt,l=Error(a(419)),l.stack="",l.digest=y,Ao({value:l,source:null,stack:null}),i=sh(e,i,s)}else if(Ln||Mr(e,i,s,!1),y=(s&e.childLanes)!==0,Ln||y){if(y=fn,y!==null&&(l=Vt(y,s),l!==0&&l!==K.retryLane))throw K.retryLane=l,Us(e,l),di(y,e,l),$f;Bh(N)||Ec(),i=sh(e,i,s)}else Bh(N)?(i.flags|=192,i.child=e.child,i=null):(e=K.treeContext,dn=zi(N.nextSibling),Yn=i,Ge=!0,ja=null,Oi=!1,e!==null&&km(i,e),i=ah(i,l.children),i.flags|=4096);return i}return f?(ss(),N=l.fallback,f=i.mode,K=e.child,xt=K.sibling,l=ga(K,{mode:"hidden",children:l.children}),l.subtreeFlags=K.subtreeFlags&65011712,xt!==null?N=ga(xt,N):(N=Ls(N,f,s,null),N.flags|=2),N.return=i,l.return=i,l.sibling=N,i.child=l,Bo(null,l),l=i.child,N=e.child.memoizedState,N===null?N=nh(s):(f=N.cachePool,f!==null?(K=Dn._currentValue,f=f.parent!==K?{parent:K,pool:K}:f):f=Km(),N={baseLanes:N.baseLanes|s,cachePool:f}),l.memoizedState=N,l.childLanes=ih(e,y,s),i.memoizedState=eh,Bo(e.child,l)):(as(i),s=e.child,e=s.sibling,s=ga(s,{mode:"visible",children:l.children}),s.return=i,s.sibling=null,e!==null&&(y=i.deletions,y===null?(i.deletions=[e],i.flags|=16):y.push(e)),i.child=s,i.memoizedState=null,s)}function ah(e,i){return i=mc({mode:"visible",children:i},e.mode),i.return=e,e.child=i}function mc(e,i){return e=gi(22,e,null,i),e.lanes=0,e}function sh(e,i,s){return Fs(i,e.child,null,s),e=ah(i,i.pendingProps.children),e.flags|=2,i.memoizedState=null,e}function lg(e,i,s){e.lanes|=i;var l=e.alternate;l!==null&&(l.lanes|=i),Sf(e.return,i,s)}function rh(e,i,s,l,f,d){var y=e.memoizedState;y===null?e.memoizedState={isBackwards:i,rendering:null,renderingStartTime:0,last:l,tail:s,tailMode:f,treeForkCount:d}:(y.isBackwards=i,y.rendering=null,y.renderingStartTime=0,y.last=l,y.tail=s,y.tailMode=f,y.treeForkCount=d)}function cg(e,i,s){var l=i.pendingProps,f=l.revealOrder,d=l.tail;l=l.children;var y=An.current,N=(y&2)!==0;if(N?(y=y&1|2,i.flags|=128):y&=1,At(An,y),Kn(e,i,l,s),l=Ge?To:0,!N&&e!==null&&(e.flags&128)!==0)t:for(e=i.child;e!==null;){if(e.tag===13)e.memoizedState!==null&&lg(e,s,i);else if(e.tag===19)lg(e,s,i);else if(e.child!==null){e.child.return=e,e=e.child;continue}if(e===i)break t;for(;e.sibling===null;){if(e.return===null||e.return===i)break t;e=e.return}e.sibling.return=e.return,e=e.sibling}switch(f){case"forwards":for(s=i.child,f=null;s!==null;)e=s.alternate,e!==null&&ic(e)===null&&(f=s),s=s.sibling;s=f,s===null?(f=i.child,i.child=null):(f=s.sibling,s.sibling=null),rh(i,!1,f,s,d,l);break;case"backwards":case"unstable_legacy-backwards":for(s=null,f=i.child,i.child=null;f!==null;){if(e=f.alternate,e!==null&&ic(e)===null){i.child=f;break}e=f.sibling,f.sibling=s,s=f,f=e}rh(i,!0,s,null,d,l);break;case"together":rh(i,!1,null,null,void 0,l);break;default:i.memoizedState=null}return i.child}function ya(e,i,s){if(e!==null&&(i.dependencies=e.dependencies),ls|=i.lanes,(s&i.childLanes)===0)if(e!==null){if(Mr(e,i,s,!1),(s&i.childLanes)===0)return null}else return null;if(e!==null&&i.child!==e.child)throw Error(a(153));if(i.child!==null){for(e=i.child,s=ga(e,e.pendingProps),i.child=s,s.return=i;e.sibling!==null;)e=e.sibling,s=s.sibling=ga(e,e.pendingProps),s.return=i;s.sibling=null}return i.child}function oh(e,i){return(e.lanes&i)!==0?!0:(e=e.dependencies,!!(e!==null&&Kl(e)))}function dM(e,i,s){switch(i.tag){case 3:Tt(i,i.stateNode.containerInfo),ts(i,Dn,e.memoizedState.cache),Ns();break;case 27:case 5:ie(i);break;case 4:Tt(i,i.stateNode.containerInfo);break;case 10:ts(i,i.type,i.memoizedProps.value);break;case 31:if(i.memoizedState!==null)return i.flags|=128,Lf(i),null;break;case 13:var l=i.memoizedState;if(l!==null)return l.dehydrated!==null?(as(i),i.flags|=128,null):(s&i.child.childLanes)!==0?og(e,i,s):(as(i),e=ya(e,i,s),e!==null?e.sibling:null);as(i);break;case 19:var f=(e.flags&128)!==0;if(l=(s&i.childLanes)!==0,l||(Mr(e,i,s,!1),l=(s&i.childLanes)!==0),f){if(l)return cg(e,i,s);i.flags|=128}if(f=i.memoizedState,f!==null&&(f.rendering=null,f.tail=null,f.lastEffect=null),At(An,An.current),l)break;return null;case 22:return i.lanes=0,eg(e,i,s,i.pendingProps);case 24:ts(i,Dn,e.memoizedState.cache)}return ya(e,i,s)}function ug(e,i,s){if(e!==null)if(e.memoizedProps!==i.pendingProps)Ln=!0;else{if(!oh(e,s)&&(i.flags&128)===0)return Ln=!1,dM(e,i,s);Ln=(e.flags&131072)!==0}else Ln=!1,Ge&&(i.flags&1048576)!==0&&Vm(i,To,i.index);switch(i.lanes=0,i.tag){case 16:t:{var l=i.pendingProps;if(e=Is(i.elementType),i.type=e,typeof e=="function")hf(e)?(l=Gs(e,l),i.tag=1,i=sg(null,i,e,l,s)):(i.tag=0,i=th(null,i,e,l,s));else{if(e!=null){var f=e.$$typeof;if(f===E){i.tag=11,i=j0(null,i,e,l,s);break t}else if(f===P){i.tag=14,i=$0(null,i,e,l,s);break t}}throw i=k(e)||e,Error(a(306,i,""))}}return i;case 0:return th(e,i,i.type,i.pendingProps,s);case 1:return l=i.type,f=Gs(l,i.pendingProps),sg(e,i,l,f,s);case 3:t:{if(Tt(i,i.stateNode.containerInfo),e===null)throw Error(a(387));l=i.pendingProps;var d=i.memoizedState;f=d.element,wf(e,i),No(i,l,null,s);var y=i.memoizedState;if(l=y.cache,ts(i,Dn,l),l!==d.cache&&Mf(i,[Dn],s,!0),Lo(),l=y.element,d.isDehydrated)if(d={element:l,isDehydrated:!1,cache:y.cache},i.updateQueue.baseState=d,i.memoizedState=d,i.flags&256){i=rg(e,i,l,s);break t}else if(l!==f){f=Ui(Error(a(424)),i),Ao(f),i=rg(e,i,l,s);break t}else{switch(e=i.stateNode.containerInfo,e.nodeType){case 9:e=e.body;break;default:e=e.nodeName==="HTML"?e.ownerDocument.body:e}for(dn=zi(e.firstChild),Yn=i,Ge=!0,ja=null,Oi=!0,s=e0(i,null,l,s),i.child=s;s;)s.flags=s.flags&-3|4096,s=s.sibling}else{if(Ns(),l===f){i=ya(e,i,s);break t}Kn(e,i,l,s)}i=i.child}return i;case 26:return pc(e,i),e===null?(s=Mv(i.type,null,i.pendingProps,null))?i.memoizedState=s:Ge||(s=i.type,e=i.pendingProps,l=Uc(zt.current).createElement(s),l[He]=i,l[qe]=e,Jn(l,s,e),Rn(l),i.stateNode=l):i.memoizedState=Mv(i.type,e.memoizedProps,i.pendingProps,e.memoizedState),null;case 27:return ie(i),e===null&&Ge&&(l=i.stateNode=_v(i.type,i.pendingProps,zt.current),Yn=i,Oi=!0,f=dn,ds(i.type)?(Hh=f,dn=zi(l.firstChild)):dn=f),Kn(e,i,i.pendingProps.children,s),pc(e,i),e===null&&(i.flags|=4194304),i.child;case 5:return e===null&&Ge&&((f=l=dn)&&(l=kM(l,i.type,i.pendingProps,Oi),l!==null?(i.stateNode=l,Yn=i,dn=zi(l.firstChild),Oi=!1,f=!0):f=!1),f||$a(i)),ie(i),f=i.type,d=i.pendingProps,y=e!==null?e.memoizedProps:null,l=d.children,Ph(f,d)?l=null:y!==null&&Ph(f,y)&&(i.flags|=32),i.memoizedState!==null&&(f=Of(e,i,aM,null,null,s),$o._currentValue=f),pc(e,i),Kn(e,i,l,s),i.child;case 6:return e===null&&Ge&&((e=s=dn)&&(s=XM(s,i.pendingProps,Oi),s!==null?(i.stateNode=s,Yn=i,dn=null,e=!0):e=!1),e||$a(i)),null;case 13:return og(e,i,s);case 4:return Tt(i,i.stateNode.containerInfo),l=i.pendingProps,e===null?i.child=Fs(i,null,l,s):Kn(e,i,l,s),i.child;case 11:return j0(e,i,i.type,i.pendingProps,s);case 7:return Kn(e,i,i.pendingProps,s),i.child;case 8:return Kn(e,i,i.pendingProps.children,s),i.child;case 12:return Kn(e,i,i.pendingProps.children,s),i.child;case 10:return l=i.pendingProps,ts(i,i.type,l.value),Kn(e,i,l.children,s),i.child;case 9:return f=i.type._context,l=i.pendingProps.children,Ps(i),f=Zn(f),l=l(f),i.flags|=1,Kn(e,i,l,s),i.child;case 14:return $0(e,i,i.type,i.pendingProps,s);case 15:return tg(e,i,i.type,i.pendingProps,s);case 19:return cg(e,i,s);case 31:return hM(e,i,s);case 22:return eg(e,i,s,i.pendingProps);case 24:return Ps(i),l=Zn(Dn),e===null?(f=Ef(),f===null&&(f=fn,d=yf(),f.pooledCache=d,d.refCount++,d!==null&&(f.pooledCacheLanes|=s),f=d),i.memoizedState={parent:l,cache:f},Af(i),ts(i,Dn,f)):((e.lanes&s)!==0&&(wf(e,i),No(i,null,null,s),Lo()),f=e.memoizedState,d=i.memoizedState,f.parent!==l?(f={parent:l,cache:l},i.memoizedState=f,i.lanes===0&&(i.memoizedState=i.updateQueue.baseState=f),ts(i,Dn,l)):(l=d.cache,ts(i,Dn,l),l!==f.cache&&Mf(i,[Dn],s,!0))),Kn(e,i,i.pendingProps.children,s),i.child;case 29:throw i.pendingProps}throw Error(a(156,i.tag))}function ba(e){e.flags|=4}function lh(e,i,s,l,f){if((i=(e.mode&32)!==0)&&(i=!1),i){if(e.flags|=16777216,(f&335544128)===f)if(e.stateNode.complete)e.flags|=8192;else if(Ig())e.flags|=8192;else throw Bs=$l,Tf}else e.flags&=-16777217}function fg(e,i){if(i.type!=="stylesheet"||(i.state.loading&4)!==0)e.flags&=-16777217;else if(e.flags|=16777216,!Av(i))if(Ig())e.flags|=8192;else throw Bs=$l,Tf}function gc(e,i){i!==null&&(e.flags|=4),e.flags&16384&&(i=e.tag!==22?it():536870912,e.lanes|=i,Nr|=i)}function Fo(e,i){if(!Ge)switch(e.tailMode){case"hidden":i=e.tail;for(var s=null;i!==null;)i.alternate!==null&&(s=i),i=i.sibling;s===null?e.tail=null:s.sibling=null;break;case"collapsed":s=e.tail;for(var l=null;s!==null;)s.alternate!==null&&(l=s),s=s.sibling;l===null?i||e.tail===null?e.tail=null:e.tail.sibling=null:l.sibling=null}}function pn(e){var i=e.alternate!==null&&e.alternate.child===e.child,s=0,l=0;if(i)for(var f=e.child;f!==null;)s|=f.lanes|f.childLanes,l|=f.subtreeFlags&65011712,l|=f.flags&65011712,f.return=e,f=f.sibling;else for(f=e.child;f!==null;)s|=f.lanes|f.childLanes,l|=f.subtreeFlags,l|=f.flags,f.return=e,f=f.sibling;return e.subtreeFlags|=l,e.childLanes=s,i}function pM(e,i,s){var l=i.pendingProps;switch(gf(i),i.tag){case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return pn(i),null;case 1:return pn(i),null;case 3:return s=i.stateNode,l=null,e!==null&&(l=e.memoizedState.cache),i.memoizedState.cache!==l&&(i.flags|=2048),xa(Dn),Ht(),s.pendingContext&&(s.context=s.pendingContext,s.pendingContext=null),(e===null||e.child===null)&&(Sr(i)?ba(i):e===null||e.memoizedState.isDehydrated&&(i.flags&256)===0||(i.flags|=1024,_f())),pn(i),null;case 26:var f=i.type,d=i.memoizedState;return e===null?(ba(i),d!==null?(pn(i),fg(i,d)):(pn(i),lh(i,f,null,l,s))):d?d!==e.memoizedState?(ba(i),pn(i),fg(i,d)):(pn(i),i.flags&=-16777217):(e=e.memoizedProps,e!==l&&ba(i),pn(i),lh(i,f,e,l,s)),null;case 27:if(qt(i),s=zt.current,f=i.type,e!==null&&i.stateNode!=null)e.memoizedProps!==l&&ba(i);else{if(!l){if(i.stateNode===null)throw Error(a(166));return pn(i),null}e=It.current,Sr(i)?Xm(i):(e=_v(f,l,s),i.stateNode=e,ba(i))}return pn(i),null;case 5:if(qt(i),f=i.type,e!==null&&i.stateNode!=null)e.memoizedProps!==l&&ba(i);else{if(!l){if(i.stateNode===null)throw Error(a(166));return pn(i),null}if(d=It.current,Sr(i))Xm(i);else{var y=Uc(zt.current);switch(d){case 1:d=y.createElementNS("http://www.w3.org/2000/svg",f);break;case 2:d=y.createElementNS("http://www.w3.org/1998/Math/MathML",f);break;default:switch(f){case"svg":d=y.createElementNS("http://www.w3.org/2000/svg",f);break;case"math":d=y.createElementNS("http://www.w3.org/1998/Math/MathML",f);break;case"script":d=y.createElement("div"),d.innerHTML="<script><\/script>",d=d.removeChild(d.firstChild);break;case"select":d=typeof l.is=="string"?y.createElement("select",{is:l.is}):y.createElement("select"),l.multiple?d.multiple=!0:l.size&&(d.size=l.size);break;default:d=typeof l.is=="string"?y.createElement(f,{is:l.is}):y.createElement(f)}}d[He]=i,d[qe]=l;t:for(y=i.child;y!==null;){if(y.tag===5||y.tag===6)d.appendChild(y.stateNode);else if(y.tag!==4&&y.tag!==27&&y.child!==null){y.child.return=y,y=y.child;continue}if(y===i)break t;for(;y.sibling===null;){if(y.return===null||y.return===i)break t;y=y.return}y.sibling.return=y.return,y=y.sibling}i.stateNode=d;t:switch(Jn(d,f,l),f){case"button":case"input":case"select":case"textarea":l=!!l.autoFocus;break t;case"img":l=!0;break t;default:l=!1}l&&ba(i)}}return pn(i),lh(i,i.type,e===null?null:e.memoizedProps,i.pendingProps,s),null;case 6:if(e&&i.stateNode!=null)e.memoizedProps!==l&&ba(i);else{if(typeof l!="string"&&i.stateNode===null)throw Error(a(166));if(e=zt.current,Sr(i)){if(e=i.stateNode,s=i.memoizedProps,l=null,f=Yn,f!==null)switch(f.tag){case 27:case 5:l=f.memoizedProps}e[He]=i,e=!!(e.nodeValue===s||l!==null&&l.suppressHydrationWarning===!0||ov(e.nodeValue,s)),e||$a(i,!0)}else e=Uc(e).createTextNode(l),e[He]=i,i.stateNode=e}return pn(i),null;case 31:if(s=i.memoizedState,e===null||e.memoizedState!==null){if(l=Sr(i),s!==null){if(e===null){if(!l)throw Error(a(318));if(e=i.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(a(557));e[He]=i}else Ns(),(i.flags&128)===0&&(i.memoizedState=null),i.flags|=4;pn(i),e=!1}else s=_f(),e!==null&&e.memoizedState!==null&&(e.memoizedState.hydrationErrors=s),e=!0;if(!e)return i.flags&256?(_i(i),i):(_i(i),null);if((i.flags&128)!==0)throw Error(a(558))}return pn(i),null;case 13:if(l=i.memoizedState,e===null||e.memoizedState!==null&&e.memoizedState.dehydrated!==null){if(f=Sr(i),l!==null&&l.dehydrated!==null){if(e===null){if(!f)throw Error(a(318));if(f=i.memoizedState,f=f!==null?f.dehydrated:null,!f)throw Error(a(317));f[He]=i}else Ns(),(i.flags&128)===0&&(i.memoizedState=null),i.flags|=4;pn(i),f=!1}else f=_f(),e!==null&&e.memoizedState!==null&&(e.memoizedState.hydrationErrors=f),f=!0;if(!f)return i.flags&256?(_i(i),i):(_i(i),null)}return _i(i),(i.flags&128)!==0?(i.lanes=s,i):(s=l!==null,e=e!==null&&e.memoizedState!==null,s&&(l=i.child,f=null,l.alternate!==null&&l.alternate.memoizedState!==null&&l.alternate.memoizedState.cachePool!==null&&(f=l.alternate.memoizedState.cachePool.pool),d=null,l.memoizedState!==null&&l.memoizedState.cachePool!==null&&(d=l.memoizedState.cachePool.pool),d!==f&&(l.flags|=2048)),s!==e&&s&&(i.child.flags|=8192),gc(i,i.updateQueue),pn(i),null);case 4:return Ht(),e===null&&Dh(i.stateNode.containerInfo),pn(i),null;case 10:return xa(i.type),pn(i),null;case 19:if(ct(An),l=i.memoizedState,l===null)return pn(i),null;if(f=(i.flags&128)!==0,d=l.rendering,d===null)if(f)Fo(l,!1);else{if(bn!==0||e!==null&&(e.flags&128)!==0)for(e=i.child;e!==null;){if(d=ic(e),d!==null){for(i.flags|=128,Fo(l,!1),e=d.updateQueue,i.updateQueue=e,gc(i,e),i.subtreeFlags=0,e=s,s=i.child;s!==null;)Fm(s,e),s=s.sibling;return At(An,An.current&1|2),Ge&&va(i,l.treeForkCount),i.child}e=e.sibling}l.tail!==null&&_e()>Mc&&(i.flags|=128,f=!0,Fo(l,!1),i.lanes=4194304)}else{if(!f)if(e=ic(d),e!==null){if(i.flags|=128,f=!0,e=e.updateQueue,i.updateQueue=e,gc(i,e),Fo(l,!0),l.tail===null&&l.tailMode==="hidden"&&!d.alternate&&!Ge)return pn(i),null}else 2*_e()-l.renderingStartTime>Mc&&s!==536870912&&(i.flags|=128,f=!0,Fo(l,!1),i.lanes=4194304);l.isBackwards?(d.sibling=i.child,i.child=d):(e=l.last,e!==null?e.sibling=d:i.child=d,l.last=d)}return l.tail!==null?(e=l.tail,l.rendering=e,l.tail=e.sibling,l.renderingStartTime=_e(),e.sibling=null,s=An.current,At(An,f?s&1|2:s&1),Ge&&va(i,l.treeForkCount),e):(pn(i),null);case 22:case 23:return _i(i),Uf(),l=i.memoizedState!==null,e!==null?e.memoizedState!==null!==l&&(i.flags|=8192):l&&(i.flags|=8192),l?(s&536870912)!==0&&(i.flags&128)===0&&(pn(i),i.subtreeFlags&6&&(i.flags|=8192)):pn(i),s=i.updateQueue,s!==null&&gc(i,s.retryQueue),s=null,e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(s=e.memoizedState.cachePool.pool),l=null,i.memoizedState!==null&&i.memoizedState.cachePool!==null&&(l=i.memoizedState.cachePool.pool),l!==s&&(i.flags|=2048),e!==null&&ct(zs),null;case 24:return s=null,e!==null&&(s=e.memoizedState.cache),i.memoizedState.cache!==s&&(i.flags|=2048),xa(Dn),pn(i),null;case 25:return null;case 30:return null}throw Error(a(156,i.tag))}function mM(e,i){switch(gf(i),i.tag){case 1:return e=i.flags,e&65536?(i.flags=e&-65537|128,i):null;case 3:return xa(Dn),Ht(),e=i.flags,(e&65536)!==0&&(e&128)===0?(i.flags=e&-65537|128,i):null;case 26:case 27:case 5:return qt(i),null;case 31:if(i.memoizedState!==null){if(_i(i),i.alternate===null)throw Error(a(340));Ns()}return e=i.flags,e&65536?(i.flags=e&-65537|128,i):null;case 13:if(_i(i),e=i.memoizedState,e!==null&&e.dehydrated!==null){if(i.alternate===null)throw Error(a(340));Ns()}return e=i.flags,e&65536?(i.flags=e&-65537|128,i):null;case 19:return ct(An),null;case 4:return Ht(),null;case 10:return xa(i.type),null;case 22:case 23:return _i(i),Uf(),e!==null&&ct(zs),e=i.flags,e&65536?(i.flags=e&-65537|128,i):null;case 24:return xa(Dn),null;case 25:return null;default:return null}}function hg(e,i){switch(gf(i),i.tag){case 3:xa(Dn),Ht();break;case 26:case 27:case 5:qt(i);break;case 4:Ht();break;case 31:i.memoizedState!==null&&_i(i);break;case 13:_i(i);break;case 19:ct(An);break;case 10:xa(i.type);break;case 22:case 23:_i(i),Uf(),e!==null&&ct(zs);break;case 24:xa(Dn)}}function Ho(e,i){try{var s=i.updateQueue,l=s!==null?s.lastEffect:null;if(l!==null){var f=l.next;s=f;do{if((s.tag&e)===e){l=void 0;var d=s.create,y=s.inst;l=d(),y.destroy=l}s=s.next}while(s!==f)}}catch(N){en(i,i.return,N)}}function rs(e,i,s){try{var l=i.updateQueue,f=l!==null?l.lastEffect:null;if(f!==null){var d=f.next;l=d;do{if((l.tag&e)===e){var y=l.inst,N=y.destroy;if(N!==void 0){y.destroy=void 0,f=i;var K=s,xt=N;try{xt()}catch(Dt){en(f,K,Dt)}}}l=l.next}while(l!==d)}}catch(Dt){en(i,i.return,Dt)}}function dg(e){var i=e.updateQueue;if(i!==null){var s=e.stateNode;try{i0(i,s)}catch(l){en(e,e.return,l)}}}function pg(e,i,s){s.props=Gs(e.type,e.memoizedProps),s.state=e.memoizedState;try{s.componentWillUnmount()}catch(l){en(e,i,l)}}function Go(e,i){try{var s=e.ref;if(s!==null){switch(e.tag){case 26:case 27:case 5:var l=e.stateNode;break;case 30:l=e.stateNode;break;default:l=e.stateNode}typeof s=="function"?e.refCleanup=s(l):s.current=l}}catch(f){en(e,i,f)}}function ia(e,i){var s=e.ref,l=e.refCleanup;if(s!==null)if(typeof l=="function")try{l()}catch(f){en(e,i,f)}finally{e.refCleanup=null,e=e.alternate,e!=null&&(e.refCleanup=null)}else if(typeof s=="function")try{s(null)}catch(f){en(e,i,f)}else s.current=null}function mg(e){var i=e.type,s=e.memoizedProps,l=e.stateNode;try{t:switch(i){case"button":case"input":case"select":case"textarea":s.autoFocus&&l.focus();break t;case"img":s.src?l.src=s.src:s.srcSet&&(l.srcset=s.srcSet)}}catch(f){en(e,e.return,f)}}function ch(e,i,s){try{var l=e.stateNode;IM(l,e.type,s,i),l[qe]=i}catch(f){en(e,e.return,f)}}function gg(e){return e.tag===5||e.tag===3||e.tag===26||e.tag===27&&ds(e.type)||e.tag===4}function uh(e){t:for(;;){for(;e.sibling===null;){if(e.return===null||gg(e.return))return null;e=e.return}for(e.sibling.return=e.return,e=e.sibling;e.tag!==5&&e.tag!==6&&e.tag!==18;){if(e.tag===27&&ds(e.type)||e.flags&2||e.child===null||e.tag===4)continue t;e.child.return=e,e=e.child}if(!(e.flags&2))return e.stateNode}}function fh(e,i,s){var l=e.tag;if(l===5||l===6)e=e.stateNode,i?(s.nodeType===9?s.body:s.nodeName==="HTML"?s.ownerDocument.body:s).insertBefore(e,i):(i=s.nodeType===9?s.body:s.nodeName==="HTML"?s.ownerDocument.body:s,i.appendChild(e),s=s._reactRootContainer,s!=null||i.onclick!==null||(i.onclick=Ci));else if(l!==4&&(l===27&&ds(e.type)&&(s=e.stateNode,i=null),e=e.child,e!==null))for(fh(e,i,s),e=e.sibling;e!==null;)fh(e,i,s),e=e.sibling}function vc(e,i,s){var l=e.tag;if(l===5||l===6)e=e.stateNode,i?s.insertBefore(e,i):s.appendChild(e);else if(l!==4&&(l===27&&ds(e.type)&&(s=e.stateNode),e=e.child,e!==null))for(vc(e,i,s),e=e.sibling;e!==null;)vc(e,i,s),e=e.sibling}function vg(e){var i=e.stateNode,s=e.memoizedProps;try{for(var l=e.type,f=i.attributes;f.length;)i.removeAttributeNode(f[0]);Jn(i,l,s),i[He]=e,i[qe]=s}catch(d){en(e,e.return,d)}}var Ea=!1,Nn=!1,hh=!1,_g=typeof WeakSet=="function"?WeakSet:Set,Hn=null;function gM(e,i){if(e=e.containerInfo,Nh=Bc,e=Dm(e),sf(e)){if("selectionStart"in e)var s={start:e.selectionStart,end:e.selectionEnd};else t:{s=(s=e.ownerDocument)&&s.defaultView||window;var l=s.getSelection&&s.getSelection();if(l&&l.rangeCount!==0){s=l.anchorNode;var f=l.anchorOffset,d=l.focusNode;l=l.focusOffset;try{s.nodeType,d.nodeType}catch{s=null;break t}var y=0,N=-1,K=-1,xt=0,Dt=0,Nt=e,yt=null;e:for(;;){for(var wt;Nt!==s||f!==0&&Nt.nodeType!==3||(N=y+f),Nt!==d||l!==0&&Nt.nodeType!==3||(K=y+l),Nt.nodeType===3&&(y+=Nt.nodeValue.length),(wt=Nt.firstChild)!==null;)yt=Nt,Nt=wt;for(;;){if(Nt===e)break e;if(yt===s&&++xt===f&&(N=y),yt===d&&++Dt===l&&(K=y),(wt=Nt.nextSibling)!==null)break;Nt=yt,yt=Nt.parentNode}Nt=wt}s=N===-1||K===-1?null:{start:N,end:K}}else s=null}s=s||{start:0,end:0}}else s=null;for(Oh={focusedElem:e,selectionRange:s},Bc=!1,Hn=i;Hn!==null;)if(i=Hn,e=i.child,(i.subtreeFlags&1028)!==0&&e!==null)e.return=i,Hn=e;else for(;Hn!==null;){switch(i=Hn,d=i.alternate,e=i.flags,i.tag){case 0:if((e&4)!==0&&(e=i.updateQueue,e=e!==null?e.events:null,e!==null))for(s=0;s<e.length;s++)f=e[s],f.ref.impl=f.nextImpl;break;case 11:case 15:break;case 1:if((e&1024)!==0&&d!==null){e=void 0,s=i,f=d.memoizedProps,d=d.memoizedState,l=s.stateNode;try{var se=Gs(s.type,f);e=l.getSnapshotBeforeUpdate(se,d),l.__reactInternalSnapshotBeforeUpdate=e}catch(ge){en(s,s.return,ge)}}break;case 3:if((e&1024)!==0){if(e=i.stateNode.containerInfo,s=e.nodeType,s===9)Ih(e);else if(s===1)switch(e.nodeName){case"HEAD":case"HTML":case"BODY":Ih(e);break;default:e.textContent=""}}break;case 5:case 26:case 27:case 6:case 4:case 17:break;default:if((e&1024)!==0)throw Error(a(163))}if(e=i.sibling,e!==null){e.return=i.return,Hn=e;break}Hn=i.return}}function xg(e,i,s){var l=s.flags;switch(s.tag){case 0:case 11:case 15:Aa(e,s),l&4&&Ho(5,s);break;case 1:if(Aa(e,s),l&4)if(e=s.stateNode,i===null)try{e.componentDidMount()}catch(y){en(s,s.return,y)}else{var f=Gs(s.type,i.memoizedProps);i=i.memoizedState;try{e.componentDidUpdate(f,i,e.__reactInternalSnapshotBeforeUpdate)}catch(y){en(s,s.return,y)}}l&64&&dg(s),l&512&&Go(s,s.return);break;case 3:if(Aa(e,s),l&64&&(e=s.updateQueue,e!==null)){if(i=null,s.child!==null)switch(s.child.tag){case 27:case 5:i=s.child.stateNode;break;case 1:i=s.child.stateNode}try{i0(e,i)}catch(y){en(s,s.return,y)}}break;case 27:i===null&&l&4&&vg(s);case 26:case 5:Aa(e,s),i===null&&l&4&&mg(s),l&512&&Go(s,s.return);break;case 12:Aa(e,s);break;case 31:Aa(e,s),l&4&&yg(e,s);break;case 13:Aa(e,s),l&4&&bg(e,s),l&64&&(e=s.memoizedState,e!==null&&(e=e.dehydrated,e!==null&&(s=TM.bind(null,s),WM(e,s))));break;case 22:if(l=s.memoizedState!==null||Ea,!l){i=i!==null&&i.memoizedState!==null||Nn,f=Ea;var d=Nn;Ea=l,(Nn=i)&&!d?wa(e,s,(s.subtreeFlags&8772)!==0):Aa(e,s),Ea=f,Nn=d}break;case 30:break;default:Aa(e,s)}}function Sg(e){var i=e.alternate;i!==null&&(e.alternate=null,Sg(i)),e.child=null,e.deletions=null,e.sibling=null,e.tag===5&&(i=e.stateNode,i!==null&&Ya(i)),e.stateNode=null,e.return=null,e.dependencies=null,e.memoizedProps=null,e.memoizedState=null,e.pendingProps=null,e.stateNode=null,e.updateQueue=null}var _n=null,ci=!1;function Ta(e,i,s){for(s=s.child;s!==null;)Mg(e,i,s),s=s.sibling}function Mg(e,i,s){if(St&&typeof St.onCommitFiberUnmount=="function")try{St.onCommitFiberUnmount(Mt,s)}catch{}switch(s.tag){case 26:Nn||ia(s,i),Ta(e,i,s),s.memoizedState?s.memoizedState.count--:s.stateNode&&(s=s.stateNode,s.parentNode.removeChild(s));break;case 27:Nn||ia(s,i);var l=_n,f=ci;ds(s.type)&&(_n=s.stateNode,ci=!1),Ta(e,i,s),Jo(s.stateNode),_n=l,ci=f;break;case 5:Nn||ia(s,i);case 6:if(l=_n,f=ci,_n=null,Ta(e,i,s),_n=l,ci=f,_n!==null)if(ci)try{(_n.nodeType===9?_n.body:_n.nodeName==="HTML"?_n.ownerDocument.body:_n).removeChild(s.stateNode)}catch(d){en(s,i,d)}else try{_n.removeChild(s.stateNode)}catch(d){en(s,i,d)}break;case 18:_n!==null&&(ci?(e=_n,dv(e.nodeType===9?e.body:e.nodeName==="HTML"?e.ownerDocument.body:e,s.stateNode),Gr(e)):dv(_n,s.stateNode));break;case 4:l=_n,f=ci,_n=s.stateNode.containerInfo,ci=!0,Ta(e,i,s),_n=l,ci=f;break;case 0:case 11:case 14:case 15:rs(2,s,i),Nn||rs(4,s,i),Ta(e,i,s);break;case 1:Nn||(ia(s,i),l=s.stateNode,typeof l.componentWillUnmount=="function"&&pg(s,i,l)),Ta(e,i,s);break;case 21:Ta(e,i,s);break;case 22:Nn=(l=Nn)||s.memoizedState!==null,Ta(e,i,s),Nn=l;break;default:Ta(e,i,s)}}function yg(e,i){if(i.memoizedState===null&&(e=i.alternate,e!==null&&(e=e.memoizedState,e!==null))){e=e.dehydrated;try{Gr(e)}catch(s){en(i,i.return,s)}}}function bg(e,i){if(i.memoizedState===null&&(e=i.alternate,e!==null&&(e=e.memoizedState,e!==null&&(e=e.dehydrated,e!==null))))try{Gr(e)}catch(s){en(i,i.return,s)}}function vM(e){switch(e.tag){case 31:case 13:case 19:var i=e.stateNode;return i===null&&(i=e.stateNode=new _g),i;case 22:return e=e.stateNode,i=e._retryCache,i===null&&(i=e._retryCache=new _g),i;default:throw Error(a(435,e.tag))}}function _c(e,i){var s=vM(e);i.forEach(function(l){if(!s.has(l)){s.add(l);var f=AM.bind(null,e,l);l.then(f,f)}})}function ui(e,i){var s=i.deletions;if(s!==null)for(var l=0;l<s.length;l++){var f=s[l],d=e,y=i,N=y;t:for(;N!==null;){switch(N.tag){case 27:if(ds(N.type)){_n=N.stateNode,ci=!1;break t}break;case 5:_n=N.stateNode,ci=!1;break t;case 3:case 4:_n=N.stateNode.containerInfo,ci=!0;break t}N=N.return}if(_n===null)throw Error(a(160));Mg(d,y,f),_n=null,ci=!1,d=f.alternate,d!==null&&(d.return=null),f.return=null}if(i.subtreeFlags&13886)for(i=i.child;i!==null;)Eg(i,e),i=i.sibling}var Xi=null;function Eg(e,i){var s=e.alternate,l=e.flags;switch(e.tag){case 0:case 11:case 14:case 15:ui(i,e),fi(e),l&4&&(rs(3,e,e.return),Ho(3,e),rs(5,e,e.return));break;case 1:ui(i,e),fi(e),l&512&&(Nn||s===null||ia(s,s.return)),l&64&&Ea&&(e=e.updateQueue,e!==null&&(l=e.callbacks,l!==null&&(s=e.shared.hiddenCallbacks,e.shared.hiddenCallbacks=s===null?l:s.concat(l))));break;case 26:var f=Xi;if(ui(i,e),fi(e),l&512&&(Nn||s===null||ia(s,s.return)),l&4){var d=s!==null?s.memoizedState:null;if(l=e.memoizedState,s===null)if(l===null)if(e.stateNode===null){t:{l=e.type,s=e.memoizedProps,f=f.ownerDocument||f;e:switch(l){case"title":d=f.getElementsByTagName("title")[0],(!d||d[qa]||d[He]||d.namespaceURI==="http://www.w3.org/2000/svg"||d.hasAttribute("itemprop"))&&(d=f.createElement(l),f.head.insertBefore(d,f.querySelector("head > title"))),Jn(d,l,s),d[He]=e,Rn(d),l=d;break t;case"link":var y=Ev("link","href",f).get(l+(s.href||""));if(y){for(var N=0;N<y.length;N++)if(d=y[N],d.getAttribute("href")===(s.href==null||s.href===""?null:s.href)&&d.getAttribute("rel")===(s.rel==null?null:s.rel)&&d.getAttribute("title")===(s.title==null?null:s.title)&&d.getAttribute("crossorigin")===(s.crossOrigin==null?null:s.crossOrigin)){y.splice(N,1);break e}}d=f.createElement(l),Jn(d,l,s),f.head.appendChild(d);break;case"meta":if(y=Ev("meta","content",f).get(l+(s.content||""))){for(N=0;N<y.length;N++)if(d=y[N],d.getAttribute("content")===(s.content==null?null:""+s.content)&&d.getAttribute("name")===(s.name==null?null:s.name)&&d.getAttribute("property")===(s.property==null?null:s.property)&&d.getAttribute("http-equiv")===(s.httpEquiv==null?null:s.httpEquiv)&&d.getAttribute("charset")===(s.charSet==null?null:s.charSet)){y.splice(N,1);break e}}d=f.createElement(l),Jn(d,l,s),f.head.appendChild(d);break;default:throw Error(a(468,l))}d[He]=e,Rn(d),l=d}e.stateNode=l}else Tv(f,e.type,e.stateNode);else e.stateNode=bv(f,l,e.memoizedProps);else d!==l?(d===null?s.stateNode!==null&&(s=s.stateNode,s.parentNode.removeChild(s)):d.count--,l===null?Tv(f,e.type,e.stateNode):bv(f,l,e.memoizedProps)):l===null&&e.stateNode!==null&&ch(e,e.memoizedProps,s.memoizedProps)}break;case 27:ui(i,e),fi(e),l&512&&(Nn||s===null||ia(s,s.return)),s!==null&&l&4&&ch(e,e.memoizedProps,s.memoizedProps);break;case 5:if(ui(i,e),fi(e),l&512&&(Nn||s===null||ia(s,s.return)),e.flags&32){f=e.stateNode;try{ii(f,"")}catch(se){en(e,e.return,se)}}l&4&&e.stateNode!=null&&(f=e.memoizedProps,ch(e,f,s!==null?s.memoizedProps:f)),l&1024&&(hh=!0);break;case 6:if(ui(i,e),fi(e),l&4){if(e.stateNode===null)throw Error(a(162));l=e.memoizedProps,s=e.stateNode;try{s.nodeValue=l}catch(se){en(e,e.return,se)}}break;case 3:if(Oc=null,f=Xi,Xi=Lc(i.containerInfo),ui(i,e),Xi=f,fi(e),l&4&&s!==null&&s.memoizedState.isDehydrated)try{Gr(i.containerInfo)}catch(se){en(e,e.return,se)}hh&&(hh=!1,Tg(e));break;case 4:l=Xi,Xi=Lc(e.stateNode.containerInfo),ui(i,e),fi(e),Xi=l;break;case 12:ui(i,e),fi(e);break;case 31:ui(i,e),fi(e),l&4&&(l=e.updateQueue,l!==null&&(e.updateQueue=null,_c(e,l)));break;case 13:ui(i,e),fi(e),e.child.flags&8192&&e.memoizedState!==null!=(s!==null&&s.memoizedState!==null)&&(Sc=_e()),l&4&&(l=e.updateQueue,l!==null&&(e.updateQueue=null,_c(e,l)));break;case 22:f=e.memoizedState!==null;var K=s!==null&&s.memoizedState!==null,xt=Ea,Dt=Nn;if(Ea=xt||f,Nn=Dt||K,ui(i,e),Nn=Dt,Ea=xt,fi(e),l&8192)t:for(i=e.stateNode,i._visibility=f?i._visibility&-2:i._visibility|1,f&&(s===null||K||Ea||Nn||Vs(e)),s=null,i=e;;){if(i.tag===5||i.tag===26){if(s===null){K=s=i;try{if(d=K.stateNode,f)y=d.style,typeof y.setProperty=="function"?y.setProperty("display","none","important"):y.display="none";else{N=K.stateNode;var Nt=K.memoizedProps.style,yt=Nt!=null&&Nt.hasOwnProperty("display")?Nt.display:null;N.style.display=yt==null||typeof yt=="boolean"?"":(""+yt).trim()}}catch(se){en(K,K.return,se)}}}else if(i.tag===6){if(s===null){K=i;try{K.stateNode.nodeValue=f?"":K.memoizedProps}catch(se){en(K,K.return,se)}}}else if(i.tag===18){if(s===null){K=i;try{var wt=K.stateNode;f?pv(wt,!0):pv(K.stateNode,!1)}catch(se){en(K,K.return,se)}}}else if((i.tag!==22&&i.tag!==23||i.memoizedState===null||i===e)&&i.child!==null){i.child.return=i,i=i.child;continue}if(i===e)break t;for(;i.sibling===null;){if(i.return===null||i.return===e)break t;s===i&&(s=null),i=i.return}s===i&&(s=null),i.sibling.return=i.return,i=i.sibling}l&4&&(l=e.updateQueue,l!==null&&(s=l.retryQueue,s!==null&&(l.retryQueue=null,_c(e,s))));break;case 19:ui(i,e),fi(e),l&4&&(l=e.updateQueue,l!==null&&(e.updateQueue=null,_c(e,l)));break;case 30:break;case 21:break;default:ui(i,e),fi(e)}}function fi(e){var i=e.flags;if(i&2){try{for(var s,l=e.return;l!==null;){if(gg(l)){s=l;break}l=l.return}if(s==null)throw Error(a(160));switch(s.tag){case 27:var f=s.stateNode,d=uh(e);vc(e,d,f);break;case 5:var y=s.stateNode;s.flags&32&&(ii(y,""),s.flags&=-33);var N=uh(e);vc(e,N,y);break;case 3:case 4:var K=s.stateNode.containerInfo,xt=uh(e);fh(e,xt,K);break;default:throw Error(a(161))}}catch(Dt){en(e,e.return,Dt)}e.flags&=-3}i&4096&&(e.flags&=-4097)}function Tg(e){if(e.subtreeFlags&1024)for(e=e.child;e!==null;){var i=e;Tg(i),i.tag===5&&i.flags&1024&&i.stateNode.reset(),e=e.sibling}}function Aa(e,i){if(i.subtreeFlags&8772)for(i=i.child;i!==null;)xg(e,i.alternate,i),i=i.sibling}function Vs(e){for(e=e.child;e!==null;){var i=e;switch(i.tag){case 0:case 11:case 14:case 15:rs(4,i,i.return),Vs(i);break;case 1:ia(i,i.return);var s=i.stateNode;typeof s.componentWillUnmount=="function"&&pg(i,i.return,s),Vs(i);break;case 27:Jo(i.stateNode);case 26:case 5:ia(i,i.return),Vs(i);break;case 22:i.memoizedState===null&&Vs(i);break;case 30:Vs(i);break;default:Vs(i)}e=e.sibling}}function wa(e,i,s){for(s=s&&(i.subtreeFlags&8772)!==0,i=i.child;i!==null;){var l=i.alternate,f=e,d=i,y=d.flags;switch(d.tag){case 0:case 11:case 15:wa(f,d,s),Ho(4,d);break;case 1:if(wa(f,d,s),l=d,f=l.stateNode,typeof f.componentDidMount=="function")try{f.componentDidMount()}catch(xt){en(l,l.return,xt)}if(l=d,f=l.updateQueue,f!==null){var N=l.stateNode;try{var K=f.shared.hiddenCallbacks;if(K!==null)for(f.shared.hiddenCallbacks=null,f=0;f<K.length;f++)n0(K[f],N)}catch(xt){en(l,l.return,xt)}}s&&y&64&&dg(d),Go(d,d.return);break;case 27:vg(d);case 26:case 5:wa(f,d,s),s&&l===null&&y&4&&mg(d),Go(d,d.return);break;case 12:wa(f,d,s);break;case 31:wa(f,d,s),s&&y&4&&yg(f,d);break;case 13:wa(f,d,s),s&&y&4&&bg(f,d);break;case 22:d.memoizedState===null&&wa(f,d,s),Go(d,d.return);break;case 30:break;default:wa(f,d,s)}i=i.sibling}}function dh(e,i){var s=null;e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(s=e.memoizedState.cachePool.pool),e=null,i.memoizedState!==null&&i.memoizedState.cachePool!==null&&(e=i.memoizedState.cachePool.pool),e!==s&&(e!=null&&e.refCount++,s!=null&&wo(s))}function ph(e,i){e=null,i.alternate!==null&&(e=i.alternate.memoizedState.cache),i=i.memoizedState.cache,i!==e&&(i.refCount++,e!=null&&wo(e))}function Wi(e,i,s,l){if(i.subtreeFlags&10256)for(i=i.child;i!==null;)Ag(e,i,s,l),i=i.sibling}function Ag(e,i,s,l){var f=i.flags;switch(i.tag){case 0:case 11:case 15:Wi(e,i,s,l),f&2048&&Ho(9,i);break;case 1:Wi(e,i,s,l);break;case 3:Wi(e,i,s,l),f&2048&&(e=null,i.alternate!==null&&(e=i.alternate.memoizedState.cache),i=i.memoizedState.cache,i!==e&&(i.refCount++,e!=null&&wo(e)));break;case 12:if(f&2048){Wi(e,i,s,l),e=i.stateNode;try{var d=i.memoizedProps,y=d.id,N=d.onPostCommit;typeof N=="function"&&N(y,i.alternate===null?"mount":"update",e.passiveEffectDuration,-0)}catch(K){en(i,i.return,K)}}else Wi(e,i,s,l);break;case 31:Wi(e,i,s,l);break;case 13:Wi(e,i,s,l);break;case 23:break;case 22:d=i.stateNode,y=i.alternate,i.memoizedState!==null?d._visibility&2?Wi(e,i,s,l):Vo(e,i):d._visibility&2?Wi(e,i,s,l):(d._visibility|=2,Dr(e,i,s,l,(i.subtreeFlags&10256)!==0||!1)),f&2048&&dh(y,i);break;case 24:Wi(e,i,s,l),f&2048&&ph(i.alternate,i);break;default:Wi(e,i,s,l)}}function Dr(e,i,s,l,f){for(f=f&&((i.subtreeFlags&10256)!==0||!1),i=i.child;i!==null;){var d=e,y=i,N=s,K=l,xt=y.flags;switch(y.tag){case 0:case 11:case 15:Dr(d,y,N,K,f),Ho(8,y);break;case 23:break;case 22:var Dt=y.stateNode;y.memoizedState!==null?Dt._visibility&2?Dr(d,y,N,K,f):Vo(d,y):(Dt._visibility|=2,Dr(d,y,N,K,f)),f&&xt&2048&&dh(y.alternate,y);break;case 24:Dr(d,y,N,K,f),f&&xt&2048&&ph(y.alternate,y);break;default:Dr(d,y,N,K,f)}i=i.sibling}}function Vo(e,i){if(i.subtreeFlags&10256)for(i=i.child;i!==null;){var s=e,l=i,f=l.flags;switch(l.tag){case 22:Vo(s,l),f&2048&&dh(l.alternate,l);break;case 24:Vo(s,l),f&2048&&ph(l.alternate,l);break;default:Vo(s,l)}i=i.sibling}}var ko=8192;function Ur(e,i,s){if(e.subtreeFlags&ko)for(e=e.child;e!==null;)wg(e,i,s),e=e.sibling}function wg(e,i,s){switch(e.tag){case 26:Ur(e,i,s),e.flags&ko&&e.memoizedState!==null&&iy(s,Xi,e.memoizedState,e.memoizedProps);break;case 5:Ur(e,i,s);break;case 3:case 4:var l=Xi;Xi=Lc(e.stateNode.containerInfo),Ur(e,i,s),Xi=l;break;case 22:e.memoizedState===null&&(l=e.alternate,l!==null&&l.memoizedState!==null?(l=ko,ko=16777216,Ur(e,i,s),ko=l):Ur(e,i,s));break;default:Ur(e,i,s)}}function Rg(e){var i=e.alternate;if(i!==null&&(e=i.child,e!==null)){i.child=null;do i=e.sibling,e.sibling=null,e=i;while(e!==null)}}function Xo(e){var i=e.deletions;if((e.flags&16)!==0){if(i!==null)for(var s=0;s<i.length;s++){var l=i[s];Hn=l,Dg(l,e)}Rg(e)}if(e.subtreeFlags&10256)for(e=e.child;e!==null;)Cg(e),e=e.sibling}function Cg(e){switch(e.tag){case 0:case 11:case 15:Xo(e),e.flags&2048&&rs(9,e,e.return);break;case 3:Xo(e);break;case 12:Xo(e);break;case 22:var i=e.stateNode;e.memoizedState!==null&&i._visibility&2&&(e.return===null||e.return.tag!==13)?(i._visibility&=-3,xc(e)):Xo(e);break;default:Xo(e)}}function xc(e){var i=e.deletions;if((e.flags&16)!==0){if(i!==null)for(var s=0;s<i.length;s++){var l=i[s];Hn=l,Dg(l,e)}Rg(e)}for(e=e.child;e!==null;){switch(i=e,i.tag){case 0:case 11:case 15:rs(8,i,i.return),xc(i);break;case 22:s=i.stateNode,s._visibility&2&&(s._visibility&=-3,xc(i));break;default:xc(i)}e=e.sibling}}function Dg(e,i){for(;Hn!==null;){var s=Hn;switch(s.tag){case 0:case 11:case 15:rs(8,s,i);break;case 23:case 22:if(s.memoizedState!==null&&s.memoizedState.cachePool!==null){var l=s.memoizedState.cachePool.pool;l!=null&&l.refCount++}break;case 24:wo(s.memoizedState.cache)}if(l=s.child,l!==null)l.return=s,Hn=l;else t:for(s=e;Hn!==null;){l=Hn;var f=l.sibling,d=l.return;if(Sg(l),l===s){Hn=null;break t}if(f!==null){f.return=d,Hn=f;break t}Hn=d}}}var _M={getCacheForType:function(e){var i=Zn(Dn),s=i.data.get(e);return s===void 0&&(s=e(),i.data.set(e,s)),s},cacheSignal:function(){return Zn(Dn).controller.signal}},xM=typeof WeakMap=="function"?WeakMap:Map,Qe=0,fn=null,Oe=null,Ie=0,tn=0,xi=null,os=!1,Lr=!1,mh=!1,Ra=0,bn=0,ls=0,ks=0,gh=0,Si=0,Nr=0,Wo=null,hi=null,vh=!1,Sc=0,Ug=0,Mc=1/0,yc=null,cs=null,zn=0,us=null,Or=null,Ca=0,_h=0,xh=null,Lg=null,qo=0,Sh=null;function Mi(){return(Qe&2)!==0&&Ie!==0?Ie&-Ie:F.T!==null?Ah():Ke()}function Ng(){if(Si===0)if((Ie&536870912)===0||Ge){var e=nt;nt<<=1,(nt&3932160)===0&&(nt=262144),Si=e}else Si=536870912;return e=vi.current,e!==null&&(e.flags|=32),Si}function di(e,i,s){(e===fn&&(tn===2||tn===9)||e.cancelPendingCommit!==null)&&(Pr(e,0),fs(e,Ie,Si,!1)),Pt(e,s),((Qe&2)===0||e!==fn)&&(e===fn&&((Qe&2)===0&&(ks|=s),bn===4&&fs(e,Ie,Si,!1)),aa(e))}function Og(e,i,s){if((Qe&6)!==0)throw Error(a(327));var l=!s&&(i&127)===0&&(i&e.expiredLanes)===0||st(e,i),f=l?yM(e,i):yh(e,i,!0),d=l;do{if(f===0){Lr&&!l&&fs(e,i,0,!1);break}else{if(s=e.current.alternate,d&&!SM(s)){f=yh(e,i,!1),d=!1;continue}if(f===2){if(d=i,e.errorRecoveryDisabledLanes&d)var y=0;else y=e.pendingLanes&-536870913,y=y!==0?y:y&536870912?536870912:0;if(y!==0){i=y;t:{var N=e;f=Wo;var K=N.current.memoizedState.isDehydrated;if(K&&(Pr(N,y).flags|=256),y=yh(N,y,!1),y!==2){if(mh&&!K){N.errorRecoveryDisabledLanes|=d,ks|=d,f=4;break t}d=hi,hi=f,d!==null&&(hi===null?hi=d:hi.push.apply(hi,d))}f=y}if(d=!1,f!==2)continue}}if(f===1){Pr(e,0),fs(e,i,0,!0);break}t:{switch(l=e,d=f,d){case 0:case 1:throw Error(a(345));case 4:if((i&4194048)!==i)break;case 6:fs(l,i,Si,!os);break t;case 2:hi=null;break;case 3:case 5:break;default:throw Error(a(329))}if((i&62914560)===i&&(f=Sc+300-_e(),10<f)){if(fs(l,i,Si,!os),X(l,0,!0)!==0)break t;Ca=i,l.timeoutHandle=fv(Pg.bind(null,l,s,hi,yc,vh,i,Si,ks,Nr,os,d,"Throttled",-0,0),f);break t}Pg(l,s,hi,yc,vh,i,Si,ks,Nr,os,d,null,-0,0)}}break}while(!0);aa(e)}function Pg(e,i,s,l,f,d,y,N,K,xt,Dt,Nt,yt,wt){if(e.timeoutHandle=-1,Nt=i.subtreeFlags,Nt&8192||(Nt&16785408)===16785408){Nt={stylesheets:null,count:0,imgCount:0,imgBytes:0,suspenseyImages:[],waitingForImages:!0,waitingForViewTransition:!1,unsuspend:Ci},wg(i,d,Nt);var se=(d&62914560)===d?Sc-_e():(d&4194048)===d?Ug-_e():0;if(se=ay(Nt,se),se!==null){Ca=d,e.cancelPendingCommit=se(kg.bind(null,e,i,d,s,l,f,y,N,K,Dt,Nt,null,yt,wt)),fs(e,d,y,!xt);return}}kg(e,i,d,s,l,f,y,N,K)}function SM(e){for(var i=e;;){var s=i.tag;if((s===0||s===11||s===15)&&i.flags&16384&&(s=i.updateQueue,s!==null&&(s=s.stores,s!==null)))for(var l=0;l<s.length;l++){var f=s[l],d=f.getSnapshot;f=f.value;try{if(!mi(d(),f))return!1}catch{return!1}}if(s=i.child,i.subtreeFlags&16384&&s!==null)s.return=i,i=s;else{if(i===e)break;for(;i.sibling===null;){if(i.return===null||i.return===e)return!0;i=i.return}i.sibling.return=i.return,i=i.sibling}}return!0}function fs(e,i,s,l){i&=~gh,i&=~ks,e.suspendedLanes|=i,e.pingedLanes&=~i,l&&(e.warmLanes|=i),l=e.expirationTimes;for(var f=i;0<f;){var d=31-Xt(f),y=1<<d;l[d]=-1,f&=~y}s!==0&&Rt(e,s,i)}function bc(){return(Qe&6)===0?(Yo(0),!1):!0}function Mh(){if(Oe!==null){if(tn===0)var e=Oe.return;else e=Oe,_a=Os=null,If(e),Tr=null,Co=0,e=Oe;for(;e!==null;)hg(e.alternate,e),e=e.return;Oe=null}}function Pr(e,i){var s=e.timeoutHandle;s!==-1&&(e.timeoutHandle=-1,HM(s)),s=e.cancelPendingCommit,s!==null&&(e.cancelPendingCommit=null,s()),Ca=0,Mh(),fn=e,Oe=s=ga(e.current,null),Ie=i,tn=0,xi=null,os=!1,Lr=st(e,i),mh=!1,Nr=Si=gh=ks=ls=bn=0,hi=Wo=null,vh=!1,(i&8)!==0&&(i|=i&32);var l=e.entangledLanes;if(l!==0)for(e=e.entanglements,l&=i;0<l;){var f=31-Xt(l),d=1<<f;i|=e[f],l&=~d}return Ra=i,Xl(),s}function zg(e,i){Ae=null,F.H=Io,i===Er||i===jl?(i=jm(),tn=3):i===Tf?(i=jm(),tn=4):tn=i===$f?8:i!==null&&typeof i=="object"&&typeof i.then=="function"?6:1,xi=i,Oe===null&&(bn=1,hc(e,Ui(i,e.current)))}function Ig(){var e=vi.current;return e===null?!0:(Ie&4194048)===Ie?Pi===null:(Ie&62914560)===Ie||(Ie&536870912)!==0?e===Pi:!1}function Bg(){var e=F.H;return F.H=Io,e===null?Io:e}function Fg(){var e=F.A;return F.A=_M,e}function Ec(){bn=4,os||(Ie&4194048)!==Ie&&vi.current!==null||(Lr=!0),(ls&134217727)===0&&(ks&134217727)===0||fn===null||fs(fn,Ie,Si,!1)}function yh(e,i,s){var l=Qe;Qe|=2;var f=Bg(),d=Fg();(fn!==e||Ie!==i)&&(yc=null,Pr(e,i)),i=!1;var y=bn;t:do try{if(tn!==0&&Oe!==null){var N=Oe,K=xi;switch(tn){case 8:Mh(),y=6;break t;case 3:case 2:case 9:case 6:vi.current===null&&(i=!0);var xt=tn;if(tn=0,xi=null,zr(e,N,K,xt),s&&Lr){y=0;break t}break;default:xt=tn,tn=0,xi=null,zr(e,N,K,xt)}}MM(),y=bn;break}catch(Dt){zg(e,Dt)}while(!0);return i&&e.shellSuspendCounter++,_a=Os=null,Qe=l,F.H=f,F.A=d,Oe===null&&(fn=null,Ie=0,Xl()),y}function MM(){for(;Oe!==null;)Hg(Oe)}function yM(e,i){var s=Qe;Qe|=2;var l=Bg(),f=Fg();fn!==e||Ie!==i?(yc=null,Mc=_e()+500,Pr(e,i)):Lr=st(e,i);t:do try{if(tn!==0&&Oe!==null){i=Oe;var d=xi;e:switch(tn){case 1:tn=0,xi=null,zr(e,i,d,1);break;case 2:case 9:if(Jm(d)){tn=0,xi=null,Gg(i);break}i=function(){tn!==2&&tn!==9||fn!==e||(tn=7),aa(e)},d.then(i,i);break t;case 3:tn=7;break t;case 4:tn=5;break t;case 7:Jm(d)?(tn=0,xi=null,Gg(i)):(tn=0,xi=null,zr(e,i,d,7));break;case 5:var y=null;switch(Oe.tag){case 26:y=Oe.memoizedState;case 5:case 27:var N=Oe;if(y?Av(y):N.stateNode.complete){tn=0,xi=null;var K=N.sibling;if(K!==null)Oe=K;else{var xt=N.return;xt!==null?(Oe=xt,Tc(xt)):Oe=null}break e}}tn=0,xi=null,zr(e,i,d,5);break;case 6:tn=0,xi=null,zr(e,i,d,6);break;case 8:Mh(),bn=6;break t;default:throw Error(a(462))}}bM();break}catch(Dt){zg(e,Dt)}while(!0);return _a=Os=null,F.H=l,F.A=f,Qe=s,Oe!==null?0:(fn=null,Ie=0,Xl(),bn)}function bM(){for(;Oe!==null&&!Se();)Hg(Oe)}function Hg(e){var i=ug(e.alternate,e,Ra);e.memoizedProps=e.pendingProps,i===null?Tc(e):Oe=i}function Gg(e){var i=e,s=i.alternate;switch(i.tag){case 15:case 0:i=ag(s,i,i.pendingProps,i.type,void 0,Ie);break;case 11:i=ag(s,i,i.pendingProps,i.type.render,i.ref,Ie);break;case 5:If(i);default:hg(s,i),i=Oe=Fm(i,Ra),i=ug(s,i,Ra)}e.memoizedProps=e.pendingProps,i===null?Tc(e):Oe=i}function zr(e,i,s,l){_a=Os=null,If(i),Tr=null,Co=0;var f=i.return;try{if(fM(e,f,i,s,Ie)){bn=1,hc(e,Ui(s,e.current)),Oe=null;return}}catch(d){if(f!==null)throw Oe=f,d;bn=1,hc(e,Ui(s,e.current)),Oe=null;return}i.flags&32768?(Ge||l===1?e=!0:Lr||(Ie&536870912)!==0?e=!1:(os=e=!0,(l===2||l===9||l===3||l===6)&&(l=vi.current,l!==null&&l.tag===13&&(l.flags|=16384))),Vg(i,e)):Tc(i)}function Tc(e){var i=e;do{if((i.flags&32768)!==0){Vg(i,os);return}e=i.return;var s=pM(i.alternate,i,Ra);if(s!==null){Oe=s;return}if(i=i.sibling,i!==null){Oe=i;return}Oe=i=e}while(i!==null);bn===0&&(bn=5)}function Vg(e,i){do{var s=mM(e.alternate,e);if(s!==null){s.flags&=32767,Oe=s;return}if(s=e.return,s!==null&&(s.flags|=32768,s.subtreeFlags=0,s.deletions=null),!i&&(e=e.sibling,e!==null)){Oe=e;return}Oe=e=s}while(e!==null);bn=6,Oe=null}function kg(e,i,s,l,f,d,y,N,K){e.cancelPendingCommit=null;do Ac();while(zn!==0);if((Qe&6)!==0)throw Error(a(327));if(i!==null){if(i===e.current)throw Error(a(177));if(d=i.lanes|i.childLanes,d|=uf,lt(e,s,d,y,N,K),e===fn&&(Oe=fn=null,Ie=0),Or=i,us=e,Ca=s,_h=d,xh=f,Lg=l,(i.subtreeFlags&10256)!==0||(i.flags&10256)!==0?(e.callbackNode=null,e.callbackPriority=0,wM(at,function(){return Zg(),null})):(e.callbackNode=null,e.callbackPriority=0),l=(i.flags&13878)!==0,(i.subtreeFlags&13878)!==0||l){l=F.T,F.T=null,f=Z.p,Z.p=2,y=Qe,Qe|=4;try{gM(e,i,s)}finally{Qe=y,Z.p=f,F.T=l}}zn=1,Xg(),Wg(),qg()}}function Xg(){if(zn===1){zn=0;var e=us,i=Or,s=(i.flags&13878)!==0;if((i.subtreeFlags&13878)!==0||s){s=F.T,F.T=null;var l=Z.p;Z.p=2;var f=Qe;Qe|=4;try{Eg(i,e);var d=Oh,y=Dm(e.containerInfo),N=d.focusedElem,K=d.selectionRange;if(y!==N&&N&&N.ownerDocument&&Cm(N.ownerDocument.documentElement,N)){if(K!==null&&sf(N)){var xt=K.start,Dt=K.end;if(Dt===void 0&&(Dt=xt),"selectionStart"in N)N.selectionStart=xt,N.selectionEnd=Math.min(Dt,N.value.length);else{var Nt=N.ownerDocument||document,yt=Nt&&Nt.defaultView||window;if(yt.getSelection){var wt=yt.getSelection(),se=N.textContent.length,ge=Math.min(K.start,se),ln=K.end===void 0?ge:Math.min(K.end,se);!wt.extend&&ge>ln&&(y=ln,ln=ge,ge=y);var ft=Rm(N,ge),tt=Rm(N,ln);if(ft&&tt&&(wt.rangeCount!==1||wt.anchorNode!==ft.node||wt.anchorOffset!==ft.offset||wt.focusNode!==tt.node||wt.focusOffset!==tt.offset)){var _t=Nt.createRange();_t.setStart(ft.node,ft.offset),wt.removeAllRanges(),ge>ln?(wt.addRange(_t),wt.extend(tt.node,tt.offset)):(_t.setEnd(tt.node,tt.offset),wt.addRange(_t))}}}}for(Nt=[],wt=N;wt=wt.parentNode;)wt.nodeType===1&&Nt.push({element:wt,left:wt.scrollLeft,top:wt.scrollTop});for(typeof N.focus=="function"&&N.focus(),N=0;N<Nt.length;N++){var Ut=Nt[N];Ut.element.scrollLeft=Ut.left,Ut.element.scrollTop=Ut.top}}Bc=!!Nh,Oh=Nh=null}finally{Qe=f,Z.p=l,F.T=s}}e.current=i,zn=2}}function Wg(){if(zn===2){zn=0;var e=us,i=Or,s=(i.flags&8772)!==0;if((i.subtreeFlags&8772)!==0||s){s=F.T,F.T=null;var l=Z.p;Z.p=2;var f=Qe;Qe|=4;try{xg(e,i.alternate,i)}finally{Qe=f,Z.p=l,F.T=s}}zn=3}}function qg(){if(zn===4||zn===3){zn=0,j();var e=us,i=Or,s=Ca,l=Lg;(i.subtreeFlags&10256)!==0||(i.flags&10256)!==0?zn=5:(zn=0,Or=us=null,Yg(e,e.pendingLanes));var f=e.pendingLanes;if(f===0&&(cs=null),pe(s),i=i.stateNode,St&&typeof St.onCommitFiberRoot=="function")try{St.onCommitFiberRoot(Mt,i,void 0,(i.current.flags&128)===128)}catch{}if(l!==null){i=F.T,f=Z.p,Z.p=2,F.T=null;try{for(var d=e.onRecoverableError,y=0;y<l.length;y++){var N=l[y];d(N.value,{componentStack:N.stack})}}finally{F.T=i,Z.p=f}}(Ca&3)!==0&&Ac(),aa(e),f=e.pendingLanes,(s&261930)!==0&&(f&42)!==0?e===Sh?qo++:(qo=0,Sh=e):qo=0,Yo(0)}}function Yg(e,i){(e.pooledCacheLanes&=i)===0&&(i=e.pooledCache,i!=null&&(e.pooledCache=null,wo(i)))}function Ac(){return Xg(),Wg(),qg(),Zg()}function Zg(){if(zn!==5)return!1;var e=us,i=_h;_h=0;var s=pe(Ca),l=F.T,f=Z.p;try{Z.p=32>s?32:s,F.T=null,s=xh,xh=null;var d=us,y=Ca;if(zn=0,Or=us=null,Ca=0,(Qe&6)!==0)throw Error(a(331));var N=Qe;if(Qe|=4,Cg(d.current),Ag(d,d.current,y,s),Qe=N,Yo(0,!1),St&&typeof St.onPostCommitFiberRoot=="function")try{St.onPostCommitFiberRoot(Mt,d)}catch{}return!0}finally{Z.p=f,F.T=l,Yg(e,i)}}function Kg(e,i,s){i=Ui(s,i),i=jf(e.stateNode,i,2),e=is(e,i,2),e!==null&&(Pt(e,2),aa(e))}function en(e,i,s){if(e.tag===3)Kg(e,e,s);else for(;i!==null;){if(i.tag===3){Kg(i,e,s);break}else if(i.tag===1){var l=i.stateNode;if(typeof i.type.getDerivedStateFromError=="function"||typeof l.componentDidCatch=="function"&&(cs===null||!cs.has(l))){e=Ui(s,e),s=J0(2),l=is(i,s,2),l!==null&&(Q0(s,l,i,e),Pt(l,2),aa(l));break}}i=i.return}}function bh(e,i,s){var l=e.pingCache;if(l===null){l=e.pingCache=new xM;var f=new Set;l.set(i,f)}else f=l.get(i),f===void 0&&(f=new Set,l.set(i,f));f.has(s)||(mh=!0,f.add(s),e=EM.bind(null,e,i,s),i.then(e,e))}function EM(e,i,s){var l=e.pingCache;l!==null&&l.delete(i),e.pingedLanes|=e.suspendedLanes&s,e.warmLanes&=~s,fn===e&&(Ie&s)===s&&(bn===4||bn===3&&(Ie&62914560)===Ie&&300>_e()-Sc?(Qe&2)===0&&Pr(e,0):gh|=s,Nr===Ie&&(Nr=0)),aa(e)}function Jg(e,i){i===0&&(i=it()),e=Us(e,i),e!==null&&(Pt(e,i),aa(e))}function TM(e){var i=e.memoizedState,s=0;i!==null&&(s=i.retryLane),Jg(e,s)}function AM(e,i){var s=0;switch(e.tag){case 31:case 13:var l=e.stateNode,f=e.memoizedState;f!==null&&(s=f.retryLane);break;case 19:l=e.stateNode;break;case 22:l=e.stateNode._retryCache;break;default:throw Error(a(314))}l!==null&&l.delete(i),Jg(e,s)}function wM(e,i){return ze(e,i)}var wc=null,Ir=null,Eh=!1,Rc=!1,Th=!1,hs=0;function aa(e){e!==Ir&&e.next===null&&(Ir===null?wc=Ir=e:Ir=Ir.next=e),Rc=!0,Eh||(Eh=!0,CM())}function Yo(e,i){if(!Th&&Rc){Th=!0;do for(var s=!1,l=wc;l!==null;){if(e!==0){var f=l.pendingLanes;if(f===0)var d=0;else{var y=l.suspendedLanes,N=l.pingedLanes;d=(1<<31-Xt(42|e)+1)-1,d&=f&~(y&~N),d=d&201326741?d&201326741|1:d?d|2:0}d!==0&&(s=!0,tv(l,d))}else d=Ie,d=X(l,l===fn?d:0,l.cancelPendingCommit!==null||l.timeoutHandle!==-1),(d&3)===0||st(l,d)||(s=!0,tv(l,d));l=l.next}while(s);Th=!1}}function RM(){Qg()}function Qg(){Rc=Eh=!1;var e=0;hs!==0&&FM()&&(e=hs);for(var i=_e(),s=null,l=wc;l!==null;){var f=l.next,d=jg(l,i);d===0?(l.next=null,s===null?wc=f:s.next=f,f===null&&(Ir=s)):(s=l,(e!==0||(d&3)!==0)&&(Rc=!0)),l=f}zn!==0&&zn!==5||Yo(e),hs!==0&&(hs=0)}function jg(e,i){for(var s=e.suspendedLanes,l=e.pingedLanes,f=e.expirationTimes,d=e.pendingLanes&-62914561;0<d;){var y=31-Xt(d),N=1<<y,K=f[y];K===-1?((N&s)===0||(N&l)!==0)&&(f[y]=rt(N,i)):K<=i&&(e.expiredLanes|=N),d&=~N}if(i=fn,s=Ie,s=X(e,e===i?s:0,e.cancelPendingCommit!==null||e.timeoutHandle!==-1),l=e.callbackNode,s===0||e===i&&(tn===2||tn===9)||e.cancelPendingCommit!==null)return l!==null&&l!==null&&ne(l),e.callbackNode=null,e.callbackPriority=0;if((s&3)===0||st(e,s)){if(i=s&-s,i===e.callbackPriority)return i;switch(l!==null&&ne(l),pe(s)){case 2:case 8:s=A;break;case 32:s=at;break;case 268435456:s=bt;break;default:s=at}return l=$g.bind(null,e),s=ze(s,l),e.callbackPriority=i,e.callbackNode=s,i}return l!==null&&l!==null&&ne(l),e.callbackPriority=2,e.callbackNode=null,2}function $g(e,i){if(zn!==0&&zn!==5)return e.callbackNode=null,e.callbackPriority=0,null;var s=e.callbackNode;if(Ac()&&e.callbackNode!==s)return null;var l=Ie;return l=X(e,e===fn?l:0,e.cancelPendingCommit!==null||e.timeoutHandle!==-1),l===0?null:(Og(e,l,i),jg(e,_e()),e.callbackNode!=null&&e.callbackNode===s?$g.bind(null,e):null)}function tv(e,i){if(Ac())return null;Og(e,i,!0)}function CM(){GM(function(){(Qe&6)!==0?ze(H,RM):Qg()})}function Ah(){if(hs===0){var e=yr;e===0&&(e=Y,Y<<=1,(Y&261888)===0&&(Y=256)),hs=e}return hs}function ev(e){return e==null||typeof e=="symbol"||typeof e=="boolean"?null:typeof e=="function"?e:Vi(""+e)}function nv(e,i){var s=i.ownerDocument.createElement("input");return s.name=i.name,s.value=i.value,e.id&&s.setAttribute("form",e.id),i.parentNode.insertBefore(s,i),e=new FormData(e),s.parentNode.removeChild(s),e}function DM(e,i,s,l,f){if(i==="submit"&&s&&s.stateNode===f){var d=ev((f[qe]||null).action),y=l.submitter;y&&(i=(i=y[qe]||null)?ev(i.formAction):y.getAttribute("formAction"),i!==null&&(d=i,y=null));var N=new Hl("action","action",null,l,f);e.push({event:N,listeners:[{instance:null,listener:function(){if(l.defaultPrevented){if(hs!==0){var K=y?nv(f,y):new FormData(f);qf(s,{pending:!0,data:K,method:f.method,action:d},null,K)}}else typeof d=="function"&&(N.preventDefault(),K=y?nv(f,y):new FormData(f),qf(s,{pending:!0,data:K,method:f.method,action:d},d,K))},currentTarget:f}]})}}for(var wh=0;wh<cf.length;wh++){var Rh=cf[wh],UM=Rh.toLowerCase(),LM=Rh[0].toUpperCase()+Rh.slice(1);ki(UM,"on"+LM)}ki(Nm,"onAnimationEnd"),ki(Om,"onAnimationIteration"),ki(Pm,"onAnimationStart"),ki("dblclick","onDoubleClick"),ki("focusin","onFocus"),ki("focusout","onBlur"),ki(ZS,"onTransitionRun"),ki(KS,"onTransitionStart"),ki(JS,"onTransitionCancel"),ki(zm,"onTransitionEnd"),$("onMouseEnter",["mouseout","mouseover"]),$("onMouseLeave",["mouseout","mouseover"]),$("onPointerEnter",["pointerout","pointerover"]),$("onPointerLeave",["pointerout","pointerover"]),D("onChange","change click focusin focusout input keydown keyup selectionchange".split(" ")),D("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")),D("onBeforeInput",["compositionend","keypress","textInput","paste"]),D("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" ")),D("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" ")),D("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var Zo="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),NM=new Set("beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(Zo));function iv(e,i){i=(i&4)!==0;for(var s=0;s<e.length;s++){var l=e[s],f=l.event;l=l.listeners;t:{var d=void 0;if(i)for(var y=l.length-1;0<=y;y--){var N=l[y],K=N.instance,xt=N.currentTarget;if(N=N.listener,K!==d&&f.isPropagationStopped())break t;d=N,f.currentTarget=xt;try{d(f)}catch(Dt){kl(Dt)}f.currentTarget=null,d=K}else for(y=0;y<l.length;y++){if(N=l[y],K=N.instance,xt=N.currentTarget,N=N.listener,K!==d&&f.isPropagationStopped())break t;d=N,f.currentTarget=xt;try{d(f)}catch(Dt){kl(Dt)}f.currentTarget=null,d=K}}}}function Pe(e,i){var s=i[wi];s===void 0&&(s=i[wi]=new Set);var l=e+"__bubble";s.has(l)||(av(i,e,2,!1),s.add(l))}function Ch(e,i,s){var l=0;i&&(l|=4),av(s,e,l,i)}var Cc="_reactListening"+Math.random().toString(36).slice(2);function Dh(e){if(!e[Cc]){e[Cc]=!0,zl.forEach(function(s){s!=="selectionchange"&&(NM.has(s)||Ch(s,!1,e),Ch(s,!0,e))});var i=e.nodeType===9?e:e.ownerDocument;i===null||i[Cc]||(i[Cc]=!0,Ch("selectionchange",!1,i))}}function av(e,i,s,l){switch(Nv(i)){case 2:var f=oy;break;case 8:f=ly;break;default:f=Wh}s=f.bind(null,i,s,e),f=void 0,!Ku||i!=="touchstart"&&i!=="touchmove"&&i!=="wheel"||(f=!0),l?f!==void 0?e.addEventListener(i,s,{capture:!0,passive:f}):e.addEventListener(i,s,!0):f!==void 0?e.addEventListener(i,s,{passive:f}):e.addEventListener(i,s,!1)}function Uh(e,i,s,l,f){var d=l;if((i&1)===0&&(i&2)===0&&l!==null)t:for(;;){if(l===null)return;var y=l.tag;if(y===3||y===4){var N=l.stateNode.containerInfo;if(N===f)break;if(y===4)for(y=l.return;y!==null;){var K=y.tag;if((K===3||K===4)&&y.stateNode.containerInfo===f)return;y=y.return}for(;N!==null;){if(y=da(N),y===null)return;if(K=y.tag,K===5||K===6||K===26||K===27){l=d=y;continue t}N=N.parentNode}}l=l.return}cm(function(){var xt=d,Dt=Yu(s),Nt=[];t:{var yt=Im.get(e);if(yt!==void 0){var wt=Hl,se=e;switch(e){case"keypress":if(Bl(s)===0)break t;case"keydown":case"keyup":wt=AS;break;case"focusin":se="focus",wt=$u;break;case"focusout":se="blur",wt=$u;break;case"beforeblur":case"afterblur":wt=$u;break;case"click":if(s.button===2)break t;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":wt=hm;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":wt=pS;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":wt=CS;break;case Nm:case Om:case Pm:wt=vS;break;case zm:wt=US;break;case"scroll":case"scrollend":wt=hS;break;case"wheel":wt=NS;break;case"copy":case"cut":case"paste":wt=xS;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":wt=pm;break;case"toggle":case"beforetoggle":wt=PS}var ge=(i&4)!==0,ln=!ge&&(e==="scroll"||e==="scrollend"),ft=ge?yt!==null?yt+"Capture":null:yt;ge=[];for(var tt=xt,_t;tt!==null;){var Ut=tt;if(_t=Ut.stateNode,Ut=Ut.tag,Ut!==5&&Ut!==26&&Ut!==27||_t===null||ft===null||(Ut=go(tt,ft),Ut!=null&&ge.push(Ko(tt,Ut,_t))),ln)break;tt=tt.return}0<ge.length&&(yt=new wt(yt,se,null,s,Dt),Nt.push({event:yt,listeners:ge}))}}if((i&7)===0){t:{if(yt=e==="mouseover"||e==="pointerover",wt=e==="mouseout"||e==="pointerout",yt&&s!==qu&&(se=s.relatedTarget||s.fromElement)&&(da(se)||se[Tn]))break t;if((wt||yt)&&(yt=Dt.window===Dt?Dt:(yt=Dt.ownerDocument)?yt.defaultView||yt.parentWindow:window,wt?(se=s.relatedTarget||s.toElement,wt=xt,se=se?da(se):null,se!==null&&(ln=c(se),ge=se.tag,se!==ln||ge!==5&&ge!==27&&ge!==6)&&(se=null)):(wt=null,se=xt),wt!==se)){if(ge=hm,Ut="onMouseLeave",ft="onMouseEnter",tt="mouse",(e==="pointerout"||e==="pointerover")&&(ge=pm,Ut="onPointerLeave",ft="onPointerEnter",tt="pointer"),ln=wt==null?yt:ws(wt),_t=se==null?yt:ws(se),yt=new ge(Ut,tt+"leave",wt,s,Dt),yt.target=ln,yt.relatedTarget=_t,Ut=null,da(Dt)===xt&&(ge=new ge(ft,tt+"enter",se,s,Dt),ge.target=_t,ge.relatedTarget=ln,Ut=ge),ln=Ut,wt&&se)e:{for(ge=OM,ft=wt,tt=se,_t=0,Ut=ft;Ut;Ut=ge(Ut))_t++;Ut=0;for(var he=tt;he;he=ge(he))Ut++;for(;0<_t-Ut;)ft=ge(ft),_t--;for(;0<Ut-_t;)tt=ge(tt),Ut--;for(;_t--;){if(ft===tt||tt!==null&&ft===tt.alternate){ge=ft;break e}ft=ge(ft),tt=ge(tt)}ge=null}else ge=null;wt!==null&&sv(Nt,yt,wt,ge,!1),se!==null&&ln!==null&&sv(Nt,ln,se,ge,!0)}}t:{if(yt=xt?ws(xt):window,wt=yt.nodeName&&yt.nodeName.toLowerCase(),wt==="select"||wt==="input"&&yt.type==="file")var Ye=ym;else if(Sm(yt))if(bm)Ye=WS;else{Ye=kS;var oe=VS}else wt=yt.nodeName,!wt||wt.toLowerCase()!=="input"||yt.type!=="checkbox"&&yt.type!=="radio"?xt&&Ri(xt.elementType)&&(Ye=ym):Ye=XS;if(Ye&&(Ye=Ye(e,xt))){Mm(Nt,Ye,s,Dt);break t}oe&&oe(e,yt,xt),e==="focusout"&&xt&&yt.type==="number"&&xt.memoizedProps.value!=null&&Pn(yt,"number",yt.value)}switch(oe=xt?ws(xt):window,e){case"focusin":(Sm(oe)||oe.contentEditable==="true")&&(pr=oe,rf=xt,Eo=null);break;case"focusout":Eo=rf=pr=null;break;case"mousedown":of=!0;break;case"contextmenu":case"mouseup":case"dragend":of=!1,Um(Nt,s,Dt);break;case"selectionchange":if(YS)break;case"keydown":case"keyup":Um(Nt,s,Dt)}var we;if(ef)t:{switch(e){case"compositionstart":var Be="onCompositionStart";break t;case"compositionend":Be="onCompositionEnd";break t;case"compositionupdate":Be="onCompositionUpdate";break t}Be=void 0}else dr?_m(e,s)&&(Be="onCompositionEnd"):e==="keydown"&&s.keyCode===229&&(Be="onCompositionStart");Be&&(mm&&s.locale!=="ko"&&(dr||Be!=="onCompositionStart"?Be==="onCompositionEnd"&&dr&&(we=um()):(Ja=Dt,Ju="value"in Ja?Ja.value:Ja.textContent,dr=!0)),oe=Dc(xt,Be),0<oe.length&&(Be=new dm(Be,e,null,s,Dt),Nt.push({event:Be,listeners:oe}),we?Be.data=we:(we=xm(s),we!==null&&(Be.data=we)))),(we=IS?BS(e,s):FS(e,s))&&(Be=Dc(xt,"onBeforeInput"),0<Be.length&&(oe=new dm("onBeforeInput","beforeinput",null,s,Dt),Nt.push({event:oe,listeners:Be}),oe.data=we)),DM(Nt,e,xt,s,Dt)}iv(Nt,i)})}function Ko(e,i,s){return{instance:e,listener:i,currentTarget:s}}function Dc(e,i){for(var s=i+"Capture",l=[];e!==null;){var f=e,d=f.stateNode;if(f=f.tag,f!==5&&f!==26&&f!==27||d===null||(f=go(e,s),f!=null&&l.unshift(Ko(e,f,d)),f=go(e,i),f!=null&&l.push(Ko(e,f,d))),e.tag===3)return l;e=e.return}return[]}function OM(e){if(e===null)return null;do e=e.return;while(e&&e.tag!==5&&e.tag!==27);return e||null}function sv(e,i,s,l,f){for(var d=i._reactName,y=[];s!==null&&s!==l;){var N=s,K=N.alternate,xt=N.stateNode;if(N=N.tag,K!==null&&K===l)break;N!==5&&N!==26&&N!==27||xt===null||(K=xt,f?(xt=go(s,d),xt!=null&&y.unshift(Ko(s,xt,K))):f||(xt=go(s,d),xt!=null&&y.push(Ko(s,xt,K)))),s=s.return}y.length!==0&&e.push({event:i,listeners:y})}var PM=/\r\n?/g,zM=/\u0000|\uFFFD/g;function rv(e){return(typeof e=="string"?e:""+e).replace(PM,`
`).replace(zM,"")}function ov(e,i){return i=rv(i),rv(e)===i}function on(e,i,s,l,f,d){switch(s){case"children":typeof l=="string"?i==="body"||i==="textarea"&&l===""||ii(e,l):(typeof l=="number"||typeof l=="bigint")&&i!=="body"&&ii(e,""+l);break;case"className":Zt(e,"class",l);break;case"tabIndex":Zt(e,"tabindex",l);break;case"dir":case"role":case"viewBox":case"width":case"height":Zt(e,s,l);break;case"style":vn(e,l,d);break;case"data":if(i!=="object"){Zt(e,"data",l);break}case"src":case"href":if(l===""&&(i!=="a"||s!=="href")){e.removeAttribute(s);break}if(l==null||typeof l=="function"||typeof l=="symbol"||typeof l=="boolean"){e.removeAttribute(s);break}l=Vi(""+l),e.setAttribute(s,l);break;case"action":case"formAction":if(typeof l=="function"){e.setAttribute(s,"javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')");break}else typeof d=="function"&&(s==="formAction"?(i!=="input"&&on(e,i,"name",f.name,f,null),on(e,i,"formEncType",f.formEncType,f,null),on(e,i,"formMethod",f.formMethod,f,null),on(e,i,"formTarget",f.formTarget,f,null)):(on(e,i,"encType",f.encType,f,null),on(e,i,"method",f.method,f,null),on(e,i,"target",f.target,f,null)));if(l==null||typeof l=="symbol"||typeof l=="boolean"){e.removeAttribute(s);break}l=Vi(""+l),e.setAttribute(s,l);break;case"onClick":l!=null&&(e.onclick=Ci);break;case"onScroll":l!=null&&Pe("scroll",e);break;case"onScrollEnd":l!=null&&Pe("scrollend",e);break;case"dangerouslySetInnerHTML":if(l!=null){if(typeof l!="object"||!("__html"in l))throw Error(a(61));if(s=l.__html,s!=null){if(f.children!=null)throw Error(a(60));e.innerHTML=s}}break;case"multiple":e.multiple=l&&typeof l!="function"&&typeof l!="symbol";break;case"muted":e.muted=l&&typeof l!="function"&&typeof l!="symbol";break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"defaultValue":case"defaultChecked":case"innerHTML":case"ref":break;case"autoFocus":break;case"xlinkHref":if(l==null||typeof l=="function"||typeof l=="boolean"||typeof l=="symbol"){e.removeAttribute("xlink:href");break}s=Vi(""+l),e.setAttributeNS("http://www.w3.org/1999/xlink","xlink:href",s);break;case"contentEditable":case"spellCheck":case"draggable":case"value":case"autoReverse":case"externalResourcesRequired":case"focusable":case"preserveAlpha":l!=null&&typeof l!="function"&&typeof l!="symbol"?e.setAttribute(s,""+l):e.removeAttribute(s);break;case"inert":case"allowFullScreen":case"async":case"autoPlay":case"controls":case"default":case"defer":case"disabled":case"disablePictureInPicture":case"disableRemotePlayback":case"formNoValidate":case"hidden":case"loop":case"noModule":case"noValidate":case"open":case"playsInline":case"readOnly":case"required":case"reversed":case"scoped":case"seamless":case"itemScope":l&&typeof l!="function"&&typeof l!="symbol"?e.setAttribute(s,""):e.removeAttribute(s);break;case"capture":case"download":l===!0?e.setAttribute(s,""):l!==!1&&l!=null&&typeof l!="function"&&typeof l!="symbol"?e.setAttribute(s,l):e.removeAttribute(s);break;case"cols":case"rows":case"size":case"span":l!=null&&typeof l!="function"&&typeof l!="symbol"&&!isNaN(l)&&1<=l?e.setAttribute(s,l):e.removeAttribute(s);break;case"rowSpan":case"start":l==null||typeof l=="function"||typeof l=="symbol"||isNaN(l)?e.removeAttribute(s):e.setAttribute(s,l);break;case"popover":Pe("beforetoggle",e),Pe("toggle",e),$t(e,"popover",l);break;case"xlinkActuate":Qt(e,"http://www.w3.org/1999/xlink","xlink:actuate",l);break;case"xlinkArcrole":Qt(e,"http://www.w3.org/1999/xlink","xlink:arcrole",l);break;case"xlinkRole":Qt(e,"http://www.w3.org/1999/xlink","xlink:role",l);break;case"xlinkShow":Qt(e,"http://www.w3.org/1999/xlink","xlink:show",l);break;case"xlinkTitle":Qt(e,"http://www.w3.org/1999/xlink","xlink:title",l);break;case"xlinkType":Qt(e,"http://www.w3.org/1999/xlink","xlink:type",l);break;case"xmlBase":Qt(e,"http://www.w3.org/XML/1998/namespace","xml:base",l);break;case"xmlLang":Qt(e,"http://www.w3.org/XML/1998/namespace","xml:lang",l);break;case"xmlSpace":Qt(e,"http://www.w3.org/XML/1998/namespace","xml:space",l);break;case"is":$t(e,"is",l);break;case"innerText":case"textContent":break;default:(!(2<s.length)||s[0]!=="o"&&s[0]!=="O"||s[1]!=="n"&&s[1]!=="N")&&(s=sn.get(s)||s,$t(e,s,l))}}function Lh(e,i,s,l,f,d){switch(s){case"style":vn(e,l,d);break;case"dangerouslySetInnerHTML":if(l!=null){if(typeof l!="object"||!("__html"in l))throw Error(a(61));if(s=l.__html,s!=null){if(f.children!=null)throw Error(a(60));e.innerHTML=s}}break;case"children":typeof l=="string"?ii(e,l):(typeof l=="number"||typeof l=="bigint")&&ii(e,""+l);break;case"onScroll":l!=null&&Pe("scroll",e);break;case"onScrollEnd":l!=null&&Pe("scrollend",e);break;case"onClick":l!=null&&(e.onclick=Ci);break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"innerHTML":case"ref":break;case"innerText":case"textContent":break;default:if(!mo.hasOwnProperty(s))t:{if(s[0]==="o"&&s[1]==="n"&&(f=s.endsWith("Capture"),i=s.slice(2,f?s.length-7:void 0),d=e[qe]||null,d=d!=null?d[s]:null,typeof d=="function"&&e.removeEventListener(i,d,f),typeof l=="function")){typeof d!="function"&&d!==null&&(s in e?e[s]=null:e.hasAttribute(s)&&e.removeAttribute(s)),e.addEventListener(i,l,f);break t}s in e?e[s]=l:l===!0?e.setAttribute(s,""):$t(e,s,l)}}}function Jn(e,i,s){switch(i){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"img":Pe("error",e),Pe("load",e);var l=!1,f=!1,d;for(d in s)if(s.hasOwnProperty(d)){var y=s[d];if(y!=null)switch(d){case"src":l=!0;break;case"srcSet":f=!0;break;case"children":case"dangerouslySetInnerHTML":throw Error(a(137,i));default:on(e,i,d,y,s,null)}}f&&on(e,i,"srcSet",s.srcSet,s,null),l&&on(e,i,"src",s.src,s,null);return;case"input":Pe("invalid",e);var N=d=y=f=null,K=null,xt=null;for(l in s)if(s.hasOwnProperty(l)){var Dt=s[l];if(Dt!=null)switch(l){case"name":f=Dt;break;case"type":y=Dt;break;case"checked":K=Dt;break;case"defaultChecked":xt=Dt;break;case"value":d=Dt;break;case"defaultValue":N=Dt;break;case"children":case"dangerouslySetInnerHTML":if(Dt!=null)throw Error(a(137,i));break;default:on(e,i,l,Dt,s,null)}}te(e,d,N,K,xt,y,f,!1);return;case"select":Pe("invalid",e),l=y=d=null;for(f in s)if(s.hasOwnProperty(f)&&(N=s[f],N!=null))switch(f){case"value":d=N;break;case"defaultValue":y=N;break;case"multiple":l=N;default:on(e,i,f,N,s,null)}i=d,s=y,e.multiple=!!l,i!=null?Ce(e,!!l,i,!1):s!=null&&Ce(e,!!l,s,!0);return;case"textarea":Pe("invalid",e),d=f=l=null;for(y in s)if(s.hasOwnProperty(y)&&(N=s[y],N!=null))switch(y){case"value":l=N;break;case"defaultValue":f=N;break;case"children":d=N;break;case"dangerouslySetInnerHTML":if(N!=null)throw Error(a(91));break;default:on(e,i,y,N,s,null)}pi(e,l,f,d);return;case"option":for(K in s)if(s.hasOwnProperty(K)&&(l=s[K],l!=null))switch(K){case"selected":e.selected=l&&typeof l!="function"&&typeof l!="symbol";break;default:on(e,i,K,l,s,null)}return;case"dialog":Pe("beforetoggle",e),Pe("toggle",e),Pe("cancel",e),Pe("close",e);break;case"iframe":case"object":Pe("load",e);break;case"video":case"audio":for(l=0;l<Zo.length;l++)Pe(Zo[l],e);break;case"image":Pe("error",e),Pe("load",e);break;case"details":Pe("toggle",e);break;case"embed":case"source":case"link":Pe("error",e),Pe("load",e);case"area":case"base":case"br":case"col":case"hr":case"keygen":case"meta":case"param":case"track":case"wbr":case"menuitem":for(xt in s)if(s.hasOwnProperty(xt)&&(l=s[xt],l!=null))switch(xt){case"children":case"dangerouslySetInnerHTML":throw Error(a(137,i));default:on(e,i,xt,l,s,null)}return;default:if(Ri(i)){for(Dt in s)s.hasOwnProperty(Dt)&&(l=s[Dt],l!==void 0&&Lh(e,i,Dt,l,s,void 0));return}}for(N in s)s.hasOwnProperty(N)&&(l=s[N],l!=null&&on(e,i,N,l,s,null))}function IM(e,i,s,l){switch(i){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"input":var f=null,d=null,y=null,N=null,K=null,xt=null,Dt=null;for(wt in s){var Nt=s[wt];if(s.hasOwnProperty(wt)&&Nt!=null)switch(wt){case"checked":break;case"value":break;case"defaultValue":K=Nt;default:l.hasOwnProperty(wt)||on(e,i,wt,null,l,Nt)}}for(var yt in l){var wt=l[yt];if(Nt=s[yt],l.hasOwnProperty(yt)&&(wt!=null||Nt!=null))switch(yt){case"type":d=wt;break;case"name":f=wt;break;case"checked":xt=wt;break;case"defaultChecked":Dt=wt;break;case"value":y=wt;break;case"defaultValue":N=wt;break;case"children":case"dangerouslySetInnerHTML":if(wt!=null)throw Error(a(137,i));break;default:wt!==Nt&&on(e,i,yt,wt,l,Nt)}}Cn(e,y,N,K,xt,Dt,d,f);return;case"select":wt=y=N=yt=null;for(d in s)if(K=s[d],s.hasOwnProperty(d)&&K!=null)switch(d){case"value":break;case"multiple":wt=K;default:l.hasOwnProperty(d)||on(e,i,d,null,l,K)}for(f in l)if(d=l[f],K=s[f],l.hasOwnProperty(f)&&(d!=null||K!=null))switch(f){case"value":yt=d;break;case"defaultValue":N=d;break;case"multiple":y=d;default:d!==K&&on(e,i,f,d,l,K)}i=N,s=y,l=wt,yt!=null?Ce(e,!!s,yt,!1):!!l!=!!s&&(i!=null?Ce(e,!!s,i,!0):Ce(e,!!s,s?[]:"",!1));return;case"textarea":wt=yt=null;for(N in s)if(f=s[N],s.hasOwnProperty(N)&&f!=null&&!l.hasOwnProperty(N))switch(N){case"value":break;case"children":break;default:on(e,i,N,null,l,f)}for(y in l)if(f=l[y],d=s[y],l.hasOwnProperty(y)&&(f!=null||d!=null))switch(y){case"value":yt=f;break;case"defaultValue":wt=f;break;case"children":break;case"dangerouslySetInnerHTML":if(f!=null)throw Error(a(91));break;default:f!==d&&on(e,i,y,f,l,d)}ni(e,yt,wt);return;case"option":for(var se in s)if(yt=s[se],s.hasOwnProperty(se)&&yt!=null&&!l.hasOwnProperty(se))switch(se){case"selected":e.selected=!1;break;default:on(e,i,se,null,l,yt)}for(K in l)if(yt=l[K],wt=s[K],l.hasOwnProperty(K)&&yt!==wt&&(yt!=null||wt!=null))switch(K){case"selected":e.selected=yt&&typeof yt!="function"&&typeof yt!="symbol";break;default:on(e,i,K,yt,l,wt)}return;case"img":case"link":case"area":case"base":case"br":case"col":case"embed":case"hr":case"keygen":case"meta":case"param":case"source":case"track":case"wbr":case"menuitem":for(var ge in s)yt=s[ge],s.hasOwnProperty(ge)&&yt!=null&&!l.hasOwnProperty(ge)&&on(e,i,ge,null,l,yt);for(xt in l)if(yt=l[xt],wt=s[xt],l.hasOwnProperty(xt)&&yt!==wt&&(yt!=null||wt!=null))switch(xt){case"children":case"dangerouslySetInnerHTML":if(yt!=null)throw Error(a(137,i));break;default:on(e,i,xt,yt,l,wt)}return;default:if(Ri(i)){for(var ln in s)yt=s[ln],s.hasOwnProperty(ln)&&yt!==void 0&&!l.hasOwnProperty(ln)&&Lh(e,i,ln,void 0,l,yt);for(Dt in l)yt=l[Dt],wt=s[Dt],!l.hasOwnProperty(Dt)||yt===wt||yt===void 0&&wt===void 0||Lh(e,i,Dt,yt,l,wt);return}}for(var ft in s)yt=s[ft],s.hasOwnProperty(ft)&&yt!=null&&!l.hasOwnProperty(ft)&&on(e,i,ft,null,l,yt);for(Nt in l)yt=l[Nt],wt=s[Nt],!l.hasOwnProperty(Nt)||yt===wt||yt==null&&wt==null||on(e,i,Nt,yt,l,wt)}function lv(e){switch(e){case"css":case"script":case"font":case"img":case"image":case"input":case"link":return!0;default:return!1}}function BM(){if(typeof performance.getEntriesByType=="function"){for(var e=0,i=0,s=performance.getEntriesByType("resource"),l=0;l<s.length;l++){var f=s[l],d=f.transferSize,y=f.initiatorType,N=f.duration;if(d&&N&&lv(y)){for(y=0,N=f.responseEnd,l+=1;l<s.length;l++){var K=s[l],xt=K.startTime;if(xt>N)break;var Dt=K.transferSize,Nt=K.initiatorType;Dt&&lv(Nt)&&(K=K.responseEnd,y+=Dt*(K<N?1:(N-xt)/(K-xt)))}if(--l,i+=8*(d+y)/(f.duration/1e3),e++,10<e)break}}if(0<e)return i/e/1e6}return navigator.connection&&(e=navigator.connection.downlink,typeof e=="number")?e:5}var Nh=null,Oh=null;function Uc(e){return e.nodeType===9?e:e.ownerDocument}function cv(e){switch(e){case"http://www.w3.org/2000/svg":return 1;case"http://www.w3.org/1998/Math/MathML":return 2;default:return 0}}function uv(e,i){if(e===0)switch(i){case"svg":return 1;case"math":return 2;default:return 0}return e===1&&i==="foreignObject"?0:e}function Ph(e,i){return e==="textarea"||e==="noscript"||typeof i.children=="string"||typeof i.children=="number"||typeof i.children=="bigint"||typeof i.dangerouslySetInnerHTML=="object"&&i.dangerouslySetInnerHTML!==null&&i.dangerouslySetInnerHTML.__html!=null}var zh=null;function FM(){var e=window.event;return e&&e.type==="popstate"?e===zh?!1:(zh=e,!0):(zh=null,!1)}var fv=typeof setTimeout=="function"?setTimeout:void 0,HM=typeof clearTimeout=="function"?clearTimeout:void 0,hv=typeof Promise=="function"?Promise:void 0,GM=typeof queueMicrotask=="function"?queueMicrotask:typeof hv<"u"?function(e){return hv.resolve(null).then(e).catch(VM)}:fv;function VM(e){setTimeout(function(){throw e})}function ds(e){return e==="head"}function dv(e,i){var s=i,l=0;do{var f=s.nextSibling;if(e.removeChild(s),f&&f.nodeType===8)if(s=f.data,s==="/$"||s==="/&"){if(l===0){e.removeChild(f),Gr(i);return}l--}else if(s==="$"||s==="$?"||s==="$~"||s==="$!"||s==="&")l++;else if(s==="html")Jo(e.ownerDocument.documentElement);else if(s==="head"){s=e.ownerDocument.head,Jo(s);for(var d=s.firstChild;d;){var y=d.nextSibling,N=d.nodeName;d[qa]||N==="SCRIPT"||N==="STYLE"||N==="LINK"&&d.rel.toLowerCase()==="stylesheet"||s.removeChild(d),d=y}}else s==="body"&&Jo(e.ownerDocument.body);s=f}while(s);Gr(i)}function pv(e,i){var s=e;e=0;do{var l=s.nextSibling;if(s.nodeType===1?i?(s._stashedDisplay=s.style.display,s.style.display="none"):(s.style.display=s._stashedDisplay||"",s.getAttribute("style")===""&&s.removeAttribute("style")):s.nodeType===3&&(i?(s._stashedText=s.nodeValue,s.nodeValue=""):s.nodeValue=s._stashedText||""),l&&l.nodeType===8)if(s=l.data,s==="/$"){if(e===0)break;e--}else s!=="$"&&s!=="$?"&&s!=="$~"&&s!=="$!"||e++;s=l}while(s)}function Ih(e){var i=e.firstChild;for(i&&i.nodeType===10&&(i=i.nextSibling);i;){var s=i;switch(i=i.nextSibling,s.nodeName){case"HTML":case"HEAD":case"BODY":Ih(s),Ya(s);continue;case"SCRIPT":case"STYLE":continue;case"LINK":if(s.rel.toLowerCase()==="stylesheet")continue}e.removeChild(s)}}function kM(e,i,s,l){for(;e.nodeType===1;){var f=s;if(e.nodeName.toLowerCase()!==i.toLowerCase()){if(!l&&(e.nodeName!=="INPUT"||e.type!=="hidden"))break}else if(l){if(!e[qa])switch(i){case"meta":if(!e.hasAttribute("itemprop"))break;return e;case"link":if(d=e.getAttribute("rel"),d==="stylesheet"&&e.hasAttribute("data-precedence"))break;if(d!==f.rel||e.getAttribute("href")!==(f.href==null||f.href===""?null:f.href)||e.getAttribute("crossorigin")!==(f.crossOrigin==null?null:f.crossOrigin)||e.getAttribute("title")!==(f.title==null?null:f.title))break;return e;case"style":if(e.hasAttribute("data-precedence"))break;return e;case"script":if(d=e.getAttribute("src"),(d!==(f.src==null?null:f.src)||e.getAttribute("type")!==(f.type==null?null:f.type)||e.getAttribute("crossorigin")!==(f.crossOrigin==null?null:f.crossOrigin))&&d&&e.hasAttribute("async")&&!e.hasAttribute("itemprop"))break;return e;default:return e}}else if(i==="input"&&e.type==="hidden"){var d=f.name==null?null:""+f.name;if(f.type==="hidden"&&e.getAttribute("name")===d)return e}else return e;if(e=zi(e.nextSibling),e===null)break}return null}function XM(e,i,s){if(i==="")return null;for(;e.nodeType!==3;)if((e.nodeType!==1||e.nodeName!=="INPUT"||e.type!=="hidden")&&!s||(e=zi(e.nextSibling),e===null))return null;return e}function mv(e,i){for(;e.nodeType!==8;)if((e.nodeType!==1||e.nodeName!=="INPUT"||e.type!=="hidden")&&!i||(e=zi(e.nextSibling),e===null))return null;return e}function Bh(e){return e.data==="$?"||e.data==="$~"}function Fh(e){return e.data==="$!"||e.data==="$?"&&e.ownerDocument.readyState!=="loading"}function WM(e,i){var s=e.ownerDocument;if(e.data==="$~")e._reactRetry=i;else if(e.data!=="$?"||s.readyState!=="loading")i();else{var l=function(){i(),s.removeEventListener("DOMContentLoaded",l)};s.addEventListener("DOMContentLoaded",l),e._reactRetry=l}}function zi(e){for(;e!=null;e=e.nextSibling){var i=e.nodeType;if(i===1||i===3)break;if(i===8){if(i=e.data,i==="$"||i==="$!"||i==="$?"||i==="$~"||i==="&"||i==="F!"||i==="F")break;if(i==="/$"||i==="/&")return null}}return e}var Hh=null;function gv(e){e=e.nextSibling;for(var i=0;e;){if(e.nodeType===8){var s=e.data;if(s==="/$"||s==="/&"){if(i===0)return zi(e.nextSibling);i--}else s!=="$"&&s!=="$!"&&s!=="$?"&&s!=="$~"&&s!=="&"||i++}e=e.nextSibling}return null}function vv(e){e=e.previousSibling;for(var i=0;e;){if(e.nodeType===8){var s=e.data;if(s==="$"||s==="$!"||s==="$?"||s==="$~"||s==="&"){if(i===0)return e;i--}else s!=="/$"&&s!=="/&"||i++}e=e.previousSibling}return null}function _v(e,i,s){switch(i=Uc(s),e){case"html":if(e=i.documentElement,!e)throw Error(a(452));return e;case"head":if(e=i.head,!e)throw Error(a(453));return e;case"body":if(e=i.body,!e)throw Error(a(454));return e;default:throw Error(a(451))}}function Jo(e){for(var i=e.attributes;i.length;)e.removeAttributeNode(i[0]);Ya(e)}var Ii=new Map,xv=new Set;function Lc(e){return typeof e.getRootNode=="function"?e.getRootNode():e.nodeType===9?e:e.ownerDocument}var Da=Z.d;Z.d={f:qM,r:YM,D:ZM,C:KM,L:JM,m:QM,X:$M,S:jM,M:ty};function qM(){var e=Da.f(),i=bc();return e||i}function YM(e){var i=pa(e);i!==null&&i.tag===5&&i.type==="form"?z0(i):Da.r(e)}var Br=typeof document>"u"?null:document;function Sv(e,i,s){var l=Br;if(l&&typeof i=="string"&&i){var f=Re(i);f='link[rel="'+e+'"][href="'+f+'"]',typeof s=="string"&&(f+='[crossorigin="'+s+'"]'),xv.has(f)||(xv.add(f),e={rel:e,crossOrigin:s,href:i},l.querySelector(f)===null&&(i=l.createElement("link"),Jn(i,"link",e),Rn(i),l.head.appendChild(i)))}}function ZM(e){Da.D(e),Sv("dns-prefetch",e,null)}function KM(e,i){Da.C(e,i),Sv("preconnect",e,i)}function JM(e,i,s){Da.L(e,i,s);var l=Br;if(l&&e&&i){var f='link[rel="preload"][as="'+Re(i)+'"]';i==="image"&&s&&s.imageSrcSet?(f+='[imagesrcset="'+Re(s.imageSrcSet)+'"]',typeof s.imageSizes=="string"&&(f+='[imagesizes="'+Re(s.imageSizes)+'"]')):f+='[href="'+Re(e)+'"]';var d=f;switch(i){case"style":d=Fr(e);break;case"script":d=Hr(e)}Ii.has(d)||(e=_({rel:"preload",href:i==="image"&&s&&s.imageSrcSet?void 0:e,as:i},s),Ii.set(d,e),l.querySelector(f)!==null||i==="style"&&l.querySelector(Qo(d))||i==="script"&&l.querySelector(jo(d))||(i=l.createElement("link"),Jn(i,"link",e),Rn(i),l.head.appendChild(i)))}}function QM(e,i){Da.m(e,i);var s=Br;if(s&&e){var l=i&&typeof i.as=="string"?i.as:"script",f='link[rel="modulepreload"][as="'+Re(l)+'"][href="'+Re(e)+'"]',d=f;switch(l){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":d=Hr(e)}if(!Ii.has(d)&&(e=_({rel:"modulepreload",href:e},i),Ii.set(d,e),s.querySelector(f)===null)){switch(l){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":if(s.querySelector(jo(d)))return}l=s.createElement("link"),Jn(l,"link",e),Rn(l),s.head.appendChild(l)}}}function jM(e,i,s){Da.S(e,i,s);var l=Br;if(l&&e){var f=Za(l).hoistableStyles,d=Fr(e);i=i||"default";var y=f.get(d);if(!y){var N={loading:0,preload:null};if(y=l.querySelector(Qo(d)))N.loading=5;else{e=_({rel:"stylesheet",href:e,"data-precedence":i},s),(s=Ii.get(d))&&Gh(e,s);var K=y=l.createElement("link");Rn(K),Jn(K,"link",e),K._p=new Promise(function(xt,Dt){K.onload=xt,K.onerror=Dt}),K.addEventListener("load",function(){N.loading|=1}),K.addEventListener("error",function(){N.loading|=2}),N.loading|=4,Nc(y,i,l)}y={type:"stylesheet",instance:y,count:1,state:N},f.set(d,y)}}}function $M(e,i){Da.X(e,i);var s=Br;if(s&&e){var l=Za(s).hoistableScripts,f=Hr(e),d=l.get(f);d||(d=s.querySelector(jo(f)),d||(e=_({src:e,async:!0},i),(i=Ii.get(f))&&Vh(e,i),d=s.createElement("script"),Rn(d),Jn(d,"link",e),s.head.appendChild(d)),d={type:"script",instance:d,count:1,state:null},l.set(f,d))}}function ty(e,i){Da.M(e,i);var s=Br;if(s&&e){var l=Za(s).hoistableScripts,f=Hr(e),d=l.get(f);d||(d=s.querySelector(jo(f)),d||(e=_({src:e,async:!0,type:"module"},i),(i=Ii.get(f))&&Vh(e,i),d=s.createElement("script"),Rn(d),Jn(d,"link",e),s.head.appendChild(d)),d={type:"script",instance:d,count:1,state:null},l.set(f,d))}}function Mv(e,i,s,l){var f=(f=zt.current)?Lc(f):null;if(!f)throw Error(a(446));switch(e){case"meta":case"title":return null;case"style":return typeof s.precedence=="string"&&typeof s.href=="string"?(i=Fr(s.href),s=Za(f).hoistableStyles,l=s.get(i),l||(l={type:"style",instance:null,count:0,state:null},s.set(i,l)),l):{type:"void",instance:null,count:0,state:null};case"link":if(s.rel==="stylesheet"&&typeof s.href=="string"&&typeof s.precedence=="string"){e=Fr(s.href);var d=Za(f).hoistableStyles,y=d.get(e);if(y||(f=f.ownerDocument||f,y={type:"stylesheet",instance:null,count:0,state:{loading:0,preload:null}},d.set(e,y),(d=f.querySelector(Qo(e)))&&!d._p&&(y.instance=d,y.state.loading=5),Ii.has(e)||(s={rel:"preload",as:"style",href:s.href,crossOrigin:s.crossOrigin,integrity:s.integrity,media:s.media,hrefLang:s.hrefLang,referrerPolicy:s.referrerPolicy},Ii.set(e,s),d||ey(f,e,s,y.state))),i&&l===null)throw Error(a(528,""));return y}if(i&&l!==null)throw Error(a(529,""));return null;case"script":return i=s.async,s=s.src,typeof s=="string"&&i&&typeof i!="function"&&typeof i!="symbol"?(i=Hr(s),s=Za(f).hoistableScripts,l=s.get(i),l||(l={type:"script",instance:null,count:0,state:null},s.set(i,l)),l):{type:"void",instance:null,count:0,state:null};default:throw Error(a(444,e))}}function Fr(e){return'href="'+Re(e)+'"'}function Qo(e){return'link[rel="stylesheet"]['+e+"]"}function yv(e){return _({},e,{"data-precedence":e.precedence,precedence:null})}function ey(e,i,s,l){e.querySelector('link[rel="preload"][as="style"]['+i+"]")?l.loading=1:(i=e.createElement("link"),l.preload=i,i.addEventListener("load",function(){return l.loading|=1}),i.addEventListener("error",function(){return l.loading|=2}),Jn(i,"link",s),Rn(i),e.head.appendChild(i))}function Hr(e){return'[src="'+Re(e)+'"]'}function jo(e){return"script[async]"+e}function bv(e,i,s){if(i.count++,i.instance===null)switch(i.type){case"style":var l=e.querySelector('style[data-href~="'+Re(s.href)+'"]');if(l)return i.instance=l,Rn(l),l;var f=_({},s,{"data-href":s.href,"data-precedence":s.precedence,href:null,precedence:null});return l=(e.ownerDocument||e).createElement("style"),Rn(l),Jn(l,"style",f),Nc(l,s.precedence,e),i.instance=l;case"stylesheet":f=Fr(s.href);var d=e.querySelector(Qo(f));if(d)return i.state.loading|=4,i.instance=d,Rn(d),d;l=yv(s),(f=Ii.get(f))&&Gh(l,f),d=(e.ownerDocument||e).createElement("link"),Rn(d);var y=d;return y._p=new Promise(function(N,K){y.onload=N,y.onerror=K}),Jn(d,"link",l),i.state.loading|=4,Nc(d,s.precedence,e),i.instance=d;case"script":return d=Hr(s.src),(f=e.querySelector(jo(d)))?(i.instance=f,Rn(f),f):(l=s,(f=Ii.get(d))&&(l=_({},s),Vh(l,f)),e=e.ownerDocument||e,f=e.createElement("script"),Rn(f),Jn(f,"link",l),e.head.appendChild(f),i.instance=f);case"void":return null;default:throw Error(a(443,i.type))}else i.type==="stylesheet"&&(i.state.loading&4)===0&&(l=i.instance,i.state.loading|=4,Nc(l,s.precedence,e));return i.instance}function Nc(e,i,s){for(var l=s.querySelectorAll('link[rel="stylesheet"][data-precedence],style[data-precedence]'),f=l.length?l[l.length-1]:null,d=f,y=0;y<l.length;y++){var N=l[y];if(N.dataset.precedence===i)d=N;else if(d!==f)break}d?d.parentNode.insertBefore(e,d.nextSibling):(i=s.nodeType===9?s.head:s,i.insertBefore(e,i.firstChild))}function Gh(e,i){e.crossOrigin==null&&(e.crossOrigin=i.crossOrigin),e.referrerPolicy==null&&(e.referrerPolicy=i.referrerPolicy),e.title==null&&(e.title=i.title)}function Vh(e,i){e.crossOrigin==null&&(e.crossOrigin=i.crossOrigin),e.referrerPolicy==null&&(e.referrerPolicy=i.referrerPolicy),e.integrity==null&&(e.integrity=i.integrity)}var Oc=null;function Ev(e,i,s){if(Oc===null){var l=new Map,f=Oc=new Map;f.set(s,l)}else f=Oc,l=f.get(s),l||(l=new Map,f.set(s,l));if(l.has(e))return l;for(l.set(e,null),s=s.getElementsByTagName(e),f=0;f<s.length;f++){var d=s[f];if(!(d[qa]||d[He]||e==="link"&&d.getAttribute("rel")==="stylesheet")&&d.namespaceURI!=="http://www.w3.org/2000/svg"){var y=d.getAttribute(i)||"";y=e+y;var N=l.get(y);N?N.push(d):l.set(y,[d])}}return l}function Tv(e,i,s){e=e.ownerDocument||e,e.head.insertBefore(s,i==="title"?e.querySelector("head > title"):null)}function ny(e,i,s){if(s===1||i.itemProp!=null)return!1;switch(e){case"meta":case"title":return!0;case"style":if(typeof i.precedence!="string"||typeof i.href!="string"||i.href==="")break;return!0;case"link":if(typeof i.rel!="string"||typeof i.href!="string"||i.href===""||i.onLoad||i.onError)break;switch(i.rel){case"stylesheet":return e=i.disabled,typeof i.precedence=="string"&&e==null;default:return!0}case"script":if(i.async&&typeof i.async!="function"&&typeof i.async!="symbol"&&!i.onLoad&&!i.onError&&i.src&&typeof i.src=="string")return!0}return!1}function Av(e){return!(e.type==="stylesheet"&&(e.state.loading&3)===0)}function iy(e,i,s,l){if(s.type==="stylesheet"&&(typeof l.media!="string"||matchMedia(l.media).matches!==!1)&&(s.state.loading&4)===0){if(s.instance===null){var f=Fr(l.href),d=i.querySelector(Qo(f));if(d){i=d._p,i!==null&&typeof i=="object"&&typeof i.then=="function"&&(e.count++,e=Pc.bind(e),i.then(e,e)),s.state.loading|=4,s.instance=d,Rn(d);return}d=i.ownerDocument||i,l=yv(l),(f=Ii.get(f))&&Gh(l,f),d=d.createElement("link"),Rn(d);var y=d;y._p=new Promise(function(N,K){y.onload=N,y.onerror=K}),Jn(d,"link",l),s.instance=d}e.stylesheets===null&&(e.stylesheets=new Map),e.stylesheets.set(s,i),(i=s.state.preload)&&(s.state.loading&3)===0&&(e.count++,s=Pc.bind(e),i.addEventListener("load",s),i.addEventListener("error",s))}}var kh=0;function ay(e,i){return e.stylesheets&&e.count===0&&Ic(e,e.stylesheets),0<e.count||0<e.imgCount?function(s){var l=setTimeout(function(){if(e.stylesheets&&Ic(e,e.stylesheets),e.unsuspend){var d=e.unsuspend;e.unsuspend=null,d()}},6e4+i);0<e.imgBytes&&kh===0&&(kh=62500*BM());var f=setTimeout(function(){if(e.waitingForImages=!1,e.count===0&&(e.stylesheets&&Ic(e,e.stylesheets),e.unsuspend)){var d=e.unsuspend;e.unsuspend=null,d()}},(e.imgBytes>kh?50:800)+i);return e.unsuspend=s,function(){e.unsuspend=null,clearTimeout(l),clearTimeout(f)}}:null}function Pc(){if(this.count--,this.count===0&&(this.imgCount===0||!this.waitingForImages)){if(this.stylesheets)Ic(this,this.stylesheets);else if(this.unsuspend){var e=this.unsuspend;this.unsuspend=null,e()}}}var zc=null;function Ic(e,i){e.stylesheets=null,e.unsuspend!==null&&(e.count++,zc=new Map,i.forEach(sy,e),zc=null,Pc.call(e))}function sy(e,i){if(!(i.state.loading&4)){var s=zc.get(e);if(s)var l=s.get(null);else{s=new Map,zc.set(e,s);for(var f=e.querySelectorAll("link[data-precedence],style[data-precedence]"),d=0;d<f.length;d++){var y=f[d];(y.nodeName==="LINK"||y.getAttribute("media")!=="not all")&&(s.set(y.dataset.precedence,y),l=y)}l&&s.set(null,l)}f=i.instance,y=f.getAttribute("data-precedence"),d=s.get(y)||l,d===l&&s.set(null,f),s.set(y,f),this.count++,l=Pc.bind(this),f.addEventListener("load",l),f.addEventListener("error",l),d?d.parentNode.insertBefore(f,d.nextSibling):(e=e.nodeType===9?e.head:e,e.insertBefore(f,e.firstChild)),i.state.loading|=4}}var $o={$$typeof:O,Provider:null,Consumer:null,_currentValue:ht,_currentValue2:ht,_threadCount:0};function ry(e,i,s,l,f,d,y,N,K){this.tag=1,this.containerInfo=e,this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.next=this.pendingContext=this.context=this.cancelPendingCommit=null,this.callbackPriority=0,this.expirationTimes=Ct(-1),this.entangledLanes=this.shellSuspendCounter=this.errorRecoveryDisabledLanes=this.expiredLanes=this.warmLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=Ct(0),this.hiddenUpdates=Ct(null),this.identifierPrefix=l,this.onUncaughtError=f,this.onCaughtError=d,this.onRecoverableError=y,this.pooledCache=null,this.pooledCacheLanes=0,this.formState=K,this.incompleteTransitions=new Map}function wv(e,i,s,l,f,d,y,N,K,xt,Dt,Nt){return e=new ry(e,i,s,y,K,xt,Dt,Nt,N),i=1,d===!0&&(i|=24),d=gi(3,null,null,i),e.current=d,d.stateNode=e,i=yf(),i.refCount++,e.pooledCache=i,i.refCount++,d.memoizedState={element:l,isDehydrated:s,cache:i},Af(d),e}function Rv(e){return e?(e=vr,e):vr}function Cv(e,i,s,l,f,d){f=Rv(f),l.context===null?l.context=f:l.pendingContext=f,l=ns(i),l.payload={element:s},d=d===void 0?null:d,d!==null&&(l.callback=d),s=is(e,l,i),s!==null&&(di(s,e,i),Uo(s,e,i))}function Dv(e,i){if(e=e.memoizedState,e!==null&&e.dehydrated!==null){var s=e.retryLane;e.retryLane=s!==0&&s<i?s:i}}function Xh(e,i){Dv(e,i),(e=e.alternate)&&Dv(e,i)}function Uv(e){if(e.tag===13||e.tag===31){var i=Us(e,67108864);i!==null&&di(i,e,67108864),Xh(e,67108864)}}function Lv(e){if(e.tag===13||e.tag===31){var i=Mi();i=Yt(i);var s=Us(e,i);s!==null&&di(s,e,i),Xh(e,i)}}var Bc=!0;function oy(e,i,s,l){var f=F.T;F.T=null;var d=Z.p;try{Z.p=2,Wh(e,i,s,l)}finally{Z.p=d,F.T=f}}function ly(e,i,s,l){var f=F.T;F.T=null;var d=Z.p;try{Z.p=8,Wh(e,i,s,l)}finally{Z.p=d,F.T=f}}function Wh(e,i,s,l){if(Bc){var f=qh(l);if(f===null)Uh(e,i,l,Fc,s),Ov(e,l);else if(uy(f,e,i,s,l))l.stopPropagation();else if(Ov(e,l),i&4&&-1<cy.indexOf(e)){for(;f!==null;){var d=pa(f);if(d!==null)switch(d.tag){case 3:if(d=d.stateNode,d.current.memoizedState.isDehydrated){var y=V(d.pendingLanes);if(y!==0){var N=d;for(N.pendingLanes|=2,N.entangledLanes|=2;y;){var K=1<<31-Xt(y);N.entanglements[1]|=K,y&=~K}aa(d),(Qe&6)===0&&(Mc=_e()+500,Yo(0))}}break;case 31:case 13:N=Us(d,2),N!==null&&di(N,d,2),bc(),Xh(d,2)}if(d=qh(l),d===null&&Uh(e,i,l,Fc,s),d===f)break;f=d}f!==null&&l.stopPropagation()}else Uh(e,i,l,null,s)}}function qh(e){return e=Yu(e),Yh(e)}var Fc=null;function Yh(e){if(Fc=null,e=da(e),e!==null){var i=c(e);if(i===null)e=null;else{var s=i.tag;if(s===13){if(e=u(i),e!==null)return e;e=null}else if(s===31){if(e=h(i),e!==null)return e;e=null}else if(s===3){if(i.stateNode.current.memoizedState.isDehydrated)return i.tag===3?i.stateNode.containerInfo:null;e=null}else i!==e&&(e=null)}}return Fc=e,null}function Nv(e){switch(e){case"beforetoggle":case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"resize":case"seeked":case"submit":case"toggle":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 2;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"scroll":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 8;case"message":switch(Ee()){case H:return 2;case A:return 8;case at:case mt:return 32;case bt:return 268435456;default:return 32}default:return 32}}var Zh=!1,ps=null,ms=null,gs=null,tl=new Map,el=new Map,vs=[],cy="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(" ");function Ov(e,i){switch(e){case"focusin":case"focusout":ps=null;break;case"dragenter":case"dragleave":ms=null;break;case"mouseover":case"mouseout":gs=null;break;case"pointerover":case"pointerout":tl.delete(i.pointerId);break;case"gotpointercapture":case"lostpointercapture":el.delete(i.pointerId)}}function nl(e,i,s,l,f,d){return e===null||e.nativeEvent!==d?(e={blockedOn:i,domEventName:s,eventSystemFlags:l,nativeEvent:d,targetContainers:[f]},i!==null&&(i=pa(i),i!==null&&Uv(i)),e):(e.eventSystemFlags|=l,i=e.targetContainers,f!==null&&i.indexOf(f)===-1&&i.push(f),e)}function uy(e,i,s,l,f){switch(i){case"focusin":return ps=nl(ps,e,i,s,l,f),!0;case"dragenter":return ms=nl(ms,e,i,s,l,f),!0;case"mouseover":return gs=nl(gs,e,i,s,l,f),!0;case"pointerover":var d=f.pointerId;return tl.set(d,nl(tl.get(d)||null,e,i,s,l,f)),!0;case"gotpointercapture":return d=f.pointerId,el.set(d,nl(el.get(d)||null,e,i,s,l,f)),!0}return!1}function Pv(e){var i=da(e.target);if(i!==null){var s=c(i);if(s!==null){if(i=s.tag,i===13){if(i=u(s),i!==null){e.blockedOn=i,gn(e.priority,function(){Lv(s)});return}}else if(i===31){if(i=h(s),i!==null){e.blockedOn=i,gn(e.priority,function(){Lv(s)});return}}else if(i===3&&s.stateNode.current.memoizedState.isDehydrated){e.blockedOn=s.tag===3?s.stateNode.containerInfo:null;return}}}e.blockedOn=null}function Hc(e){if(e.blockedOn!==null)return!1;for(var i=e.targetContainers;0<i.length;){var s=qh(e.nativeEvent);if(s===null){s=e.nativeEvent;var l=new s.constructor(s.type,s);qu=l,s.target.dispatchEvent(l),qu=null}else return i=pa(s),i!==null&&Uv(i),e.blockedOn=s,!1;i.shift()}return!0}function zv(e,i,s){Hc(e)&&s.delete(i)}function fy(){Zh=!1,ps!==null&&Hc(ps)&&(ps=null),ms!==null&&Hc(ms)&&(ms=null),gs!==null&&Hc(gs)&&(gs=null),tl.forEach(zv),el.forEach(zv)}function Gc(e,i){e.blockedOn===i&&(e.blockedOn=null,Zh||(Zh=!0,r.unstable_scheduleCallback(r.unstable_NormalPriority,fy)))}var Vc=null;function Iv(e){Vc!==e&&(Vc=e,r.unstable_scheduleCallback(r.unstable_NormalPriority,function(){Vc===e&&(Vc=null);for(var i=0;i<e.length;i+=3){var s=e[i],l=e[i+1],f=e[i+2];if(typeof l!="function"){if(Yh(l||s)===null)continue;break}var d=pa(s);d!==null&&(e.splice(i,3),i-=3,qf(d,{pending:!0,data:f,method:s.method,action:l},l,f))}}))}function Gr(e){function i(K){return Gc(K,e)}ps!==null&&Gc(ps,e),ms!==null&&Gc(ms,e),gs!==null&&Gc(gs,e),tl.forEach(i),el.forEach(i);for(var s=0;s<vs.length;s++){var l=vs[s];l.blockedOn===e&&(l.blockedOn=null)}for(;0<vs.length&&(s=vs[0],s.blockedOn===null);)Pv(s),s.blockedOn===null&&vs.shift();if(s=(e.ownerDocument||e).$$reactFormReplay,s!=null)for(l=0;l<s.length;l+=3){var f=s[l],d=s[l+1],y=f[qe]||null;if(typeof d=="function")y||Iv(s);else if(y){var N=null;if(d&&d.hasAttribute("formAction")){if(f=d,y=d[qe]||null)N=y.formAction;else if(Yh(f)!==null)continue}else N=y.action;typeof N=="function"?s[l+1]=N:(s.splice(l,3),l-=3),Iv(s)}}}function Bv(){function e(d){d.canIntercept&&d.info==="react-transition"&&d.intercept({handler:function(){return new Promise(function(y){return f=y})},focusReset:"manual",scroll:"manual"})}function i(){f!==null&&(f(),f=null),l||setTimeout(s,20)}function s(){if(!l&&!navigation.transition){var d=navigation.currentEntry;d&&d.url!=null&&navigation.navigate(d.url,{state:d.getState(),info:"react-transition",history:"replace"})}}if(typeof navigation=="object"){var l=!1,f=null;return navigation.addEventListener("navigate",e),navigation.addEventListener("navigatesuccess",i),navigation.addEventListener("navigateerror",i),setTimeout(s,100),function(){l=!0,navigation.removeEventListener("navigate",e),navigation.removeEventListener("navigatesuccess",i),navigation.removeEventListener("navigateerror",i),f!==null&&(f(),f=null)}}}function Kh(e){this._internalRoot=e}kc.prototype.render=Kh.prototype.render=function(e){var i=this._internalRoot;if(i===null)throw Error(a(409));var s=i.current,l=Mi();Cv(s,l,e,i,null,null)},kc.prototype.unmount=Kh.prototype.unmount=function(){var e=this._internalRoot;if(e!==null){this._internalRoot=null;var i=e.containerInfo;Cv(e.current,2,null,e,null,null),bc(),i[Tn]=null}};function kc(e){this._internalRoot=e}kc.prototype.unstable_scheduleHydration=function(e){if(e){var i=Ke();e={blockedOn:null,target:e,priority:i};for(var s=0;s<vs.length&&i!==0&&i<vs[s].priority;s++);vs.splice(s,0,e),s===0&&Pv(e)}};var Fv=t.version;if(Fv!=="19.2.7")throw Error(a(527,Fv,"19.2.7"));Z.findDOMNode=function(e){var i=e._reactInternals;if(i===void 0)throw typeof e.render=="function"?Error(a(188)):(e=Object.keys(e).join(","),Error(a(268,e)));return e=p(i),e=e!==null?g(e):null,e=e===null?null:e.stateNode,e};var hy={bundleType:0,version:"19.2.7",rendererPackageName:"react-dom",currentDispatcherRef:F,reconcilerVersion:"19.2.7"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"){var Xc=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!Xc.isDisabled&&Xc.supportsFiber)try{Mt=Xc.inject(hy),St=Xc}catch{}}return al.createRoot=function(e,i){if(!o(e))throw Error(a(299));var s=!1,l="",f=q0,d=Y0,y=Z0;return i!=null&&(i.unstable_strictMode===!0&&(s=!0),i.identifierPrefix!==void 0&&(l=i.identifierPrefix),i.onUncaughtError!==void 0&&(f=i.onUncaughtError),i.onCaughtError!==void 0&&(d=i.onCaughtError),i.onRecoverableError!==void 0&&(y=i.onRecoverableError)),i=wv(e,1,!1,null,null,s,l,null,f,d,y,Bv),e[Tn]=i.current,Dh(e),new Kh(i)},al.hydrateRoot=function(e,i,s){if(!o(e))throw Error(a(299));var l=!1,f="",d=q0,y=Y0,N=Z0,K=null;return s!=null&&(s.unstable_strictMode===!0&&(l=!0),s.identifierPrefix!==void 0&&(f=s.identifierPrefix),s.onUncaughtError!==void 0&&(d=s.onUncaughtError),s.onCaughtError!==void 0&&(y=s.onCaughtError),s.onRecoverableError!==void 0&&(N=s.onRecoverableError),s.formState!==void 0&&(K=s.formState)),i=wv(e,1,!0,i,s??null,l,f,K,d,y,N,Bv),i.context=Rv(null),s=i.current,l=Mi(),l=Yt(l),f=ns(l),f.callback=null,is(s,f,l),s=l,i.current.lanes=s,Pt(i,s),aa(i),e[Tn]=i.current,Dh(e),new kc(i)},al.version="19.2.7",al}var Kv;function yy(){if(Kv)return jh.exports;Kv=1;function r(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(r)}catch(t){console.error(t)}}return r(),jh.exports=My(),jh.exports}var by=yy();class Ey{constructor(t){this.options=t,this.holders=[],this.engine=null,this.canvas=null,this.status="loading",this.unsupported=!1,this.disposeTimer=0,this.observer=null,this.observed=null}acquire(t){return window.clearTimeout(this.disposeTimer),this.holders.push(t),this.ensureEngine(),this.attachTop(),t.onStatus(this.status),()=>this.release(t)}setRunning(t,n){t.running=n,this.top===t&&this.applyRunning()}get top(){return this.holders[this.holders.length-1]}configure(t){}drag(t,n,a){var o,c;this.top===t&&((c=(o=this.engine)==null?void 0:o.drag)==null||c.call(o,n,a))}releaseDrag(t){var n,a;this.top===t&&((a=(n=this.engine)==null?void 0:n.releaseDrag)==null||a.call(n))}release(t){var n,a;if(this.holders=this.holders.filter(o=>o!==t),this.holders.length){this.attachTop();return}(n=this.engine)==null||n.stop(),this.observe(null),(a=this.canvas)==null||a.remove(),this.disposeTimer=window.setTimeout(()=>this.teardown(),5e3)}setStatus(t){this.status=t;for(const n of this.holders)n.onStatus(t)}ensureEngine(){if(this.engine||this.unsupported)return;if(!this.options.isSupported()){this.unsupported=!0,this.setStatus("failed");return}const t=document.createElement("canvas");t.className=this.options.canvasClass,t.setAttribute("aria-hidden","true"),this.canvas=t;try{this.engine=this.options.create(t,()=>this.fail())}catch{this.fail();return}const n=this.engine;this.setStatus("loading"),this.configure(n),this.resize(),n.init().then(()=>{this.engine===n&&(n.renderFrame(0),this.setStatus("ready"),this.applyRunning())}).catch(()=>this.fail())}attachTop(){var n,a;const t=this.top;!t||!this.canvas||((a=(n=this.engine)==null?void 0:n.releaseDrag)==null||a.call(n),this.canvas.parentElement!==t.mount&&t.mount.appendChild(this.canvas),this.observe(t.mount),this.resize(),this.applyRunning())}observe(t){var n;this.observed!==t&&((n=this.observer)==null||n.disconnect(),this.observed=t,t&&(this.observer??(this.observer=new ResizeObserver(()=>this.resize())),this.observer.observe(t)))}resize(){var o,c;const t=(o=this.top)==null?void 0:o.mount;if(!t||!this.engine)return;const n=t.clientWidth||window.innerWidth,a=t.clientHeight||window.innerHeight;this.engine.setSize(n,a,window.devicePixelRatio||1),this.status==="ready"&&!((c=this.top)!=null&&c.running)&&this.engine.renderFrame(0)}applyRunning(){var t;!this.engine||this.status!=="ready"||((t=this.top)!=null&&t.running?this.engine.start():this.engine.stop())}fail(){this.teardown(),this.setStatus("failed")}teardown(){var t,n;window.clearTimeout(this.disposeTimer),this.observe(null),(t=this.engine)==null||t.dispose(),this.engine=null,(n=this.canvas)==null||n.remove(),this.canvas=null,this.status!=="failed"&&(this.status="loading")}}function Ty(r){const[t,n]=Vn.useState(!1);return Vn.useEffect(()=>{const a=window.matchMedia("(prefers-reduced-motion: reduce)"),o=()=>n(r&&!document.hidden&&!a.matches&&!document.documentElement.classList.contains("reduce-motion")),c=new MutationObserver(o);return c.observe(document.documentElement,{attributes:!0,attributeFilter:["class"]}),a.addEventListener("change",o),document.addEventListener("visibilitychange",o),o(),()=>{c.disconnect(),a.removeEventListener("change",o),document.removeEventListener("visibilitychange",o)}},[r]),t}/**
 * @license
 * Copyright 2010-2026 Three.js Authors
 * SPDX-License-Identifier: MIT
 */const Pp="186",Ay=0,Jv=1,wy=2,Su=1,mx=2,pl=3,$s=0,oi=1,cn=2,Ha=0,vl=1,Qv=2,jv=3,$v=4,Ry=5,io=100,Cy=101,Dy=102,Uy=103,Ly=104,Ny=200,Oy=201,Py=202,zy=203,gx=204,vx=205,Iy=206,By=207,Fy=208,Hy=209,Gy=210,Vy=211,ky=212,Xy=213,Wy=214,Hd=0,Gd=1,Vd=2,bl=3,kd=4,Xd=5,Wd=6,qd=7,_x=0,qy=1,Yy=2,ca=0,xx=1,Sx=2,Mx=3,zp=4,yx=5,bx=6,Ex=7,Tx=300,tr=301,lo=302,nd=303,id=304,zu=306,Va=1e3,Ba=1001,Yd=1002,Qn=1003,Zy=1004,Wc=1005,Xn=1006,ad=1007,Ks=1008,Ti=1009,Ax=1010,wx=1011,El=1012,Ip=1013,ua=1014,Ji=1015,$i=1016,Bp=1017,Fp=1018,Tl=1020,Rx=35902,Cx=35899,Dx=1021,Ux=1022,Qi=1023,ka=1026,Js=1027,Hp=1028,Gp=1029,er=1030,Vp=1031,kp=1033,Mu=33776,yu=33777,bu=33778,Eu=33779,Zd=35840,Kd=35841,Jd=35842,Qd=35843,jd=36196,$d=37492,tp=37496,ep=37488,np=37489,Au=37490,ip=37491,ap=37808,sp=37809,rp=37810,op=37811,lp=37812,cp=37813,up=37814,fp=37815,hp=37816,dp=37817,pp=37818,mp=37819,gp=37820,vp=37821,_p=36492,xp=36494,Sp=36495,Mp=36283,yp=36284,wu=36285,bp=36286,Ky=3200,Ep=0,Jy=1,Ia="",In="srgb",Ru="srgb-linear",Cu="linear",nn="srgb",sd=7680,Qy=519,jy=512,$y=513,t1=514,Xp=515,e1=516,n1=517,Wp=518,i1=519,Lx=35044,t_="300 es",la=2e3,Al=2001;function a1(r){for(let t=r.length-1;t>=0;--t)if(r[t]>=65535)return!0;return!1}function Du(r){return document.createElementNS("http://www.w3.org/1999/xhtml",r)}function s1(){const r=Du("canvas");return r.style.display="block",r}const e_={};function n_(...r){const t="THREE."+r.shift();console.log(t,...r)}function Nx(r){const t=r[0];if(typeof t=="string"&&t.startsWith("TSL:")){const n=r[1];n&&n.isStackTrace?r[0]+=" "+n.getLocation():r[1]='Stack trace not available. Enable "THREE.Node.captureStackTrace" to capture stack traces.'}return r}function ve(...r){r=Nx(r);const t="THREE."+r.shift();{const n=r[0];n&&n.isStackTrace?console.warn(n.getError(t)):console.warn(t,...r)}}function We(...r){r=Nx(r);const t="THREE."+r.shift();{const n=r[0];n&&n.isStackTrace?console.error(n.getError(t)):console.error(t,...r)}}function ro(...r){const t=r.join(" ");t in e_||(e_[t]=!0,ve(...r))}function r1(r,t,n){return new Promise(function(a,o){function c(){switch(r.clientWaitSync(t,r.SYNC_FLUSH_COMMANDS_BIT,0)){case r.WAIT_FAILED:o();break;case r.TIMEOUT_EXPIRED:setTimeout(c,n);break;default:a()}}setTimeout(c,n)})}const o1={[Hd]:Gd,[Vd]:Wd,[kd]:qd,[bl]:Xd,[Gd]:Hd,[Wd]:Vd,[qd]:kd,[Xd]:bl};class rr{addEventListener(t,n){this._listeners===void 0&&(this._listeners={});const a=this._listeners;a[t]===void 0&&(a[t]=[]),a[t].indexOf(n)===-1&&a[t].push(n)}hasEventListener(t,n){const a=this._listeners;return a===void 0?!1:a[t]!==void 0&&a[t].indexOf(n)!==-1}removeEventListener(t,n){const a=this._listeners;if(a===void 0)return;const o=a[t];if(o!==void 0){const c=o.indexOf(n);c!==-1&&o.splice(c,1)}}dispatchEvent(t){const n=this._listeners;if(n===void 0)return;const a=n[t.type];if(a!==void 0){t.target=this;const o=a.slice(0);for(let c=0,u=o.length;c<u;c++)o[c].call(this,t);t.target=null}}}const $n=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"];let i_=1234567;const _l=Math.PI/180,wl=180/Math.PI;function or(){const r=Math.random()*4294967295|0,t=Math.random()*4294967295|0,n=Math.random()*4294967295|0,a=Math.random()*4294967295|0;return($n[r&255]+$n[r>>8&255]+$n[r>>16&255]+$n[r>>24&255]+"-"+$n[t&255]+$n[t>>8&255]+"-"+$n[t>>16&15|64]+$n[t>>24&255]+"-"+$n[n&63|128]+$n[n>>8&255]+"-"+$n[n>>16&255]+$n[n>>24&255]+$n[a&255]+$n[a>>8&255]+$n[a>>16&255]+$n[a>>24&255]).toLowerCase()}function Ue(r,t,n){return Math.max(t,Math.min(n,r))}function qp(r,t){return(r%t+t)%t}function l1(r,t,n,a,o){return a+(r-t)*(o-a)/(n-t)}function c1(r,t,n){return r!==t?(n-r)/(t-r):0}function xl(r,t,n){return(1-n)*r+n*t}function u1(r,t,n,a){return xl(r,t,1-Math.exp(-n*a))}function f1(r,t=1){return t-Math.abs(qp(r,t*2)-t)}function h1(r,t,n){return r<=t?0:r>=n?1:(r=(r-t)/(n-t),r*r*(3-2*r))}function d1(r,t,n){return r<=t?0:r>=n?1:(r=(r-t)/(n-t),r*r*r*(r*(r*6-15)+10))}function p1(r,t){return r+Math.floor(Math.random()*(t-r+1))}function m1(r,t){return r+Math.random()*(t-r)}function g1(r){return r*(.5-Math.random())}function v1(r){r!==void 0&&(i_=r);let t=i_+=1831565813;return t=Math.imul(t^t>>>15,t|1),t^=t+Math.imul(t^t>>>7,t|61),((t^t>>>14)>>>0)/4294967296}function _1(r){return r*_l}function x1(r){return r*wl}function S1(r){return r>0&&Number.isInteger(r)&&2**Math.round(Math.log2(r))===r}function M1(r){return Math.pow(2,Math.ceil(Math.log(r)/Math.LN2))}function y1(r){return Math.pow(2,Math.floor(Math.log(r)/Math.LN2))}function b1(r,t,n,a,o){const c=Math.cos,u=Math.sin,h=c(n/2),m=u(n/2),p=c((t+a)/2),g=u((t+a)/2),_=c((t-a)/2),v=u((t-a)/2),x=c((a-t)/2),b=u((a-t)/2);switch(o){case"XYX":r.set(h*g,m*_,m*v,h*p);break;case"YZY":r.set(m*v,h*g,m*_,h*p);break;case"ZXZ":r.set(m*_,m*v,h*g,h*p);break;case"XZX":r.set(h*g,m*b,m*x,h*p);break;case"YXY":r.set(m*x,h*g,m*b,h*p);break;case"ZYZ":r.set(m*b,m*x,h*g,h*p);break;default:ve("MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: "+o)}}function ao(r,t){switch(t.constructor){case Float32Array:return r;case Uint32Array:return r/4294967295;case Uint16Array:return r/65535;case Uint8Array:case Uint8ClampedArray:return r/255;case Int32Array:return Math.max(r/2147483647,-1);case Int16Array:return Math.max(r/32767,-1);case Int8Array:return Math.max(r/127,-1);default:throw new Error("THREE.MathUtils: Invalid component type.")}}function si(r,t){switch(t.constructor){case Float32Array:return r;case Uint32Array:return Math.round(r*4294967295);case Uint16Array:return Math.round(r*65535);case Uint8Array:case Uint8ClampedArray:return Math.round(r*255);case Int32Array:return Math.round(r*2147483647);case Int16Array:return Math.round(r*32767);case Int8Array:return Math.round(r*127);default:throw new Error("THREE.MathUtils: Invalid component type.")}}const Qs={DEG2RAD:_l,RAD2DEG:wl,generateUUID:or,clamp:Ue,euclideanModulo:qp,mapLinear:l1,inverseLerp:c1,lerp:xl,damp:u1,pingpong:f1,smoothstep:h1,smootherstep:d1,randInt:p1,randFloat:m1,randFloatSpread:g1,seededRandom:v1,degToRad:_1,radToDeg:x1,isPowerOfTwo:S1,ceilPowerOfTwo:M1,floorPowerOfTwo:y1,setQuaternionFromProperEuler:b1,normalize:si,denormalize:ao},im=class im{constructor(t=0,n=0){this.x=t,this.y=n}get width(){return this.x}set width(t){this.x=t}get height(){return this.y}set height(t){this.y=t}set(t,n){return this.x=t,this.y=n,this}setScalar(t){return this.x=t,this.y=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setComponent(t,n){switch(t){case 0:this.x=n;break;case 1:this.y=n;break;default:throw new Error("THREE.Vector2: index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;default:throw new Error("THREE.Vector2: index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y)}copy(t){return this.x=t.x,this.y=t.y,this}add(t){return this.x+=t.x,this.y+=t.y,this}addScalar(t){return this.x+=t,this.y+=t,this}addVectors(t,n){return this.x=t.x+n.x,this.y=t.y+n.y,this}addScaledVector(t,n){return this.x+=t.x*n,this.y+=t.y*n,this}sub(t){return this.x-=t.x,this.y-=t.y,this}subScalar(t){return this.x-=t,this.y-=t,this}subVectors(t,n){return this.x=t.x-n.x,this.y=t.y-n.y,this}multiply(t){return this.x*=t.x,this.y*=t.y,this}multiplyScalar(t){return this.x*=t,this.y*=t,this}divide(t){return this.x/=t.x,this.y/=t.y,this}divideScalar(t){return this.multiplyScalar(1/t)}applyMatrix3(t){const n=this.x,a=this.y,o=t.elements;return this.x=o[0]*n+o[3]*a+o[6],this.y=o[1]*n+o[4]*a+o[7],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this}clamp(t,n){return this.x=Ue(this.x,t.x,n.x),this.y=Ue(this.y,t.y,n.y),this}clampScalar(t,n){return this.x=Ue(this.x,t,n),this.y=Ue(this.y,t,n),this}clampLength(t,n){const a=this.length();return this.divideScalar(a||1).multiplyScalar(Ue(a,t,n))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(t){return this.x*t.x+this.y*t.y}cross(t){return this.x*t.y-this.y*t.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(t){const n=Math.sqrt(this.lengthSq()*t.lengthSq());if(n===0)return Math.PI/2;const a=this.dot(t)/n;return Math.acos(Ue(a,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){const n=this.x-t.x,a=this.y-t.y;return n*n+a*a}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,n){return this.x+=(t.x-this.x)*n,this.y+=(t.y-this.y)*n,this}lerpVectors(t,n,a){return this.x=t.x+(n.x-t.x)*a,this.y=t.y+(n.y-t.y)*a,this}equals(t){return t.x===this.x&&t.y===this.y}fromArray(t,n=0){return this.x=t[n],this.y=t[n+1],this}toArray(t=[],n=0){return t[n]=this.x,t[n+1]=this.y,t}fromBufferAttribute(t,n){return this.x=t.getX(n),this.y=t.getY(n),this}rotateAround(t,n){const a=Math.cos(n),o=Math.sin(n),c=this.x-t.x,u=this.y-t.y;return this.x=c*a-u*o+t.x,this.y=c*o+u*a+t.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}};im.prototype.isVector2=!0;let Lt=im;class Ai{constructor(t=0,n=0,a=0,o=1){this.isQuaternion=!0,this._x=t,this._y=n,this._z=a,this._w=o}static slerpFlat(t,n,a,o,c,u,h){let m=a[o+0],p=a[o+1],g=a[o+2],_=a[o+3],v=c[u+0],x=c[u+1],b=c[u+2],R=c[u+3];if(_!==R||m!==v||p!==x||g!==b){let M=m*v+p*x+g*b+_*R;M<0&&(v=-v,x=-x,b=-b,R=-R,M=-M);let S=1-h;if(M<.9995){const C=Math.acos(M),O=Math.sin(C);S=Math.sin(S*C)/O,h=Math.sin(h*C)/O,m=m*S+v*h,p=p*S+x*h,g=g*S+b*h,_=_*S+R*h}else{m=m*S+v*h,p=p*S+x*h,g=g*S+b*h,_=_*S+R*h;const C=1/Math.sqrt(m*m+p*p+g*g+_*_);m*=C,p*=C,g*=C,_*=C}}t[n]=m,t[n+1]=p,t[n+2]=g,t[n+3]=_}static multiplyQuaternionsFlat(t,n,a,o,c,u){const h=a[o],m=a[o+1],p=a[o+2],g=a[o+3],_=c[u],v=c[u+1],x=c[u+2],b=c[u+3];return t[n]=h*b+g*_+m*x-p*v,t[n+1]=m*b+g*v+p*_-h*x,t[n+2]=p*b+g*x+h*v-m*_,t[n+3]=g*b-h*_-m*v-p*x,t}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get w(){return this._w}set w(t){this._w=t,this._onChangeCallback()}set(t,n,a,o){return this._x=t,this._y=n,this._z=a,this._w=o,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(t){return this._x=t.x,this._y=t.y,this._z=t.z,this._w=t.w,this._onChangeCallback(),this}setFromEuler(t,n=!0){const a=t._x,o=t._y,c=t._z,u=t._order,h=Math.cos,m=Math.sin,p=h(a/2),g=h(o/2),_=h(c/2),v=m(a/2),x=m(o/2),b=m(c/2);switch(u){case"XYZ":this._x=v*g*_+p*x*b,this._y=p*x*_-v*g*b,this._z=p*g*b+v*x*_,this._w=p*g*_-v*x*b;break;case"YXZ":this._x=v*g*_+p*x*b,this._y=p*x*_-v*g*b,this._z=p*g*b-v*x*_,this._w=p*g*_+v*x*b;break;case"ZXY":this._x=v*g*_-p*x*b,this._y=p*x*_+v*g*b,this._z=p*g*b+v*x*_,this._w=p*g*_-v*x*b;break;case"ZYX":this._x=v*g*_-p*x*b,this._y=p*x*_+v*g*b,this._z=p*g*b-v*x*_,this._w=p*g*_+v*x*b;break;case"YZX":this._x=v*g*_+p*x*b,this._y=p*x*_+v*g*b,this._z=p*g*b-v*x*_,this._w=p*g*_-v*x*b;break;case"XZY":this._x=v*g*_-p*x*b,this._y=p*x*_-v*g*b,this._z=p*g*b+v*x*_,this._w=p*g*_+v*x*b;break;default:ve("Quaternion: .setFromEuler() encountered an unknown order: "+u)}return n===!0&&this._onChangeCallback(),this}setFromAxisAngle(t,n){const a=n/2,o=Math.sin(a);return this._x=t.x*o,this._y=t.y*o,this._z=t.z*o,this._w=Math.cos(a),this._onChangeCallback(),this}setFromRotationMatrix(t){const n=t.elements,a=n[0],o=n[4],c=n[8],u=n[1],h=n[5],m=n[9],p=n[2],g=n[6],_=n[10],v=a+h+_;if(v>0){const x=.5/Math.sqrt(v+1);this._w=.25/x,this._x=(g-m)*x,this._y=(c-p)*x,this._z=(u-o)*x}else if(a>h&&a>_){const x=2*Math.sqrt(1+a-h-_);this._w=(g-m)/x,this._x=.25*x,this._y=(o+u)/x,this._z=(c+p)/x}else if(h>_){const x=2*Math.sqrt(1+h-a-_);this._w=(c-p)/x,this._x=(o+u)/x,this._y=.25*x,this._z=(m+g)/x}else{const x=2*Math.sqrt(1+_-a-h);this._w=(u-o)/x,this._x=(c+p)/x,this._y=(m+g)/x,this._z=.25*x}return this._onChangeCallback(),this}setFromUnitVectors(t,n){let a=t.dot(n)+1;return a<1e-8?(a=0,Math.abs(t.x)>Math.abs(t.z)?(this._x=-t.y,this._y=t.x,this._z=0,this._w=a):(this._x=0,this._y=-t.z,this._z=t.y,this._w=a)):(this._x=t.y*n.z-t.z*n.y,this._y=t.z*n.x-t.x*n.z,this._z=t.x*n.y-t.y*n.x,this._w=a),this.normalize()}angleTo(t){return 2*Math.acos(Math.abs(Ue(this.dot(t),-1,1)))}rotateTowards(t,n){const a=this.angleTo(t);if(a===0)return this;const o=Math.min(1,n/a);return this.slerp(t,o),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(t){return this._x*t._x+this._y*t._y+this._z*t._z+this._w*t._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let t=this.length();return t===0?(this._x=0,this._y=0,this._z=0,this._w=1):(t=1/t,this._x=this._x*t,this._y=this._y*t,this._z=this._z*t,this._w=this._w*t),this._onChangeCallback(),this}multiply(t){return this.multiplyQuaternions(this,t)}premultiply(t){return this.multiplyQuaternions(t,this)}multiplyQuaternions(t,n){const a=t._x,o=t._y,c=t._z,u=t._w,h=n._x,m=n._y,p=n._z,g=n._w;return this._x=a*g+u*h+o*p-c*m,this._y=o*g+u*m+c*h-a*p,this._z=c*g+u*p+a*m-o*h,this._w=u*g-a*h-o*m-c*p,this._onChangeCallback(),this}slerp(t,n){let a=t._x,o=t._y,c=t._z,u=t._w,h=this.dot(t);h<0&&(a=-a,o=-o,c=-c,u=-u,h=-h);let m=1-n;if(h<.9995){const p=Math.acos(h),g=Math.sin(p);m=Math.sin(m*p)/g,n=Math.sin(n*p)/g,this._x=this._x*m+a*n,this._y=this._y*m+o*n,this._z=this._z*m+c*n,this._w=this._w*m+u*n,this._onChangeCallback()}else this._x=this._x*m+a*n,this._y=this._y*m+o*n,this._z=this._z*m+c*n,this._w=this._w*m+u*n,this.normalize();return this}slerpQuaternions(t,n,a){return this.copy(t).slerp(n,a)}random(){const t=2*Math.PI*Math.random(),n=2*Math.PI*Math.random(),a=Math.random(),o=Math.sqrt(1-a),c=Math.sqrt(a);return this.set(o*Math.sin(t),o*Math.cos(t),c*Math.sin(n),c*Math.cos(n))}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._w===this._w}fromArray(t,n=0){return this._x=t[n],this._y=t[n+1],this._z=t[n+2],this._w=t[n+3],this._onChangeCallback(),this}toArray(t=[],n=0){return t[n]=this._x,t[n+1]=this._y,t[n+2]=this._z,t[n+3]=this._w,t}fromBufferAttribute(t,n){return this._x=t.getX(n),this._y=t.getY(n),this._z=t.getZ(n),this._w=t.getW(n),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}const am=class am{constructor(t=0,n=0,a=0){this.x=t,this.y=n,this.z=a}set(t,n,a){return a===void 0&&(a=this.z),this.x=t,this.y=n,this.z=a,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setComponent(t,n){switch(t){case 0:this.x=n;break;case 1:this.y=n;break;case 2:this.z=n;break;default:throw new Error("THREE.Vector3: index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("THREE.Vector3: index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this}addVectors(t,n){return this.x=t.x+n.x,this.y=t.y+n.y,this.z=t.z+n.z,this}addScaledVector(t,n){return this.x+=t.x*n,this.y+=t.y*n,this.z+=t.z*n,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this}subVectors(t,n){return this.x=t.x-n.x,this.y=t.y-n.y,this.z=t.z-n.z,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this}multiplyVectors(t,n){return this.x=t.x*n.x,this.y=t.y*n.y,this.z=t.z*n.z,this}applyEuler(t){return this.applyQuaternion(a_.setFromEuler(t))}applyAxisAngle(t,n){return this.applyQuaternion(a_.setFromAxisAngle(t,n))}applyMatrix3(t){const n=this.x,a=this.y,o=this.z,c=t.elements;return this.x=c[0]*n+c[3]*a+c[6]*o,this.y=c[1]*n+c[4]*a+c[7]*o,this.z=c[2]*n+c[5]*a+c[8]*o,this}applyNormalMatrix(t){return this.applyMatrix3(t).normalize()}applyMatrix4(t){const n=this.x,a=this.y,o=this.z,c=t.elements,u=1/(c[3]*n+c[7]*a+c[11]*o+c[15]);return this.x=(c[0]*n+c[4]*a+c[8]*o+c[12])*u,this.y=(c[1]*n+c[5]*a+c[9]*o+c[13])*u,this.z=(c[2]*n+c[6]*a+c[10]*o+c[14])*u,this}applyQuaternion(t){const n=this.x,a=this.y,o=this.z,c=t.x,u=t.y,h=t.z,m=t.w,p=2*(u*o-h*a),g=2*(h*n-c*o),_=2*(c*a-u*n);return this.x=n+m*p+u*_-h*g,this.y=a+m*g+h*p-c*_,this.z=o+m*_+c*g-u*p,this}project(t){return this.applyMatrix4(t.matrixWorldInverse).applyMatrix4(t.projectionMatrix)}unproject(t){return this.applyMatrix4(t.projectionMatrixInverse).applyMatrix4(t.matrixWorld)}transformDirection(t){const n=this.x,a=this.y,o=this.z,c=t.elements;return this.x=c[0]*n+c[4]*a+c[8]*o,this.y=c[1]*n+c[5]*a+c[9]*o,this.z=c[2]*n+c[6]*a+c[10]*o,this.normalize()}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this}divideScalar(t){return this.multiplyScalar(1/t)}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this}clamp(t,n){return this.x=Ue(this.x,t.x,n.x),this.y=Ue(this.y,t.y,n.y),this.z=Ue(this.z,t.z,n.z),this}clampScalar(t,n){return this.x=Ue(this.x,t,n),this.y=Ue(this.y,t,n),this.z=Ue(this.z,t,n),this}clampLength(t,n){const a=this.length();return this.divideScalar(a||1).multiplyScalar(Ue(a,t,n))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,n){return this.x+=(t.x-this.x)*n,this.y+=(t.y-this.y)*n,this.z+=(t.z-this.z)*n,this}lerpVectors(t,n,a){return this.x=t.x+(n.x-t.x)*a,this.y=t.y+(n.y-t.y)*a,this.z=t.z+(n.z-t.z)*a,this}cross(t){return this.crossVectors(this,t)}crossVectors(t,n){const a=t.x,o=t.y,c=t.z,u=n.x,h=n.y,m=n.z;return this.x=o*m-c*h,this.y=c*u-a*m,this.z=a*h-o*u,this}projectOnVector(t){const n=t.lengthSq();if(n===0)return this.set(0,0,0);const a=t.dot(this)/n;return this.copy(t).multiplyScalar(a)}projectOnPlane(t){return rd.copy(this).projectOnVector(t),this.sub(rd)}reflect(t){return this.sub(rd.copy(t).multiplyScalar(2*this.dot(t)))}angleTo(t){const n=Math.sqrt(this.lengthSq()*t.lengthSq());if(n===0)return Math.PI/2;const a=this.dot(t)/n;return Math.acos(Ue(a,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){const n=this.x-t.x,a=this.y-t.y,o=this.z-t.z;return n*n+a*a+o*o}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)+Math.abs(this.z-t.z)}setFromSpherical(t){return this.setFromSphericalCoords(t.radius,t.phi,t.theta)}setFromSphericalCoords(t,n,a){const o=Math.sin(n)*t;return this.x=o*Math.sin(a),this.y=Math.cos(n)*t,this.z=o*Math.cos(a),this}setFromCylindrical(t){return this.setFromCylindricalCoords(t.radius,t.theta,t.y)}setFromCylindricalCoords(t,n,a){return this.x=t*Math.sin(n),this.y=a,this.z=t*Math.cos(n),this}setFromMatrixPosition(t){const n=t.elements;return this.x=n[12],this.y=n[13],this.z=n[14],this}setFromMatrixScale(t){const n=this.setFromMatrixColumn(t,0).length(),a=this.setFromMatrixColumn(t,1).length(),o=this.setFromMatrixColumn(t,2).length();return this.x=n,this.y=a,this.z=o,this}setFromMatrixColumn(t,n){return this.fromArray(t.elements,n*4)}setFromMatrix3Column(t,n){return this.fromArray(t.elements,n*3)}setFromEuler(t){return this.x=t._x,this.y=t._y,this.z=t._z,this}setFromColor(t){return this.x=t.r,this.y=t.g,this.z=t.b,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z}fromArray(t,n=0){return this.x=t[n],this.y=t[n+1],this.z=t[n+2],this}toArray(t=[],n=0){return t[n]=this.x,t[n+1]=this.y,t[n+2]=this.z,t}fromBufferAttribute(t,n){return this.x=t.getX(n),this.y=t.getY(n),this.z=t.getZ(n),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const t=Math.random()*Math.PI*2,n=Math.random()*2-1,a=Math.sqrt(1-n*n);return this.x=a*Math.cos(t),this.y=n,this.z=a*Math.sin(t),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}};am.prototype.isVector3=!0;let B=am;const rd=new B,a_=new Ai,sm=class sm{constructor(t,n,a,o,c,u,h,m,p){this.elements=[1,0,0,0,1,0,0,0,1],t!==void 0&&this.set(t,n,a,o,c,u,h,m,p)}set(t,n,a,o,c,u,h,m,p){const g=this.elements;return g[0]=t,g[1]=o,g[2]=h,g[3]=n,g[4]=c,g[5]=m,g[6]=a,g[7]=u,g[8]=p,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(t){const n=this.elements,a=t.elements;return n[0]=a[0],n[1]=a[1],n[2]=a[2],n[3]=a[3],n[4]=a[4],n[5]=a[5],n[6]=a[6],n[7]=a[7],n[8]=a[8],this}extractBasis(t,n,a){return t.setFromMatrix3Column(this,0),n.setFromMatrix3Column(this,1),a.setFromMatrix3Column(this,2),this}setFromMatrix4(t){const n=t.elements;return this.set(n[0],n[4],n[8],n[1],n[5],n[9],n[2],n[6],n[10]),this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,n){const a=t.elements,o=n.elements,c=this.elements,u=a[0],h=a[3],m=a[6],p=a[1],g=a[4],_=a[7],v=a[2],x=a[5],b=a[8],R=o[0],M=o[3],S=o[6],C=o[1],O=o[4],E=o[7],U=o[2],L=o[5],P=o[8];return c[0]=u*R+h*C+m*U,c[3]=u*M+h*O+m*L,c[6]=u*S+h*E+m*P,c[1]=p*R+g*C+_*U,c[4]=p*M+g*O+_*L,c[7]=p*S+g*E+_*P,c[2]=v*R+x*C+b*U,c[5]=v*M+x*O+b*L,c[8]=v*S+x*E+b*P,this}multiplyScalar(t){const n=this.elements;return n[0]*=t,n[3]*=t,n[6]*=t,n[1]*=t,n[4]*=t,n[7]*=t,n[2]*=t,n[5]*=t,n[8]*=t,this}determinant(){const t=this.elements,n=t[0],a=t[1],o=t[2],c=t[3],u=t[4],h=t[5],m=t[6],p=t[7],g=t[8];return n*u*g-n*h*p-a*c*g+a*h*m+o*c*p-o*u*m}invert(){const t=this.elements,n=t[0],a=t[1],o=t[2],c=t[3],u=t[4],h=t[5],m=t[6],p=t[7],g=t[8],_=g*u-h*p,v=h*m-g*c,x=p*c-u*m,b=n*_+a*v+o*x;if(b===0)return this.set(0,0,0,0,0,0,0,0,0);const R=1/b;return t[0]=_*R,t[1]=(o*p-g*a)*R,t[2]=(h*a-o*u)*R,t[3]=v*R,t[4]=(g*n-o*m)*R,t[5]=(o*c-h*n)*R,t[6]=x*R,t[7]=(a*m-p*n)*R,t[8]=(u*n-a*c)*R,this}transpose(){let t;const n=this.elements;return t=n[1],n[1]=n[3],n[3]=t,t=n[2],n[2]=n[6],n[6]=t,t=n[5],n[5]=n[7],n[7]=t,this}getNormalMatrix(t){return this.setFromMatrix4(t).invert().transpose()}transposeIntoArray(t){const n=this.elements;return t[0]=n[0],t[1]=n[3],t[2]=n[6],t[3]=n[1],t[4]=n[4],t[5]=n[7],t[6]=n[2],t[7]=n[5],t[8]=n[8],this}setUvTransform(t,n,a,o,c,u,h){const m=Math.cos(c),p=Math.sin(c);return this.set(a*m,a*p,-a*(m*u+p*h)+u+t,-o*p,o*m,-o*(-p*u+m*h)+h+n,0,0,1),this}scale(t,n){return ro("Matrix3: .scale() is deprecated. Use .makeScale() instead."),this.premultiply(od.makeScale(t,n)),this}rotate(t){return ro("Matrix3: .rotate() is deprecated. Use .makeRotation() instead."),this.premultiply(od.makeRotation(-t)),this}translate(t,n){return ro("Matrix3: .translate() is deprecated. Use .makeTranslation() instead."),this.premultiply(od.makeTranslation(t,n)),this}makeTranslation(t,n){return t.isVector2?this.set(1,0,t.x,0,1,t.y,0,0,1):this.set(1,0,t,0,1,n,0,0,1),this}makeRotation(t){const n=Math.cos(t),a=Math.sin(t);return this.set(n,-a,0,a,n,0,0,0,1),this}makeScale(t,n){return this.set(t,0,0,0,n,0,0,0,1),this}equals(t){const n=this.elements,a=t.elements;for(let o=0;o<9;o++)if(n[o]!==a[o])return!1;return!0}fromArray(t,n=0){for(let a=0;a<9;a++)this.elements[a]=t[a+n];return this}toArray(t=[],n=0){const a=this.elements;return t[n]=a[0],t[n+1]=a[1],t[n+2]=a[2],t[n+3]=a[3],t[n+4]=a[4],t[n+5]=a[5],t[n+6]=a[6],t[n+7]=a[7],t[n+8]=a[8],t}clone(){return new this.constructor().fromArray(this.elements)}};sm.prototype.isMatrix3=!0;let ye=sm;const od=new ye,s_=new ye().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),r_=new ye().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function E1(){const r={enabled:!0,workingColorSpace:Ru,spaces:{},convert:function(o,c,u){return this.enabled===!1||c===u||!c||!u||(this.spaces[c].transfer===nn&&(o.r=Ga(o.r),o.g=Ga(o.g),o.b=Ga(o.b)),this.spaces[c].primaries!==this.spaces[u].primaries&&(o.applyMatrix3(this.spaces[c].toXYZ),o.applyMatrix3(this.spaces[u].fromXYZ)),this.spaces[u].transfer===nn&&(o.r=oo(o.r),o.g=oo(o.g),o.b=oo(o.b))),o},workingToColorSpace:function(o,c){return this.convert(o,this.workingColorSpace,c)},colorSpaceToWorking:function(o,c){return this.convert(o,c,this.workingColorSpace)},getPrimaries:function(o){return this.spaces[o].primaries},getTransfer:function(o){return o===Ia?Cu:this.spaces[o].transfer},getToneMappingMode:function(o){return this.spaces[o].outputColorSpaceConfig.toneMappingMode||"standard"},getLuminanceCoefficients:function(o,c=this.workingColorSpace){return o.fromArray(this.spaces[c].luminanceCoefficients)},define:function(o){Object.assign(this.spaces,o)},_getMatrix:function(o,c,u){return o.copy(this.spaces[c].toXYZ).multiply(this.spaces[u].fromXYZ)},_getDrawingBufferColorSpace:function(o){return this.spaces[o].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(o=this.workingColorSpace){return this.spaces[o].workingColorSpaceConfig.unpackColorSpace},fromWorkingColorSpace:function(o,c){return ro("ColorManagement: .fromWorkingColorSpace() has been renamed to .workingToColorSpace()."),r.workingToColorSpace(o,c)},toWorkingColorSpace:function(o,c){return ro("ColorManagement: .toWorkingColorSpace() has been renamed to .colorSpaceToWorking()."),r.colorSpaceToWorking(o,c)}},t=[.64,.33,.3,.6,.15,.06],n=[.2126,.7152,.0722],a=[.3127,.329];return r.define({[Ru]:{primaries:t,whitePoint:a,transfer:Cu,toXYZ:s_,fromXYZ:r_,luminanceCoefficients:n,workingColorSpaceConfig:{unpackColorSpace:In},outputColorSpaceConfig:{drawingBufferColorSpace:In}},[In]:{primaries:t,whitePoint:a,transfer:nn,toXYZ:s_,fromXYZ:r_,luminanceCoefficients:n,outputColorSpaceConfig:{drawingBufferColorSpace:In}}}),r}const Ve=E1();function Ga(r){return r<.04045?r*.0773993808:Math.pow(r*.9478672986+.0521327014,2.4)}function oo(r){return r<.0031308?r*12.92:1.055*Math.pow(r,.41666)-.055}let Vr;class T1{static getDataURL(t,n="image/png"){if(/^data:/i.test(t.src)||typeof HTMLCanvasElement>"u")return t.src;let a;if(t instanceof HTMLCanvasElement)a=t;else{Vr===void 0&&(Vr=Du("canvas")),Vr.width=t.width,Vr.height=t.height;const o=Vr.getContext("2d");t instanceof ImageData?o.putImageData(t,0,0):o.drawImage(t,0,0,t.width,t.height),a=Vr}return a.toDataURL(n)}static sRGBToLinear(t){if(typeof HTMLImageElement<"u"&&t instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&t instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&t instanceof ImageBitmap){const n=Du("canvas");n.width=t.width,n.height=t.height;const a=n.getContext("2d");a.drawImage(t,0,0,t.width,t.height);const o=a.getImageData(0,0,t.width,t.height),c=o.data;for(let u=0;u<c.length;u++)c[u]=Ga(c[u]/255)*255;return a.putImageData(o,0,0),n}else if(t.data){const n=t.data.slice(0);for(let a=0;a<n.length;a++)n instanceof Uint8Array||n instanceof Uint8ClampedArray?n[a]=Math.floor(Ga(n[a]/255)*255):n[a]=Ga(n[a]);return{data:n,width:t.width,height:t.height}}else return ve("ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),t}}let A1=0;class Yp{constructor(t=null){this.isTextureSource=!0,Object.defineProperty(this,"id",{value:A1++}),this.uuid=or(),this.data=t,this.dataReady=!0,this.version=0}getSize(t){const n=this.data;return typeof HTMLVideoElement<"u"&&n instanceof HTMLVideoElement?t.set(n.videoWidth,n.videoHeight,0):typeof VideoFrame<"u"&&n instanceof VideoFrame?t.set(n.displayWidth,n.displayHeight,0):n!==null?t.set(n.width,n.height,n.depth||0):t.set(0,0,0),t}set needsUpdate(t){t===!0&&this.version++}toJSON(t){const n=t===void 0||typeof t=="string";if(!n&&t.images[this.uuid]!==void 0)return t.images[this.uuid];const a={uuid:this.uuid,url:""},o=this.data;if(o!==null){let c;if(Array.isArray(o)){c=[];for(let u=0,h=o.length;u<h;u++)o[u].isDataTexture?c.push(ld(o[u].image)):c.push(ld(o[u]))}else c=ld(o);a.url=c}return n||(t.images[this.uuid]=a),a}}function ld(r){return typeof HTMLImageElement<"u"&&r instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&r instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&r instanceof ImageBitmap?T1.getDataURL(r):r.data?{data:Array.from(r.data),width:r.width,height:r.height,type:r.data.constructor.name}:(ve("Texture: Unable to serialize Texture."),{})}let w1=0;const cd=new B;class Wn extends rr{constructor(t=Wn.DEFAULT_IMAGE,n=Wn.DEFAULT_MAPPING,a=Ba,o=Ba,c=Xn,u=Ks,h=Qi,m=Ti,p=Wn.DEFAULT_ANISOTROPY,g=Ia){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:w1++}),this.uuid=or(),this.name="",this.source=new Yp(t),this.mipmaps=[],this.mapping=n,this.channel=0,this.wrapS=a,this.wrapT=o,this.magFilter=c,this.minFilter=u,this.anisotropy=p,this.format=h,this.internalFormat=null,this.type=m,this.offset=new Lt(0,0),this.repeat=new Lt(1,1),this.center=new Lt(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new ye,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=g,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=!!(t&&t.depth&&t.depth>1),this.pmremVersion=0,this.normalized=!1}get width(){return this.source.getSize(cd).x}get height(){return this.source.getSize(cd).y}get depth(){return this.source.getSize(cd).z}get image(){return this.source.data}set image(t){this.source.data=t}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}addUpdateRange(t,n){this.updateRanges.push({start:t,count:n})}clearUpdateRanges(){this.updateRanges.length=0}clone(){return new this.constructor().copy(this)}copy(t){return this.name=t.name,this.source=t.source,this.mipmaps=t.mipmaps.slice(0),this.mapping=t.mapping,this.channel=t.channel,this.wrapS=t.wrapS,this.wrapT=t.wrapT,this.magFilter=t.magFilter,this.minFilter=t.minFilter,this.anisotropy=t.anisotropy,this.format=t.format,this.internalFormat=t.internalFormat,this.type=t.type,this.normalized=t.normalized,this.offset.copy(t.offset),this.repeat.copy(t.repeat),this.center.copy(t.center),this.rotation=t.rotation,this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrix.copy(t.matrix),this.generateMipmaps=t.generateMipmaps,this.premultiplyAlpha=t.premultiplyAlpha,this.flipY=t.flipY,this.unpackAlignment=t.unpackAlignment,this.colorSpace=t.colorSpace,this.renderTarget=t.renderTarget,this.isRenderTargetTexture=t.isRenderTargetTexture,this.isArrayTexture=t.isArrayTexture,this.userData=JSON.parse(JSON.stringify(t.userData)),this.needsUpdate=!0,this}setValues(t){for(const n in t){const a=t[n];if(a===void 0){ve(`Texture.setValues(): parameter '${n}' has value of undefined.`);continue}const o=this[n];if(o===void 0){ve(`Texture.setValues(): property '${n}' does not exist.`);continue}o&&a&&o.isVector2&&a.isVector2||o&&a&&o.isVector3&&a.isVector3||o&&a&&o.isMatrix3&&a.isMatrix3?o.copy(a):this[n]=a}}toJSON(t){const n=t===void 0||typeof t=="string";if(!n&&t.textures[this.uuid]!==void 0)return t.textures[this.uuid];const a={metadata:{version:4.7,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(t).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,normalized:this.normalized,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(a.userData=this.userData),n||(t.textures[this.uuid]=a),a}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(t){if(this.mapping!==Tx)return t;if(t.applyMatrix3(this.matrix),t.x<0||t.x>1)switch(this.wrapS){case Va:t.x=t.x-Math.floor(t.x);break;case Ba:t.x=t.x<0?0:1;break;case Yd:Math.abs(Math.floor(t.x)%2)===1?t.x=Math.ceil(t.x)-t.x:t.x=t.x-Math.floor(t.x);break}if(t.y<0||t.y>1)switch(this.wrapT){case Va:t.y=t.y-Math.floor(t.y);break;case Ba:t.y=t.y<0?0:1;break;case Yd:Math.abs(Math.floor(t.y)%2)===1?t.y=Math.ceil(t.y)-t.y:t.y=t.y-Math.floor(t.y);break}return this.flipY&&(t.y=1-t.y),t}set needsUpdate(t){t===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(t){t===!0&&this.pmremVersion++}}Wn.DEFAULT_IMAGE=null;Wn.DEFAULT_MAPPING=Tx;Wn.DEFAULT_ANISOTROPY=1;const rm=class rm{constructor(t=0,n=0,a=0,o=1){this.x=t,this.y=n,this.z=a,this.w=o}get width(){return this.z}set width(t){this.z=t}get height(){return this.w}set height(t){this.w=t}set(t,n,a,o){return this.x=t,this.y=n,this.z=a,this.w=o,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this.w=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setW(t){return this.w=t,this}setComponent(t,n){switch(t){case 0:this.x=n;break;case 1:this.y=n;break;case 2:this.z=n;break;case 3:this.w=n;break;default:throw new Error("THREE.Vector4: index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("THREE.Vector4: index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this.w=t.w!==void 0?t.w:1,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this.w+=t.w,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this.w+=t,this}addVectors(t,n){return this.x=t.x+n.x,this.y=t.y+n.y,this.z=t.z+n.z,this.w=t.w+n.w,this}addScaledVector(t,n){return this.x+=t.x*n,this.y+=t.y*n,this.z+=t.z*n,this.w+=t.w*n,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this.w-=t.w,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this.w-=t,this}subVectors(t,n){return this.x=t.x-n.x,this.y=t.y-n.y,this.z=t.z-n.z,this.w=t.w-n.w,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this.w*=t.w,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this.w*=t,this}applyMatrix4(t){const n=this.x,a=this.y,o=this.z,c=this.w,u=t.elements;return this.x=u[0]*n+u[4]*a+u[8]*o+u[12]*c,this.y=u[1]*n+u[5]*a+u[9]*o+u[13]*c,this.z=u[2]*n+u[6]*a+u[10]*o+u[14]*c,this.w=u[3]*n+u[7]*a+u[11]*o+u[15]*c,this}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this.w/=t.w,this}divideScalar(t){return this.multiplyScalar(1/t)}setAxisAngleFromQuaternion(t){this.w=2*Math.acos(t.w);const n=Math.sqrt(1-t.w*t.w);return n<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=t.x/n,this.y=t.y/n,this.z=t.z/n),this}setAxisAngleFromRotationMatrix(t){let n,a,o,c;const m=t.elements,p=m[0],g=m[4],_=m[8],v=m[1],x=m[5],b=m[9],R=m[2],M=m[6],S=m[10];if(Math.abs(g-v)<.01&&Math.abs(_-R)<.01&&Math.abs(b-M)<.01){if(Math.abs(g+v)<.1&&Math.abs(_+R)<.1&&Math.abs(b+M)<.1&&Math.abs(p+x+S-3)<.1)return this.set(1,0,0,0),this;n=Math.PI;const O=(p+1)/2,E=(x+1)/2,U=(S+1)/2,L=(g+v)/4,P=(_+R)/4,T=(b+M)/4;return O>E&&O>U?O<.01?(a=0,o=.707106781,c=.707106781):(a=Math.sqrt(O),o=L/a,c=P/a):E>U?E<.01?(a=.707106781,o=0,c=.707106781):(o=Math.sqrt(E),a=L/o,c=T/o):U<.01?(a=.707106781,o=.707106781,c=0):(c=Math.sqrt(U),a=P/c,o=T/c),this.set(a,o,c,n),this}let C=Math.sqrt((M-b)*(M-b)+(_-R)*(_-R)+(v-g)*(v-g));return Math.abs(C)<.001&&(C=1),this.x=(M-b)/C,this.y=(_-R)/C,this.z=(v-g)/C,this.w=Math.acos((p+x+S-1)/2),this}setFromMatrixPosition(t){const n=t.elements;return this.x=n[12],this.y=n[13],this.z=n[14],this.w=n[15],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this.w=Math.min(this.w,t.w),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this.w=Math.max(this.w,t.w),this}clamp(t,n){return this.x=Ue(this.x,t.x,n.x),this.y=Ue(this.y,t.y,n.y),this.z=Ue(this.z,t.z,n.z),this.w=Ue(this.w,t.w,n.w),this}clampScalar(t,n){return this.x=Ue(this.x,t,n),this.y=Ue(this.y,t,n),this.z=Ue(this.z,t,n),this.w=Ue(this.w,t,n),this}clampLength(t,n){const a=this.length();return this.divideScalar(a||1).multiplyScalar(Ue(a,t,n))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z+this.w*t.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,n){return this.x+=(t.x-this.x)*n,this.y+=(t.y-this.y)*n,this.z+=(t.z-this.z)*n,this.w+=(t.w-this.w)*n,this}lerpVectors(t,n,a){return this.x=t.x+(n.x-t.x)*a,this.y=t.y+(n.y-t.y)*a,this.z=t.z+(n.z-t.z)*a,this.w=t.w+(n.w-t.w)*a,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z&&t.w===this.w}fromArray(t,n=0){return this.x=t[n],this.y=t[n+1],this.z=t[n+2],this.w=t[n+3],this}toArray(t=[],n=0){return t[n]=this.x,t[n+1]=this.y,t[n+2]=this.z,t[n+3]=this.w,t}fromBufferAttribute(t,n){return this.x=t.getX(n),this.y=t.getY(n),this.z=t.getZ(n),this.w=t.getW(n),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}};rm.prototype.isVector4=!0;let xn=rm;class R1 extends rr{constructor(t=1,n=1,a={}){super(),a=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:Xn,depthBuffer:!0,stencilBuffer:!1,resolveColorBuffer:!0,resolveDepthBuffer:!0,resolveStencilBuffer:!0,storeMultisampledColorBuffer:!0,storeMultisampledDepthBuffer:!0,storeMultisampledStencilBuffer:!0,depthTexture:null,samples:0,count:1,depth:1,multiview:!1,useArrayDepthTexture:!1},a),this.isRenderTarget=!0,this.width=t,this.height=n,this.depth=a.depth,this.scissor=new xn(0,0,t,n),this.scissorTest=!1,this.viewport=new xn(0,0,t,n),this.textures=[];const o={width:t,height:n,depth:a.depth},c=new Wn(o),u=a.count;for(let h=0;h<u;h++)this.textures[h]=c.clone(),this.textures[h].isRenderTargetTexture=!0,this.textures[h].renderTarget=this;this._setTextureOptions(a),this.depthBuffer=a.depthBuffer,this.stencilBuffer=a.stencilBuffer,this.resolveColorBuffer=a.resolveColorBuffer,this.resolveDepthBuffer=a.resolveDepthBuffer,this.resolveStencilBuffer=a.resolveStencilBuffer,this.storeMultisampledColorBuffer=a.storeMultisampledColorBuffer,this.storeMultisampledDepthBuffer=a.storeMultisampledDepthBuffer,this.storeMultisampledStencilBuffer=a.storeMultisampledStencilBuffer,this._depthTexture=null,this.depthTexture=a.depthTexture,this.samples=a.samples,this.multiview=a.multiview,this.useArrayDepthTexture=a.useArrayDepthTexture}_setTextureOptions(t={}){const n={minFilter:Xn,generateMipmaps:!1,flipY:!1,internalFormat:null};t.mapping!==void 0&&(n.mapping=t.mapping),t.wrapS!==void 0&&(n.wrapS=t.wrapS),t.wrapT!==void 0&&(n.wrapT=t.wrapT),t.wrapR!==void 0&&(n.wrapR=t.wrapR),t.magFilter!==void 0&&(n.magFilter=t.magFilter),t.minFilter!==void 0&&(n.minFilter=t.minFilter),t.format!==void 0&&(n.format=t.format),t.type!==void 0&&(n.type=t.type),t.anisotropy!==void 0&&(n.anisotropy=t.anisotropy),t.colorSpace!==void 0&&(n.colorSpace=t.colorSpace),t.flipY!==void 0&&(n.flipY=t.flipY),t.generateMipmaps!==void 0&&(n.generateMipmaps=t.generateMipmaps),t.internalFormat!==void 0&&(n.internalFormat=t.internalFormat);for(let a=0;a<this.textures.length;a++)this.textures[a].setValues(n)}get texture(){return this.textures[0]}set texture(t){this.textures[0]=t}set depthTexture(t){this._depthTexture!==null&&this._depthTexture.renderTarget===this&&(this._depthTexture.renderTarget=null),t!==null&&t.renderTarget===null&&(t.renderTarget=this),this._depthTexture=t}get depthTexture(){return this._depthTexture}setSize(t,n,a=1){if(this.width!==t||this.height!==n||this.depth!==a){this.width=t,this.height=n,this.depth=a;for(let o=0,c=this.textures.length;o<c;o++)this.textures[o].image.width=t,this.textures[o].image.height=n,this.textures[o].image.depth=a,this.textures[o].isData3DTexture!==!0&&(this.textures[o].isArrayTexture=this.textures[o].image.depth>1);this.dispose()}this.viewport.set(0,0,t,n),this.scissor.set(0,0,t,n)}clone(){return new this.constructor().copy(this)}copy(t){this.width=t.width,this.height=t.height,this.depth=t.depth,this.scissor.copy(t.scissor),this.scissorTest=t.scissorTest,this.viewport.copy(t.viewport),this.textures.length=0;for(let n=0,a=t.textures.length;n<a;n++){this.textures[n]=t.textures[n].clone(),this.textures[n].isRenderTargetTexture=!0,this.textures[n].renderTarget=this;const o=Object.assign({},t.textures[n].image);this.textures[n].source=new Yp(o)}if(this.depthBuffer=t.depthBuffer,this.stencilBuffer=t.stencilBuffer,this.resolveColorBuffer=t.resolveColorBuffer,this.resolveDepthBuffer=t.resolveDepthBuffer,this.resolveStencilBuffer=t.resolveStencilBuffer,this.storeMultisampledColorBuffer=t.storeMultisampledColorBuffer,this.storeMultisampledDepthBuffer=t.storeMultisampledDepthBuffer,this.storeMultisampledStencilBuffer=t.storeMultisampledStencilBuffer,t.depthTexture!==null)if(t.depthTexture.renderTarget===t){const n=t.depthTexture.clone();n.renderTarget=null,this.depthTexture=n}else this.depthTexture=t.depthTexture;return this.samples=t.samples,this.multiview=t.multiview,this.useArrayDepthTexture=t.useArrayDepthTexture,this}dispose(){this.dispatchEvent({type:"dispose"})}}class Hi extends R1{constructor(t=1,n=1,a={}){super(t,n,a),this.isWebGLRenderTarget=!0}}class Ox extends Wn{constructor(t=null,n=1,a=1,o=1){super(null),this.isDataArrayTexture=!0,this.image={data:t,width:n,height:a,depth:o},this.magFilter=Qn,this.minFilter=Qn,this.wrapR=Ba,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}copy(t){return super.copy(t),this.wrapR=t.wrapR,this}addLayerUpdate(t){this.layerUpdates.add(t)}clearLayerUpdates(){this.layerUpdates.clear()}}class C1 extends Wn{constructor(t=null,n=1,a=1,o=1){super(null),this.isData3DTexture=!0,this.image={data:t,width:n,height:a,depth:o},this.magFilter=Qn,this.minFilter=Qn,this.wrapR=Ba,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}copy(t){return super.copy(t),this.wrapR=t.wrapR,this}}const Pu=class Pu{constructor(t,n,a,o,c,u,h,m,p,g,_,v,x,b,R,M){this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],t!==void 0&&this.set(t,n,a,o,c,u,h,m,p,g,_,v,x,b,R,M)}set(t,n,a,o,c,u,h,m,p,g,_,v,x,b,R,M){const S=this.elements;return S[0]=t,S[4]=n,S[8]=a,S[12]=o,S[1]=c,S[5]=u,S[9]=h,S[13]=m,S[2]=p,S[6]=g,S[10]=_,S[14]=v,S[3]=x,S[7]=b,S[11]=R,S[15]=M,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new Pu().fromArray(this.elements)}copy(t){const n=this.elements,a=t.elements;return n[0]=a[0],n[1]=a[1],n[2]=a[2],n[3]=a[3],n[4]=a[4],n[5]=a[5],n[6]=a[6],n[7]=a[7],n[8]=a[8],n[9]=a[9],n[10]=a[10],n[11]=a[11],n[12]=a[12],n[13]=a[13],n[14]=a[14],n[15]=a[15],this}copyPosition(t){const n=this.elements,a=t.elements;return n[12]=a[12],n[13]=a[13],n[14]=a[14],this}setFromMatrix3(t){const n=t.elements;return this.set(n[0],n[3],n[6],0,n[1],n[4],n[7],0,n[2],n[5],n[8],0,0,0,0,1),this}extractBasis(t,n,a){return this.determinantAffine()===0?(t.set(1,0,0),n.set(0,1,0),a.set(0,0,1),this):(t.setFromMatrixColumn(this,0),n.setFromMatrixColumn(this,1),a.setFromMatrixColumn(this,2),this)}makeBasis(t,n,a){return this.set(t.x,n.x,a.x,0,t.y,n.y,a.y,0,t.z,n.z,a.z,0,0,0,0,1),this}extractRotation(t){if(t.determinantAffine()===0)return this.identity();const n=this.elements,a=t.elements,o=1/kr.setFromMatrixColumn(t,0).length(),c=1/kr.setFromMatrixColumn(t,1).length(),u=1/kr.setFromMatrixColumn(t,2).length();return n[0]=a[0]*o,n[1]=a[1]*o,n[2]=a[2]*o,n[3]=0,n[4]=a[4]*c,n[5]=a[5]*c,n[6]=a[6]*c,n[7]=0,n[8]=a[8]*u,n[9]=a[9]*u,n[10]=a[10]*u,n[11]=0,n[12]=0,n[13]=0,n[14]=0,n[15]=1,this}makeRotationFromEuler(t){const n=this.elements,a=t.x,o=t.y,c=t.z,u=Math.cos(a),h=Math.sin(a),m=Math.cos(o),p=Math.sin(o),g=Math.cos(c),_=Math.sin(c);if(t.order==="XYZ"){const v=u*g,x=u*_,b=h*g,R=h*_;n[0]=m*g,n[4]=-m*_,n[8]=p,n[1]=x+b*p,n[5]=v-R*p,n[9]=-h*m,n[2]=R-v*p,n[6]=b+x*p,n[10]=u*m}else if(t.order==="YXZ"){const v=m*g,x=m*_,b=p*g,R=p*_;n[0]=v+R*h,n[4]=b*h-x,n[8]=u*p,n[1]=u*_,n[5]=u*g,n[9]=-h,n[2]=x*h-b,n[6]=R+v*h,n[10]=u*m}else if(t.order==="ZXY"){const v=m*g,x=m*_,b=p*g,R=p*_;n[0]=v-R*h,n[4]=-u*_,n[8]=b+x*h,n[1]=x+b*h,n[5]=u*g,n[9]=R-v*h,n[2]=-u*p,n[6]=h,n[10]=u*m}else if(t.order==="ZYX"){const v=u*g,x=u*_,b=h*g,R=h*_;n[0]=m*g,n[4]=b*p-x,n[8]=v*p+R,n[1]=m*_,n[5]=R*p+v,n[9]=x*p-b,n[2]=-p,n[6]=h*m,n[10]=u*m}else if(t.order==="YZX"){const v=u*m,x=u*p,b=h*m,R=h*p;n[0]=m*g,n[4]=R-v*_,n[8]=b*_+x,n[1]=_,n[5]=u*g,n[9]=-h*g,n[2]=-p*g,n[6]=x*_+b,n[10]=v-R*_}else if(t.order==="XZY"){const v=u*m,x=u*p,b=h*m,R=h*p;n[0]=m*g,n[4]=-_,n[8]=p*g,n[1]=v*_+R,n[5]=u*g,n[9]=x*_-b,n[2]=b*_-x,n[6]=h*g,n[10]=R*_+v}return n[3]=0,n[7]=0,n[11]=0,n[12]=0,n[13]=0,n[14]=0,n[15]=1,this}makeRotationFromQuaternion(t){return this.compose(D1,t,U1)}lookAt(t,n,a){const o=this.elements;return yi.subVectors(t,n),yi.lengthSq()===0&&(yi.z=1),yi.normalize(),xs.crossVectors(a,yi),xs.lengthSq()===0&&(Math.abs(a.z)===1?yi.x+=1e-4:yi.z+=1e-4,yi.normalize(),xs.crossVectors(a,yi)),xs.normalize(),qc.crossVectors(yi,xs),o[0]=xs.x,o[4]=qc.x,o[8]=yi.x,o[1]=xs.y,o[5]=qc.y,o[9]=yi.y,o[2]=xs.z,o[6]=qc.z,o[10]=yi.z,this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,n){const a=t.elements,o=n.elements,c=this.elements,u=a[0],h=a[4],m=a[8],p=a[12],g=a[1],_=a[5],v=a[9],x=a[13],b=a[2],R=a[6],M=a[10],S=a[14],C=a[3],O=a[7],E=a[11],U=a[15],L=o[0],P=o[4],T=o[8],z=o[12],W=o[1],J=o[5],Q=o[9],et=o[13],k=o[2],q=o[6],F=o[10],Z=o[14],ht=o[3],dt=o[7],pt=o[11],I=o[15];return c[0]=u*L+h*W+m*k+p*ht,c[4]=u*P+h*J+m*q+p*dt,c[8]=u*T+h*Q+m*F+p*pt,c[12]=u*z+h*et+m*Z+p*I,c[1]=g*L+_*W+v*k+x*ht,c[5]=g*P+_*J+v*q+x*dt,c[9]=g*T+_*Q+v*F+x*pt,c[13]=g*z+_*et+v*Z+x*I,c[2]=b*L+R*W+M*k+S*ht,c[6]=b*P+R*J+M*q+S*dt,c[10]=b*T+R*Q+M*F+S*pt,c[14]=b*z+R*et+M*Z+S*I,c[3]=C*L+O*W+E*k+U*ht,c[7]=C*P+O*J+E*q+U*dt,c[11]=C*T+O*Q+E*F+U*pt,c[15]=C*z+O*et+E*Z+U*I,this}multiplyScalar(t){const n=this.elements;return n[0]*=t,n[4]*=t,n[8]*=t,n[12]*=t,n[1]*=t,n[5]*=t,n[9]*=t,n[13]*=t,n[2]*=t,n[6]*=t,n[10]*=t,n[14]*=t,n[3]*=t,n[7]*=t,n[11]*=t,n[15]*=t,this}determinant(){const t=this.elements,n=t[0],a=t[4],o=t[8],c=t[12],u=t[1],h=t[5],m=t[9],p=t[13],g=t[2],_=t[6],v=t[10],x=t[14],b=t[3],R=t[7],M=t[11],S=t[15],C=m*x-p*v,O=h*x-p*_,E=h*v-m*_,U=u*x-p*g,L=u*v-m*g,P=u*_-h*g;return n*(R*C-M*O+S*E)-a*(b*C-M*U+S*L)+o*(b*O-R*U+S*P)-c*(b*E-R*L+M*P)}determinantAffine(){const t=this.elements,n=t[0],a=t[4],o=t[8],c=t[1],u=t[5],h=t[9],m=t[2],p=t[6],g=t[10];return n*(u*g-h*p)-a*(c*g-h*m)+o*(c*p-u*m)}transpose(){const t=this.elements;let n;return n=t[1],t[1]=t[4],t[4]=n,n=t[2],t[2]=t[8],t[8]=n,n=t[6],t[6]=t[9],t[9]=n,n=t[3],t[3]=t[12],t[12]=n,n=t[7],t[7]=t[13],t[13]=n,n=t[11],t[11]=t[14],t[14]=n,this}setPosition(t,n,a){const o=this.elements;return t.isVector3?(o[12]=t.x,o[13]=t.y,o[14]=t.z):(o[12]=t,o[13]=n,o[14]=a),this}invert(){const t=this.elements,n=t[0],a=t[1],o=t[2],c=t[3],u=t[4],h=t[5],m=t[6],p=t[7],g=t[8],_=t[9],v=t[10],x=t[11],b=t[12],R=t[13],M=t[14],S=t[15],C=n*h-a*u,O=n*m-o*u,E=n*p-c*u,U=a*m-o*h,L=a*p-c*h,P=o*p-c*m,T=g*R-_*b,z=g*M-v*b,W=g*S-x*b,J=_*M-v*R,Q=_*S-x*R,et=v*S-x*M,k=C*et-O*Q+E*J+U*W-L*z+P*T;if(k===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const q=1/k;return t[0]=(h*et-m*Q+p*J)*q,t[1]=(o*Q-a*et-c*J)*q,t[2]=(R*P-M*L+S*U)*q,t[3]=(v*L-_*P-x*U)*q,t[4]=(m*W-u*et-p*z)*q,t[5]=(n*et-o*W+c*z)*q,t[6]=(M*E-b*P-S*O)*q,t[7]=(g*P-v*E+x*O)*q,t[8]=(u*Q-h*W+p*T)*q,t[9]=(a*W-n*Q-c*T)*q,t[10]=(b*L-R*E+S*C)*q,t[11]=(_*E-g*L-x*C)*q,t[12]=(h*z-u*J-m*T)*q,t[13]=(n*J-a*z+o*T)*q,t[14]=(R*O-b*U-M*C)*q,t[15]=(g*U-_*O+v*C)*q,this}scale(t){const n=this.elements,a=t.x,o=t.y,c=t.z;return n[0]*=a,n[4]*=o,n[8]*=c,n[1]*=a,n[5]*=o,n[9]*=c,n[2]*=a,n[6]*=o,n[10]*=c,n[3]*=a,n[7]*=o,n[11]*=c,this}getMaxScaleOnAxis(){const t=this.elements,n=t[0]*t[0]+t[1]*t[1]+t[2]*t[2],a=t[4]*t[4]+t[5]*t[5]+t[6]*t[6],o=t[8]*t[8]+t[9]*t[9]+t[10]*t[10];return Math.sqrt(Math.max(n,a,o))}makeTranslation(t,n,a){return t.isVector3?this.set(1,0,0,t.x,0,1,0,t.y,0,0,1,t.z,0,0,0,1):this.set(1,0,0,t,0,1,0,n,0,0,1,a,0,0,0,1),this}makeRotationX(t){const n=Math.cos(t),a=Math.sin(t);return this.set(1,0,0,0,0,n,-a,0,0,a,n,0,0,0,0,1),this}makeRotationY(t){const n=Math.cos(t),a=Math.sin(t);return this.set(n,0,a,0,0,1,0,0,-a,0,n,0,0,0,0,1),this}makeRotationZ(t){const n=Math.cos(t),a=Math.sin(t);return this.set(n,-a,0,0,a,n,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(t,n){const a=Math.cos(n),o=Math.sin(n),c=1-a,u=t.x,h=t.y,m=t.z,p=c*u,g=c*h;return this.set(p*u+a,p*h-o*m,p*m+o*h,0,p*h+o*m,g*h+a,g*m-o*u,0,p*m-o*h,g*m+o*u,c*m*m+a,0,0,0,0,1),this}makeScale(t,n,a){return this.set(t,0,0,0,0,n,0,0,0,0,a,0,0,0,0,1),this}makeShear(t,n,a,o,c,u){return this.set(1,a,c,0,t,1,u,0,n,o,1,0,0,0,0,1),this}compose(t,n,a){const o=this.elements,c=n._x,u=n._y,h=n._z,m=n._w,p=c+c,g=u+u,_=h+h,v=c*p,x=c*g,b=c*_,R=u*g,M=u*_,S=h*_,C=m*p,O=m*g,E=m*_,U=a.x,L=a.y,P=a.z;return o[0]=(1-(R+S))*U,o[1]=(x+E)*U,o[2]=(b-O)*U,o[3]=0,o[4]=(x-E)*L,o[5]=(1-(v+S))*L,o[6]=(M+C)*L,o[7]=0,o[8]=(b+O)*P,o[9]=(M-C)*P,o[10]=(1-(v+R))*P,o[11]=0,o[12]=t.x,o[13]=t.y,o[14]=t.z,o[15]=1,this}decompose(t,n,a){const o=this.elements;t.x=o[12],t.y=o[13],t.z=o[14];const c=this.determinantAffine();if(c===0)return a.set(1,1,1),n.identity(),this;let u=kr.set(o[0],o[1],o[2]).length();const h=kr.set(o[4],o[5],o[6]).length(),m=kr.set(o[8],o[9],o[10]).length();c<0&&(u=-u),qi.copy(this);const p=1/u,g=1/h,_=1/m;return qi.elements[0]*=p,qi.elements[1]*=p,qi.elements[2]*=p,qi.elements[4]*=g,qi.elements[5]*=g,qi.elements[6]*=g,qi.elements[8]*=_,qi.elements[9]*=_,qi.elements[10]*=_,n.setFromRotationMatrix(qi),a.x=u,a.y=h,a.z=m,this}makePerspective(t,n,a,o,c,u,h=la,m=!1){const p=this.elements,g=2*c/(n-t),_=2*c/(a-o),v=(n+t)/(n-t),x=(a+o)/(a-o);let b,R;if(m)b=c/(u-c),R=u*c/(u-c);else if(h===la)b=-(u+c)/(u-c),R=-2*u*c/(u-c);else if(h===Al)b=-u/(u-c),R=-u*c/(u-c);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+h);return p[0]=g,p[4]=0,p[8]=v,p[12]=0,p[1]=0,p[5]=_,p[9]=x,p[13]=0,p[2]=0,p[6]=0,p[10]=b,p[14]=R,p[3]=0,p[7]=0,p[11]=-1,p[15]=0,this}makeOrthographic(t,n,a,o,c,u,h=la,m=!1){const p=this.elements,g=2/(n-t),_=2/(a-o),v=-(n+t)/(n-t),x=-(a+o)/(a-o);let b,R;if(m)b=1/(u-c),R=u/(u-c);else if(h===la)b=-2/(u-c),R=-(u+c)/(u-c);else if(h===Al)b=-1/(u-c),R=-c/(u-c);else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+h);return p[0]=g,p[4]=0,p[8]=0,p[12]=v,p[1]=0,p[5]=_,p[9]=0,p[13]=x,p[2]=0,p[6]=0,p[10]=b,p[14]=R,p[3]=0,p[7]=0,p[11]=0,p[15]=1,this}equals(t){const n=this.elements,a=t.elements;for(let o=0;o<16;o++)if(n[o]!==a[o])return!1;return!0}fromArray(t,n=0){for(let a=0;a<16;a++)this.elements[a]=t[a+n];return this}toArray(t=[],n=0){const a=this.elements;return t[n]=a[0],t[n+1]=a[1],t[n+2]=a[2],t[n+3]=a[3],t[n+4]=a[4],t[n+5]=a[5],t[n+6]=a[6],t[n+7]=a[7],t[n+8]=a[8],t[n+9]=a[9],t[n+10]=a[10],t[n+11]=a[11],t[n+12]=a[12],t[n+13]=a[13],t[n+14]=a[14],t[n+15]=a[15],t}};Pu.prototype.isMatrix4=!0;let an=Pu;const kr=new B,qi=new an,D1=new B(0,0,0),U1=new B(1,1,1),xs=new B,qc=new B,yi=new B,o_=new an,l_=new Ai;class Xa{constructor(t=0,n=0,a=0,o=Xa.DEFAULT_ORDER){this.isEuler=!0,this._x=t,this._y=n,this._z=a,this._order=o}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get order(){return this._order}set order(t){this._order=t,this._onChangeCallback()}set(t,n,a,o=this._order){return this._x=t,this._y=n,this._z=a,this._order=o,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(t){return this._x=t._x,this._y=t._y,this._z=t._z,this._order=t._order,this._onChangeCallback(),this}setFromRotationMatrix(t,n=this._order,a=!0){const o=t.elements,c=o[0],u=o[4],h=o[8],m=o[1],p=o[5],g=o[9],_=o[2],v=o[6],x=o[10];switch(n){case"XYZ":this._y=Math.asin(Ue(h,-1,1)),Math.abs(h)<.9999999?(this._x=Math.atan2(-g,x),this._z=Math.atan2(-u,c)):(this._x=Math.atan2(v,p),this._z=0);break;case"YXZ":this._x=Math.asin(-Ue(g,-1,1)),Math.abs(g)<.9999999?(this._y=Math.atan2(h,x),this._z=Math.atan2(m,p)):(this._y=Math.atan2(-_,c),this._z=0);break;case"ZXY":this._x=Math.asin(Ue(v,-1,1)),Math.abs(v)<.9999999?(this._y=Math.atan2(-_,x),this._z=Math.atan2(-u,p)):(this._y=0,this._z=Math.atan2(m,c));break;case"ZYX":this._y=Math.asin(-Ue(_,-1,1)),Math.abs(_)<.9999999?(this._x=Math.atan2(v,x),this._z=Math.atan2(m,c)):(this._x=0,this._z=Math.atan2(-u,p));break;case"YZX":this._z=Math.asin(Ue(m,-1,1)),Math.abs(m)<.9999999?(this._x=Math.atan2(-g,p),this._y=Math.atan2(-_,c)):(this._x=0,this._y=Math.atan2(h,x));break;case"XZY":this._z=Math.asin(-Ue(u,-1,1)),Math.abs(u)<.9999999?(this._x=Math.atan2(v,p),this._y=Math.atan2(h,c)):(this._x=Math.atan2(-g,x),this._y=0);break;default:ve("Euler: .setFromRotationMatrix() encountered an unknown order: "+n)}return this._order=n,a===!0&&this._onChangeCallback(),this}setFromQuaternion(t,n,a){return o_.makeRotationFromQuaternion(t),this.setFromRotationMatrix(o_,n,a)}setFromVector3(t,n=this._order){return this.set(t.x,t.y,t.z,n)}reorder(t){return l_.setFromEuler(this),this.setFromQuaternion(l_,t)}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._order===this._order}fromArray(t){return this._x=t[0],this._y=t[1],this._z=t[2],t[3]!==void 0&&(this._order=t[3]),this._onChangeCallback(),this}toArray(t=[],n=0){return t[n]=this._x,t[n+1]=this._y,t[n+2]=this._z,t[n+3]=this._order,t}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}Xa.DEFAULT_ORDER="XYZ";class Zp{constructor(){this.mask=1}set(t){this.mask=(1<<t|0)>>>0}enable(t){this.mask|=1<<t|0}enableAll(){this.mask=-1}toggle(t){this.mask^=1<<t|0}disable(t){this.mask&=~(1<<t|0)}disableAll(){this.mask=0}test(t){return(this.mask&t.mask)!==0}isEnabled(t){return(this.mask&(1<<t|0))!==0}}let L1=0;const c_=new B,Xr=new Ai,Ua=new an,Yc=new B,sl=new B,N1=new B,O1=new Ai,u_=new B(1,0,0),f_=new B(0,1,0),h_=new B(0,0,1),d_={type:"added"},P1={type:"removed"},Wr={type:"childadded",child:null},ud={type:"childremoved",child:null};class Mn extends rr{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:L1++}),this.uuid=or(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=Mn.DEFAULT_UP.clone();const t=new B,n=new Xa,a=new Ai,o=new B(1,1,1);function c(){a.setFromEuler(n,!1)}function u(){n.setFromQuaternion(a,void 0,!1)}n._onChange(c),a._onChange(u),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:t},rotation:{configurable:!0,enumerable:!0,value:n},quaternion:{configurable:!0,enumerable:!0,value:a},scale:{configurable:!0,enumerable:!0,value:o},modelViewMatrix:{value:new an},normalMatrix:{value:new ye}}),this.matrix=new an,this.matrixWorld=new an,this.matrixAutoUpdate=Mn.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=Mn.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new Zp,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.static=!1,this.userData={},this.pivot=null}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(t){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(t),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(t){return this.quaternion.premultiply(t),this}setRotationFromAxisAngle(t,n){this.quaternion.setFromAxisAngle(t,n)}setRotationFromEuler(t){this.quaternion.setFromEuler(t,!0)}setRotationFromMatrix(t){this.quaternion.setFromRotationMatrix(t)}setRotationFromQuaternion(t){this.quaternion.copy(t)}rotateOnAxis(t,n){return Xr.setFromAxisAngle(t,n),this.quaternion.multiply(Xr),this}rotateOnWorldAxis(t,n){return Xr.setFromAxisAngle(t,n),this.quaternion.premultiply(Xr),this}rotateX(t){return this.rotateOnAxis(u_,t)}rotateY(t){return this.rotateOnAxis(f_,t)}rotateZ(t){return this.rotateOnAxis(h_,t)}translateOnAxis(t,n){return c_.copy(t).applyQuaternion(this.quaternion),this.position.add(c_.multiplyScalar(n)),this}translateX(t){return this.translateOnAxis(u_,t)}translateY(t){return this.translateOnAxis(f_,t)}translateZ(t){return this.translateOnAxis(h_,t)}localToWorld(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(this.matrixWorld)}worldToLocal(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(Ua.copy(this.matrixWorld).invert())}lookAt(t,n,a){t.isVector3?Yc.copy(t):Yc.set(t,n,a);const o=this.parent;this.updateWorldMatrix(!0,!1),sl.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?Ua.lookAt(sl,Yc,this.up):Ua.lookAt(Yc,sl,this.up),this.quaternion.setFromRotationMatrix(Ua),o&&(Ua.extractRotation(o.matrixWorld),Xr.setFromRotationMatrix(Ua),this.quaternion.premultiply(Xr.invert()))}add(t){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.add(arguments[n]);return this}return t===this?(We("Object3D.add: object can't be added as a child of itself.",t),this):(t&&t.isObject3D?(t.removeFromParent(),t.parent=this,this.children.push(t),t.dispatchEvent(d_),Wr.child=t,this.dispatchEvent(Wr),Wr.child=null):We("Object3D.add: object not an instance of THREE.Object3D.",t),this)}remove(t){if(arguments.length>1){for(let a=0;a<arguments.length;a++)this.remove(arguments[a]);return this}const n=this.children.indexOf(t);return n!==-1&&(t.parent=null,this.children.splice(n,1),t.dispatchEvent(P1),ud.child=t,this.dispatchEvent(ud),ud.child=null),this}removeFromParent(){const t=this.parent;return t!==null&&t.remove(this),this}clear(){return this.remove(...this.children)}attach(t){return this.updateWorldMatrix(!0,!1),Ua.copy(this.matrixWorld).invert(),t.parent!==null&&(t.parent.updateWorldMatrix(!0,!1),Ua.multiply(t.parent.matrixWorld)),t.applyMatrix4(Ua),t.removeFromParent(),t.parent=this,this.children.push(t),t.updateWorldMatrix(!1,!0),t.dispatchEvent(d_),Wr.child=t,this.dispatchEvent(Wr),Wr.child=null,this}getObjectById(t){return this.getObjectByProperty("id",t)}getObjectByName(t){return this.getObjectByProperty("name",t)}getObjectByProperty(t,n){if(this[t]===n)return this;for(let a=0,o=this.children.length;a<o;a++){const u=this.children[a].getObjectByProperty(t,n);if(u!==void 0)return u}}getObjectsByProperty(t,n,a=[]){this[t]===n&&a.push(this);const o=this.children;for(let c=0,u=o.length;c<u;c++)o[c].getObjectsByProperty(t,n,a);return a}getWorldPosition(t){return this.updateWorldMatrix(!0,!1),t.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(sl,t,N1),t}getWorldScale(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(sl,O1,t),t}getWorldDirection(t){this.updateWorldMatrix(!0,!1);const n=this.matrixWorld.elements;return t.set(n[8],n[9],n[10]).normalize()}raycast(){}intersectsFrustum(){}traverse(t){t(this);const n=this.children;for(let a=0,o=n.length;a<o;a++)n[a].traverse(t)}traverseVisible(t){if(this.visible===!1)return;t(this);const n=this.children;for(let a=0,o=n.length;a<o;a++)n[a].traverseVisible(t)}traverseAncestors(t){const n=this.parent;n!==null&&(t(n),n.traverseAncestors(t))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale);const t=this.pivot;if(t!==null){const n=t.x,a=t.y,o=t.z,c=this.matrix.elements;c[12]+=n-c[0]*n-c[4]*a-c[8]*o,c[13]+=a-c[1]*n-c[5]*a-c[9]*o,c[14]+=o-c[2]*n-c[6]*a-c[10]*o}this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(t){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||t)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,t=!0);const n=this.children;for(let a=0,o=n.length;a<o;a++)n[a].updateMatrixWorld(t)}updateWorldMatrix(t,n,a=!1){const o=this.parent;if(t===!0&&o!==null&&o.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||a)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,a=!0),n===!0){const c=this.children;for(let u=0,h=c.length;u<h;u++)c[u].updateWorldMatrix(!1,!0,a)}}toJSON(t){const n=t===void 0||typeof t=="string",a={};n&&(t={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},a.metadata={version:4.7,type:"Object",generator:"Object3D.toJSON"});const o={};o.uuid=this.uuid,o.type=this.type,o.name=this.name,o.castShadow=this.castShadow,o.receiveShadow=this.receiveShadow,o.visible=this.visible,o.frustumCulled=this.frustumCulled,o.renderOrder=this.renderOrder,o.static=this.static,o.matrixAutoUpdate=this.matrixAutoUpdate,Object.keys(this.userData).length>0&&(o.userData=this.userData),o.layers=this.layers.mask,o.matrix=this.matrix.toArray(),o.up=this.up.toArray(),this.pivot!==null&&(o.pivot=this.pivot.toArray()),this.morphTargetDictionary!==void 0&&(o.morphTargetDictionary=Object.assign({},this.morphTargetDictionary)),this.morphTargetInfluences!==void 0&&(o.morphTargetInfluences=this.morphTargetInfluences.slice()),this.isInstancedMesh&&(o.type="InstancedMesh",o.count=this.count,o.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(o.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(o.type="BatchedMesh",o.perObjectFrustumCulled=this.perObjectFrustumCulled,o.sortObjects=this.sortObjects,o.drawRanges=this._drawRanges,o.reservedRanges=this._reservedRanges,o.geometryInfo=this._geometryInfo.map(h=>({...h,boundingBox:h.boundingBox?h.boundingBox.toJSON():void 0,boundingSphere:h.boundingSphere?h.boundingSphere.toJSON():void 0})),o.instanceInfo=this._instanceInfo.map(h=>({...h})),o.availableInstanceIds=this._availableInstanceIds.slice(),o.availableGeometryIds=this._availableGeometryIds.slice(),o.nextIndexStart=this._nextIndexStart,o.nextVertexStart=this._nextVertexStart,o.geometryCount=this._geometryCount,o.maxInstanceCount=this._maxInstanceCount,o.maxVertexCount=this._maxVertexCount,o.maxIndexCount=this._maxIndexCount,o.geometryInitialized=this._geometryInitialized,o.matricesTexture=this._matricesTexture.toJSON(t),o.indirectTexture=this._indirectTexture.toJSON(t),this._colorsTexture!==null&&(o.colorsTexture=this._colorsTexture.toJSON(t)),this.boundingSphere!==null&&(o.boundingSphere=this.boundingSphere.toJSON()),this.boundingBox!==null&&(o.boundingBox=this.boundingBox.toJSON()));function c(h,m){return h[m.uuid]===void 0&&(h[m.uuid]=m.toJSON(t)),m.uuid}if(this.isScene)this.background&&(this.background.isColor?o.background=this.background.toJSON():this.background.isTexture&&(o.background=this.background.toJSON(t).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(o.environment=this.environment.toJSON(t).uuid);else if(this.isMesh||this.isLine||this.isPoints){o.geometry=c(t.geometries,this.geometry);const h=this.geometry.parameters;if(h!==void 0&&h.shapes!==void 0){const m=h.shapes;if(Array.isArray(m))for(let p=0,g=m.length;p<g;p++){const _=m[p];c(t.shapes,_)}else c(t.shapes,m)}}if(this.isSkinnedMesh&&(o.bindMode=this.bindMode,o.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(c(t.skeletons,this.skeleton),o.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const h=[];for(let m=0,p=this.material.length;m<p;m++)h.push(c(t.materials,this.material[m]));o.material=h}else o.material=c(t.materials,this.material);if(this.children.length>0){o.children=[];for(let h=0;h<this.children.length;h++)o.children.push(this.children[h].toJSON(t).object)}if(this.animations.length>0){o.animations=[];for(let h=0;h<this.animations.length;h++){const m=this.animations[h];o.animations.push(c(t.animations,m))}}if(n){const h=u(t.geometries),m=u(t.materials),p=u(t.textures),g=u(t.images),_=u(t.shapes),v=u(t.skeletons),x=u(t.animations),b=u(t.nodes);h.length>0&&(a.geometries=h),m.length>0&&(a.materials=m),p.length>0&&(a.textures=p),g.length>0&&(a.images=g),_.length>0&&(a.shapes=_),v.length>0&&(a.skeletons=v),x.length>0&&(a.animations=x),b.length>0&&(a.nodes=b)}return a.object=o,a;function u(h){const m=[];for(const p in h){const g=h[p];delete g.metadata,m.push(g)}return m}}clone(t){return new this.constructor().copy(this,t)}copy(t,n=!0){if(this.name=t.name,this.up.copy(t.up),this.position.copy(t.position),this.rotation.order=t.rotation.order,this.quaternion.copy(t.quaternion),this.scale.copy(t.scale),this.pivot=t.pivot!==null?t.pivot.clone():null,this.matrix.copy(t.matrix),this.matrixWorld.copy(t.matrixWorld),this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrixWorldAutoUpdate=t.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=t.matrixWorldNeedsUpdate,this.layers.mask=t.layers.mask,this.visible=t.visible,this.castShadow=t.castShadow,this.receiveShadow=t.receiveShadow,this.frustumCulled=t.frustumCulled,this.renderOrder=t.renderOrder,this.static=t.static,this.animations=t.animations.slice(),this.userData=JSON.parse(JSON.stringify(t.userData)),n===!0)for(let a=0;a<t.children.length;a++){const o=t.children[a];this.add(o.clone())}return this}dispose(){this.dispatchEvent({type:"dispose"})}}Mn.DEFAULT_UP=new B(0,1,0);Mn.DEFAULT_MATRIX_AUTO_UPDATE=!0;Mn.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;class ji extends Mn{constructor(){super(),this.isGroup=!0,this.type="Group"}}const z1={type:"move"};class fd{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new ji,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new ji,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new B,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new B),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new ji,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new B,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new B,this._grip.eventsEnabled=!1),this._grip}dispatchEvent(t){return this._targetRay!==null&&this._targetRay.dispatchEvent(t),this._grip!==null&&this._grip.dispatchEvent(t),this._hand!==null&&this._hand.dispatchEvent(t),this}connect(t){if(t&&t.hand){const n=this._hand;if(n)for(const a of t.hand.values())this._getHandJoint(n,a)}return this.dispatchEvent({type:"connected",data:t}),this}disconnect(t){return this.dispatchEvent({type:"disconnected",data:t}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(t,n,a){let o=null,c=null,u=null;const h=this._targetRay,m=this._grip,p=this._hand;if(t&&n.session.visibilityState!=="visible-blurred"){if(p&&t.hand){u=!0;for(const R of t.hand.values()){const M=n.getJointPose(R,a),S=this._getHandJoint(p,R);M!==null&&(S.matrix.fromArray(M.transform.matrix),S.matrix.decompose(S.position,S.rotation,S.scale),S.matrixWorldNeedsUpdate=!0,S.jointRadius=M.radius),S.visible=M!==null}const g=p.joints["index-finger-tip"],_=p.joints["thumb-tip"],v=g.position.distanceTo(_.position),x=.02,b=.005;p.inputState.pinching&&v>x+b?(p.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:t.handedness,target:this})):!p.inputState.pinching&&v<=x-b&&(p.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:t.handedness,target:this}))}else m!==null&&t.gripSpace&&(c=n.getPose(t.gripSpace,a),c!==null&&(m.matrix.fromArray(c.transform.matrix),m.matrix.decompose(m.position,m.rotation,m.scale),m.matrixWorldNeedsUpdate=!0,c.linearVelocity?(m.hasLinearVelocity=!0,m.linearVelocity.copy(c.linearVelocity)):m.hasLinearVelocity=!1,c.angularVelocity?(m.hasAngularVelocity=!0,m.angularVelocity.copy(c.angularVelocity)):m.hasAngularVelocity=!1,m.eventsEnabled&&m.dispatchEvent({type:"gripUpdated",data:t,target:this})));h!==null&&(o=n.getPose(t.targetRaySpace,a),o===null&&c!==null&&(o=c),o!==null&&(h.matrix.fromArray(o.transform.matrix),h.matrix.decompose(h.position,h.rotation,h.scale),h.matrixWorldNeedsUpdate=!0,o.linearVelocity?(h.hasLinearVelocity=!0,h.linearVelocity.copy(o.linearVelocity)):h.hasLinearVelocity=!1,o.angularVelocity?(h.hasAngularVelocity=!0,h.angularVelocity.copy(o.angularVelocity)):h.hasAngularVelocity=!1,this.dispatchEvent(z1)))}return h!==null&&(h.visible=o!==null),m!==null&&(m.visible=c!==null),p!==null&&(p.visible=u!==null),this}_getHandJoint(t,n){if(t.joints[n.jointName]===void 0){const a=new ji;a.matrixAutoUpdate=!1,a.visible=!1,t.joints[n.jointName]=a,t.add(a)}return t.joints[n.jointName]}}const Px={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},Ss={h:0,s:0,l:0},Zc={h:0,s:0,l:0};function hd(r,t,n){return n<0&&(n+=1),n>1&&(n-=1),n<1/6?r+(t-r)*6*n:n<1/2?t:n<2/3?r+(t-r)*6*(2/3-n):r}class ue{constructor(t,n,a){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(t,n,a)}set(t,n,a){if(n===void 0&&a===void 0){const o=t;o&&o.isColor?this.copy(o):typeof o=="number"?this.setHex(o):typeof o=="string"&&this.setStyle(o)}else this.setRGB(t,n,a);return this}setScalar(t){return this.r=t,this.g=t,this.b=t,this}setHex(t,n=In){return t=Math.floor(t),this.r=(t>>16&255)/255,this.g=(t>>8&255)/255,this.b=(t&255)/255,Ve.colorSpaceToWorking(this,n),this}setRGB(t,n,a,o=Ve.workingColorSpace){return this.r=t,this.g=n,this.b=a,Ve.colorSpaceToWorking(this,o),this}setHSL(t,n,a,o=Ve.workingColorSpace){if(t=qp(t,1),n=Ue(n,0,1),a=Ue(a,0,1),n===0)this.r=this.g=this.b=a;else{const c=a<=.5?a*(1+n):a+n-a*n,u=2*a-c;this.r=hd(u,c,t+1/3),this.g=hd(u,c,t),this.b=hd(u,c,t-1/3)}return Ve.colorSpaceToWorking(this,o),this}setStyle(t,n=In){function a(c){c!==void 0&&parseFloat(c)<1&&ve("Color: Alpha component of "+t+" will be ignored.")}let o;if(o=/^(\w+)\(([^\)]*)\)/.exec(t)){let c;const u=o[1],h=o[2];switch(u){case"rgb":case"rgba":if(c=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(h))return a(c[4]),this.setRGB(Math.min(255,parseInt(c[1],10))/255,Math.min(255,parseInt(c[2],10))/255,Math.min(255,parseInt(c[3],10))/255,n);if(c=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(h))return a(c[4]),this.setRGB(Math.min(100,parseInt(c[1],10))/100,Math.min(100,parseInt(c[2],10))/100,Math.min(100,parseInt(c[3],10))/100,n);break;case"hsl":case"hsla":if(c=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(h))return a(c[4]),this.setHSL(parseFloat(c[1])/360,parseFloat(c[2])/100,parseFloat(c[3])/100,n);break;default:ve("Color: Unknown color model "+t)}}else if(o=/^\#([A-Fa-f\d]+)$/.exec(t)){const c=o[1],u=c.length;if(u===3)return this.setRGB(parseInt(c.charAt(0),16)/15,parseInt(c.charAt(1),16)/15,parseInt(c.charAt(2),16)/15,n);if(u===6)return this.setHex(parseInt(c,16),n);ve("Color: Invalid hex color "+t)}else if(t&&t.length>0)return this.setColorName(t,n);return this}setColorName(t,n=In){const a=Px[t.toLowerCase()];return a!==void 0?this.setHex(a,n):ve("Color: Unknown color "+t),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(t){return this.r=t.r,this.g=t.g,this.b=t.b,this}copySRGBToLinear(t){return this.r=Ga(t.r),this.g=Ga(t.g),this.b=Ga(t.b),this}copyLinearToSRGB(t){return this.r=oo(t.r),this.g=oo(t.g),this.b=oo(t.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(t=In){return Ve.workingToColorSpace(ti.copy(this),t),Math.round(Ue(ti.r*255,0,255))*65536+Math.round(Ue(ti.g*255,0,255))*256+Math.round(Ue(ti.b*255,0,255))}getHexString(t=In){return("000000"+this.getHex(t).toString(16)).slice(-6)}getHSL(t,n=Ve.workingColorSpace){Ve.workingToColorSpace(ti.copy(this),n);const a=ti.r,o=ti.g,c=ti.b,u=Math.max(a,o,c),h=Math.min(a,o,c);let m,p;const g=(h+u)/2;if(h===u)m=0,p=0;else{const _=u-h;switch(p=g<=.5?_/(u+h):_/(2-u-h),u){case a:m=(o-c)/_+(o<c?6:0);break;case o:m=(c-a)/_+2;break;case c:m=(a-o)/_+4;break}m/=6}return t.h=m,t.s=p,t.l=g,t}getRGB(t,n=Ve.workingColorSpace){return Ve.workingToColorSpace(ti.copy(this),n),t.r=ti.r,t.g=ti.g,t.b=ti.b,t}getStyle(t=In){Ve.workingToColorSpace(ti.copy(this),t);const n=ti.r,a=ti.g,o=ti.b;return t!==In?`color(${t} ${n.toFixed(3)} ${a.toFixed(3)} ${o.toFixed(3)})`:`rgb(${Math.round(n*255)},${Math.round(a*255)},${Math.round(o*255)})`}offsetHSL(t,n,a){return this.getHSL(Ss),this.setHSL(Ss.h+t,Ss.s+n,Ss.l+a)}add(t){return this.r+=t.r,this.g+=t.g,this.b+=t.b,this}addColors(t,n){return this.r=t.r+n.r,this.g=t.g+n.g,this.b=t.b+n.b,this}addScalar(t){return this.r+=t,this.g+=t,this.b+=t,this}sub(t){return this.r=Math.max(0,this.r-t.r),this.g=Math.max(0,this.g-t.g),this.b=Math.max(0,this.b-t.b),this}multiply(t){return this.r*=t.r,this.g*=t.g,this.b*=t.b,this}multiplyScalar(t){return this.r*=t,this.g*=t,this.b*=t,this}lerp(t,n){return this.r+=(t.r-this.r)*n,this.g+=(t.g-this.g)*n,this.b+=(t.b-this.b)*n,this}lerpColors(t,n,a){return this.r=t.r+(n.r-t.r)*a,this.g=t.g+(n.g-t.g)*a,this.b=t.b+(n.b-t.b)*a,this}lerpHSL(t,n){this.getHSL(Ss),t.getHSL(Zc);const a=xl(Ss.h,Zc.h,n),o=xl(Ss.s,Zc.s,n),c=xl(Ss.l,Zc.l,n);return this.setHSL(a,o,c),this}setFromVector3(t){return this.r=t.x,this.g=t.y,this.b=t.z,this}applyMatrix3(t){const n=this.r,a=this.g,o=this.b,c=t.elements;return this.r=c[0]*n+c[3]*a+c[6]*o,this.g=c[1]*n+c[4]*a+c[7]*o,this.b=c[2]*n+c[5]*a+c[8]*o,this}equals(t){return t.r===this.r&&t.g===this.g&&t.b===this.b}fromArray(t,n=0){return this.r=t[n],this.g=t[n+1],this.b=t[n+2],this}toArray(t=[],n=0){return t[n]=this.r,t[n+1]=this.g,t[n+2]=this.b,t}fromBufferAttribute(t,n){return this.r=t.getX(n),this.g=t.getY(n),this.b=t.getZ(n),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const ti=new ue;ue.NAMES=Px;class fo{constructor(t,n=25e-5){this.isFogExp2=!0,this.name="",this.color=new ue(t),this.density=n}clone(){return new fo(this.color,this.density)}toJSON(){return{type:"FogExp2",name:this.name,color:this.color.getHex(),density:this.density}}}class I1 extends Mn{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new Xa,this.environmentIntensity=1,this.environmentRotation=new Xa,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(t,n){return super.copy(t,n),t.background!==null&&(this.background=t.background.clone()),t.environment!==null&&(this.environment=t.environment.clone()),t.fog!==null&&(this.fog=t.fog.clone()),this.backgroundBlurriness=t.backgroundBlurriness,this.backgroundIntensity=t.backgroundIntensity,this.backgroundRotation.copy(t.backgroundRotation),this.environmentIntensity=t.environmentIntensity,this.environmentRotation.copy(t.environmentRotation),t.overrideMaterial!==null&&(this.overrideMaterial=t.overrideMaterial.clone()),this.matrixAutoUpdate=t.matrixAutoUpdate,this}toJSON(t){const n=super.toJSON(t);return this.fog!==null&&(n.object.fog=this.fog.toJSON()),n.object.backgroundBlurriness=this.backgroundBlurriness,n.object.backgroundIntensity=this.backgroundIntensity,n.object.backgroundRotation=this.backgroundRotation.toArray(),n.object.environmentIntensity=this.environmentIntensity,n.object.environmentRotation=this.environmentRotation.toArray(),n}}const Yi=new B,La=new B,dd=new B,Na=new B,qr=new B,Yr=new B,p_=new B,pd=new B,md=new B,gd=new B,vd=new xn,_d=new xn,xd=new xn;class Ki{constructor(t=new B,n=new B,a=new B){this.a=t,this.b=n,this.c=a}static getNormal(t,n,a,o){o.subVectors(a,n),Yi.subVectors(t,n),o.cross(Yi);const c=o.lengthSq();return c>0?o.multiplyScalar(1/Math.sqrt(c)):o.set(0,0,0)}static getBarycoord(t,n,a,o,c){Yi.subVectors(o,n),La.subVectors(a,n),dd.subVectors(t,n);const u=Yi.dot(Yi),h=Yi.dot(La),m=Yi.dot(dd),p=La.dot(La),g=La.dot(dd),_=u*p-h*h;if(_===0)return c.set(0,0,0),null;const v=1/_,x=(p*m-h*g)*v,b=(u*g-h*m)*v;return c.set(1-x-b,b,x)}static containsPoint(t,n,a,o){return this.getBarycoord(t,n,a,o,Na)===null?!1:Na.x>=0&&Na.y>=0&&Na.x+Na.y<=1}static getInterpolation(t,n,a,o,c,u,h,m){return this.getBarycoord(t,n,a,o,Na)===null?(m.x=0,m.y=0,"z"in m&&(m.z=0),"w"in m&&(m.w=0),null):(m.setScalar(0),m.addScaledVector(c,Na.x),m.addScaledVector(u,Na.y),m.addScaledVector(h,Na.z),m)}static getInterpolatedAttribute(t,n,a,o,c,u){return vd.setScalar(0),_d.setScalar(0),xd.setScalar(0),vd.fromBufferAttribute(t,n),_d.fromBufferAttribute(t,a),xd.fromBufferAttribute(t,o),u.setScalar(0),u.addScaledVector(vd,c.x),u.addScaledVector(_d,c.y),u.addScaledVector(xd,c.z),u}static isFrontFacing(t,n,a,o){return Yi.subVectors(a,n),La.subVectors(t,n),Yi.cross(La).dot(o)<0}set(t,n,a){return this.a.copy(t),this.b.copy(n),this.c.copy(a),this}setFromPointsAndIndices(t,n,a,o){return this.a.copy(t[n]),this.b.copy(t[a]),this.c.copy(t[o]),this}setFromAttributeAndIndices(t,n,a,o){return this.a.fromBufferAttribute(t,n),this.b.fromBufferAttribute(t,a),this.c.fromBufferAttribute(t,o),this}clone(){return new this.constructor().copy(this)}copy(t){return this.a.copy(t.a),this.b.copy(t.b),this.c.copy(t.c),this}getArea(){return Yi.subVectors(this.c,this.b),La.subVectors(this.a,this.b),Yi.cross(La).length()*.5}getMidpoint(t){return t.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(t){return Ki.getNormal(this.a,this.b,this.c,t)}getPlane(t){return t.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(t,n){return Ki.getBarycoord(t,this.a,this.b,this.c,n)}getInterpolation(t,n,a,o,c){return Ki.getInterpolation(t,this.a,this.b,this.c,n,a,o,c)}containsPoint(t){return Ki.containsPoint(t,this.a,this.b,this.c)}isFrontFacing(t){return Ki.isFrontFacing(this.a,this.b,this.c,t)}intersectsBox(t){return t.intersectsTriangle(this)}closestPointToPoint(t,n){const a=this.a,o=this.b,c=this.c;let u,h;qr.subVectors(o,a),Yr.subVectors(c,a),pd.subVectors(t,a);const m=qr.dot(pd),p=Yr.dot(pd);if(m<=0&&p<=0)return n.copy(a);md.subVectors(t,o);const g=qr.dot(md),_=Yr.dot(md);if(g>=0&&_<=g)return n.copy(o);const v=m*_-g*p;if(v<=0&&m>=0&&g<=0)return u=m/(m-g),n.copy(a).addScaledVector(qr,u);gd.subVectors(t,c);const x=qr.dot(gd),b=Yr.dot(gd);if(b>=0&&x<=b)return n.copy(c);const R=x*p-m*b;if(R<=0&&p>=0&&b<=0)return h=p/(p-b),n.copy(a).addScaledVector(Yr,h);const M=g*b-x*_;if(M<=0&&_-g>=0&&x-b>=0)return p_.subVectors(c,o),h=(_-g)/(_-g+(x-b)),n.copy(o).addScaledVector(p_,h);const S=1/(M+R+v);return u=R*S,h=v*S,n.copy(a).addScaledVector(qr,u).addScaledVector(Yr,h)}equals(t){return t.a.equals(this.a)&&t.b.equals(this.b)&&t.c.equals(this.c)}}class lr{constructor(t=new B(1/0,1/0,1/0),n=new B(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=t,this.max=n}set(t,n){return this.min.copy(t),this.max.copy(n),this}setFromArray(t){this.makeEmpty();for(let n=0,a=t.length;n<a;n+=3)this.expandByPoint(Zi.fromArray(t,n));return this}setFromBufferAttribute(t){this.makeEmpty();for(let n=0,a=t.count;n<a;n++)this.expandByPoint(Zi.fromBufferAttribute(t,n));return this}setFromPoints(t){this.makeEmpty();for(let n=0,a=t.length;n<a;n++)this.expandByPoint(t[n]);return this}setFromCenterAndSize(t,n){const a=Zi.copy(n).multiplyScalar(.5);return this.min.copy(t).sub(a),this.max.copy(t).add(a),this}setFromObject(t,n=!1){return this.makeEmpty(),this.expandByObject(t,n)}clone(){return new this.constructor().copy(this)}copy(t){return this.min.copy(t.min),this.max.copy(t.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(t){return this.isEmpty()?t.set(0,0,0):t.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(t){return this.isEmpty()?t.set(0,0,0):t.subVectors(this.max,this.min)}expandByPoint(t){return this.min.min(t),this.max.max(t),this}expandByVector(t){return this.min.sub(t),this.max.add(t),this}expandByScalar(t){return this.min.addScalar(-t),this.max.addScalar(t),this}expandByObject(t,n=!1){t.updateWorldMatrix(!1,!1);const a=t.geometry;if(a!==void 0){const c=a.getAttribute("position");if(n===!0&&c!==void 0&&t.isInstancedMesh!==!0)for(let u=0,h=c.count;u<h;u++)t.isMesh===!0?t.getVertexPosition(u,Zi):Zi.fromBufferAttribute(c,u),Zi.applyMatrix4(t.matrixWorld),this.expandByPoint(Zi);else t.boundingBox!==void 0?(t.boundingBox===null&&t.computeBoundingBox(),Kc.copy(t.boundingBox)):(a.boundingBox===null&&a.computeBoundingBox(),Kc.copy(a.boundingBox)),Kc.applyMatrix4(t.matrixWorld),this.union(Kc)}const o=t.children;for(let c=0,u=o.length;c<u;c++)this.expandByObject(o[c],n);return this}containsPoint(t){return t.x>=this.min.x&&t.x<=this.max.x&&t.y>=this.min.y&&t.y<=this.max.y&&t.z>=this.min.z&&t.z<=this.max.z}containsBox(t){return this.min.x<=t.min.x&&t.max.x<=this.max.x&&this.min.y<=t.min.y&&t.max.y<=this.max.y&&this.min.z<=t.min.z&&t.max.z<=this.max.z}getParameter(t,n){return n.set((t.x-this.min.x)/(this.max.x-this.min.x),(t.y-this.min.y)/(this.max.y-this.min.y),(t.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(t){return t.max.x>=this.min.x&&t.min.x<=this.max.x&&t.max.y>=this.min.y&&t.min.y<=this.max.y&&t.max.z>=this.min.z&&t.min.z<=this.max.z}intersectsSphere(t){return this.clampPoint(t.center,Zi),Zi.distanceToSquared(t.center)<=t.radius*t.radius}intersectsPlane(t){let n,a;return t.normal.x>0?(n=t.normal.x*this.min.x,a=t.normal.x*this.max.x):(n=t.normal.x*this.max.x,a=t.normal.x*this.min.x),t.normal.y>0?(n+=t.normal.y*this.min.y,a+=t.normal.y*this.max.y):(n+=t.normal.y*this.max.y,a+=t.normal.y*this.min.y),t.normal.z>0?(n+=t.normal.z*this.min.z,a+=t.normal.z*this.max.z):(n+=t.normal.z*this.max.z,a+=t.normal.z*this.min.z),n<=-t.constant&&a>=-t.constant}intersectsTriangle(t){if(this.isEmpty())return!1;this.getCenter(rl),Jc.subVectors(this.max,rl),Zr.subVectors(t.a,rl),Kr.subVectors(t.b,rl),Jr.subVectors(t.c,rl),Ms.subVectors(Kr,Zr),ys.subVectors(Jr,Kr),Xs.subVectors(Zr,Jr);let n=[0,-Ms.z,Ms.y,0,-ys.z,ys.y,0,-Xs.z,Xs.y,Ms.z,0,-Ms.x,ys.z,0,-ys.x,Xs.z,0,-Xs.x,-Ms.y,Ms.x,0,-ys.y,ys.x,0,-Xs.y,Xs.x,0];return!Sd(n,Zr,Kr,Jr,Jc)||(n=[1,0,0,0,1,0,0,0,1],!Sd(n,Zr,Kr,Jr,Jc))?!1:(Qc.crossVectors(Ms,ys),n=[Qc.x,Qc.y,Qc.z],Sd(n,Zr,Kr,Jr,Jc))}clampPoint(t,n){return n.copy(t).clamp(this.min,this.max)}distanceToPoint(t){return this.clampPoint(t,Zi).distanceTo(t)}getBoundingSphere(t){return this.isEmpty()?t.makeEmpty():(this.getCenter(t.center),t.radius=this.getSize(Zi).length()*.5),t}intersect(t){return this.min.max(t.min),this.max.min(t.max),this.isEmpty()&&this.makeEmpty(),this}union(t){return this.min.min(t.min),this.max.max(t.max),this}applyMatrix4(t){return this.isEmpty()?this:(Oa[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(t),Oa[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(t),Oa[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(t),Oa[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(t),Oa[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(t),Oa[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(t),Oa[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(t),Oa[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(t),this.setFromPoints(Oa),this)}translate(t){return this.min.add(t),this.max.add(t),this}equals(t){return t.min.equals(this.min)&&t.max.equals(this.max)}toJSON(){return{min:this.min.toArray(),max:this.max.toArray()}}fromJSON(t){return this.min.fromArray(t.min),this.max.fromArray(t.max),this}}const Oa=[new B,new B,new B,new B,new B,new B,new B,new B],Zi=new B,Kc=new lr,Zr=new B,Kr=new B,Jr=new B,Ms=new B,ys=new B,Xs=new B,rl=new B,Jc=new B,Qc=new B,Ws=new B;function Sd(r,t,n,a,o){for(let c=0,u=r.length-3;c<=u;c+=3){Ws.fromArray(r,c);const h=o.x*Math.abs(Ws.x)+o.y*Math.abs(Ws.y)+o.z*Math.abs(Ws.z),m=t.dot(Ws),p=n.dot(Ws),g=a.dot(Ws);if(Math.max(-Math.max(m,p,g),Math.min(m,p,g))>h)return!1}return!0}const On=new B,jc=new Lt;let B1=0;class qn extends rr{constructor(t,n,a=!1){if(super(),Array.isArray(t))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:B1++}),this.name="",this.array=t,this.itemSize=n,this.count=t!==void 0?t.length/n:0,this.normalized=a,this.usage=Lx,this.updateRanges=[],this.gpuType=Ji,this.version=0}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}setUsage(t){return this.usage=t,this}addUpdateRange(t,n){this.updateRanges.push({start:t,count:n})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.name=t.name,this.array=new t.array.constructor(t.array),this.itemSize=t.itemSize,this.count=t.count,this.normalized=t.normalized,this.usage=t.usage,this.gpuType=t.gpuType,this}copyAt(t,n,a){t*=this.itemSize,a*=n.itemSize;for(let o=0,c=this.itemSize;o<c;o++)this.array[t+o]=n.array[a+o];return this}copyArray(t){return this.array.set(t),this}applyMatrix3(t){if(this.itemSize===2)for(let n=0,a=this.count;n<a;n++)jc.fromBufferAttribute(this,n),jc.applyMatrix3(t),this.setXY(n,jc.x,jc.y);else if(this.itemSize===3)for(let n=0,a=this.count;n<a;n++)On.fromBufferAttribute(this,n),On.applyMatrix3(t),this.setXYZ(n,On.x,On.y,On.z);return this}applyMatrix4(t){for(let n=0,a=this.count;n<a;n++)On.fromBufferAttribute(this,n),On.applyMatrix4(t),this.setXYZ(n,On.x,On.y,On.z);return this}applyNormalMatrix(t){for(let n=0,a=this.count;n<a;n++)On.fromBufferAttribute(this,n),On.applyNormalMatrix(t),this.setXYZ(n,On.x,On.y,On.z);return this}transformDirection(t){for(let n=0,a=this.count;n<a;n++)On.fromBufferAttribute(this,n),On.transformDirection(t),this.setXYZ(n,On.x,On.y,On.z);return this}set(t,n=0){return this.array.set(t,n),this}getComponent(t,n){let a=this.array[t*this.itemSize+n];return this.normalized&&(a=ao(a,this.array)),a}setComponent(t,n,a){return this.normalized&&(a=si(a,this.array)),this.array[t*this.itemSize+n]=a,this}getX(t){let n=this.array[t*this.itemSize];return this.normalized&&(n=ao(n,this.array)),n}setX(t,n){return this.normalized&&(n=si(n,this.array)),this.array[t*this.itemSize]=n,this}getY(t){let n=this.array[t*this.itemSize+1];return this.normalized&&(n=ao(n,this.array)),n}setY(t,n){return this.normalized&&(n=si(n,this.array)),this.array[t*this.itemSize+1]=n,this}getZ(t){let n=this.array[t*this.itemSize+2];return this.normalized&&(n=ao(n,this.array)),n}setZ(t,n){return this.normalized&&(n=si(n,this.array)),this.array[t*this.itemSize+2]=n,this}getW(t){let n=this.array[t*this.itemSize+3];return this.normalized&&(n=ao(n,this.array)),n}setW(t,n){return this.normalized&&(n=si(n,this.array)),this.array[t*this.itemSize+3]=n,this}setXY(t,n,a){return t*=this.itemSize,this.normalized&&(n=si(n,this.array),a=si(a,this.array)),this.array[t+0]=n,this.array[t+1]=a,this}setXYZ(t,n,a,o){return t*=this.itemSize,this.normalized&&(n=si(n,this.array),a=si(a,this.array),o=si(o,this.array)),this.array[t+0]=n,this.array[t+1]=a,this.array[t+2]=o,this}setXYZW(t,n,a,o,c){return t*=this.itemSize,this.normalized&&(n=si(n,this.array),a=si(a,this.array),o=si(o,this.array),c=si(c,this.array)),this.array[t+0]=n,this.array[t+1]=a,this.array[t+2]=o,this.array[t+3]=c,this}onUpload(t){return this.onUploadCallback=t,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const t={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return t.name=this.name,t.usage=this.usage,t.gpuType=this.gpuType,t}dispose(){this.dispatchEvent({type:"dispose"})}}class zx extends qn{constructor(t,n,a){super(new Uint16Array(t),n,a)}}class Ix extends qn{constructor(t,n,a){super(new Uint32Array(t),n,a)}}class ce extends qn{constructor(t,n,a){super(new Float32Array(t),n,a)}}const F1=new lr,ol=new B,Md=new B;class cr{constructor(t=new B,n=-1){this.isSphere=!0,this.center=t,this.radius=n}set(t,n){return this.center.copy(t),this.radius=n,this}setFromPoints(t,n){const a=this.center;n!==void 0?a.copy(n):F1.setFromPoints(t).getCenter(a);let o=0;for(let c=0,u=t.length;c<u;c++)o=Math.max(o,a.distanceToSquared(t[c]));return this.radius=Math.sqrt(o),this}copy(t){return this.center.copy(t.center),this.radius=t.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(t){return t.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(t){return t.distanceTo(this.center)-this.radius}intersectsSphere(t){const n=this.radius+t.radius;return t.center.distanceToSquared(this.center)<=n*n}intersectsBox(t){return t.intersectsSphere(this)}intersectsPlane(t){return Math.abs(t.distanceToPoint(this.center))<=this.radius}clampPoint(t,n){const a=this.center.distanceToSquared(t);return n.copy(t),a>this.radius*this.radius&&(n.sub(this.center).normalize(),n.multiplyScalar(this.radius).add(this.center)),n}getBoundingBox(t){return this.isEmpty()?(t.makeEmpty(),t):(t.set(this.center,this.center),t.expandByScalar(this.radius),t)}applyMatrix4(t){return this.center.applyMatrix4(t),this.radius=this.radius*t.getMaxScaleOnAxis(),this}translate(t){return this.center.add(t),this}expandByPoint(t){if(this.isEmpty())return this.center.copy(t),this.radius=0,this;ol.subVectors(t,this.center);const n=ol.lengthSq();if(n>this.radius*this.radius){const a=Math.sqrt(n),o=(a-this.radius)*.5;this.center.addScaledVector(ol,o/a),this.radius+=o}return this}union(t){return t.isEmpty()?this:this.isEmpty()?(this.copy(t),this):(this.center.equals(t.center)===!0?this.radius=Math.max(this.radius,t.radius):(Md.subVectors(t.center,this.center).setLength(t.radius),this.expandByPoint(ol.copy(t.center).add(Md)),this.expandByPoint(ol.copy(t.center).sub(Md))),this)}equals(t){return t.center.equals(this.center)&&t.radius===this.radius}clone(){return new this.constructor().copy(this)}toJSON(){return{radius:this.radius,center:this.center.toArray()}}fromJSON(t){return this.radius=t.radius,this.center.fromArray(t.center),this}}let H1=0;const Bi=new an,yd=new Mn,Qr=new B,bi=new lr,ll=new lr,Gn=new B;class Ne extends rr{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:H1++}),this.uuid=or(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.indirectOffset=0,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={},this._transformed=!1}getIndex(){return this.index}setIndex(t){return Array.isArray(t)?this.index=new(a1(t)?Ix:zx)(t,1):this.index=t,this}setIndirect(t,n=0){return this.indirect=t,this.indirectOffset=n,this}getIndirect(){return this.indirect}getAttribute(t){return this.attributes[t]}setAttribute(t,n){return this.attributes[t]=n,this}deleteAttribute(t){return delete this.attributes[t],this}hasAttribute(t){return this.attributes[t]!==void 0}addGroup(t,n,a=0){this.groups.push({start:t,count:n,materialIndex:a})}clearGroups(){this.groups=[]}setDrawRange(t,n){this.drawRange.start=t,this.drawRange.count=n}applyMatrix4(t){const n=this.attributes.position;n!==void 0&&(n.applyMatrix4(t),n.needsUpdate=!0);const a=this.attributes.normal;if(a!==void 0){const c=new ye().getNormalMatrix(t);a.applyNormalMatrix(c),a.needsUpdate=!0}const o=this.attributes.tangent;return o!==void 0&&(o.transformDirection(t),o.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this._transformed=!0,this}applyQuaternion(t){return Bi.makeRotationFromQuaternion(t),this.applyMatrix4(Bi),this}rotateX(t){return Bi.makeRotationX(t),this.applyMatrix4(Bi),this}rotateY(t){return Bi.makeRotationY(t),this.applyMatrix4(Bi),this}rotateZ(t){return Bi.makeRotationZ(t),this.applyMatrix4(Bi),this}translate(t,n,a){return Bi.makeTranslation(t,n,a),this.applyMatrix4(Bi),this}scale(t,n,a){return Bi.makeScale(t,n,a),this.applyMatrix4(Bi),this}lookAt(t){return yd.lookAt(t),yd.updateMatrix(),this.applyMatrix4(yd.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Qr).negate(),this.translate(Qr.x,Qr.y,Qr.z),this}setFromPoints(t){const n=this.getAttribute("position");if(n===void 0){const a=[];for(let o=0,c=t.length;o<c;o++){const u=t[o];a.push(u.x,u.y,u.z||0)}this.setAttribute("position",new ce(a,3))}else{const a=Math.min(t.length,n.count);for(let o=0;o<a;o++){const c=t[o];n.setXYZ(o,c.x,c.y,c.z||0)}t.length>n.count&&ve("BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),n.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new lr);const t=this.attributes.position,n=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){We("BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new B(-1/0,-1/0,-1/0),new B(1/0,1/0,1/0));return}if(t!==void 0){if(this.boundingBox.setFromBufferAttribute(t),n)for(let a=0,o=n.length;a<o;a++){const c=n[a];bi.setFromBufferAttribute(c),this.morphTargetsRelative?(Gn.addVectors(this.boundingBox.min,bi.min),this.boundingBox.expandByPoint(Gn),Gn.addVectors(this.boundingBox.max,bi.max),this.boundingBox.expandByPoint(Gn)):(this.boundingBox.expandByPoint(bi.min),this.boundingBox.expandByPoint(bi.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&We('BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new cr);const t=this.attributes.position,n=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){We("BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new B,1/0);return}if(t){const a=this.boundingSphere.center;if(bi.setFromBufferAttribute(t),n)for(let c=0,u=n.length;c<u;c++){const h=n[c];ll.setFromBufferAttribute(h),this.morphTargetsRelative?(Gn.addVectors(bi.min,ll.min),bi.expandByPoint(Gn),Gn.addVectors(bi.max,ll.max),bi.expandByPoint(Gn)):(bi.expandByPoint(ll.min),bi.expandByPoint(ll.max))}bi.getCenter(a);let o=0;for(let c=0,u=t.count;c<u;c++)Gn.fromBufferAttribute(t,c),o=Math.max(o,a.distanceToSquared(Gn));if(n)for(let c=0,u=n.length;c<u;c++){const h=n[c],m=this.morphTargetsRelative;for(let p=0,g=h.count;p<g;p++)Gn.fromBufferAttribute(h,p),m&&(Qr.fromBufferAttribute(t,p),Gn.add(Qr)),o=Math.max(o,a.distanceToSquared(Gn))}this.boundingSphere.radius=Math.sqrt(o),isNaN(this.boundingSphere.radius)&&We('BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const t=this.index,n=this.attributes;if(t===null||n.position===void 0||n.normal===void 0||n.uv===void 0){We("BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const a=n.position,o=n.normal,c=n.uv;let u=this.getAttribute("tangent");(u===void 0||u.count!==a.count)&&(u=new qn(new Float32Array(4*a.count),4),this.setAttribute("tangent",u));const h=[],m=[];for(let T=0;T<a.count;T++)h[T]=new B,m[T]=new B;const p=new B,g=new B,_=new B,v=new Lt,x=new Lt,b=new Lt,R=new B,M=new B;function S(T,z,W){p.fromBufferAttribute(a,T),g.fromBufferAttribute(a,z),_.fromBufferAttribute(a,W),v.fromBufferAttribute(c,T),x.fromBufferAttribute(c,z),b.fromBufferAttribute(c,W),g.sub(p),_.sub(p),x.sub(v),b.sub(v);const J=1/(x.x*b.y-b.x*x.y);isFinite(J)&&(R.copy(g).multiplyScalar(b.y).addScaledVector(_,-x.y).multiplyScalar(J),M.copy(_).multiplyScalar(x.x).addScaledVector(g,-b.x).multiplyScalar(J),h[T].add(R),h[z].add(R),h[W].add(R),m[T].add(M),m[z].add(M),m[W].add(M))}let C=this.groups;C.length===0&&(C=[{start:0,count:t.count}]);for(let T=0,z=C.length;T<z;++T){const W=C[T],J=W.start,Q=W.count;for(let et=J,k=J+Q;et<k;et+=3)S(t.getX(et+0),t.getX(et+1),t.getX(et+2))}const O=new B,E=new B,U=new B,L=new B;function P(T){U.fromBufferAttribute(o,T),L.copy(U);const z=h[T];O.copy(z),O.sub(U.multiplyScalar(U.dot(z))).normalize(),E.crossVectors(L,z);const J=E.dot(m[T])<0?-1:1;u.setXYZW(T,O.x,O.y,O.z,J)}for(let T=0,z=C.length;T<z;++T){const W=C[T],J=W.start,Q=W.count;for(let et=J,k=J+Q;et<k;et+=3)P(t.getX(et+0)),P(t.getX(et+1)),P(t.getX(et+2))}this._transformed=!0}computeVertexNormals(){const t=this.index,n=this.getAttribute("position");if(n!==void 0){let a=this.getAttribute("normal");if(a===void 0||a.count!==n.count)a=new qn(new Float32Array(n.count*3),3),this.setAttribute("normal",a);else for(let v=0,x=a.count;v<x;v++)a.setXYZ(v,0,0,0);const o=new B,c=new B,u=new B,h=new B,m=new B,p=new B,g=new B,_=new B;if(t)for(let v=0,x=t.count;v<x;v+=3){const b=t.getX(v+0),R=t.getX(v+1),M=t.getX(v+2);o.fromBufferAttribute(n,b),c.fromBufferAttribute(n,R),u.fromBufferAttribute(n,M),g.subVectors(u,c),_.subVectors(o,c),g.cross(_),h.fromBufferAttribute(a,b),m.fromBufferAttribute(a,R),p.fromBufferAttribute(a,M),h.add(g),m.add(g),p.add(g),a.setXYZ(b,h.x,h.y,h.z),a.setXYZ(R,m.x,m.y,m.z),a.setXYZ(M,p.x,p.y,p.z)}else for(let v=0,x=n.count;v<x;v+=3)o.fromBufferAttribute(n,v+0),c.fromBufferAttribute(n,v+1),u.fromBufferAttribute(n,v+2),g.subVectors(u,c),_.subVectors(o,c),g.cross(_),a.setXYZ(v+0,g.x,g.y,g.z),a.setXYZ(v+1,g.x,g.y,g.z),a.setXYZ(v+2,g.x,g.y,g.z);this.normalizeNormals(),a.needsUpdate=!0}}normalizeNormals(){const t=this.attributes.normal;for(let n=0,a=t.count;n<a;n++)Gn.fromBufferAttribute(t,n),Gn.normalize(),t.setXYZ(n,Gn.x,Gn.y,Gn.z)}toNonIndexed(){function t(h,m){const p=h.array,g=h.itemSize,_=h.normalized,v=new p.constructor(m.length*g);let x=0,b=0;for(let R=0,M=m.length;R<M;R++){h.isInterleavedBufferAttribute?x=m[R]*h.data.stride+h.offset:x=m[R]*g;for(let S=0;S<g;S++)v[b++]=p[x++]}return new qn(v,g,_)}if(this.index===null)return ve("BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const n=new Ne,a=this.index.array,o=this.attributes;for(const h in o){const m=o[h],p=t(m,a);n.setAttribute(h,p)}const c=this.morphAttributes;for(const h in c){const m=[],p=c[h];for(let g=0,_=p.length;g<_;g++){const v=p[g],x=t(v,a);m.push(x)}n.morphAttributes[h]=m}n.morphTargetsRelative=this.morphTargetsRelative;const u=this.groups;for(let h=0,m=u.length;h<m;h++){const p=u[h];n.addGroup(p.start,p.count,p.materialIndex)}return n}toJSON(){const t={metadata:{version:4.7,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(t.uuid=this.uuid,t.type=this.parameters!==void 0&&this._transformed===!0?"BufferGeometry":this.type,t.name=this.name,Object.keys(this.userData).length>0&&(t.userData=this.userData),this.parameters!==void 0&&this._transformed!==!0){const m=this.parameters;for(const p in m)m[p]!==void 0&&(t[p]=m[p]);return t}t.data={attributes:{}};const n=this.index;n!==null&&(t.data.index={type:n.array.constructor.name,array:Array.prototype.slice.call(n.array)});const a=this.attributes;for(const m in a){const p=a[m];t.data.attributes[m]=p.toJSON(t.data)}const o={};let c=!1;for(const m in this.morphAttributes){const p=this.morphAttributes[m],g=[];for(let _=0,v=p.length;_<v;_++){const x=p[_];g.push(x.toJSON(t.data))}g.length>0&&(o[m]=g,c=!0)}c&&(t.data.morphAttributes=o,t.data.morphTargetsRelative=this.morphTargetsRelative);const u=this.groups;u.length>0&&(t.data.groups=JSON.parse(JSON.stringify(u)));const h=this.boundingSphere;return h!==null&&(t.data.boundingSphere=h.toJSON()),t}clone(){return new this.constructor().copy(this)}copy(t){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const n={};this.name=t.name;const a=t.index;a!==null&&this.setIndex(a.clone());const o=t.attributes;for(const p in o){const g=o[p];this.setAttribute(p,g.clone(n))}const c=t.morphAttributes;for(const p in c){const g=[],_=c[p];for(let v=0,x=_.length;v<x;v++)g.push(_[v].clone(n));this.morphAttributes[p]=g}this.morphTargetsRelative=t.morphTargetsRelative;const u=t.groups;for(let p=0,g=u.length;p<g;p++){const _=u[p];this.addGroup(_.start,_.count,_.materialIndex)}const h=t.boundingBox;h!==null&&(this.boundingBox=h.clone());const m=t.boundingSphere;return m!==null&&(this.boundingSphere=m.clone()),this.drawRange.start=t.drawRange.start,this.drawRange.count=t.drawRange.count,this.userData=t.userData,this._transformed=t._transformed,this}dispose(){this.dispatchEvent({type:"dispose"})}}const bd=new B,G1=new B,V1=new ye;class Es{constructor(t=new B(1,0,0),n=0){this.isPlane=!0,this.normal=t,this.constant=n}set(t,n){return this.normal.copy(t),this.constant=n,this}setComponents(t,n,a,o){return this.normal.set(t,n,a),this.constant=o,this}setFromNormalAndCoplanarPoint(t,n){return this.normal.copy(t),this.constant=-n.dot(this.normal),this}setFromCoplanarPoints(t,n,a){const o=bd.subVectors(a,n).cross(G1.subVectors(t,n)).normalize();return this.setFromNormalAndCoplanarPoint(o,t),this}copy(t){return this.normal.copy(t.normal),this.constant=t.constant,this}normalize(){const t=1/this.normal.length();return this.normal.multiplyScalar(t),this.constant*=t,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(t){return this.normal.dot(t)+this.constant}distanceToSphere(t){return this.distanceToPoint(t.center)-t.radius}projectPoint(t,n){return n.copy(t).addScaledVector(this.normal,-this.distanceToPoint(t))}intersectLine(t,n,a=!0){const o=t.delta(bd),c=this.normal.dot(o);if(c===0)return this.distanceToPoint(t.start)===0?n.copy(t.start):null;const u=-(t.start.dot(this.normal)+this.constant)/c;return a===!0&&(u<0||u>1)?null:n.copy(t.start).addScaledVector(o,u)}intersectsLine(t){const n=this.distanceToPoint(t.start),a=this.distanceToPoint(t.end);return n<0&&a>0||a<0&&n>0}intersectsBox(t){return t.intersectsPlane(this)}intersectsSphere(t){return t.intersectsPlane(this)}coplanarPoint(t){return t.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(t,n){const a=n||V1.getNormalMatrix(t),o=this.coplanarPoint(bd).applyMatrix4(t),c=this.normal.applyMatrix3(a).normalize();return this.constant=-o.dot(c),this}translate(t){return this.constant-=t.dot(this.normal),this}equals(t){return t.normal.equals(this.normal)&&t.constant===this.constant}clone(){return new this.constructor().copy(this)}toJSON(){return{normal:this.normal.toArray(),constant:this.constant}}fromJSON(t){return this.normal.fromArray(t.normal),this.constant=t.constant,this}}let k1=0;class ur extends rr{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:k1++}),this.uuid=or(),this.name="",this.type="Material",this.blending=vl,this.side=$s,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=gx,this.blendDst=vx,this.blendEquation=io,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new ue(0,0,0),this.blendAlpha=0,this.depthFunc=bl,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=Qy,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=sd,this.stencilZFail=sd,this.stencilZPass=sd,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.allowOverride=!0,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(t){this._alphaTest>0!=t>0&&this.version++,this._alphaTest=t}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(t){if(t!==void 0)for(const n in t){const a=t[n];if(a===void 0){ve(`Material: parameter '${n}' has value of undefined.`);continue}const o=this[n];if(o===void 0){ve(`Material: '${n}' is not a property of THREE.${this.type}.`);continue}o&&o.isColor?o.set(a):o&&o.isVector2&&a&&a.isVector2||o&&o.isEuler&&a&&a.isEuler||o&&o.isVector3&&a&&a.isVector3?o.copy(a):this[n]=a}}toJSON(t){const n=t===void 0||typeof t=="string";n&&(t={textures:{},images:{}});const a={metadata:{version:4.7,type:"Material",generator:"Material.toJSON"}};a.uuid=this.uuid,a.type=this.type,a.blending=this.blending,a.side=this.side,a.shadowSide=this.shadowSide,a.vertexColors=this.vertexColors,a.opacity=this.opacity,a.transparent=this.transparent,a.blendSrc=this.blendSrc,a.blendDst=this.blendDst,a.blendEquation=this.blendEquation,a.blendSrcAlpha=this.blendSrcAlpha,a.blendDstAlpha=this.blendDstAlpha,a.blendEquationAlpha=this.blendEquationAlpha,a.blendColor=this.blendColor.getHex(),a.blendAlpha=this.blendAlpha,a.depthFunc=this.depthFunc,a.depthTest=this.depthTest,a.depthWrite=this.depthWrite,a.colorWrite=this.colorWrite,a.clipIntersection=this.clipIntersection,a.clipShadows=this.clipShadows,a.stencilWriteMask=this.stencilWriteMask,a.stencilFunc=this.stencilFunc,a.stencilRef=this.stencilRef,a.stencilFuncMask=this.stencilFuncMask,a.stencilFail=this.stencilFail,a.stencilZFail=this.stencilZFail,a.stencilZPass=this.stencilZPass,a.stencilWrite=this.stencilWrite,a.polygonOffset=this.polygonOffset,a.polygonOffsetFactor=this.polygonOffsetFactor,a.polygonOffsetUnits=this.polygonOffsetUnits,a.dithering=this.dithering,a.alphaTest=this.alphaTest,a.alphaHash=this.alphaHash,a.alphaToCoverage=this.alphaToCoverage,a.premultipliedAlpha=this.premultipliedAlpha,a.forceSinglePass=this.forceSinglePass,a.allowOverride=this.allowOverride,a.visible=this.visible,a.toneMapped=this.toneMapped,a.name=this.name,this.color&&this.color.isColor&&(a.color=this.color.getHex()),this.roughness!==void 0&&(a.roughness=this.roughness),this.metalness!==void 0&&(a.metalness=this.metalness),this.sheen!==void 0&&(a.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(a.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(a.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(a.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&(a.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(a.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(a.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(a.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(a.shininess=this.shininess),this.clearcoat!==void 0&&(a.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(a.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(a.clearcoatMap=this.clearcoatMap.toJSON(t).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(a.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(t).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(a.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(t).uuid,a.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.sheenColorMap&&this.sheenColorMap.isTexture&&(a.sheenColorMap=this.sheenColorMap.toJSON(t).uuid),this.sheenRoughnessMap&&this.sheenRoughnessMap.isTexture&&(a.sheenRoughnessMap=this.sheenRoughnessMap.toJSON(t).uuid),this.dispersion!==void 0&&(a.dispersion=this.dispersion),this.retroreflectivity!==void 0&&(a.retroreflectivity=this.retroreflectivity),this.iridescence!==void 0&&(a.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(a.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(a.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(a.iridescenceMap=this.iridescenceMap.toJSON(t).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(a.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(t).uuid),this.anisotropy!==void 0&&(a.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(a.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(a.anisotropyMap=this.anisotropyMap.toJSON(t).uuid),this.map&&this.map.isTexture&&(a.map=this.map.toJSON(t).uuid),this.matcap&&this.matcap.isTexture&&(a.matcap=this.matcap.toJSON(t).uuid),this.alphaMap&&this.alphaMap.isTexture&&(a.alphaMap=this.alphaMap.toJSON(t).uuid),this.lightMap&&this.lightMap.isTexture&&(a.lightMap=this.lightMap.toJSON(t).uuid,a.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(a.aoMap=this.aoMap.toJSON(t).uuid,a.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(a.bumpMap=this.bumpMap.toJSON(t).uuid,a.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(a.normalMap=this.normalMap.toJSON(t).uuid,a.normalMapType=this.normalMapType,a.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(a.displacementMap=this.displacementMap.toJSON(t).uuid,a.displacementScale=this.displacementScale,a.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(a.roughnessMap=this.roughnessMap.toJSON(t).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(a.metalnessMap=this.metalnessMap.toJSON(t).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(a.emissiveMap=this.emissiveMap.toJSON(t).uuid),this.specularMap&&this.specularMap.isTexture&&(a.specularMap=this.specularMap.toJSON(t).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(a.specularIntensityMap=this.specularIntensityMap.toJSON(t).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(a.specularColorMap=this.specularColorMap.toJSON(t).uuid),this.envMap&&this.envMap.isTexture&&(a.envMap=this.envMap.toJSON(t).uuid,this.combine!==void 0&&(a.combine=this.combine)),this.envMapRotation!==void 0&&(a.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(a.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(a.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(a.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(a.gradientMap=this.gradientMap.toJSON(t).uuid),this.transmission!==void 0&&(a.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(a.transmissionMap=this.transmissionMap.toJSON(t).uuid),this.thickness!==void 0&&(a.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(a.thicknessMap=this.thicknessMap.toJSON(t).uuid),this.attenuationDistance!==void 0&&(a.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(a.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(a.size=this.size),this.sizeAttenuation!==void 0&&(a.sizeAttenuation=this.sizeAttenuation),Array.isArray(this.clippingPlanes)&&this.clippingPlanes.length>0&&(a.clippingPlanes=this.clippingPlanes.map(c=>c.toJSON())),this.rotation!==void 0&&(a.rotation=this.rotation),this.depthPacking!==void 0&&(a.depthPacking=this.depthPacking),this.linewidth!==void 0&&(a.linewidth=this.linewidth),this.linecap!==void 0&&(a.linecap=this.linecap),this.linejoin!==void 0&&(a.linejoin=this.linejoin),this.dashSize!==void 0&&(a.dashSize=this.dashSize),this.gapSize!==void 0&&(a.gapSize=this.gapSize),this.scale!==void 0&&(a.scale=this.scale),this.wireframe!==void 0&&(a.wireframe=this.wireframe),this.wireframeLinewidth!==void 0&&(a.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!==void 0&&(a.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!==void 0&&(a.wireframeLinejoin=this.wireframeLinejoin),this.flatShading!==void 0&&(a.flatShading=this.flatShading),this.fog!==void 0&&(a.fog=this.fog),Object.keys(this.userData).length>0&&(a.userData=this.userData);function o(c){const u=[];for(const h in c){const m=c[h];delete m.metadata,u.push(m)}return u}if(n){const c=o(t.textures),u=o(t.images);c.length>0&&(a.textures=c),u.length>0&&(a.images=u)}return a}fromJSON(t,n){if(t.uuid!==void 0&&(this.uuid=t.uuid),t.name!==void 0&&(this.name=t.name),t.color!==void 0&&this.color!==void 0&&this.color.setHex(t.color),t.roughness!==void 0&&(this.roughness=t.roughness),t.metalness!==void 0&&(this.metalness=t.metalness),t.sheen!==void 0&&(this.sheen=t.sheen),t.sheenColor!==void 0&&(this.sheenColor=new ue().setHex(t.sheenColor)),t.sheenRoughness!==void 0&&(this.sheenRoughness=t.sheenRoughness),t.emissive!==void 0&&this.emissive!==void 0&&this.emissive.setHex(t.emissive),t.specular!==void 0&&this.specular!==void 0&&this.specular.setHex(t.specular),t.specularIntensity!==void 0&&(this.specularIntensity=t.specularIntensity),t.specularColor!==void 0&&this.specularColor!==void 0&&this.specularColor.setHex(t.specularColor),t.shininess!==void 0&&(this.shininess=t.shininess),t.clearcoat!==void 0&&(this.clearcoat=t.clearcoat),t.clearcoatRoughness!==void 0&&(this.clearcoatRoughness=t.clearcoatRoughness),t.dispersion!==void 0&&(this.dispersion=t.dispersion),t.retroreflectivity!==void 0&&(this.retroreflectivity=t.retroreflectivity),t.iridescence!==void 0&&(this.iridescence=t.iridescence),t.iridescenceIOR!==void 0&&(this.iridescenceIOR=t.iridescenceIOR),t.iridescenceThicknessRange!==void 0&&(this.iridescenceThicknessRange=t.iridescenceThicknessRange),t.transmission!==void 0&&(this.transmission=t.transmission),t.thickness!==void 0&&(this.thickness=t.thickness),t.attenuationDistance!==void 0&&(this.attenuationDistance=t.attenuationDistance),t.attenuationColor!==void 0&&this.attenuationColor!==void 0&&this.attenuationColor.setHex(t.attenuationColor),t.anisotropy!==void 0&&(this.anisotropy=t.anisotropy),t.anisotropyRotation!==void 0&&(this.anisotropyRotation=t.anisotropyRotation),t.fog!==void 0&&(this.fog=t.fog),t.flatShading!==void 0&&(this.flatShading=t.flatShading),t.blending!==void 0&&(this.blending=t.blending),t.combine!==void 0&&(this.combine=t.combine),t.side!==void 0&&(this.side=t.side),t.shadowSide!==void 0&&(this.shadowSide=t.shadowSide),t.opacity!==void 0&&(this.opacity=t.opacity),t.transparent!==void 0&&(this.transparent=t.transparent),t.alphaTest!==void 0&&(this.alphaTest=t.alphaTest),t.alphaHash!==void 0&&(this.alphaHash=t.alphaHash),t.depthFunc!==void 0&&(this.depthFunc=t.depthFunc),t.depthTest!==void 0&&(this.depthTest=t.depthTest),t.depthWrite!==void 0&&(this.depthWrite=t.depthWrite),t.colorWrite!==void 0&&(this.colorWrite=t.colorWrite),t.clippingPlanes!==void 0&&(this.clippingPlanes=t.clippingPlanes.map(a=>new Es().fromJSON(a))),t.clipIntersection!==void 0&&(this.clipIntersection=t.clipIntersection),t.clipShadows!==void 0&&(this.clipShadows=t.clipShadows),t.depthPacking!==void 0&&(this.depthPacking=t.depthPacking),t.blendSrc!==void 0&&(this.blendSrc=t.blendSrc),t.blendDst!==void 0&&(this.blendDst=t.blendDst),t.blendEquation!==void 0&&(this.blendEquation=t.blendEquation),t.blendSrcAlpha!==void 0&&(this.blendSrcAlpha=t.blendSrcAlpha),t.blendDstAlpha!==void 0&&(this.blendDstAlpha=t.blendDstAlpha),t.blendEquationAlpha!==void 0&&(this.blendEquationAlpha=t.blendEquationAlpha),t.blendColor!==void 0&&this.blendColor!==void 0&&this.blendColor.setHex(t.blendColor),t.blendAlpha!==void 0&&(this.blendAlpha=t.blendAlpha),t.stencilWriteMask!==void 0&&(this.stencilWriteMask=t.stencilWriteMask),t.stencilFunc!==void 0&&(this.stencilFunc=t.stencilFunc),t.stencilRef!==void 0&&(this.stencilRef=t.stencilRef),t.stencilFuncMask!==void 0&&(this.stencilFuncMask=t.stencilFuncMask),t.stencilFail!==void 0&&(this.stencilFail=t.stencilFail),t.stencilZFail!==void 0&&(this.stencilZFail=t.stencilZFail),t.stencilZPass!==void 0&&(this.stencilZPass=t.stencilZPass),t.stencilWrite!==void 0&&(this.stencilWrite=t.stencilWrite),t.wireframe!==void 0&&(this.wireframe=t.wireframe),t.wireframeLinewidth!==void 0&&(this.wireframeLinewidth=t.wireframeLinewidth),t.wireframeLinecap!==void 0&&(this.wireframeLinecap=t.wireframeLinecap),t.wireframeLinejoin!==void 0&&(this.wireframeLinejoin=t.wireframeLinejoin),t.rotation!==void 0&&(this.rotation=t.rotation),t.linewidth!==void 0&&(this.linewidth=t.linewidth),t.linecap!==void 0&&(this.linecap=t.linecap),t.linejoin!==void 0&&(this.linejoin=t.linejoin),t.dashSize!==void 0&&(this.dashSize=t.dashSize),t.gapSize!==void 0&&(this.gapSize=t.gapSize),t.scale!==void 0&&(this.scale=t.scale),t.polygonOffset!==void 0&&(this.polygonOffset=t.polygonOffset),t.polygonOffsetFactor!==void 0&&(this.polygonOffsetFactor=t.polygonOffsetFactor),t.polygonOffsetUnits!==void 0&&(this.polygonOffsetUnits=t.polygonOffsetUnits),t.dithering!==void 0&&(this.dithering=t.dithering),t.alphaToCoverage!==void 0&&(this.alphaToCoverage=t.alphaToCoverage),t.premultipliedAlpha!==void 0&&(this.premultipliedAlpha=t.premultipliedAlpha),t.forceSinglePass!==void 0&&(this.forceSinglePass=t.forceSinglePass),t.allowOverride!==void 0&&(this.allowOverride=t.allowOverride),t.visible!==void 0&&(this.visible=t.visible),t.toneMapped!==void 0&&(this.toneMapped=t.toneMapped),t.userData!==void 0&&(this.userData=t.userData),t.vertexColors!==void 0&&(typeof t.vertexColors=="number"?this.vertexColors=t.vertexColors>0:this.vertexColors=t.vertexColors),t.size!==void 0&&(this.size=t.size),t.sizeAttenuation!==void 0&&(this.sizeAttenuation=t.sizeAttenuation),t.map!==void 0&&(this.map=n[t.map]||null),t.matcap!==void 0&&(this.matcap=n[t.matcap]||null),t.alphaMap!==void 0&&(this.alphaMap=n[t.alphaMap]||null),t.bumpMap!==void 0&&(this.bumpMap=n[t.bumpMap]||null),t.bumpScale!==void 0&&(this.bumpScale=t.bumpScale),t.normalMap!==void 0&&(this.normalMap=n[t.normalMap]||null),t.normalMapType!==void 0&&(this.normalMapType=t.normalMapType),t.normalScale!==void 0){let a=t.normalScale;Array.isArray(a)===!1&&(a=[a,a]),this.normalScale=new Lt().fromArray(a)}return t.displacementMap!==void 0&&(this.displacementMap=n[t.displacementMap]||null),t.displacementScale!==void 0&&(this.displacementScale=t.displacementScale),t.displacementBias!==void 0&&(this.displacementBias=t.displacementBias),t.roughnessMap!==void 0&&(this.roughnessMap=n[t.roughnessMap]||null),t.metalnessMap!==void 0&&(this.metalnessMap=n[t.metalnessMap]||null),t.emissiveMap!==void 0&&(this.emissiveMap=n[t.emissiveMap]||null),t.emissiveIntensity!==void 0&&(this.emissiveIntensity=t.emissiveIntensity),t.specularMap!==void 0&&(this.specularMap=n[t.specularMap]||null),t.specularIntensityMap!==void 0&&(this.specularIntensityMap=n[t.specularIntensityMap]||null),t.specularColorMap!==void 0&&(this.specularColorMap=n[t.specularColorMap]||null),t.envMap!==void 0&&(this.envMap=n[t.envMap]||null),t.envMapRotation!==void 0&&this.envMapRotation.fromArray(t.envMapRotation),t.envMapIntensity!==void 0&&(this.envMapIntensity=t.envMapIntensity),t.reflectivity!==void 0&&(this.reflectivity=t.reflectivity),t.refractionRatio!==void 0&&(this.refractionRatio=t.refractionRatio),t.lightMap!==void 0&&(this.lightMap=n[t.lightMap]||null),t.lightMapIntensity!==void 0&&(this.lightMapIntensity=t.lightMapIntensity),t.aoMap!==void 0&&(this.aoMap=n[t.aoMap]||null),t.aoMapIntensity!==void 0&&(this.aoMapIntensity=t.aoMapIntensity),t.gradientMap!==void 0&&(this.gradientMap=n[t.gradientMap]||null),t.clearcoatMap!==void 0&&(this.clearcoatMap=n[t.clearcoatMap]||null),t.clearcoatRoughnessMap!==void 0&&(this.clearcoatRoughnessMap=n[t.clearcoatRoughnessMap]||null),t.clearcoatNormalMap!==void 0&&(this.clearcoatNormalMap=n[t.clearcoatNormalMap]||null),t.clearcoatNormalScale!==void 0&&(this.clearcoatNormalScale=new Lt().fromArray(t.clearcoatNormalScale)),t.iridescenceMap!==void 0&&(this.iridescenceMap=n[t.iridescenceMap]||null),t.iridescenceThicknessMap!==void 0&&(this.iridescenceThicknessMap=n[t.iridescenceThicknessMap]||null),t.transmissionMap!==void 0&&(this.transmissionMap=n[t.transmissionMap]||null),t.thicknessMap!==void 0&&(this.thicknessMap=n[t.thicknessMap]||null),t.anisotropyMap!==void 0&&(this.anisotropyMap=n[t.anisotropyMap]||null),t.sheenColorMap!==void 0&&(this.sheenColorMap=n[t.sheenColorMap]||null),t.sheenRoughnessMap!==void 0&&(this.sheenRoughnessMap=n[t.sheenRoughnessMap]||null),this}clone(){return new this.constructor().copy(this)}copy(t){this.name=t.name,this.blending=t.blending,this.side=t.side,this.vertexColors=t.vertexColors,this.opacity=t.opacity,this.transparent=t.transparent,this.blendSrc=t.blendSrc,this.blendDst=t.blendDst,this.blendEquation=t.blendEquation,this.blendSrcAlpha=t.blendSrcAlpha,this.blendDstAlpha=t.blendDstAlpha,this.blendEquationAlpha=t.blendEquationAlpha,this.blendColor.copy(t.blendColor),this.blendAlpha=t.blendAlpha,this.depthFunc=t.depthFunc,this.depthTest=t.depthTest,this.depthWrite=t.depthWrite,this.stencilWriteMask=t.stencilWriteMask,this.stencilFunc=t.stencilFunc,this.stencilRef=t.stencilRef,this.stencilFuncMask=t.stencilFuncMask,this.stencilFail=t.stencilFail,this.stencilZFail=t.stencilZFail,this.stencilZPass=t.stencilZPass,this.stencilWrite=t.stencilWrite;const n=t.clippingPlanes;let a=null;if(n!==null){const o=n.length;a=new Array(o);for(let c=0;c!==o;++c)a[c]=n[c].clone()}return this.clippingPlanes=a,this.clipIntersection=t.clipIntersection,this.clipShadows=t.clipShadows,this.shadowSide=t.shadowSide,this.colorWrite=t.colorWrite,this.precision=t.precision,this.polygonOffset=t.polygonOffset,this.polygonOffsetFactor=t.polygonOffsetFactor,this.polygonOffsetUnits=t.polygonOffsetUnits,this.dithering=t.dithering,this.alphaTest=t.alphaTest,this.alphaHash=t.alphaHash,this.alphaToCoverage=t.alphaToCoverage,this.premultipliedAlpha=t.premultipliedAlpha,this.forceSinglePass=t.forceSinglePass,this.allowOverride=t.allowOverride,this.visible=t.visible,this.toneMapped=t.toneMapped,this.userData=JSON.parse(JSON.stringify(t.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(t){t===!0&&this.version++}}const Pa=new B,Ed=new B,$c=new B,tu=new B;class Iu{constructor(t=new B,n=new B(0,0,-1)){this.origin=t,this.direction=n}set(t,n){return this.origin.copy(t),this.direction.copy(n),this}copy(t){return this.origin.copy(t.origin),this.direction.copy(t.direction),this}at(t,n){return n.copy(this.origin).addScaledVector(this.direction,t)}lookAt(t){return this.direction.copy(t).sub(this.origin).normalize(),this}recast(t){return this.origin.copy(this.at(t,Pa)),this}closestPointToPoint(t,n){n.subVectors(t,this.origin);const a=n.dot(this.direction);return a<0?n.copy(this.origin):n.copy(this.origin).addScaledVector(this.direction,a)}distanceToPoint(t){return Math.sqrt(this.distanceSqToPoint(t))}distanceSqToPoint(t){const n=Pa.subVectors(t,this.origin).dot(this.direction);return n<0?this.origin.distanceToSquared(t):(Pa.copy(this.origin).addScaledVector(this.direction,n),Pa.distanceToSquared(t))}distanceSqToSegment(t,n,a,o){Ed.copy(t).add(n).multiplyScalar(.5),$c.copy(n).sub(t).normalize(),tu.copy(this.origin).sub(Ed);const c=t.distanceTo(n)*.5,u=-this.direction.dot($c),h=tu.dot(this.direction),m=-tu.dot($c),p=tu.lengthSq(),g=Math.abs(1-u*u);let _,v,x,b;if(g>0)if(_=u*m-h,v=u*h-m,b=c*g,_>=0)if(v>=-b)if(v<=b){const R=1/g;_*=R,v*=R,x=_*(_+u*v+2*h)+v*(u*_+v+2*m)+p}else v=c,_=Math.max(0,-(u*v+h)),x=-_*_+v*(v+2*m)+p;else v=-c,_=Math.max(0,-(u*v+h)),x=-_*_+v*(v+2*m)+p;else v<=-b?(_=Math.max(0,-(-u*c+h)),v=_>0?-c:Math.min(Math.max(-c,-m),c),x=-_*_+v*(v+2*m)+p):v<=b?(_=0,v=Math.min(Math.max(-c,-m),c),x=v*(v+2*m)+p):(_=Math.max(0,-(u*c+h)),v=_>0?c:Math.min(Math.max(-c,-m),c),x=-_*_+v*(v+2*m)+p);else v=u>0?-c:c,_=Math.max(0,-(u*v+h)),x=-_*_+v*(v+2*m)+p;return a&&a.copy(this.origin).addScaledVector(this.direction,_),o&&o.copy(Ed).addScaledVector($c,v),x}intersectSphere(t,n){if(t.radius<0)return null;Pa.subVectors(t.center,this.origin);const a=Pa.dot(this.direction),o=Pa.dot(Pa)-a*a,c=t.radius*t.radius;if(o>c)return null;const u=Math.sqrt(c-o),h=a-u,m=a+u;return m<0?null:h<0?this.at(m,n):this.at(h,n)}intersectsSphere(t){return t.radius<0?!1:this.distanceSqToPoint(t.center)<=t.radius*t.radius}distanceToPlane(t){const n=t.normal.dot(this.direction);if(n===0)return t.distanceToPoint(this.origin)===0?0:null;const a=-(this.origin.dot(t.normal)+t.constant)/n;return a>=0?a:null}intersectPlane(t,n){const a=this.distanceToPlane(t);return a===null?null:this.at(a,n)}intersectsPlane(t){const n=t.distanceToPoint(this.origin);return n===0||t.normal.dot(this.direction)*n<0}intersectBox(t,n){let a,o,c,u,h,m;const p=1/this.direction.x,g=1/this.direction.y,_=1/this.direction.z,v=this.origin;return p>=0?(a=(t.min.x-v.x)*p,o=(t.max.x-v.x)*p):(a=(t.max.x-v.x)*p,o=(t.min.x-v.x)*p),g>=0?(c=(t.min.y-v.y)*g,u=(t.max.y-v.y)*g):(c=(t.max.y-v.y)*g,u=(t.min.y-v.y)*g),a>u||c>o||((c>a||isNaN(a))&&(a=c),(u<o||isNaN(o))&&(o=u),_>=0?(h=(t.min.z-v.z)*_,m=(t.max.z-v.z)*_):(h=(t.max.z-v.z)*_,m=(t.min.z-v.z)*_),a>m||h>o)||((h>a||a!==a)&&(a=h),(m<o||o!==o)&&(o=m),o<0)?null:this.at(a>=0?a:o,n)}intersectsBox(t){return this.intersectBox(t,Pa)!==null}intersectTriangle(t,n,a,o,c){const u=this.origin,h=this.direction,m=h.x,p=h.y,g=h.z,_=t.x-u.x,v=t.y-u.y,x=t.z-u.z,b=n.x-u.x,R=n.y-u.y,M=n.z-u.z,S=a.x-u.x,C=a.y-u.y,O=a.z-u.z,E=Math.abs(m),U=Math.abs(p),L=Math.abs(g);let P,T,z,W,J,Q,et,k,q,F,Z,ht;if(E>=U&&E>=L?(z=m,Q=_,q=b,ht=S,m>=0?(P=p,T=g,W=v,J=x,et=R,k=M,F=C,Z=O):(P=g,T=p,W=x,J=v,et=M,k=R,F=O,Z=C)):U>=L?(z=p,Q=v,q=R,ht=C,p>=0?(P=g,T=m,W=x,J=_,et=M,k=b,F=O,Z=S):(P=m,T=g,W=_,J=x,et=b,k=M,F=S,Z=O)):(z=g,Q=x,q=M,ht=O,g>=0?(P=m,T=p,W=_,J=v,et=b,k=R,F=S,Z=C):(P=p,T=m,W=v,J=_,et=R,k=b,F=C,Z=S)),z===0)return null;const dt=P/z,pt=T/z,I=1/z,ct=W-dt*Q,At=J-pt*Q,It=et-dt*q,kt=k-pt*q,zt=F-dt*ht,ut=Z-pt*ht,Tt=zt*kt-ut*It,Ht=ct*ut-At*zt,ie=It*At-kt*ct;if(o){if(Tt<0||Ht<0||ie<0)return null}else if((Tt<0||Ht<0||ie<0)&&(Tt>0||Ht>0||ie>0))return null;const qt=Tt+Ht+ie;if(qt===0)return null;const re=I*(Tt*Q+Ht*q+ie*ht);return(qt>0?re<0:re>0)?null:this.at(re/qt,c)}applyMatrix4(t){return this.origin.applyMatrix4(t),this.direction.transformDirection(t),this}equals(t){return t.origin.equals(this.origin)&&t.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class Fa extends ur{constructor(t){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new ue(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Xa,this.combine=_x,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.specularMap=t.specularMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapRotation.copy(t.envMapRotation),this.combine=t.combine,this.reflectivity=t.reflectivity,this.refractionRatio=t.refractionRatio,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.fog=t.fog,this}}const m_=new an,qs=new Iu,eu=new cr,g_=new B,nu=new B,iu=new B,au=new B,Td=new B,su=new B,v_=new B,ru=new B;class le extends Mn{constructor(t=new Ne,n=new Fa){super(),this.isMesh=!0,this.type="Mesh",this.geometry=t,this.material=n,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.count=1,this.updateMorphTargets()}copy(t,n){return super.copy(t,n),t.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=t.morphTargetInfluences.slice()),t.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},t.morphTargetDictionary)),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}updateMorphTargets(){const n=this.geometry.morphAttributes,a=Object.keys(n);if(a.length>0){const o=n[a[0]];if(o!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let c=0,u=o.length;c<u;c++){const h=o[c].name||String(c);this.morphTargetInfluences.push(0),this.morphTargetDictionary[h]=c}}}}getVertexPosition(t,n){const a=this.geometry,o=a.attributes.position,c=a.morphAttributes.position,u=a.morphTargetsRelative;n.fromBufferAttribute(o,t);const h=this.morphTargetInfluences;if(c&&h){su.set(0,0,0);for(let m=0,p=c.length;m<p;m++){const g=h[m],_=c[m];g!==0&&(Td.fromBufferAttribute(_,t),u?su.addScaledVector(Td,g):su.addScaledVector(Td.sub(n),g))}n.add(su)}return n}intersectsFrustum(t){return t.intersectsObject(this)}raycast(t,n){const a=this.geometry,o=this.material,c=this.matrixWorld;o!==void 0&&(a.boundingSphere===null&&a.computeBoundingSphere(),eu.copy(a.boundingSphere),eu.applyMatrix4(c),qs.copy(t.ray).recast(t.near),!(eu.containsPoint(qs.origin)===!1&&(qs.intersectSphere(eu,g_)===null||qs.origin.distanceToSquared(g_)>(t.far-t.near)**2))&&(m_.copy(c).invert(),qs.copy(t.ray).applyMatrix4(m_),!(a.boundingBox!==null&&qs.intersectsBox(a.boundingBox)===!1)&&this._computeIntersections(t,n,qs)))}_computeIntersections(t,n,a){let o;const c=this.geometry,u=this.material,h=c.index,m=c.attributes.position,p=c.attributes.uv,g=c.attributes.uv1,_=c.attributes.normal,v=c.groups,x=c.drawRange;if(h!==null)if(Array.isArray(u))for(let b=0,R=v.length;b<R;b++){const M=v[b],S=u[M.materialIndex],C=Math.max(M.start,x.start),O=Math.min(h.count,Math.min(M.start+M.count,x.start+x.count));for(let E=C,U=O;E<U;E+=3){const L=h.getX(E),P=h.getX(E+1),T=h.getX(E+2);o=ou(this,S,t,a,p,g,_,L,P,T),o&&(o.faceIndex=Math.floor(E/3),o.face.materialIndex=M.materialIndex,n.push(o))}}else{const b=Math.max(0,x.start),R=Math.min(h.count,x.start+x.count);for(let M=b,S=R;M<S;M+=3){const C=h.getX(M),O=h.getX(M+1),E=h.getX(M+2);o=ou(this,u,t,a,p,g,_,C,O,E),o&&(o.faceIndex=Math.floor(M/3),n.push(o))}}else if(m!==void 0)if(Array.isArray(u))for(let b=0,R=v.length;b<R;b++){const M=v[b],S=u[M.materialIndex],C=Math.max(M.start,x.start),O=Math.min(m.count,Math.min(M.start+M.count,x.start+x.count));for(let E=C,U=O;E<U;E+=3){const L=E,P=E+1,T=E+2;o=ou(this,S,t,a,p,g,_,L,P,T),o&&(o.faceIndex=Math.floor(E/3),o.face.materialIndex=M.materialIndex,n.push(o))}}else{const b=Math.max(0,x.start),R=Math.min(m.count,x.start+x.count);for(let M=b,S=R;M<S;M+=3){const C=M,O=M+1,E=M+2;o=ou(this,u,t,a,p,g,_,C,O,E),o&&(o.faceIndex=Math.floor(M/3),n.push(o))}}}}function X1(r,t,n,a,o,c,u,h){let m;if(t.side===oi?m=a.intersectTriangle(u,c,o,!0,h):m=a.intersectTriangle(o,c,u,t.side===$s,h),m===null)return null;ru.copy(h),ru.applyMatrix4(r.matrixWorld);const p=n.ray.origin.distanceTo(ru);return p<n.near||p>n.far?null:{distance:p,point:ru.clone(),object:r}}function ou(r,t,n,a,o,c,u,h,m,p){r.getVertexPosition(h,nu),r.getVertexPosition(m,iu),r.getVertexPosition(p,au);const g=X1(r,t,n,a,nu,iu,au,v_);if(g){const _=new B;Ki.getBarycoord(v_,nu,iu,au,_),o&&(g.uv=Ki.getInterpolatedAttribute(o,h,m,p,_,new Lt)),c&&(g.uv1=Ki.getInterpolatedAttribute(c,h,m,p,_,new Lt)),u&&(g.normal=Ki.getInterpolatedAttribute(u,h,m,p,_,new B),g.normal.dot(a.direction)>0&&g.normal.multiplyScalar(-1));const v={a:h,b:m,c:p,normal:new B,materialIndex:0};Ki.getNormal(nu,iu,au,v.normal),g.face=v,g.barycoord=_}return g}class Bx extends Wn{constructor(t=null,n=1,a=1,o,c,u,h,m,p=Qn,g=Qn,_,v){super(null,u,h,m,p,g,o,c,_,v),this.isDataTexture=!0,this.image={data:t,width:n,height:a},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class __ extends qn{constructor(t,n,a,o=1){super(t,n,a),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=o}copy(t){return super.copy(t),this.meshPerAttribute=t.meshPerAttribute,this}toJSON(){const t=super.toJSON();return t.meshPerAttribute=this.meshPerAttribute,t.isInstancedBufferAttribute=!0,t}}const jr=new an,x_=new an,lu=[],S_=new lr,W1=new an,cl=new le,ul=new cr;class En extends le{constructor(t,n,a){super(t,n),this.isInstancedMesh=!0,this.instanceMatrix=new __(new Float32Array(a*16),16),this.instanceColor=null,this.morphTexture=null,this.count=a,this.boundingBox=null,this.boundingSphere=null;for(let o=0;o<a;o++)this.setMatrixAt(o,W1)}computeBoundingBox(){const t=this.geometry,n=this.count;this.boundingBox===null&&(this.boundingBox=new lr),t.boundingBox===null&&t.computeBoundingBox(),this.boundingBox.makeEmpty();for(let a=0;a<n;a++)this.getMatrixAt(a,jr),S_.copy(t.boundingBox).applyMatrix4(jr),this.boundingBox.union(S_)}computeBoundingSphere(){const t=this.geometry,n=this.count;this.boundingSphere===null&&(this.boundingSphere=new cr),t.boundingSphere===null&&t.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let a=0;a<n;a++)this.getMatrixAt(a,jr),ul.copy(t.boundingSphere).applyMatrix4(jr),this.boundingSphere.union(ul)}copy(t,n){return super.copy(t,n),this.instanceMatrix.copy(t.instanceMatrix),t.morphTexture!==null&&(this.morphTexture=t.morphTexture.clone()),t.instanceColor!==null&&(this.instanceColor=t.instanceColor.clone()),this.count=t.count,t.boundingBox!==null&&(this.boundingBox=t.boundingBox.clone()),t.boundingSphere!==null&&(this.boundingSphere=t.boundingSphere.clone()),this}getColorAt(t,n){return this.instanceColor===null?n.setRGB(1,1,1):n.fromArray(this.instanceColor.array,t*3)}getMatrixAt(t,n){return n.fromArray(this.instanceMatrix.array,t*16)}getMorphAt(t,n){const a=n.morphTargetInfluences,o=this.morphTexture.source.data.data,c=a.length+1,u=t*c+1;for(let h=0;h<a.length;h++)a[h]=o[u+h]}raycast(t,n){const a=this.matrixWorld,o=this.count;if(cl.geometry=this.geometry,cl.material=this.material,cl.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),ul.copy(this.boundingSphere),ul.applyMatrix4(a),t.ray.intersectsSphere(ul)!==!1))for(let c=0;c<o;c++){this.getMatrixAt(c,jr),x_.multiplyMatrices(a,jr),cl.matrixWorld=x_,cl.raycast(t,lu);for(let u=0,h=lu.length;u<h;u++){const m=lu[u];m.instanceId=c,m.object=this,n.push(m)}lu.length=0}}setColorAt(t,n){return this.instanceColor===null&&(this.instanceColor=new __(new Float32Array(this.instanceMatrix.count*3).fill(1),3)),n.toArray(this.instanceColor.array,t*3),this}setMatrixAt(t,n){return n.toArray(this.instanceMatrix.array,t*16),this}setMorphAt(t,n){const a=n.morphTargetInfluences,o=a.length+1;this.morphTexture===null&&(this.morphTexture=new Bx(new Float32Array(o*this.count),o,this.count,Hp,Ji));const c=this.morphTexture.source.data.data;let u=0;for(let p=0;p<a.length;p++)u+=a[p];const h=this.geometry.morphTargetsRelative?1:1-u,m=o*t;return c[m]=h,c.set(a,m+1),this}updateMorphTargets(){}dispose(){super.dispose(),this.morphTexture!==null&&(this.morphTexture.dispose(),this.morphTexture=null)}}const Ys=new cr,q1=new Lt(.5,.5),cu=new B;class Kp{constructor(t=new Es,n=new Es,a=new Es,o=new Es,c=new Es,u=new Es){this.planes=[t,n,a,o,c,u]}set(t,n,a,o,c,u){const h=this.planes;return h[0].copy(t),h[1].copy(n),h[2].copy(a),h[3].copy(o),h[4].copy(c),h[5].copy(u),this}copy(t){const n=this.planes;for(let a=0;a<6;a++)n[a].copy(t.planes[a]);return this}setFromProjectionMatrix(t,n=la,a=!1){const o=this.planes,c=t.elements,u=c[0],h=c[1],m=c[2],p=c[3],g=c[4],_=c[5],v=c[6],x=c[7],b=c[8],R=c[9],M=c[10],S=c[11],C=c[12],O=c[13],E=c[14],U=c[15];if(o[0].setComponents(p-u,x-g,S-b,U-C).normalize(),o[1].setComponents(p+u,x+g,S+b,U+C).normalize(),o[2].setComponents(p+h,x+_,S+R,U+O).normalize(),o[3].setComponents(p-h,x-_,S-R,U-O).normalize(),a)o[4].setComponents(m,v,M,E).normalize(),o[5].setComponents(p-m,x-v,S-M,U-E).normalize();else if(o[4].setComponents(p-m,x-v,S-M,U-E).normalize(),n===la)o[5].setComponents(p+m,x+v,S+M,U+E).normalize();else if(n===Al)o[5].setComponents(m,v,M,E).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+n);return this}intersectsObject(t){if(t.boundingSphere!==void 0)t.boundingSphere===null&&t.computeBoundingSphere(),Ys.copy(t.boundingSphere).applyMatrix4(t.matrixWorld);else{const n=t.geometry;n.boundingSphere===null&&n.computeBoundingSphere(),Ys.copy(n.boundingSphere).applyMatrix4(t.matrixWorld)}return this.intersectsSphere(Ys)}intersectsSprite(t){Ys.center.set(0,0,0);const n=q1.distanceTo(t.center);return Ys.radius=.7071067811865476+n,Ys.applyMatrix4(t.matrixWorld),this.intersectsSphere(Ys)}intersectsSphere(t){const n=this.planes,a=t.center,o=-t.radius;for(let c=0;c<6;c++)if(n[c].distanceToPoint(a)<o)return!1;return!0}intersectsBox(t){const n=this.planes;for(let a=0;a<6;a++){const o=n[a];if(cu.x=o.normal.x>0?t.max.x:t.min.x,cu.y=o.normal.y>0?t.max.y:t.min.y,cu.z=o.normal.z>0?t.max.z:t.min.z,o.distanceToPoint(cu)<0)return!1}return!0}containsPoint(t){const n=this.planes;for(let a=0;a<6;a++)if(n[a].distanceToPoint(t)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}class nr extends ur{constructor(t){super(),this.isLineBasicMaterial=!0,this.type="LineBasicMaterial",this.color=new ue(16777215),this.map=null,this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.linewidth=t.linewidth,this.linecap=t.linecap,this.linejoin=t.linejoin,this.fog=t.fog,this}}const Uu=new B,Lu=new B,M_=new an,fl=new Iu,uu=new cr,Ad=new B,y_=new B;class Y1 extends Mn{constructor(t=new Ne,n=new nr){super(),this.isLine=!0,this.type="Line",this.geometry=t,this.material=n,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(t,n){return super.copy(t,n),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}computeLineDistances(){const t=this.geometry;if(t.index===null){const n=t.attributes.position,a=[0];for(let o=1,c=n.count;o<c;o++)Uu.fromBufferAttribute(n,o-1),Lu.fromBufferAttribute(n,o),a[o]=a[o-1],a[o]+=Uu.distanceTo(Lu);t.setAttribute("lineDistance",new ce(a,1))}else ve("Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}intersectsFrustum(t){return t.intersectsObject(this)}raycast(t,n){const a=this.geometry,o=this.matrixWorld,c=t.params.Line.threshold,u=a.drawRange;if(a.boundingSphere===null&&a.computeBoundingSphere(),uu.copy(a.boundingSphere),uu.applyMatrix4(o),uu.radius+=c,t.ray.intersectsSphere(uu)===!1)return;M_.copy(o).invert(),fl.copy(t.ray).applyMatrix4(M_);const h=c/((this.scale.x+this.scale.y+this.scale.z)/3),m=h*h,p=this.isLineSegments?2:1,g=a.index,v=a.attributes.position;if(g!==null){const x=Math.max(0,u.start),b=Math.min(g.count,u.start+u.count);for(let R=x,M=b-1;R<M;R+=p){const S=g.getX(R),C=g.getX(R+1),O=fu(this,t,fl,m,S,C,R);O&&n.push(O)}if(this.isLineLoop){const R=g.getX(b-1),M=g.getX(x),S=fu(this,t,fl,m,R,M,b-1);S&&n.push(S)}}else{const x=Math.max(0,u.start),b=Math.min(v.count,u.start+u.count);for(let R=x,M=b-1;R<M;R+=p){const S=fu(this,t,fl,m,R,R+1,R);S&&n.push(S)}if(this.isLineLoop){const R=fu(this,t,fl,m,b-1,x,b-1);R&&n.push(R)}}}updateMorphTargets(){const n=this.geometry.morphAttributes,a=Object.keys(n);if(a.length>0){const o=n[a[0]];if(o!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let c=0,u=o.length;c<u;c++){const h=o[c].name||String(c);this.morphTargetInfluences.push(0),this.morphTargetDictionary[h]=c}}}}}function fu(r,t,n,a,o,c,u){const h=r.geometry.attributes.position;if(Uu.fromBufferAttribute(h,o),Lu.fromBufferAttribute(h,c),n.distanceSqToSegment(Uu,Lu,Ad,y_)>a)return;Ad.applyMatrix4(r.matrixWorld);const p=t.ray.origin.distanceTo(Ad);if(!(p<t.near||p>t.far))return{distance:p,point:y_.clone().applyMatrix4(r.matrixWorld),index:u,face:null,faceIndex:null,barycoord:null,object:r}}const b_=new B,E_=new B;class ir extends Y1{constructor(t,n){super(t,n),this.isLineSegments=!0,this.type="LineSegments"}computeLineDistances(){const t=this.geometry;if(t.index===null){const n=t.attributes.position,a=[];for(let o=0,c=n.count;o<c;o+=2)b_.fromBufferAttribute(n,o),E_.fromBufferAttribute(n,o+1),a[o]=o===0?0:a[o-1],a[o+1]=a[o]+b_.distanceTo(E_);t.setAttribute("lineDistance",new ce(a,1))}else ve("LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}}class Fx extends ur{constructor(t){super(),this.isPointsMaterial=!0,this.type="PointsMaterial",this.color=new ue(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.alphaMap=t.alphaMap,this.size=t.size,this.sizeAttenuation=t.sizeAttenuation,this.fog=t.fog,this}}const T_=new an,Tp=new Iu,hu=new cr,du=new B;class Z1 extends Mn{constructor(t=new Ne,n=new Fx){super(),this.isPoints=!0,this.type="Points",this.geometry=t,this.material=n,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(t,n){return super.copy(t,n),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}intersectsFrustum(t){return t.intersectsObject(this)}raycast(t,n){const a=this.geometry,o=this.matrixWorld,c=t.params.Points.threshold,u=a.drawRange;if(a.boundingSphere===null&&a.computeBoundingSphere(),hu.copy(a.boundingSphere),hu.applyMatrix4(o),hu.radius+=c,t.ray.intersectsSphere(hu)===!1)return;T_.copy(o).invert(),Tp.copy(t.ray).applyMatrix4(T_);const h=c/((this.scale.x+this.scale.y+this.scale.z)/3),m=h*h,p=a.index,_=a.attributes.position;if(p!==null){const v=Math.max(0,u.start),x=Math.min(p.count,u.start+u.count);for(let b=v,R=x;b<R;b++){const M=p.getX(b);du.fromBufferAttribute(_,M),A_(du,M,m,o,t,n,this)}}else{const v=Math.max(0,u.start),x=Math.min(_.count,u.start+u.count);for(let b=v,R=x;b<R;b++)du.fromBufferAttribute(_,b),A_(du,b,m,o,t,n,this)}}updateMorphTargets(){const n=this.geometry.morphAttributes,a=Object.keys(n);if(a.length>0){const o=n[a[0]];if(o!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let c=0,u=o.length;c<u;c++){const h=o[c].name||String(c);this.morphTargetInfluences.push(0),this.morphTargetDictionary[h]=c}}}}}function A_(r,t,n,a,o,c,u){const h=Tp.distanceSqToPoint(r);if(h<n){const m=new B;Tp.closestPointToPoint(r,m),m.applyMatrix4(a);const p=o.ray.origin.distanceTo(m);if(p<o.near||p>o.far)return;c.push({distance:p,distanceToRay:Math.sqrt(h),point:m,index:t,face:null,faceIndex:null,barycoord:null,object:u})}}class Hx extends Wn{constructor(t=[],n=tr,a,o,c,u,h,m,p,g){super(t,n,a,o,c,u,h,m,p,g),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(t){this.image=t}}class ar extends Wn{constructor(t,n,a,o,c,u,h,m,p){super(t,n,a,o,c,u,h,m,p),this.isCanvasTexture=!0,this.needsUpdate=!0}}class Rl extends Wn{constructor(t,n,a=ua,o,c,u,h=Qn,m=Qn,p,g=ka,_=1){if(g!==ka&&g!==Js)throw new Error("THREE.DepthTexture: format must be either THREE.DepthFormat or THREE.DepthStencilFormat");const v={width:t,height:n,depth:_};super(v,o,c,u,h,m,g,a,p),this.isDepthTexture=!0,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(t){return super.copy(t),this.source=new Yp(Object.assign({},t.image)),this.compareFunction=t.compareFunction,this}toJSON(t){const n=super.toJSON(t);return n.compareFunction=this.compareFunction,n}}class K1 extends Rl{constructor(t,n=ua,a=tr,o,c,u=Qn,h=Qn,m,p=ka){const g={width:t,height:t,depth:1},_=[g,g,g,g,g,g];super(t,t,n,a,o,c,u,h,m,p),this.image=_,this.isCubeDepthTexture=!0,this.isCubeTexture=!0}get images(){return this.image}set images(t){this.image=t}}class Gx extends Wn{constructor(t=null){super(),this.sourceTexture=t,this.isExternalTexture=!0}copy(t){return super.copy(t),this.sourceTexture=t.sourceTexture,this}}class Wa extends Ne{constructor(t=1,n=1,a=1,o=1,c=1,u=1){super(),this.type="BoxGeometry",this.parameters={width:t,height:n,depth:a,widthSegments:o,heightSegments:c,depthSegments:u};const h=this;o=Math.floor(o),c=Math.floor(c),u=Math.floor(u);const m=[],p=[],g=[],_=[];let v=0,x=0;b("z","y","x",-1,-1,a,n,t,u,c,0),b("z","y","x",1,-1,a,n,-t,u,c,1),b("x","z","y",1,1,t,a,n,o,u,2),b("x","z","y",1,-1,t,a,-n,o,u,3),b("x","y","z",1,-1,t,n,a,o,c,4),b("x","y","z",-1,-1,t,n,-a,o,c,5),this.setIndex(m),this.setAttribute("position",new ce(p,3)),this.setAttribute("normal",new ce(g,3)),this.setAttribute("uv",new ce(_,2));function b(R,M,S,C,O,E,U,L,P,T,z){const W=E/P,J=U/T,Q=E/2,et=U/2,k=L/2,q=P+1,F=T+1;let Z=0,ht=0;const dt=new B;for(let pt=0;pt<F;pt++){const I=pt*J-et;for(let ct=0;ct<q;ct++){const At=ct*W-Q;dt[R]=At*C,dt[M]=I*O,dt[S]=k,p.push(dt.x,dt.y,dt.z),dt[R]=0,dt[M]=0,dt[S]=L>0?1:-1,g.push(dt.x,dt.y,dt.z),_.push(ct/P),_.push(1-pt/T),Z+=1}}for(let pt=0;pt<T;pt++)for(let I=0;I<P;I++){const ct=v+I+q*pt,At=v+I+q*(pt+1),It=v+(I+1)+q*(pt+1),kt=v+(I+1)+q*pt;m.push(ct,At,kt),m.push(At,It,kt),ht+=6}h.addGroup(x,ht,z),x+=ht,v+=Z}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new Wa(t.width,t.height,t.depth,t.widthSegments,t.heightSegments,t.depthSegments)}}class Ts extends Ne{constructor(t=1,n=32,a=0,o=Math.PI*2){super(),this.type="CircleGeometry",this.parameters={radius:t,segments:n,thetaStart:a,thetaLength:o},n=Math.max(3,n);const c=[],u=[],h=[],m=[],p=new B,g=new Lt;u.push(0,0,0),h.push(0,0,1),m.push(.5,.5);for(let _=0,v=3;_<=n;_++,v+=3){const x=a+_/n*o;p.x=t*Math.cos(x),p.y=t*Math.sin(x),u.push(p.x,p.y,p.z),h.push(0,0,1),g.x=(u[v]/t+1)/2,g.y=(u[v+1]/t+1)/2,m.push(g.x,g.y)}for(let _=1;_<=n;_++)c.push(_,_+1,0);this.setIndex(c),this.setAttribute("position",new ce(u,3)),this.setAttribute("normal",new ce(h,3)),this.setAttribute("uv",new ce(m,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new Ts(t.radius,t.segments,t.thetaStart,t.thetaLength)}}class mn extends Ne{constructor(t=1,n=1,a=1,o=32,c=1,u=!1,h=0,m=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:t,radiusBottom:n,height:a,radialSegments:o,heightSegments:c,openEnded:u,thetaStart:h,thetaLength:m};const p=this;o=Math.floor(o),c=Math.floor(c);const g=[],_=[],v=[],x=[];let b=0;const R=[],M=a/2;let S=0;C(),u===!1&&(t>0&&O(!0),n>0&&O(!1)),this.setIndex(g),this.setAttribute("position",new ce(_,3)),this.setAttribute("normal",new ce(v,3)),this.setAttribute("uv",new ce(x,2));function C(){const E=new B,U=new B;let L=0;const P=(n-t)/a;for(let T=0;T<=c;T++){const z=[],W=T/c,J=W*(n-t)+t;for(let Q=0;Q<=o;Q++){const et=Q/o,k=et*m+h,q=Math.sin(k),F=Math.cos(k);U.x=J*q,U.y=-W*a+M,U.z=J*F,_.push(U.x,U.y,U.z),E.set(q,P,F).normalize(),v.push(E.x,E.y,E.z),x.push(et,1-W),z.push(b++)}R.push(z)}for(let T=0;T<o;T++)for(let z=0;z<c;z++){const W=R[z][T],J=R[z+1][T],Q=R[z+1][T+1],et=R[z][T+1];(t>0||z!==0)&&(g.push(W,J,et),L+=3),(n>0||z!==c-1)&&(g.push(J,Q,et),L+=3)}p.addGroup(S,L,0),S+=L}function O(E){const U=b,L=new Lt,P=new B;let T=0;const z=E===!0?t:n,W=E===!0?1:-1;for(let Q=1;Q<=o;Q++)_.push(0,M*W,0),v.push(0,W,0),x.push(.5,.5),b++;const J=b;for(let Q=0;Q<=o;Q++){const k=Q/o*m+h,q=Math.cos(k),F=Math.sin(k);P.x=z*F,P.y=M*W,P.z=z*q,_.push(P.x,P.y,P.z),v.push(0,W,0),L.x=q*.5+.5,L.y=F*.5*W+.5,x.push(L.x,L.y),b++}for(let Q=0;Q<o;Q++){const et=U+Q,k=J+Q;E===!0?g.push(k,k+1,et):g.push(k+1,k,et),T+=3}p.addGroup(S,T,E===!0?1:2),S+=T}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new mn(t.radiusTop,t.radiusBottom,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}}class Bu extends mn{constructor(t=1,n=1,a=32,o=1,c=!1,u=0,h=Math.PI*2){super(0,t,n,a,o,c,u,h),this.type="ConeGeometry",this.parameters={radius:t,height:n,radialSegments:a,heightSegments:o,openEnded:c,thetaStart:u,thetaLength:h}}static fromJSON(t){return new Bu(t.radius,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}}class Jp extends Ne{constructor(t=[],n=[],a=1,o=0){super(),this.type="PolyhedronGeometry",this.parameters={vertices:t,indices:n,radius:a,detail:o};const c=[],u=[];h(o),p(a),g(),this.setAttribute("position",new ce(c,3)),this.setAttribute("normal",new ce(c.slice(),3)),this.setAttribute("uv",new ce(u,2)),o===0?this.computeVertexNormals():this.normalizeNormals();function h(C){const O=new B,E=new B,U=new B;for(let L=0;L<n.length;L+=3)x(n[L+0],O),x(n[L+1],E),x(n[L+2],U),m(O,E,U,C)}function m(C,O,E,U){const L=U+1,P=[];for(let T=0;T<=L;T++){P[T]=[];const z=C.clone().lerp(E,T/L),W=O.clone().lerp(E,T/L),J=L-T;for(let Q=0;Q<=J;Q++)Q===0&&T===L?P[T][Q]=z:P[T][Q]=z.clone().lerp(W,Q/J)}for(let T=0;T<L;T++)for(let z=0;z<2*(L-T)-1;z++){const W=Math.floor(z/2);z%2===0?(v(P[T][W+1]),v(P[T+1][W]),v(P[T][W])):(v(P[T][W+1]),v(P[T+1][W+1]),v(P[T+1][W]))}}function p(C){const O=new B;for(let E=0;E<c.length;E+=3)O.x=c[E+0],O.y=c[E+1],O.z=c[E+2],O.normalize().multiplyScalar(C),c[E+0]=O.x,c[E+1]=O.y,c[E+2]=O.z}function g(){const C=new B;for(let O=0;O<c.length;O+=3){C.x=c[O+0],C.y=c[O+1],C.z=c[O+2];const E=M(C)/2/Math.PI+.5,U=S(C)/Math.PI+.5;u.push(E,1-U)}b(),_()}function _(){for(let C=0;C<u.length;C+=6){const O=u[C+0],E=u[C+2],U=u[C+4],L=Math.max(O,E,U),P=Math.min(O,E,U);L>.9&&P<.1&&(O<.2&&(u[C+0]+=1),E<.2&&(u[C+2]+=1),U<.2&&(u[C+4]+=1))}}function v(C){c.push(C.x,C.y,C.z)}function x(C,O){const E=C*3;O.x=t[E+0],O.y=t[E+1],O.z=t[E+2]}function b(){const C=new B,O=new B,E=new B,U=new B,L=new Lt,P=new Lt,T=new Lt;for(let z=0,W=0;z<c.length;z+=9,W+=6){C.set(c[z+0],c[z+1],c[z+2]),O.set(c[z+3],c[z+4],c[z+5]),E.set(c[z+6],c[z+7],c[z+8]),L.set(u[W+0],u[W+1]),P.set(u[W+2],u[W+3]),T.set(u[W+4],u[W+5]),U.copy(C).add(O).add(E).divideScalar(3);const J=M(U);R(L,W+0,C,J),R(P,W+2,O,J),R(T,W+4,E,J)}}function R(C,O,E,U){U<0&&C.x===1&&(u[O]=C.x-1),E.x===0&&E.z===0&&(u[O]=U/2/Math.PI+.5)}function M(C){return Math.atan2(C.z,-C.x)}function S(C){return Math.atan2(-C.y,Math.sqrt(C.x*C.x+C.z*C.z))}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new Jp(t.vertices,t.indices,t.radius,t.detail)}}class fa{constructor(){this.type="Curve",this.arcLengthDivisions=200,this.needsUpdate=!1,this.cacheArcLengths=null}getPoint(){ve("Curve: .getPoint() not implemented.")}getPointAt(t,n){const a=this.getUtoTmapping(t);return this.getPoint(a,n)}getPoints(t=5){const n=[];for(let a=0;a<=t;a++)n.push(this.getPoint(a/t));return n}getSpacedPoints(t=5){const n=[];for(let a=0;a<=t;a++)n.push(this.getPointAt(a/t));return n}getLength(){const t=this.getLengths();return t[t.length-1]}getLengths(t=this.arcLengthDivisions){if(this.cacheArcLengths&&this.cacheArcLengths.length===t+1&&!this.needsUpdate)return this.cacheArcLengths;this.needsUpdate=!1;const n=[];let a,o=this.getPoint(0),c=0;n.push(0);for(let u=1;u<=t;u++)a=this.getPoint(u/t),c+=a.distanceTo(o),n.push(c),o=a;return this.cacheArcLengths=n,n}updateArcLengths(){this.needsUpdate=!0,this.getLengths()}getUtoTmapping(t,n=null){const a=this.getLengths();let o=0;const c=a.length;let u;n?u=n:u=t*a[c-1];let h=0,m=c-1,p;for(;h<=m;)if(o=Math.floor(h+(m-h)/2),p=a[o]-u,p<0)h=o+1;else if(p>0)m=o-1;else{m=o;break}if(o=m,a[o]===u)return o/(c-1);const g=a[o],v=a[o+1]-g,x=(u-g)/v;return(o+x)/(c-1)}getTangent(t,n){let o=t-1e-4,c=t+1e-4;o<0&&(o=0),c>1&&(c=1);const u=this.getPoint(o),h=this.getPoint(c),m=n||(u.isVector2?new Lt:new B);return m.copy(h).sub(u).normalize(),m}getTangentAt(t,n){const a=this.getUtoTmapping(t);return this.getTangent(a,n)}computeFrenetFrames(t,n=!1){const a=new B,o=[],c=[],u=[],h=new B,m=new an;for(let x=0;x<=t;x++){const b=x/t;o[x]=this.getTangentAt(b,new B)}c[0]=new B,u[0]=new B;let p=Number.MAX_VALUE;const g=Math.abs(o[0].x),_=Math.abs(o[0].y),v=Math.abs(o[0].z);g<=p&&(p=g,a.set(1,0,0)),_<=p&&(p=_,a.set(0,1,0)),v<=p&&a.set(0,0,1),h.crossVectors(o[0],a).normalize(),c[0].crossVectors(o[0],h),u[0].crossVectors(o[0],c[0]);for(let x=1;x<=t;x++){if(c[x]=c[x-1].clone(),u[x]=u[x-1].clone(),h.crossVectors(o[x-1],o[x]),h.length()>Number.EPSILON){h.normalize();const b=Math.acos(Ue(o[x-1].dot(o[x]),-1,1));c[x].applyMatrix4(m.makeRotationAxis(h,b))}u[x].crossVectors(o[x],c[x])}if(n===!0){let x=Math.acos(Ue(c[0].dot(c[t]),-1,1));x/=t,o[0].dot(h.crossVectors(c[0],c[t]))>0&&(x=-x);for(let b=1;b<=t;b++)c[b].applyMatrix4(m.makeRotationAxis(o[b],x*b)),u[b].crossVectors(o[b],c[b])}return{tangents:o,normals:c,binormals:u}}clone(){return new this.constructor().copy(this)}copy(t){return this.arcLengthDivisions=t.arcLengthDivisions,this}toJSON(){const t={metadata:{version:4.7,type:"Curve",generator:"Curve.toJSON"}};return t.arcLengthDivisions=this.arcLengthDivisions,t.type=this.type,t}fromJSON(t){return this.arcLengthDivisions=t.arcLengthDivisions,this}}class Qp extends fa{constructor(t=0,n=0,a=1,o=1,c=0,u=Math.PI*2,h=!1,m=0){super(),this.isEllipseCurve=!0,this.type="EllipseCurve",this.aX=t,this.aY=n,this.xRadius=a,this.yRadius=o,this.aStartAngle=c,this.aEndAngle=u,this.aClockwise=h,this.aRotation=m}getPoint(t,n=new Lt){const a=n,o=Math.PI*2;let c=this.aEndAngle-this.aStartAngle;const u=Math.abs(c)<Number.EPSILON;for(;c<0;)c+=o;for(;c>o;)c-=o;c<Number.EPSILON&&(u?c=0:c=o),this.aClockwise===!0&&!u&&(c===o?c=-o:c=c-o);const h=this.aStartAngle+t*c;let m=this.aX+this.xRadius*Math.cos(h),p=this.aY+this.yRadius*Math.sin(h);if(this.aRotation!==0){const g=Math.cos(this.aRotation),_=Math.sin(this.aRotation),v=m-this.aX,x=p-this.aY;m=v*g-x*_+this.aX,p=v*_+x*g+this.aY}return a.set(m,p)}copy(t){return super.copy(t),this.aX=t.aX,this.aY=t.aY,this.xRadius=t.xRadius,this.yRadius=t.yRadius,this.aStartAngle=t.aStartAngle,this.aEndAngle=t.aEndAngle,this.aClockwise=t.aClockwise,this.aRotation=t.aRotation,this}toJSON(){const t=super.toJSON();return t.aX=this.aX,t.aY=this.aY,t.xRadius=this.xRadius,t.yRadius=this.yRadius,t.aStartAngle=this.aStartAngle,t.aEndAngle=this.aEndAngle,t.aClockwise=this.aClockwise,t.aRotation=this.aRotation,t}fromJSON(t){return super.fromJSON(t),this.aX=t.aX,this.aY=t.aY,this.xRadius=t.xRadius,this.yRadius=t.yRadius,this.aStartAngle=t.aStartAngle,this.aEndAngle=t.aEndAngle,this.aClockwise=t.aClockwise,this.aRotation=t.aRotation,this}}class J1 extends Qp{constructor(t,n,a,o,c,u){super(t,n,a,a,o,c,u),this.isArcCurve=!0,this.type="ArcCurve"}}function jp(){let r=0,t=0,n=0,a=0;function o(c,u,h,m){r=c,t=h,n=-3*c+3*u-2*h-m,a=2*c-2*u+h+m}return{initCatmullRom:function(c,u,h,m,p){o(u,h,p*(h-c),p*(m-u))},initNonuniformCatmullRom:function(c,u,h,m,p,g,_){let v=(u-c)/p-(h-c)/(p+g)+(h-u)/g,x=(h-u)/g-(m-u)/(g+_)+(m-h)/_;v*=g,x*=g,o(u,h,v,x)},calc:function(c){const u=c*c,h=u*c;return r+t*c+n*u+a*h}}}const w_=new B,R_=new B,wd=new jp,Rd=new jp,Cd=new jp;class Nu extends fa{constructor(t=[],n=!1,a="centripetal",o=.5){super(),this.isCatmullRomCurve3=!0,this.type="CatmullRomCurve3",this.points=t,this.closed=n,this.curveType=a,this.tension=o}getPoint(t,n=new B){const a=n,o=this.points,c=o.length,u=(c-(this.closed?0:1))*t;let h=Math.floor(u),m=u-h;this.closed?h+=h>0?0:(Math.floor(Math.abs(h)/c)+1)*c:m===0&&h===c-1&&(h=c-2,m=1);let p,g;this.closed||h>0?p=o[(h-1)%c]:(R_.subVectors(o[0],o[1]).add(o[0]),p=R_);const _=o[h%c],v=o[(h+1)%c];if(this.closed||h+2<c?g=o[(h+2)%c]:(w_.subVectors(o[c-1],o[c-2]).add(o[c-1]),g=w_),this.curveType==="centripetal"||this.curveType==="chordal"){const x=this.curveType==="chordal"?.5:.25;let b=Math.pow(p.distanceToSquared(_),x),R=Math.pow(_.distanceToSquared(v),x),M=Math.pow(v.distanceToSquared(g),x);R<1e-4&&(R=1),b<1e-4&&(b=R),M<1e-4&&(M=R),wd.initNonuniformCatmullRom(p.x,_.x,v.x,g.x,b,R,M),Rd.initNonuniformCatmullRom(p.y,_.y,v.y,g.y,b,R,M),Cd.initNonuniformCatmullRom(p.z,_.z,v.z,g.z,b,R,M)}else this.curveType==="catmullrom"&&(wd.initCatmullRom(p.x,_.x,v.x,g.x,this.tension),Rd.initCatmullRom(p.y,_.y,v.y,g.y,this.tension),Cd.initCatmullRom(p.z,_.z,v.z,g.z,this.tension));return a.set(wd.calc(m),Rd.calc(m),Cd.calc(m)),a}copy(t){super.copy(t),this.points=[];for(let n=0,a=t.points.length;n<a;n++){const o=t.points[n];this.points.push(o.clone())}return this.closed=t.closed,this.curveType=t.curveType,this.tension=t.tension,this}toJSON(){const t=super.toJSON();t.points=[];for(let n=0,a=this.points.length;n<a;n++){const o=this.points[n];t.points.push(o.toArray())}return t.closed=this.closed,t.curveType=this.curveType,t.tension=this.tension,t}fromJSON(t){super.fromJSON(t),this.points=[];for(let n=0,a=t.points.length;n<a;n++){const o=t.points[n];this.points.push(new B().fromArray(o))}return this.closed=t.closed,this.curveType=t.curveType,this.tension=t.tension,this}}function C_(r,t,n,a,o){const c=(a-t)*.5,u=(o-n)*.5,h=r*r,m=r*h;return(2*n-2*a+c+u)*m+(-3*n+3*a-2*c-u)*h+c*r+n}function Q1(r,t){const n=1-r;return n*n*t}function j1(r,t){return 2*(1-r)*r*t}function $1(r,t){return r*r*t}function Sl(r,t,n,a){return Q1(r,t)+j1(r,n)+$1(r,a)}function tb(r,t){const n=1-r;return n*n*n*t}function eb(r,t){const n=1-r;return 3*n*n*r*t}function nb(r,t){return 3*(1-r)*r*r*t}function ib(r,t){return r*r*r*t}function Ml(r,t,n,a,o){return tb(r,t)+eb(r,n)+nb(r,a)+ib(r,o)}class Vx extends fa{constructor(t=new Lt,n=new Lt,a=new Lt,o=new Lt){super(),this.isCubicBezierCurve=!0,this.type="CubicBezierCurve",this.v0=t,this.v1=n,this.v2=a,this.v3=o}getPoint(t,n=new Lt){const a=n,o=this.v0,c=this.v1,u=this.v2,h=this.v3;return a.set(Ml(t,o.x,c.x,u.x,h.x),Ml(t,o.y,c.y,u.y,h.y)),a}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this.v3.copy(t.v3),this}toJSON(){const t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t.v3=this.v3.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this.v3.fromArray(t.v3),this}}class ab extends fa{constructor(t=new B,n=new B,a=new B,o=new B){super(),this.isCubicBezierCurve3=!0,this.type="CubicBezierCurve3",this.v0=t,this.v1=n,this.v2=a,this.v3=o}getPoint(t,n=new B){const a=n,o=this.v0,c=this.v1,u=this.v2,h=this.v3;return a.set(Ml(t,o.x,c.x,u.x,h.x),Ml(t,o.y,c.y,u.y,h.y),Ml(t,o.z,c.z,u.z,h.z)),a}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this.v3.copy(t.v3),this}toJSON(){const t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t.v3=this.v3.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this.v3.fromArray(t.v3),this}}class kx extends fa{constructor(t=new Lt,n=new Lt){super(),this.isLineCurve=!0,this.type="LineCurve",this.v1=t,this.v2=n}getPoint(t,n=new Lt){const a=n;return t===1?a.copy(this.v2):(a.copy(this.v2).sub(this.v1),a.multiplyScalar(t).add(this.v1)),a}getPointAt(t,n){return this.getPoint(t,n)}getTangent(t,n=new Lt){return n.subVectors(this.v2,this.v1).normalize()}getTangentAt(t,n){return this.getTangent(t,n)}copy(t){return super.copy(t),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){const t=super.toJSON();return t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}}class sb extends fa{constructor(t=new B,n=new B){super(),this.isLineCurve3=!0,this.type="LineCurve3",this.v1=t,this.v2=n}getPoint(t,n=new B){const a=n;return t===1?a.copy(this.v2):(a.copy(this.v2).sub(this.v1),a.multiplyScalar(t).add(this.v1)),a}getPointAt(t,n){return this.getPoint(t,n)}getTangent(t,n=new B){return n.subVectors(this.v2,this.v1).normalize()}getTangentAt(t,n){return this.getTangent(t,n)}copy(t){return super.copy(t),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){const t=super.toJSON();return t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}}class Xx extends fa{constructor(t=new Lt,n=new Lt,a=new Lt){super(),this.isQuadraticBezierCurve=!0,this.type="QuadraticBezierCurve",this.v0=t,this.v1=n,this.v2=a}getPoint(t,n=new Lt){const a=n,o=this.v0,c=this.v1,u=this.v2;return a.set(Sl(t,o.x,c.x,u.x),Sl(t,o.y,c.y,u.y)),a}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){const t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}}class Wx extends fa{constructor(t=new B,n=new B,a=new B){super(),this.isQuadraticBezierCurve3=!0,this.type="QuadraticBezierCurve3",this.v0=t,this.v1=n,this.v2=a}getPoint(t,n=new B){const a=n,o=this.v0,c=this.v1,u=this.v2;return a.set(Sl(t,o.x,c.x,u.x),Sl(t,o.y,c.y,u.y),Sl(t,o.z,c.z,u.z)),a}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){const t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}}class qx extends fa{constructor(t=[]){super(),this.isSplineCurve=!0,this.type="SplineCurve",this.points=t}getPoint(t,n=new Lt){const a=n,o=this.points,c=(o.length-1)*t,u=Math.floor(c),h=c-u,m=o[u===0?u:u-1],p=o[u],g=o[u>o.length-2?o.length-1:u+1],_=o[u>o.length-3?o.length-1:u+2];return a.set(C_(h,m.x,p.x,g.x,_.x),C_(h,m.y,p.y,g.y,_.y)),a}copy(t){super.copy(t),this.points=[];for(let n=0,a=t.points.length;n<a;n++){const o=t.points[n];this.points.push(o.clone())}return this}toJSON(){const t=super.toJSON();t.points=[];for(let n=0,a=this.points.length;n<a;n++){const o=this.points[n];t.points.push(o.toArray())}return t}fromJSON(t){super.fromJSON(t),this.points=[];for(let n=0,a=t.points.length;n<a;n++){const o=t.points[n];this.points.push(new Lt().fromArray(o))}return this}}var Ap=Object.freeze({__proto__:null,ArcCurve:J1,CatmullRomCurve3:Nu,CubicBezierCurve:Vx,CubicBezierCurve3:ab,EllipseCurve:Qp,LineCurve:kx,LineCurve3:sb,QuadraticBezierCurve:Xx,QuadraticBezierCurve3:Wx,SplineCurve:qx});class rb extends fa{constructor(){super(),this.type="CurvePath",this.curves=[],this.autoClose=!1}add(t){this.curves.push(t)}closePath(){const t=this.curves[0].getPoint(0),n=this.curves[this.curves.length-1].getPoint(1);if(!t.equals(n)){const a=t.isVector2===!0?"LineCurve":"LineCurve3";this.curves.push(new Ap[a](n,t))}return this}getPoint(t,n){const a=t*this.getLength(),o=this.getCurveLengths();let c=0;for(;c<o.length;){if(o[c]>=a){const u=o[c]-a,h=this.curves[c],m=h.getLength(),p=m===0?0:1-u/m;return h.getPointAt(p,n)}c++}return null}getLength(){const t=this.getCurveLengths();return t[t.length-1]}updateArcLengths(){this.needsUpdate=!0,this.cacheLengths=null,this.getCurveLengths()}getCurveLengths(){if(this.cacheLengths&&this.cacheLengths.length===this.curves.length)return this.cacheLengths;const t=[];let n=0;for(let a=0,o=this.curves.length;a<o;a++)n+=this.curves[a].getLength(),t.push(n);return this.cacheLengths=t,t}getSpacedPoints(t=40){const n=[];for(let a=0;a<=t;a++)n.push(this.getPoint(a/t));return this.autoClose&&n.push(n[0]),n}getPoints(t=12){const n=[];let a;for(let o=0,c=this.curves;o<c.length;o++){const u=c[o],h=u.isEllipseCurve?t*2:u.isLineCurve||u.isLineCurve3?1:u.isSplineCurve?t*u.points.length:t,m=u.getPoints(h);for(let p=0;p<m.length;p++){const g=m[p];a&&a.equals(g)||(n.push(g),a=g)}}return this.autoClose&&n.length>1&&!n[n.length-1].equals(n[0])&&n.push(n[0]),n}copy(t){super.copy(t),this.curves=[];for(let n=0,a=t.curves.length;n<a;n++){const o=t.curves[n];this.curves.push(o.clone())}return this.autoClose=t.autoClose,this}toJSON(){const t=super.toJSON();t.autoClose=this.autoClose,t.curves=[];for(let n=0,a=this.curves.length;n<a;n++){const o=this.curves[n];t.curves.push(o.toJSON())}return t}fromJSON(t){super.fromJSON(t),this.autoClose=t.autoClose,this.curves=[];for(let n=0,a=t.curves.length;n<a;n++){const o=t.curves[n];this.curves.push(new Ap[o.type]().fromJSON(o))}return this}}class D_ extends rb{constructor(t){super(),this.type="Path",this.currentPoint=new Lt,t&&this.setFromPoints(t)}setFromPoints(t){this.moveTo(t[0].x,t[0].y);for(let n=1,a=t.length;n<a;n++)this.lineTo(t[n].x,t[n].y);return this}moveTo(t,n){return this.currentPoint.set(t,n),this}lineTo(t,n){const a=new kx(this.currentPoint.clone(),new Lt(t,n));return this.curves.push(a),this.currentPoint.set(t,n),this}quadraticCurveTo(t,n,a,o){const c=new Xx(this.currentPoint.clone(),new Lt(t,n),new Lt(a,o));return this.curves.push(c),this.currentPoint.set(a,o),this}bezierCurveTo(t,n,a,o,c,u){const h=new Vx(this.currentPoint.clone(),new Lt(t,n),new Lt(a,o),new Lt(c,u));return this.curves.push(h),this.currentPoint.set(c,u),this}splineThru(t){const n=[this.currentPoint.clone()].concat(t),a=new qx(n);return this.curves.push(a),this.currentPoint.copy(t[t.length-1]),this}arc(t,n,a,o,c,u){const h=this.currentPoint.x,m=this.currentPoint.y;return this.absarc(t+h,n+m,a,o,c,u),this}absarc(t,n,a,o,c,u){return this.absellipse(t,n,a,a,o,c,u),this}ellipse(t,n,a,o,c,u,h,m){const p=this.currentPoint.x,g=this.currentPoint.y;return this.absellipse(t+p,n+g,a,o,c,u,h,m),this}absellipse(t,n,a,o,c,u,h,m){const p=new Qp(t,n,a,o,c,u,h,m);if(this.curves.length>0){const _=p.getPoint(0);_.equals(this.currentPoint)||this.lineTo(_.x,_.y)}this.curves.push(p);const g=p.getPoint(1);return this.currentPoint.copy(g),this}copy(t){return super.copy(t),this.currentPoint.copy(t.currentPoint),this}toJSON(){const t=super.toJSON();return t.currentPoint=this.currentPoint.toArray(),t}fromJSON(t){return super.fromJSON(t),this.currentPoint.fromArray(t.currentPoint),this}}class wp extends D_{constructor(t){super(t),this.uuid=or(),this.type="Shape",this.holes=[]}getPointsHoles(t){const n=[];for(let a=0,o=this.holes.length;a<o;a++)n[a]=this.holes[a].getPoints(t);return n}extractPoints(t){return{shape:this.getPoints(t),holes:this.getPointsHoles(t)}}copy(t){super.copy(t),this.holes=[];for(let n=0,a=t.holes.length;n<a;n++){const o=t.holes[n];this.holes.push(o.clone())}return this}toJSON(){const t=super.toJSON();t.uuid=this.uuid,t.holes=[];for(let n=0,a=this.holes.length;n<a;n++){const o=this.holes[n];t.holes.push(o.toJSON())}return t}fromJSON(t){super.fromJSON(t),this.uuid=t.uuid,this.holes=[];for(let n=0,a=t.holes.length;n<a;n++){const o=t.holes[n];this.holes.push(new D_().fromJSON(o))}return this}}function ob(r,t,n=2){const a=t&&t.length,o=a?t[0]*n:r.length;let c=Yx(r,0,o,n,!0);const u=[];if(!c||c.next===c.prev)return u;let h,m,p;if(a&&(c=hb(r,t,c,n)),r.length>80*n){h=r[0],m=r[1];let g=h,_=m;for(let v=n;v<o;v+=n){const x=r[v],b=r[v+1];x<h&&(h=x),b<m&&(m=b),x>g&&(g=x),b>_&&(_=b)}p=Math.max(g-h,_-m),p=p!==0?32767/p:0}return Cl(c,u,n,h,m,p,0),u}function Yx(r,t,n,a,o){let c;if(o===bb(r,t,n,a)>0)for(let u=t;u<n;u+=a)c=U_(u/a|0,r[u],r[u+1],c);else for(let u=n-a;u>=t;u-=a)c=U_(u/a|0,r[u],r[u+1],c);return c&&co(c,c.next)&&(Ul(c),c=c.next),c}function sr(r,t){if(!r)return r;t||(t=r);let n=r,a;do if(a=!1,!n.steiner&&(co(n,n.next)||Sn(n.prev,n,n.next)===0)){if(Ul(n),n=t=n.prev,n===n.next)break;a=!0}else n=n.next;while(a||n!==t);return t}function Cl(r,t,n,a,o,c,u){if(!r)return;!u&&c&&vb(r,a,o,c);let h=r;for(;r.prev!==r.next;){const m=r.prev,p=r.next;if(c?cb(r,a,o,c):lb(r)){t.push(m.i,r.i,p.i),Ul(r),r=p.next,h=p.next;continue}if(r=p,r===h){u?u===1?(r=ub(sr(r),t),Cl(r,t,n,a,o,c,2)):u===2&&fb(r,t,n,a,o,c):Cl(sr(r),t,n,a,o,c,1);break}}}function lb(r){const t=r.prev,n=r,a=r.next;if(Sn(t,n,a)>=0)return!1;const o=t.x,c=n.x,u=a.x,h=t.y,m=n.y,p=a.y,g=Math.min(o,c,u),_=Math.min(h,m,p),v=Math.max(o,c,u),x=Math.max(h,m,p);let b=a.next;for(;b!==t;){if(b.x>=g&&b.x<=v&&b.y>=_&&b.y<=x&&ml(o,h,c,m,u,p,b.x,b.y)&&Sn(b.prev,b,b.next)>=0)return!1;b=b.next}return!0}function cb(r,t,n,a){const o=r.prev,c=r,u=r.next;if(Sn(o,c,u)>=0)return!1;const h=o.x,m=c.x,p=u.x,g=o.y,_=c.y,v=u.y,x=Math.min(h,m,p),b=Math.min(g,_,v),R=Math.max(h,m,p),M=Math.max(g,_,v),S=Rp(x,b,t,n,a),C=Rp(R,M,t,n,a);let O=r.prevZ,E=r.nextZ;for(;O&&O.z>=S&&E&&E.z<=C;){if(O.x>=x&&O.x<=R&&O.y>=b&&O.y<=M&&O!==o&&O!==u&&ml(h,g,m,_,p,v,O.x,O.y)&&Sn(O.prev,O,O.next)>=0||(O=O.prevZ,E.x>=x&&E.x<=R&&E.y>=b&&E.y<=M&&E!==o&&E!==u&&ml(h,g,m,_,p,v,E.x,E.y)&&Sn(E.prev,E,E.next)>=0))return!1;E=E.nextZ}for(;O&&O.z>=S;){if(O.x>=x&&O.x<=R&&O.y>=b&&O.y<=M&&O!==o&&O!==u&&ml(h,g,m,_,p,v,O.x,O.y)&&Sn(O.prev,O,O.next)>=0)return!1;O=O.prevZ}for(;E&&E.z<=C;){if(E.x>=x&&E.x<=R&&E.y>=b&&E.y<=M&&E!==o&&E!==u&&ml(h,g,m,_,p,v,E.x,E.y)&&Sn(E.prev,E,E.next)>=0)return!1;E=E.nextZ}return!0}function ub(r,t){let n=r;do{const a=n.prev,o=n.next.next;!co(a,o)&&Kx(a,n,n.next,o)&&Dl(a,o)&&Dl(o,a)&&(t.push(a.i,n.i,o.i),Ul(n),Ul(n.next),n=r=o),n=n.next}while(n!==r);return sr(n)}function fb(r,t,n,a,o,c){let u=r;do{let h=u.next.next;for(;h!==u.prev;){if(u.i!==h.i&&Sb(u,h)){let m=Jx(u,h);u=sr(u,u.next),m=sr(m,m.next),Cl(u,t,n,a,o,c,0),Cl(m,t,n,a,o,c,0);return}h=h.next}u=u.next}while(u!==r)}function hb(r,t,n,a){const o=[];for(let c=0,u=t.length;c<u;c++){const h=t[c]*a,m=c<u-1?t[c+1]*a:r.length,p=Yx(r,h,m,a,!1);p===p.next&&(p.steiner=!0),o.push(xb(p))}o.sort(db);for(let c=0;c<o.length;c++)n=pb(o[c],n);return n}function db(r,t){let n=r.x-t.x;if(n===0&&(n=r.y-t.y,n===0)){const a=(r.next.y-r.y)/(r.next.x-r.x),o=(t.next.y-t.y)/(t.next.x-t.x);n=a-o}return n}function pb(r,t){const n=mb(r,t);if(!n)return t;const a=Jx(n,r);return sr(a,a.next),sr(n,n.next)}function mb(r,t){let n=t;const a=r.x,o=r.y;let c=-1/0,u;if(co(r,n))return n;do{if(co(r,n.next))return n.next;if(o<=n.y&&o>=n.next.y&&n.next.y!==n.y){const _=n.x+(o-n.y)*(n.next.x-n.x)/(n.next.y-n.y);if(_<=a&&_>c&&(c=_,u=n.x<n.next.x?n:n.next,_===a))return u}n=n.next}while(n!==t);if(!u)return null;const h=u,m=u.x,p=u.y;let g=1/0;n=u;do{if(a>=n.x&&n.x>=m&&a!==n.x&&Zx(o<p?a:c,o,m,p,o<p?c:a,o,n.x,n.y)){const _=Math.abs(o-n.y)/(a-n.x);Dl(n,r)&&(_<g||_===g&&(n.x>u.x||n.x===u.x&&gb(u,n)))&&(u=n,g=_)}n=n.next}while(n!==h);return u}function gb(r,t){return Sn(r.prev,r,t.prev)<0&&Sn(t.next,r,r.next)<0}function vb(r,t,n,a){let o=r;do o.z===0&&(o.z=Rp(o.x,o.y,t,n,a)),o.prevZ=o.prev,o.nextZ=o.next,o=o.next;while(o!==r);o.prevZ.nextZ=null,o.prevZ=null,_b(o)}function _b(r){let t,n=1;do{let a=r,o;r=null;let c=null;for(t=0;a;){t++;let u=a,h=0;for(let p=0;p<n&&(h++,u=u.nextZ,!!u);p++);let m=n;for(;h>0||m>0&&u;)h!==0&&(m===0||!u||a.z<=u.z)?(o=a,a=a.nextZ,h--):(o=u,u=u.nextZ,m--),c?c.nextZ=o:r=o,o.prevZ=c,c=o;a=u}c.nextZ=null,n*=2}while(t>1);return r}function Rp(r,t,n,a,o){return r=(r-n)*o|0,t=(t-a)*o|0,r=(r|r<<8)&16711935,r=(r|r<<4)&252645135,r=(r|r<<2)&858993459,r=(r|r<<1)&1431655765,t=(t|t<<8)&16711935,t=(t|t<<4)&252645135,t=(t|t<<2)&858993459,t=(t|t<<1)&1431655765,r|t<<1}function xb(r){let t=r,n=r;do(t.x<n.x||t.x===n.x&&t.y<n.y)&&(n=t),t=t.next;while(t!==r);return n}function Zx(r,t,n,a,o,c,u,h){return(o-u)*(t-h)>=(r-u)*(c-h)&&(r-u)*(a-h)>=(n-u)*(t-h)&&(n-u)*(c-h)>=(o-u)*(a-h)}function ml(r,t,n,a,o,c,u,h){return!(r===u&&t===h)&&Zx(r,t,n,a,o,c,u,h)}function Sb(r,t){return r.next.i!==t.i&&r.prev.i!==t.i&&!Mb(r,t)&&(Dl(r,t)&&Dl(t,r)&&yb(r,t)&&(Sn(r.prev,r,t.prev)||Sn(r,t.prev,t))||co(r,t)&&Sn(r.prev,r,r.next)>0&&Sn(t.prev,t,t.next)>0)}function Sn(r,t,n){return(t.y-r.y)*(n.x-t.x)-(t.x-r.x)*(n.y-t.y)}function co(r,t){return r.x===t.x&&r.y===t.y}function Kx(r,t,n,a){const o=mu(Sn(r,t,n)),c=mu(Sn(r,t,a)),u=mu(Sn(n,a,r)),h=mu(Sn(n,a,t));return!!(o!==c&&u!==h||o===0&&pu(r,n,t)||c===0&&pu(r,a,t)||u===0&&pu(n,r,a)||h===0&&pu(n,t,a))}function pu(r,t,n){return t.x<=Math.max(r.x,n.x)&&t.x>=Math.min(r.x,n.x)&&t.y<=Math.max(r.y,n.y)&&t.y>=Math.min(r.y,n.y)}function mu(r){return r>0?1:r<0?-1:0}function Mb(r,t){let n=r;do{if(n.i!==r.i&&n.next.i!==r.i&&n.i!==t.i&&n.next.i!==t.i&&Kx(n,n.next,r,t))return!0;n=n.next}while(n!==r);return!1}function Dl(r,t){return Sn(r.prev,r,r.next)<0?Sn(r,t,r.next)>=0&&Sn(r,r.prev,t)>=0:Sn(r,t,r.prev)<0||Sn(r,r.next,t)<0}function yb(r,t){let n=r,a=!1;const o=(r.x+t.x)/2,c=(r.y+t.y)/2;do n.y>c!=n.next.y>c&&n.next.y!==n.y&&o<(n.next.x-n.x)*(c-n.y)/(n.next.y-n.y)+n.x&&(a=!a),n=n.next;while(n!==r);return a}function Jx(r,t){const n=Cp(r.i,r.x,r.y),a=Cp(t.i,t.x,t.y),o=r.next,c=t.prev;return r.next=t,t.prev=r,n.next=o,o.prev=n,a.next=n,n.prev=a,c.next=a,a.prev=c,a}function U_(r,t,n,a){const o=Cp(r,t,n);return a?(o.next=a.next,o.prev=a,a.next.prev=o,a.next=o):(o.prev=o,o.next=o),o}function Ul(r){r.next.prev=r.prev,r.prev.next=r.next,r.prevZ&&(r.prevZ.nextZ=r.nextZ),r.nextZ&&(r.nextZ.prevZ=r.prevZ)}function Cp(r,t,n){return{i:r,x:t,y:n,prev:null,next:null,z:0,prevZ:null,nextZ:null,steiner:!1}}function bb(r,t,n,a){let o=0;for(let c=t,u=n-a;c<n;c+=a)o+=(r[u]-r[c])*(r[c+1]+r[u+1]),u=c;return o}class Eb{static triangulate(t,n,a=2){return ob(t,n,a)}}class yl{static area(t){const n=t.length;let a=0;for(let o=n-1,c=0;c<n;o=c++)a+=t[o].x*t[c].y-t[c].x*t[o].y;return a*.5}static isClockWise(t){return yl.area(t)<0}static triangulateShape(t,n){const a=[],o=[],c=[];L_(t),N_(a,t);let u=t.length;n.forEach(L_);for(let m=0;m<n.length;m++)o.push(u),u+=n[m].length,N_(a,n[m]);const h=Eb.triangulate(a,o);for(let m=0;m<h.length;m+=3)c.push(h.slice(m,m+3));return c}}function L_(r){const t=r.length;t>2&&r[t-1].equals(r[0])&&r.pop()}function N_(r,t){for(let n=0;n<t.length;n++)r.push(t[n].x),r.push(t[n].y)}class ho extends Jp{constructor(t=1,n=0){const a=(1+Math.sqrt(5))/2,o=[-1,a,0,1,a,0,-1,-a,0,1,-a,0,0,-1,a,0,1,a,0,-1,-a,0,1,-a,a,0,-1,a,0,1,-a,0,-1,-a,0,1],c=[0,11,5,0,5,1,0,1,7,0,7,10,0,10,11,1,5,9,5,11,4,11,10,2,10,7,6,7,1,8,3,9,4,3,4,2,3,2,6,3,6,8,3,8,9,4,9,5,2,4,11,6,2,10,8,6,7,9,8,1];super(o,c,t,n),this.type="IcosahedronGeometry",this.parameters={radius:t,detail:n}}static fromJSON(t){return new ho(t.radius,t.detail)}}class Pl extends Ne{constructor(t=[new Lt(0,-.5),new Lt(.5,0),new Lt(0,.5)],n=12,a=0,o=Math.PI*2){super(),this.type="LatheGeometry",this.parameters={points:t,segments:n,phiStart:a,phiLength:o},n=Math.floor(n),o=Ue(o,0,Math.PI*2);const c=[],u=[],h=[],m=[],p=[],g=1/n,_=new B,v=new Lt,x=new B,b=new B,R=new B;let M=0,S=0;for(let C=0;C<=t.length-1;C++)switch(C){case 0:M=t[C+1].x-t[C].x,S=t[C+1].y-t[C].y,x.x=S*1,x.y=-M,x.z=S*0,R.copy(x),x.normalize(),m.push(x.x,x.y,x.z);break;case t.length-1:m.push(R.x,R.y,R.z);break;default:M=t[C+1].x-t[C].x,S=t[C+1].y-t[C].y,x.x=S*1,x.y=-M,x.z=S*0,b.copy(x),x.x+=R.x,x.y+=R.y,x.z+=R.z,x.normalize(),m.push(x.x,x.y,x.z),R.copy(b)}for(let C=0;C<=n;C++){const O=a+C*g*o,E=Math.sin(O),U=Math.cos(O);for(let L=0;L<=t.length-1;L++){_.x=t[L].x*E,_.y=t[L].y,_.z=t[L].x*U,u.push(_.x,_.y,_.z),v.x=C/n,v.y=L/(t.length-1),h.push(v.x,v.y);const P=m[3*L+0]*E,T=m[3*L+1],z=m[3*L+0]*U;p.push(P,T,z)}}for(let C=0;C<n;C++)for(let O=0;O<t.length-1;O++){const E=O+C*t.length,U=E,L=E+t.length,P=E+t.length+1,T=E+1;c.push(U,L,T),c.push(P,T,L)}this.setIndex(c),this.setAttribute("position",new ce(u,3)),this.setAttribute("uv",new ce(h,2)),this.setAttribute("normal",new ce(p,3))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new Pl(t.points,t.segments,t.phiStart,t.phiLength)}}class kn extends Ne{constructor(t=1,n=1,a=1,o=1){super(),this.type="PlaneGeometry",this.parameters={width:t,height:n,widthSegments:a,heightSegments:o};const c=t/2,u=n/2,h=Math.floor(a),m=Math.floor(o),p=h+1,g=m+1,_=t/h,v=n/m,x=[],b=[],R=[],M=[];for(let S=0;S<g;S++){const C=S*v-u;for(let O=0;O<p;O++){const E=O*_-c;b.push(E,-C,0),R.push(0,0,1),M.push(O/h),M.push(1-S/m)}}for(let S=0;S<m;S++)for(let C=0;C<h;C++){const O=C+p*S,E=C+p*(S+1),U=C+1+p*(S+1),L=C+1+p*S;x.push(O,E,L),x.push(E,U,L)}this.setIndex(x),this.setAttribute("position",new ce(b,3)),this.setAttribute("normal",new ce(R,3)),this.setAttribute("uv",new ce(M,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new kn(t.width,t.height,t.widthSegments,t.heightSegments)}}class $p extends Ne{constructor(t=.5,n=1,a=32,o=1,c=0,u=Math.PI*2){super(),this.type="RingGeometry",this.parameters={innerRadius:t,outerRadius:n,thetaSegments:a,phiSegments:o,thetaStart:c,thetaLength:u},a=Math.max(3,a),o=Math.max(1,o);const h=[],m=[],p=[],g=[];let _=t;const v=(n-t)/o,x=new B,b=new Lt;for(let R=0;R<=o;R++){for(let M=0;M<=a;M++){const S=c+M/a*u;x.x=_*Math.cos(S),x.y=_*Math.sin(S),m.push(x.x,x.y,x.z),p.push(0,0,1),b.x=(x.x/n+1)/2,b.y=(x.y/n+1)/2,g.push(b.x,b.y)}_+=v}for(let R=0;R<o;R++){const M=R*(a+1);for(let S=0;S<a;S++){const C=S+M,O=C,E=C+a+1,U=C+a+2,L=C+1;h.push(O,E,L),h.push(E,U,L)}}this.setIndex(h),this.setAttribute("position",new ce(m,3)),this.setAttribute("normal",new ce(p,3)),this.setAttribute("uv",new ce(g,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new $p(t.innerRadius,t.outerRadius,t.thetaSegments,t.phiSegments,t.thetaStart,t.thetaLength)}}class Ou extends Ne{constructor(t=new wp([new Lt(0,.5),new Lt(-.5,-.5),new Lt(.5,-.5)]),n=12){super(),this.type="ShapeGeometry",this.parameters={shapes:t,curveSegments:n};const a=[],o=[],c=[],u=[];let h=0,m=0;if(Array.isArray(t)===!1)p(t);else for(let g=0;g<t.length;g++)p(t[g]),this.addGroup(h,m,g),h+=m,m=0;this.setIndex(a),this.setAttribute("position",new ce(o,3)),this.setAttribute("normal",new ce(c,3)),this.setAttribute("uv",new ce(u,2));function p(g){const _=o.length/3,v=g.extractPoints(n);let x=v.shape;const b=v.holes;yl.isClockWise(x)===!1&&(x=x.reverse());for(let M=0,S=b.length;M<S;M++){const C=b[M];yl.isClockWise(C)===!0&&(b[M]=C.reverse())}const R=yl.triangulateShape(x,b);for(let M=0,S=b.length;M<S;M++){const C=b[M];x=x.concat(C)}for(let M=0,S=x.length;M<S;M++){const C=x[M];o.push(C.x,C.y,0),c.push(0,0,1),u.push(C.x,C.y)}for(let M=0,S=R.length;M<S;M++){const C=R[M],O=C[0]+_,E=C[1]+_,U=C[2]+_;a.push(O,E,U),m+=3}}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}toJSON(){const t=super.toJSON(),n=this.parameters.shapes;return Tb(n,t)}static fromJSON(t,n){const a=[];for(let o=0,c=t.shapes.length;o<c;o++){const u=n[t.shapes[o]];a.push(u)}return new Ou(a,t.curveSegments)}}function Tb(r,t){if(t.shapes=[],Array.isArray(r))for(let n=0,a=r.length;n<a;n++){const o=r[n];t.shapes.push(o.uuid)}else t.shapes.push(r.uuid);return t}class Fu extends Ne{constructor(t=1,n=32,a=16,o=0,c=Math.PI*2,u=0,h=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:t,widthSegments:n,heightSegments:a,phiStart:o,phiLength:c,thetaStart:u,thetaLength:h},n=Math.max(3,Math.floor(n)),a=Math.max(2,Math.floor(a));const m=Math.min(u+h,Math.PI);let p=0;const g=[],_=new B,v=new B,x=[],b=[],R=[],M=[];for(let S=0;S<=a;S++){const C=[],O=S/a,E=u+O*h,U=t*Math.cos(E),L=Math.sqrt(t*t-U*U);let P=0;S===0&&u===0?P=.5/n:S===a&&m===Math.PI&&(P=-.5/n);for(let T=0;T<=n;T++){const z=T/n,W=o+z*c;_.x=-L*Math.cos(W),_.y=U,_.z=L*Math.sin(W),b.push(_.x,_.y,_.z),v.copy(_).normalize(),R.push(v.x,v.y,v.z),M.push(z+P,1-O),C.push(p++)}g.push(C)}for(let S=0;S<a;S++)for(let C=0;C<n;C++){const O=g[S][C+1],E=g[S][C],U=g[S+1][C],L=g[S+1][C+1];(S!==0||u>0)&&x.push(O,E,L),(S!==a-1||m<Math.PI)&&x.push(E,U,L)}this.setIndex(x),this.setAttribute("position",new ce(b,3)),this.setAttribute("normal",new ce(R,3)),this.setAttribute("uv",new ce(M,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new Fu(t.radius,t.widthSegments,t.heightSegments,t.phiStart,t.phiLength,t.thetaStart,t.thetaLength)}}class js extends Ne{constructor(t=1,n=.4,a=12,o=48,c=Math.PI*2,u=0,h=Math.PI*2){super(),this.type="TorusGeometry",this.parameters={radius:t,tube:n,radialSegments:a,tubularSegments:o,arc:c,thetaStart:u,thetaLength:h},a=Math.floor(a),o=Math.floor(o);const m=[],p=[],g=[],_=[],v=new B,x=new B,b=new B;for(let R=0;R<=a;R++){const M=u+R/a*h;for(let S=0;S<=o;S++){const C=S/o*c;x.x=(t+n*Math.cos(M))*Math.cos(C),x.y=(t+n*Math.cos(M))*Math.sin(C),x.z=n*Math.sin(M),p.push(x.x,x.y,x.z),v.x=t*Math.cos(C),v.y=t*Math.sin(C),b.subVectors(x,v).normalize(),g.push(b.x,b.y,b.z),_.push(S/o),_.push(R/a)}}for(let R=1;R<=a;R++)for(let M=1;M<=o;M++){const S=(o+1)*R+M-1,C=(o+1)*(R-1)+M-1,O=(o+1)*(R-1)+M,E=(o+1)*R+M;m.push(S,C,E),m.push(C,O,E)}this.setIndex(m),this.setAttribute("position",new ce(p,3)),this.setAttribute("normal",new ce(g,3)),this.setAttribute("uv",new ce(_,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new js(t.radius,t.tube,t.radialSegments,t.tubularSegments,t.arc,t.thetaStart,t.thetaLength)}}class Ll extends Ne{constructor(t=new Wx(new B(-1,-1,0),new B(-1,1,0),new B(1,1,0)),n=64,a=1,o=8,c=!1){super(),this.type="TubeGeometry",this.parameters={path:t,tubularSegments:n,radius:a,radialSegments:o,closed:c};const u=t.computeFrenetFrames(n,c);this.tangents=u.tangents,this.normals=u.normals,this.binormals=u.binormals;const h=new B,m=new B,p=new Lt;let g=new B;const _=[],v=[],x=[],b=[];R(),this.setIndex(b),this.setAttribute("position",new ce(_,3)),this.setAttribute("normal",new ce(v,3)),this.setAttribute("uv",new ce(x,2));function R(){for(let O=0;O<n;O++)M(O);M(c===!1?n:0),C(),S()}function M(O){g=t.getPointAt(O/n,g);const E=u.normals[O],U=u.binormals[O];for(let L=0;L<=o;L++){const P=L/o*Math.PI*2,T=Math.sin(P),z=-Math.cos(P);m.x=z*E.x+T*U.x,m.y=z*E.y+T*U.y,m.z=z*E.z+T*U.z,m.normalize(),v.push(m.x,m.y,m.z),h.x=g.x+a*m.x,h.y=g.y+a*m.y,h.z=g.z+a*m.z,_.push(h.x,h.y,h.z)}}function S(){for(let O=1;O<=n;O++)for(let E=1;E<=o;E++){const U=(o+1)*(O-1)+(E-1),L=(o+1)*O+(E-1),P=(o+1)*O+E,T=(o+1)*(O-1)+E;b.push(U,L,T),b.push(L,P,T)}}function C(){for(let O=0;O<=n;O++)for(let E=0;E<=o;E++)p.x=O/n,p.y=E/o,x.push(p.x,p.y)}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}toJSON(){const t=super.toJSON();return t.path=this.parameters.path.toJSON(),t}static fromJSON(t){return new Ll(new Ap[t.path.type]().fromJSON(t.path),t.tubularSegments,t.radius,t.radialSegments,t.closed)}}function uo(r){const t={};for(const n in r){t[n]={};for(const a in r[n]){const o=r[n][a];if(O_(o))o.isRenderTargetTexture?(ve("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),t[n][a]=null):t[n][a]=o.clone();else if(Array.isArray(o))if(O_(o[0])){const c=[];for(let u=0,h=o.length;u<h;u++)c[u]=o[u].clone();t[n][a]=c}else t[n][a]=o.slice();else t[n][a]=o}}return t}function ri(r){const t={};for(let n=0;n<r.length;n++){const a=uo(r[n]);for(const o in a)t[o]=a[o]}return t}function O_(r){return r&&(r.isColor||r.isMatrix3||r.isMatrix4||r.isVector2||r.isVector3||r.isVector4||r.isTexture||r.isQuaternion)}function Ab(r){const t=[];for(let n=0;n<r.length;n++)t.push(r[n].clone());return t}function Qx(r){const t=r.getRenderTarget();return t===null?r.outputColorSpace:t.isXRRenderTarget===!0?t.texture.colorSpace:Ve.workingColorSpace}const wb={clone:uo,merge:ri};var Rb=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,Cb=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class ei extends ur{constructor(t){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=Rb,this.fragmentShader=Cb,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,t!==void 0&&this.setValues(t)}copy(t){return super.copy(t),this.fragmentShader=t.fragmentShader,this.vertexShader=t.vertexShader,this.uniforms=uo(t.uniforms),this.uniformsGroups=Ab(t.uniformsGroups),this.defines=Object.assign({},t.defines),this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.fog=t.fog,this.lights=t.lights,this.clipping=t.clipping,this.extensions=Object.assign({},t.extensions),this.glslVersion=t.glslVersion,this.defaultAttributeValues=Object.assign({},t.defaultAttributeValues),this.index0AttributeName=t.index0AttributeName,this.uniformsNeedUpdate=t.uniformsNeedUpdate,this}toJSON(t){const n=super.toJSON(t);n.glslVersion=this.glslVersion,n.uniforms={};for(const o in this.uniforms){const u=this.uniforms[o].value;u&&u.isTexture?n.uniforms[o]={type:"t",value:u.toJSON(t).uuid}:u&&u.isColor?n.uniforms[o]={type:"c",value:u.getHex()}:u&&u.isVector2?n.uniforms[o]={type:"v2",value:u.toArray()}:u&&u.isVector3?n.uniforms[o]={type:"v3",value:u.toArray()}:u&&u.isVector4?n.uniforms[o]={type:"v4",value:u.toArray()}:u&&u.isMatrix3?n.uniforms[o]={type:"m3",value:u.toArray()}:u&&u.isMatrix4?n.uniforms[o]={type:"m4",value:u.toArray()}:n.uniforms[o]={value:u}}Object.keys(this.defines).length>0&&(n.defines=this.defines),n.vertexShader=this.vertexShader,n.fragmentShader=this.fragmentShader,n.lights=this.lights,n.clipping=this.clipping;const a={};for(const o in this.extensions)this.extensions[o]===!0&&(a[o]=!0);return Object.keys(a).length>0&&(n.extensions=a),n}fromJSON(t,n){if(super.fromJSON(t,n),t.uniforms!==void 0)for(const a in t.uniforms){const o=t.uniforms[a];switch(this.uniforms[a]={},o.type){case"t":this.uniforms[a].value=n[o.value]||null;break;case"c":this.uniforms[a].value=new ue().setHex(o.value);break;case"v2":this.uniforms[a].value=new Lt().fromArray(o.value);break;case"v3":this.uniforms[a].value=new B().fromArray(o.value);break;case"v4":this.uniforms[a].value=new xn().fromArray(o.value);break;case"m3":this.uniforms[a].value=new ye().fromArray(o.value);break;case"m4":this.uniforms[a].value=new an().fromArray(o.value);break;default:this.uniforms[a].value=o.value}}if(t.defines!==void 0&&(this.defines=t.defines),t.vertexShader!==void 0&&(this.vertexShader=t.vertexShader),t.fragmentShader!==void 0&&(this.fragmentShader=t.fragmentShader),t.glslVersion!==void 0&&(this.glslVersion=t.glslVersion),t.extensions!==void 0)for(const a in t.extensions)this.extensions[a]=t.extensions[a];return t.lights!==void 0&&(this.lights=t.lights),t.clipping!==void 0&&(this.clipping=t.clipping),this}}class Db extends ei{constructor(t){super(t),this.isRawShaderMaterial=!0,this.type="RawShaderMaterial"}}class me extends ur{constructor(t){super(),this.isMeshStandardMaterial=!0,this.type="MeshStandardMaterial",this.defines={STANDARD:""},this.color=new ue(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new ue(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=Ep,this.normalScale=new Lt(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Xa,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.defines={STANDARD:""},this.color.copy(t.color),this.roughness=t.roughness,this.metalness=t.metalness,this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.emissive.copy(t.emissive),this.emissiveMap=t.emissiveMap,this.emissiveIntensity=t.emissiveIntensity,this.bumpMap=t.bumpMap,this.bumpScale=t.bumpScale,this.normalMap=t.normalMap,this.normalMapType=t.normalMapType,this.normalScale.copy(t.normalScale),this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.roughnessMap=t.roughnessMap,this.metalnessMap=t.metalnessMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapRotation.copy(t.envMapRotation),this.envMapIntensity=t.envMapIntensity,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.flatShading=t.flatShading,this.fog=t.fog,this}}class Nl extends me{constructor(t){super(),this.isMeshPhysicalMaterial=!0,this.defines={STANDARD:"",PHYSICAL:""},this.type="MeshPhysicalMaterial",this.anisotropyRotation=0,this.anisotropyMap=null,this.clearcoatMap=null,this.clearcoatRoughness=0,this.clearcoatRoughnessMap=null,this.clearcoatNormalScale=new Lt(1,1),this.clearcoatNormalMap=null,this.ior=1.5,Object.defineProperty(this,"reflectivity",{get:function(){return Ue(2.5*(this.ior-1)/(this.ior+1),0,1)},set:function(n){this.ior=(1+.4*n)/(1-.4*n)}}),this.iridescenceMap=null,this.iridescenceIOR=1.3,this.iridescenceThicknessRange=[100,400],this.iridescenceThicknessMap=null,this.sheenColor=new ue(0),this.sheenColorMap=null,this.sheenRoughness=1,this.sheenRoughnessMap=null,this.transmissionMap=null,this.thickness=0,this.thicknessMap=null,this.attenuationDistance=1/0,this.attenuationColor=new ue(1,1,1),this.specularIntensity=1,this.specularIntensityMap=null,this.specularColor=new ue(1,1,1),this.specularColorMap=null,this._anisotropy=0,this._clearcoat=0,this._dispersion=0,this._iridescence=0,this._retroreflectivity=0,this._sheen=0,this._transmission=0,this.setValues(t)}get anisotropy(){return this._anisotropy}set anisotropy(t){this._anisotropy>0!=t>0&&this.version++,this._anisotropy=t}get clearcoat(){return this._clearcoat}set clearcoat(t){this._clearcoat>0!=t>0&&this.version++,this._clearcoat=t}get iridescence(){return this._iridescence}set iridescence(t){this._iridescence>0!=t>0&&this.version++,this._iridescence=t}get dispersion(){return this._dispersion}set dispersion(t){this._dispersion>0!=t>0&&this.version++,this._dispersion=t}get retroreflectivity(){return this._retroreflectivity}set retroreflectivity(t){this._retroreflectivity>0!=t>0&&this.version++,this._retroreflectivity=t}get sheen(){return this._sheen}set sheen(t){this._sheen>0!=t>0&&this.version++,this._sheen=t}get transmission(){return this._transmission}set transmission(t){this._transmission>0!=t>0&&this.version++,this._transmission=t}copy(t){return super.copy(t),this.defines={STANDARD:"",PHYSICAL:""},this.anisotropy=t.anisotropy,this.anisotropyRotation=t.anisotropyRotation,this.anisotropyMap=t.anisotropyMap,this.clearcoat=t.clearcoat,this.clearcoatMap=t.clearcoatMap,this.clearcoatRoughness=t.clearcoatRoughness,this.clearcoatRoughnessMap=t.clearcoatRoughnessMap,this.clearcoatNormalMap=t.clearcoatNormalMap,this.clearcoatNormalScale.copy(t.clearcoatNormalScale),this.dispersion=t.dispersion,this.ior=t.ior,this.iridescence=t.iridescence,this.iridescenceMap=t.iridescenceMap,this.iridescenceIOR=t.iridescenceIOR,this.iridescenceThicknessRange=[...t.iridescenceThicknessRange],this.iridescenceThicknessMap=t.iridescenceThicknessMap,this.retroreflectivity=t.retroreflectivity,this.sheen=t.sheen,this.sheenColor.copy(t.sheenColor),this.sheenColorMap=t.sheenColorMap,this.sheenRoughness=t.sheenRoughness,this.sheenRoughnessMap=t.sheenRoughnessMap,this.transmission=t.transmission,this.transmissionMap=t.transmissionMap,this.thickness=t.thickness,this.thicknessMap=t.thicknessMap,this.attenuationDistance=t.attenuationDistance,this.attenuationColor.copy(t.attenuationColor),this.specularIntensity=t.specularIntensity,this.specularIntensityMap=t.specularIntensityMap,this.specularColor.copy(t.specularColor),this.specularColorMap=t.specularColorMap,this}}class Ub extends ur{constructor(t){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=Ky,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(t)}copy(t){return super.copy(t),this.depthPacking=t.depthPacking,this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this}}class Lb extends ur{constructor(t){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(t)}copy(t){return super.copy(t),this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this}}class tm extends Mn{constructor(t,n=1){super(),this.isLight=!0,this.type="Light",this.color=new ue(t),this.intensity=n}copy(t,n){return super.copy(t,n),this.color.copy(t.color),this.intensity=t.intensity,this}toJSON(t){const n=super.toJSON(t);return n.object.color=this.color.getHex(),n.object.intensity=this.intensity,n}}class Hu extends tm{constructor(t,n,a){super(t,a),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(Mn.DEFAULT_UP),this.updateMatrix(),this.groundColor=new ue(n)}copy(t,n){return super.copy(t,n),this.groundColor.copy(t.groundColor),this}toJSON(t){const n=super.toJSON(t);return n.object.groundColor=this.groundColor.getHex(),n}}const Dd=new an,P_=new B,z_=new B;class jx{constructor(t){this.camera=t,this.intensity=1,this.bias=0,this.biasNode=null,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new Lt(512,512),this.mapType=Ti,this.map=null,this.mapPass=null,this.matrix=new an,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new Kp,this._frameExtents=new Lt(1,1),this._viewportCount=1,this._viewports=[new xn(0,0,1,1)]}getViewportCount(){return this._viewportCount}getCamera(){return this.camera}getFrustum(){return this._frustum}updateMatrices(t){const n=this.camera;P_.setFromMatrixPosition(t.matrixWorld),n.position.copy(P_),z_.setFromMatrixPosition(t.target.matrixWorld),n.lookAt(z_),n.updateMatrixWorld(),this._updateMatrix(n,this.matrix,this._frustum)}_updateMatrix(t,n,a,o){Dd.multiplyMatrices(t.projectionMatrix,t.matrixWorldInverse),a.setFromProjectionMatrix(Dd,t.coordinateSystem,t.reversedDepth);const c=this._frameExtents,u=o?o.z/c.x:1,h=o?o.w/c.y:1,m=o?o.x/c.x:0,p=o?o.y/c.y:0;t.coordinateSystem===Al||t.reversedDepth?n.set(.5*u,0,0,.5*u+m,0,.5*h,0,.5*h+p,0,0,1,0,0,0,0,1):n.set(.5*u,0,0,.5*u+m,0,.5*h,0,.5*h+p,0,0,.5,.5,0,0,0,1),n.multiply(Dd)}getViewport(t){return this._viewports[t]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(t){return this.camera=t.camera.clone(),this.intensity=t.intensity,this.bias=t.bias,this.radius=t.radius,this.autoUpdate=t.autoUpdate,this.needsUpdate=t.needsUpdate,this.normalBias=t.normalBias,this.blurSamples=t.blurSamples,this.mapSize.copy(t.mapSize),this.biasNode=t.biasNode,this}clone(){return new this.constructor().copy(this)}toJSON(){const t={};return t.intensity=this.intensity,t.bias=this.bias,t.normalBias=this.normalBias,t.radius=this.radius,t.blurSamples=this.blurSamples,t.mapSize=this.mapSize.toArray(),t.camera=this.camera.toJSON(!1).object,delete t.camera.matrix,t}}const gu=new B,vu=new Ai,sa=new B;class $x extends Mn{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new an,this.projectionMatrix=new an,this.projectionMatrixInverse=new an,this.coordinateSystem=la,this._reversedDepth=!1}get reversedDepth(){return this._reversedDepth}copy(t,n){return super.copy(t,n),this.matrixWorldInverse.copy(t.matrixWorldInverse),this.projectionMatrix.copy(t.projectionMatrix),this.projectionMatrixInverse.copy(t.projectionMatrixInverse),this.coordinateSystem=t.coordinateSystem,this}getWorldDirection(t){return super.getWorldDirection(t).negate()}updateMatrixWorld(t){super.updateMatrixWorld(t),this.matrixWorld.decompose(gu,vu,sa),sa.x===1&&sa.y===1&&sa.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(gu,vu,sa.set(1,1,1)).invert()}updateWorldMatrix(t,n,a=!1){super.updateWorldMatrix(t,n,a),this.matrixWorld.decompose(gu,vu,sa),sa.x===1&&sa.y===1&&sa.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(gu,vu,sa.set(1,1,1)).invert()}clone(){return new this.constructor().copy(this)}}const bs=new B,I_=new Lt,B_=new Lt;class Ei extends $x{constructor(t=50,n=1,a=.1,o=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=t,this.zoom=1,this.near=a,this.far=o,this.focus=10,this.aspect=n,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(t,n){return super.copy(t,n),this.fov=t.fov,this.zoom=t.zoom,this.near=t.near,this.far=t.far,this.focus=t.focus,this.aspect=t.aspect,this.view=t.view===null?null:Object.assign({},t.view),this.filmGauge=t.filmGauge,this.filmOffset=t.filmOffset,this}setFocalLength(t){const n=.5*this.getFilmHeight()/t;this.fov=wl*2*Math.atan(n),this.updateProjectionMatrix()}getFocalLength(){const t=Math.tan(_l*.5*this.fov);return .5*this.getFilmHeight()/t}getEffectiveFOV(){return wl*2*Math.atan(Math.tan(_l*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(t,n,a){bs.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),n.set(bs.x,bs.y).multiplyScalar(-t/bs.z),bs.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),a.set(bs.x,bs.y).multiplyScalar(-t/bs.z)}getViewSize(t,n){return this.getViewBounds(t,I_,B_),n.subVectors(B_,I_)}setViewOffset(t,n,a,o,c,u){this.aspect=t/n,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=n,this.view.offsetX=a,this.view.offsetY=o,this.view.width=c,this.view.height=u,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const t=this.near;let n=t*Math.tan(_l*.5*this.fov)/this.zoom,a=2*n,o=this.aspect*a,c=-.5*o;const u=this.view;if(this.view!==null&&this.view.enabled){const m=u.fullWidth,p=u.fullHeight;c+=u.offsetX*o/m,n-=u.offsetY*a/p,o*=u.width/m,a*=u.height/p}const h=this.filmOffset;h!==0&&(c+=t*h/this.getFilmWidth()),this.projectionMatrix.makePerspective(c,c+o,n,n-a,t,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){const n=super.toJSON(t);return n.object.fov=this.fov,n.object.zoom=this.zoom,n.object.near=this.near,n.object.far=this.far,n.object.focus=this.focus,n.object.aspect=this.aspect,this.view!==null&&(n.object.view=Object.assign({},this.view)),n.object.filmGauge=this.filmGauge,n.object.filmOffset=this.filmOffset,n}}class Nb extends jx{constructor(){super(new Ei(90,1,.5,500)),this.isPointLightShadow=!0}}class Ol extends tm{constructor(t,n,a=0,o=2){super(t,n),this.isPointLight=!0,this.type="PointLight",this.distance=a,this.decay=o,this.shadow=new Nb}get power(){return this.intensity*4*Math.PI}set power(t){this.intensity=t/(4*Math.PI)}dispose(){super.dispose(),this.shadow.dispose()}copy(t,n){return super.copy(t,n),this.distance=t.distance,this.decay=t.decay,this.shadow=t.shadow.clone(),this}toJSON(t){const n=super.toJSON(t);return n.object.distance=this.distance,n.object.decay=this.decay,n.object.shadow=this.shadow.toJSON(),n}}class em extends $x{constructor(t=-1,n=1,a=1,o=-1,c=.1,u=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=t,this.right=n,this.top=a,this.bottom=o,this.near=c,this.far=u,this.updateProjectionMatrix()}copy(t,n){return super.copy(t,n),this.left=t.left,this.right=t.right,this.top=t.top,this.bottom=t.bottom,this.near=t.near,this.far=t.far,this.zoom=t.zoom,this.view=t.view===null?null:Object.assign({},t.view),this}setViewOffset(t,n,a,o,c,u){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=n,this.view.offsetX=a,this.view.offsetY=o,this.view.width=c,this.view.height=u,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const t=(this.right-this.left)/(2*this.zoom),n=(this.top-this.bottom)/(2*this.zoom),a=(this.right+this.left)/2,o=(this.top+this.bottom)/2;let c=a-t,u=a+t,h=o+n,m=o-n;if(this.view!==null&&this.view.enabled){const p=(this.right-this.left)/this.view.fullWidth/this.zoom,g=(this.top-this.bottom)/this.view.fullHeight/this.zoom;c+=p*this.view.offsetX,u=c+p*this.view.width,h-=g*this.view.offsetY,m=h-g*this.view.height}this.projectionMatrix.makeOrthographic(c,u,h,m,this.near,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){const n=super.toJSON(t);return n.object.zoom=this.zoom,n.object.left=this.left,n.object.right=this.right,n.object.top=this.top,n.object.bottom=this.bottom,n.object.near=this.near,n.object.far=this.far,this.view!==null&&(n.object.view=Object.assign({},this.view)),n}}class Ob extends jx{constructor(){super(new em(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}}class Gu extends tm{constructor(t,n){super(t,n),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(Mn.DEFAULT_UP),this.updateMatrix(),this.target=new Mn,this.shadow=new Ob}dispose(){super.dispose(),this.shadow.dispose()}copy(t){return super.copy(t),this.target=t.target.clone(),this.shadow=t.shadow.clone(),this}toJSON(t){const n=super.toJSON(t);return n.object.shadow=this.shadow.toJSON(),n.object.target=this.target.uuid,n}}const $r=-90,to=1;class Pb extends Mn{constructor(t,n,a){super(),this.type="CubeCamera",this.renderTarget=a,this.coordinateSystem=null,this.activeMipmapLevel=0;const o=new Ei($r,to,t,n);o.layers=this.layers,this.add(o);const c=new Ei($r,to,t,n);c.layers=this.layers,this.add(c);const u=new Ei($r,to,t,n);u.layers=this.layers,this.add(u);const h=new Ei($r,to,t,n);h.layers=this.layers,this.add(h);const m=new Ei($r,to,t,n);m.layers=this.layers,this.add(m);const p=new Ei($r,to,t,n);p.layers=this.layers,this.add(p)}updateCoordinateSystem(){const t=this.coordinateSystem,n=this.children.concat(),[a,o,c,u,h,m]=n;for(const p of n)this.remove(p);if(t===la)a.up.set(0,1,0),a.lookAt(1,0,0),o.up.set(0,1,0),o.lookAt(-1,0,0),c.up.set(0,0,-1),c.lookAt(0,1,0),u.up.set(0,0,1),u.lookAt(0,-1,0),h.up.set(0,1,0),h.lookAt(0,0,1),m.up.set(0,1,0),m.lookAt(0,0,-1);else if(t===Al)a.up.set(0,-1,0),a.lookAt(-1,0,0),o.up.set(0,-1,0),o.lookAt(1,0,0),c.up.set(0,0,1),c.lookAt(0,1,0),u.up.set(0,0,-1),u.lookAt(0,-1,0),h.up.set(0,-1,0),h.lookAt(0,0,1),m.up.set(0,-1,0),m.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+t);for(const p of n)this.add(p),p.updateMatrixWorld()}update(t,n){this.parent===null&&this.updateMatrixWorld();const{renderTarget:a,activeMipmapLevel:o}=this;this.coordinateSystem!==t.coordinateSystem&&(this.coordinateSystem=t.coordinateSystem,this.updateCoordinateSystem());const[c,u,h,m,p,g]=this.children,_=t.getRenderTarget(),v=t.getActiveCubeFace(),x=t.getActiveMipmapLevel(),b=t.xr.enabled;t.xr.enabled=!1;const R=a.texture.generateMipmaps;a.texture.generateMipmaps=!1;let M=!1;t.isWebGLRenderer===!0?M=t.state.buffers.depth.getReversed():M=t.reversedDepthBuffer,t.setRenderTarget(a,0,o),M&&t.autoClear===!1&&t.clearDepth(),t.render(n,c),t.setRenderTarget(a,1,o),M&&t.autoClear===!1&&t.clearDepth(),t.render(n,u),t.setRenderTarget(a,2,o),M&&t.autoClear===!1&&t.clearDepth(),t.render(n,h),t.setRenderTarget(a,3,o),M&&t.autoClear===!1&&t.clearDepth(),t.render(n,m),t.setRenderTarget(a,4,o),M&&t.autoClear===!1&&t.clearDepth(),t.render(n,p),a.texture.generateMipmaps=R,t.setRenderTarget(a,5,o),M&&t.autoClear===!1&&t.clearDepth(),t.render(n,g),t.setRenderTarget(_,v,x),t.xr.enabled=b,a.texture.needsPMREMUpdate=!0}}class zb extends Ei{constructor(t=[]){super(),this.isArrayCamera=!0,this.isMultiViewCamera=!1,this.cameras=t}}const F_=new an;class Vu{constructor(t,n,a=0,o=1/0){this.ray=new Iu(t,n),this.near=a,this.far=o,this.camera=null,this.layers=new Zp,this.params={Mesh:{},Line:{threshold:1},LOD:{},Points:{threshold:1},Sprite:{}}}set(t,n){this.ray.set(t,n)}setFromCamera(t,n){n.isPerspectiveCamera?(this.ray.origin.setFromMatrixPosition(n.matrixWorld),this.ray.direction.set(t.x,t.y,.5).unproject(n).sub(this.ray.origin).normalize(),this.camera=n):n.isOrthographicCamera?(this.ray.origin.set(t.x,t.y,n.projectionMatrix.elements[14]).unproject(n),this.ray.direction.set(0,0,-1).transformDirection(n.matrixWorld),this.camera=n):We("Raycaster: Unsupported camera type: "+n.type)}setFromXRController(t){return F_.identity().extractRotation(t.matrixWorld),this.ray.origin.setFromMatrixPosition(t.matrixWorld),this.ray.direction.set(0,0,-1).applyMatrix4(F_),this}intersectObject(t,n=!0,a=[]){return Dp(t,this,a,n),a.sort(H_),a}intersectObjects(t,n=!0,a=[]){for(let o=0,c=t.length;o<c;o++)Dp(t[o],this,a,n);return a.sort(H_),a}}function H_(r,t){return r.distance-t.distance}function Dp(r,t,n,a){let o=!0;if(r.layers.test(t.layers)&&r.raycast(t,n)===!1&&(o=!1),o===!0&&a===!0){const c=r.children;for(let u=0,h=c.length;u<h;u++)Dp(c[u],t,n,!0)}}const om=class om{constructor(t,n,a,o){this.elements=[1,0,0,1],t!==void 0&&this.set(t,n,a,o)}identity(){return this.set(1,0,0,1),this}fromArray(t,n=0){for(let a=0;a<4;a++)this.elements[a]=t[a+n];return this}set(t,n,a,o){const c=this.elements;return c[0]=t,c[2]=n,c[1]=a,c[3]=o,this}};om.prototype.isMatrix2=!0;let G_=om;function V_(r,t,n,a){const o=Ib(a);switch(n){case Dx:return r*t;case Hp:return r*t/o.components*o.byteLength;case Gp:return r*t/o.components*o.byteLength;case er:return r*t*2/o.components*o.byteLength;case Vp:return r*t*2/o.components*o.byteLength;case Ux:return r*t*3/o.components*o.byteLength;case Qi:return r*t*4/o.components*o.byteLength;case kp:return r*t*4/o.components*o.byteLength;case Mu:case yu:return Math.floor((r+3)/4)*Math.floor((t+3)/4)*8;case bu:case Eu:return Math.floor((r+3)/4)*Math.floor((t+3)/4)*16;case Kd:case Qd:return Math.max(r,16)*Math.max(t,8)/4;case Zd:case Jd:return Math.max(r,8)*Math.max(t,8)/2;case jd:case $d:case ep:case np:return Math.floor((r+3)/4)*Math.floor((t+3)/4)*8;case tp:case Au:case ip:return Math.floor((r+3)/4)*Math.floor((t+3)/4)*16;case ap:return Math.floor((r+3)/4)*Math.floor((t+3)/4)*16;case sp:return Math.floor((r+4)/5)*Math.floor((t+3)/4)*16;case rp:return Math.floor((r+4)/5)*Math.floor((t+4)/5)*16;case op:return Math.floor((r+5)/6)*Math.floor((t+4)/5)*16;case lp:return Math.floor((r+5)/6)*Math.floor((t+5)/6)*16;case cp:return Math.floor((r+7)/8)*Math.floor((t+4)/5)*16;case up:return Math.floor((r+7)/8)*Math.floor((t+5)/6)*16;case fp:return Math.floor((r+7)/8)*Math.floor((t+7)/8)*16;case hp:return Math.floor((r+9)/10)*Math.floor((t+4)/5)*16;case dp:return Math.floor((r+9)/10)*Math.floor((t+5)/6)*16;case pp:return Math.floor((r+9)/10)*Math.floor((t+7)/8)*16;case mp:return Math.floor((r+9)/10)*Math.floor((t+9)/10)*16;case gp:return Math.floor((r+11)/12)*Math.floor((t+9)/10)*16;case vp:return Math.floor((r+11)/12)*Math.floor((t+11)/12)*16;case _p:case xp:case Sp:return Math.ceil(r/4)*Math.ceil(t/4)*16;case Mp:case yp:return Math.ceil(r/4)*Math.ceil(t/4)*8;case wu:case bp:return Math.ceil(r/4)*Math.ceil(t/4)*16}throw new Error(`Unable to determine texture byte length for ${n} format.`)}function Ib(r){switch(r){case Ti:case Ax:return{byteLength:1,components:1};case El:case wx:case $i:return{byteLength:2,components:1};case Bp:case Fp:return{byteLength:2,components:4};case ua:case Ip:case Ji:return{byteLength:4,components:1};case Rx:case Cx:return{byteLength:4,components:3}}throw new Error(`THREE.TextureUtils: Unknown texture type ${r}.`)}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:Pp}}));typeof window<"u"&&(window.__THREE__?ve("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=Pp);/**
 * @license
 * Copyright 2010-2026 Three.js Authors
 * SPDX-License-Identifier: MIT
 */function tS(){let r=null,t=!1,n=null,a=null;function o(c,u){a=r.requestAnimationFrame(o),n(c,u)}return{start:function(){t!==!0&&n!==null&&r!==null&&(a=r.requestAnimationFrame(o),t=!0)},stop:function(){r!==null&&r.cancelAnimationFrame(a),t=!1},setAnimationLoop:function(c){n=c},setContext:function(c){r=c}}}function Bb(r){const t=new WeakMap;function n(h,m){const p=h.array,g=h.usage,_=p.byteLength,v=r.createBuffer();r.bindBuffer(m,v),r.bufferData(m,p,g),h.onUploadCallback();let x;if(p instanceof Float32Array)x=r.FLOAT;else if(typeof Float16Array<"u"&&p instanceof Float16Array)x=r.HALF_FLOAT;else if(p instanceof Uint16Array)h.isFloat16BufferAttribute?x=r.HALF_FLOAT:x=r.UNSIGNED_SHORT;else if(p instanceof Int16Array)x=r.SHORT;else if(p instanceof Uint32Array)x=r.UNSIGNED_INT;else if(p instanceof Int32Array)x=r.INT;else if(p instanceof Int8Array)x=r.BYTE;else if(p instanceof Uint8Array)x=r.UNSIGNED_BYTE;else if(p instanceof Uint8ClampedArray)x=r.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+p);return{buffer:v,type:x,bytesPerElement:p.BYTES_PER_ELEMENT,version:h.version,size:_}}function a(h,m,p){const g=m.array,_=m.updateRanges;if(r.bindBuffer(p,h),_.length===0)r.bufferSubData(p,0,g);else{_.sort((x,b)=>x.start-b.start);let v=0;for(let x=1;x<_.length;x++){const b=_[v],R=_[x];R.start<=b.start+b.count+1?b.count=Math.max(b.count,R.start+R.count-b.start):(++v,_[v]=R)}_.length=v+1;for(let x=0,b=_.length;x<b;x++){const R=_[x];r.bufferSubData(p,R.start*g.BYTES_PER_ELEMENT,g,R.start,R.count)}m.clearUpdateRanges()}m.onUploadCallback()}function o(h){return h.isInterleavedBufferAttribute&&(h=h.data),t.get(h)}function c(h){h.isInterleavedBufferAttribute&&(h=h.data);const m=t.get(h);m&&(r.deleteBuffer(m.buffer),t.delete(h))}function u(h,m){if(h.isInterleavedBufferAttribute&&(h=h.data),h.isGLBufferAttribute){const g=t.get(h);(!g||g.version<h.version)&&t.set(h,{buffer:h.buffer,type:h.type,bytesPerElement:h.elementSize,version:h.version});return}const p=t.get(h);if(p===void 0)t.set(h,n(h,m));else if(p.version<h.version){if(p.size!==h.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");a(p.buffer,h,m),p.version=h.version}}return{get:o,remove:c,update:u}}var Fb=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,Hb=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,Gb=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,Vb=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,kb=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,Xb=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,Wb=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,qb=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,Yb=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec4 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 );
	}
#endif`,Zb=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,Kb=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,Jb=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,Qb=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,jb=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,$b=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,tE=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,eE=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,nE=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,iE=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,aE=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#endif`,sE=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#endif`,rE=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec4 vColor;
#endif`,oE=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec4( 1.0 );
#endif
#ifdef USE_COLOR_ALPHA
	vColor *= color;
#elif defined( USE_COLOR )
	vColor.rgb *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.rgb *= instanceColor.rgb;
#endif
#ifdef USE_BATCHING_COLOR
	vColor *= getBatchingColor( getIndirectIndex( gl_DrawID ) );
#endif`,lE=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
#define inverseTransformDirection transformDirectionByInverseViewMatrix
vec3 transformNormalByInverseViewMatrix( in vec3 normal, in mat4 viewMatrix ) {
	return normalize( ( vec4( normal, 0.0 ) * viewMatrix ).xyz );
}
vec3 transformDirectionByInverseViewMatrix( in vec3 dir, in mat4 viewMatrix ) {
	return normalize( ( vec4( dir, 0.0 ) * viewMatrix ).xyz );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,cE=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,uE=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
#endif`,fE=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,hE=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,dE=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,pE=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,mE="gl_FragColor = linearToOutputTexel( gl_FragColor );",gE=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,vE=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * reflectVec );
		#ifdef ENVMAP_BLENDING_MULTIPLY
			outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_MIX )
			outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_ADD )
			outgoingLight += envColor.xyz * specularStrength * reflectivity;
		#endif
	#endif
#endif`,_E=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
#endif`,xE=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,SE=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,ME=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,yE=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,bE=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,EE=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,TE=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,AE=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,wE=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,RE=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,CE=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,DE=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_SUN_LIGHTS > 0
	struct SunLight {
		vec3 direction;
		vec3 color;
	};
	uniform SunLight sunLights[ NUM_SUN_LIGHTS ];
	void getSunLightInfo( const in SunLight sunLight, out IncidentLight light ) {
		light.color = sunLight.color;
		light.direction = sunLight.direction;
		light.visible = true;
	}
#endif
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif
#include <lightprobes_pars_fragment>`,UE=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, pow4( roughness ) ) );
			reflectVec = transformDirectionByInverseViewMatrix( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_RETROREFLECTION
		vec3 getIBLRetroRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 retroVec = normalize( mix( viewDir, normal, pow4( roughness ) ) );
				retroVec = transformDirectionByInverseViewMatrix( retroVec, viewMatrix );
				vec4 envMapColor = textureCubeUV( envMap, envMapRotation * retroVec, roughness );
				return envMapColor.rgb * envMapIntensity;
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
		#ifdef USE_RETROREFLECTION
			vec3 getIBLAnisotropyRetroRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
				#ifdef ENVMAP_TYPE_CUBE_UV
					vec3 bentNormal = cross( bitangent, viewDir );
					bentNormal = normalize( cross( bentNormal, bitangent ) );
					bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
					return getIBLRetroRadiance( viewDir, bentNormal, roughness );
				#else
					return vec3( 0.0 );
				#endif
			}
		#endif
	#endif
#endif`,LE=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,NE=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,OE=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,PE=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,zE=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.diffuseContribution = diffuseColor.rgb * ( 1.0 - metalnessFactor );
material.metalness = metalnessFactor;
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor;
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = vec3( 0.04 );
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_RETROREFLECTION
	material.retroreflectivity = retroreflectivity;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.0001, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,IE=`uniform sampler2D dfgLUT;
struct PhysicalMaterial {
	vec3 diffuseColor;
	vec3 diffuseContribution;
	vec3 specularColor;
	vec3 specularColorBlended;
	float roughness;
	float metalness;
	float specularF90;
	float dispersion;
	vec2 dfg;
	vec3 multiScatteringCompensation;
	#ifdef USE_RETROREFLECTION
		float retroreflectivity;
	#endif
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0Dielectric;
		vec3 iridescenceF0Metallic;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		return 0.5 / max( gv + gl, EPSILON );
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColorBlended;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transpose( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float rInv = 1.0 / ( roughness + 0.1 );
	float a = -1.9362 + 1.0678 * roughness + 0.4573 * r2 - 0.8469 * rInv;
	float b = -0.6014 + 0.5538 * roughness - 0.4670 * r2 - 0.1255 * rInv;
	float DG = exp( a * dotNV + b );
	return saturate( DG );
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec2 fab, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec2 fab, const in vec3 specularColor, const in float specularF90, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColorBlended * t2.x + ( material.specularF90 - material.specularColorBlended ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseContribution * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
		#ifdef USE_CLEARCOAT
			vec3 Ncc = geometryClearcoatNormal;
			vec2 uvClearcoat = LTC_Uv( Ncc, viewDir, material.clearcoatRoughness );
			vec4 t1Clearcoat = texture2D( ltc_1, uvClearcoat );
			vec4 t2Clearcoat = texture2D( ltc_2, uvClearcoat );
			mat3 mInvClearcoat = mat3(
				vec3( t1Clearcoat.x, 0, t1Clearcoat.y ),
				vec3(             0, 1,             0 ),
				vec3( t1Clearcoat.z, 0, t1Clearcoat.w )
			);
			vec3 fresnelClearcoat = material.clearcoatF0 * t2Clearcoat.x + ( material.clearcoatF90 - material.clearcoatF0 ) * t2Clearcoat.y;
			clearcoatSpecularDirect += lightColor * fresnelClearcoat * LTC_Evaluate( Ncc, viewDir, position, mInvClearcoat, rectCoords );
		#endif
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
 
 		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
 
 		float sheenAlbedoV = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
 		float sheenAlbedoL = IBLSheenBRDF( geometryNormal, directLight.direction, material.sheenRoughness );
 
 		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * max( sheenAlbedoV, sheenAlbedoL );
 
 		irradiance *= sheenEnergyComp;
 
 	#endif
	vec3 specularBRDF = BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	#ifdef USE_RETROREFLECTION
		vec3 retroViewDir = reflect( - geometryViewDir, geometryNormal );
		vec3 retroSpecularBRDF = BRDF_GGX( directLight.direction, retroViewDir, geometryNormal, material );
		specularBRDF = mix( specularBRDF, retroSpecularBRDF, saturate( material.retroreflectivity ) );
	#endif
	reflectedLight.directSpecular += irradiance * specularBRDF * material.multiScatteringCompensation;
	vec3 halfDir = normalize( directLight.direction + geometryViewDir );
	float dotVH = saturate( dot( geometryViewDir, halfDir ) );
	vec3 F = F_Schlick( material.specularColor, material.specularF90, dotVH );
	#ifdef USE_RETROREFLECTION
		vec3 retroHalfDir = normalize( directLight.direction + retroViewDir );
		float dotRetroVH = saturate( dot( retroViewDir, retroHalfDir ) );
		vec3 retroF = F_Schlick( material.specularColor, material.specularF90, dotRetroVH );
		F = mix( F, retroF, saturate( material.retroreflectivity ) );
	#endif
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseContribution ) * ( 1.0 - F );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( material.dfg, material.specularColor, material.specularF90, material.iridescence, material.iridescenceF0Dielectric, singleScattering, multiScattering );
	#else
		computeMultiscattering( material.dfg, material.specularColor, material.specularF90, singleScattering, multiScattering );
	#endif
	vec3 diffuse = irradiance * BRDF_Lambert( material.diffuseContribution ) * ( 1.0 - singleScattering - multiScattering );
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		sheenSpecularIndirect += irradiance * material.sheenColor * sheenAlbedo * RECIPROCAL_PI;
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		diffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectDiffuse += diffuse;
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness ) * RECIPROCAL_PI;
 	#endif
	vec3 singleScatteringDielectric = vec3( 0.0 );
	vec3 multiScatteringDielectric = vec3( 0.0 );
	vec3 singleScatteringMetallic = vec3( 0.0 );
	vec3 multiScatteringMetallic = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( material.dfg, material.specularColor, material.specularF90, material.iridescence, material.iridescenceF0Dielectric, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscatteringIridescence( material.dfg, material.diffuseColor, material.specularF90, material.iridescence, material.iridescenceF0Metallic, singleScatteringMetallic, multiScatteringMetallic );
	#else
		computeMultiscattering( material.dfg, material.specularColor, material.specularF90, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscattering( material.dfg, material.diffuseColor, material.specularF90, singleScatteringMetallic, multiScatteringMetallic );
	#endif
	vec3 singleScattering = mix( singleScatteringDielectric, singleScatteringMetallic, material.metalness );
	vec3 multiScattering = mix( multiScatteringDielectric, multiScatteringMetallic, material.metalness );
	vec3 totalScatteringDielectric = singleScatteringDielectric + multiScatteringDielectric;
	vec3 diffuse = material.diffuseContribution * ( 1.0 - totalScatteringDielectric );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	vec3 indirectSpecular = radiance * singleScattering;
	indirectSpecular += multiScattering * cosineWeightedIrradiance;
	vec3 indirectDiffuse = diffuse * cosineWeightedIrradiance;
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		indirectSpecular *= sheenEnergyComp;
		indirectDiffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectSpecular += indirectSpecular;
	reflectedLight.indirectDiffuse += indirectDiffuse;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,BE=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		vec3 iridescenceFresnelDielectric = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		vec3 iridescenceFresnelMetallic = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.diffuseColor );
		material.iridescenceFresnel = mix( iridescenceFresnelDielectric, iridescenceFresnelMetallic, material.metalness );
		material.iridescenceF0Dielectric = Schlick_to_F0( iridescenceFresnelDielectric, 1.0, dotNVi );
		material.iridescenceF0Metallic = Schlick_to_F0( iridescenceFresnelMetallic, 1.0, dotNVi );
	}
#endif
#ifdef STANDARD
	float dotNVms = saturate( dot( geometryNormal, geometryViewDir ) );
	material.dfg = texture2D( dfgLUT, vec2( material.roughness, dotNVms ) ).rg;
	#if ( NUM_SUN_LIGHTS > 0 || NUM_DIR_LIGHTS > 0 || NUM_POINT_LIGHTS > 0 || NUM_SPOT_LIGHTS > 0 )
		float EssMs = material.dfg.x + material.dfg.y;
		material.multiScatteringCompensation = 1.0 + material.specularColorBlended * ( 1.0 / EssMs - 1.0 );
	#endif
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS ) && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SUN_LIGHTS > 0 ) && defined( RE_Direct )
	SunLight sunLight;
	#if defined( USE_SHADOWMAP ) && NUM_SUN_LIGHT_SHADOWS > 0
	SunLightShadow sunLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SUN_LIGHTS; i ++ ) {
		sunLight = sunLights[ i ];
		getSunLightInfo( sunLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SUN_LIGHT_SHADOWS )
		sunLightShadow = sunLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getSunShadow( sunShadowMap[ i ], sunLightShadow, UNROLLED_LOOP_INDEX ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
	#ifdef USE_LIGHT_PROBES_GRID
		vec3 probeWorldPos = ( ( vec4( geometryPosition, 1.0 ) - viewMatrix[ 3 ] ) * viewMatrix ).xyz;
		vec3 probeWorldNormal = transformNormalByInverseViewMatrix( geometryNormal, viewMatrix );
		irradiance += getLightProbeGridIrradiance( probeWorldPos, probeWorldNormal );
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,FE=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( ENVMAP_TYPE_CUBE_UV )
		#if defined( STANDARD ) || defined( LAMBERT ) || defined( PHONG )
			iblIrradiance += getIBLIrradiance( geometryNormal );
		#endif
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		vec3 iblRadiance = getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		vec3 iblRadiance = getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_RETROREFLECTION
		#ifdef USE_ANISOTROPY
			vec3 retroIBLRadiance = getIBLAnisotropyRetroRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
		#else
			vec3 retroIBLRadiance = getIBLRetroRadiance( geometryViewDir, geometryNormal, material.roughness );
		#endif
		iblRadiance = mix( iblRadiance, retroIBLRadiance, saturate( material.retroreflectivity ) );
	#endif
	radiance += iblRadiance;
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,HE=`#if defined( RE_IndirectDiffuse )
	#if defined( LAMBERT ) || defined( PHONG )
		irradiance += iblIrradiance;
	#endif
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,GE=`#ifdef USE_LIGHT_PROBES_GRID
uniform highp sampler3D probesSH;
uniform vec3 probesMin;
uniform vec3 probesMax;
uniform vec3 probesResolution;
vec3 getLightProbeGridIrradiance( vec3 worldPos, vec3 worldNormal ) {
	vec3 res = probesResolution;
	vec3 gridRange = probesMax - probesMin;
	vec3 resMinusOne = res - 1.0;
	vec3 probeSpacing = gridRange / resMinusOne;
	vec3 samplePos = worldPos + worldNormal * probeSpacing * 0.5;
	vec3 uvw = clamp( ( samplePos - probesMin ) / gridRange, 0.0, 1.0 );
	uvw = uvw * resMinusOne / res + 0.5 / res;
	float nz          = res.z;
	float paddedSlices = nz + 2.0;
	float atlasDepth  = 7.0 * paddedSlices;
	float uvZBase     = uvw.z * nz + 1.0;
	vec4 s0 = texture( probesSH, vec3( uvw.xy, ( uvZBase                       ) / atlasDepth ) );
	vec4 s1 = texture( probesSH, vec3( uvw.xy, ( uvZBase +       paddedSlices   ) / atlasDepth ) );
	vec4 s2 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 2.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s3 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 3.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s4 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 4.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s5 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 5.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s6 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 6.0 * paddedSlices   ) / atlasDepth ) );
	vec3 c0 = s0.xyz;
	vec3 c1 = vec3( s0.w, s1.xy );
	vec3 c2 = vec3( s1.zw, s2.x );
	vec3 c3 = s2.yzw;
	vec3 c4 = s3.xyz;
	vec3 c5 = vec3( s3.w, s4.xy );
	vec3 c6 = vec3( s4.zw, s5.x );
	vec3 c7 = s5.yzw;
	vec3 c8 = s6.xyz;
	float x = worldNormal.x, y = worldNormal.y, z = worldNormal.z;
	vec3 result = c0 * 0.886227;
	result += c1 * 2.0 * 0.511664 * y;
	result += c2 * 2.0 * 0.511664 * z;
	result += c3 * 2.0 * 0.511664 * x;
	result += c4 * 2.0 * 0.429043 * x * y;
	result += c5 * 2.0 * 0.429043 * y * z;
	result += c6 * ( 0.743125 * z * z - 0.247708 );
	result += c7 * 2.0 * 0.429043 * x * z;
	result += c8 * 0.429043 * ( x * x - y * y );
	return max( result, vec3( 0.0 ) );
}
#endif`,VE=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,kE=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,XE=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,WE=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,qE=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,YE=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,ZE=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,KE=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,JE=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,QE=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,jE=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,$E=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,tT=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,eT=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,nT=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,iT=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#ifdef DOUBLE_SIDED
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#ifdef DOUBLE_SIDED
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,aT=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#if defined( USE_PACKED_NORMALMAP )
		mapN = vec3( mapN.xy, sqrt( saturate( 1.0 - dot( mapN.xy, mapN.xy ) ) ) );
	#endif
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,sT=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,rT=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,oT=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
		#ifdef FLIP_SIDED
			vBitangent = - vBitangent;
		#endif
	#endif
#endif`,lT=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,cT=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,uT=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,fT=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,hT=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,dT=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,pT=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	#ifdef USE_REVERSED_DEPTH_BUFFER
	
		return depth * ( far - near ) - far;
	#else
		return depth * ( near - far ) - near;
	#endif
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	
	#ifdef USE_REVERSED_DEPTH_BUFFER
		return ( near * far ) / ( ( near - far ) * depth - near );
	#else
		return ( near * far ) / ( ( far - near ) * depth - far );
	#endif
}`,mT=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,gT=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,vT=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,_T=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,xT=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,ST=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,MT=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
		#define SUN_LIGHT_CASCADES 2
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow sunShadowMap[ NUM_SUN_LIGHT_SHADOWS ];
		#else
			uniform sampler2D sunShadowMap[ NUM_SUN_LIGHT_SHADOWS ];
		#endif
		uniform mat4 sunShadowMatrix[ NUM_SUN_LIGHT_SHADOWS * SUN_LIGHT_CASCADES ];
		uniform vec4 sunShadowCascade[ NUM_SUN_LIGHT_SHADOWS * SUN_LIGHT_CASCADES ];
		varying vec4 vSunShadowWorldPosition;
		varying vec3 vSunShadowWorldNormal;
		struct SunLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SunLightShadow sunLightShadows[ NUM_SUN_LIGHT_SHADOWS ];
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#else
			uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#endif
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#else
			uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#endif
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform samplerCubeShadow pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#elif defined( SHADOWMAP_TYPE_BASIC )
			uniform samplerCube pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#endif
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float interleavedGradientNoise( vec2 position ) {
			return fract( 52.9829189 * fract( dot( position, vec2( 0.06711056, 0.00583715 ) ) ) );
		}
		vec2 vogelDiskSample( int sampleIndex, int samplesCount, float phi ) {
			const float goldenAngle = 2.399963229728653;
			float r = sqrt( ( float( sampleIndex ) + 0.5 ) / float( samplesCount ) );
			float theta = float( sampleIndex ) * goldenAngle + phi;
			return vec2( cos( theta ), sin( theta ) ) * r;
		}
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float getShadow( sampler2DShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			shadowCoord.z += shadowBias;
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
				float radius = shadowRadius * texelSize.x;
				float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
				shadow = (
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 0, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 1, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 2, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 3, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 4, 5, phi ) * radius, shadowCoord.z ) )
				) * 0.2;
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#elif defined( SHADOWMAP_TYPE_VSM )
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 distribution = texture2D( shadowMap, shadowCoord.xy ).rg;
				float mean = distribution.x;
				float variance = distribution.y * distribution.y;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					float hard_shadow = step( mean, shadowCoord.z );
				#else
					float hard_shadow = step( shadowCoord.z, mean );
				#endif
				
				if ( hard_shadow == 1.0 ) {
					shadow = 1.0;
				} else {
					variance = max( variance, 0.0000001 );
					float d = shadowCoord.z - mean;
					float p_max = variance / ( variance + d * d );
					p_max = clamp( ( p_max - 0.3 ) / 0.65, 0.0, 1.0 );
					shadow = max( hard_shadow, p_max );
				}
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#else
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				float depth = texture2D( shadowMap, shadowCoord.xy ).r;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					shadow = step( depth, shadowCoord.z );
				#else
					shadow = step( shadowCoord.z, depth );
				#endif
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#endif
	#if NUM_SUN_LIGHT_SHADOWS > 0
		float getSunShadow(
			#if defined( SHADOWMAP_TYPE_PCF )
				sampler2DShadow shadowMap,
			#else
				sampler2D shadowMap,
			#endif
			SunLightShadow sunLightShadow,
			int shadowIndex
		) {
			vec4 shadowWorldPosition = vec4( vSunShadowWorldPosition.xyz + vSunShadowWorldNormal * sunLightShadow.shadowNormalBias, 1.0 );
			float viewDepth = vSunShadowWorldPosition.w;
			int cascadeOffset = shadowIndex * SUN_LIGHT_CASCADES;
			float shadow = 1.0;
			for ( int i = SUN_LIGHT_CASCADES - 1; i >= 0; i -- ) {
				vec4 cascade = sunShadowCascade[ cascadeOffset + i ];
				if ( viewDepth >= cascade.x && viewDepth < cascade.y ) {
					float cascadeShadow = getShadow(
						shadowMap,
						sunLightShadow.shadowMapSize,
						sunLightShadow.shadowIntensity,
						sunLightShadow.shadowBias,
						sunLightShadow.shadowRadius,
						sunShadowMatrix[ cascadeOffset + i ] * shadowWorldPosition
					);
					shadow = mix( cascadeShadow, shadow, smoothstep( cascade.z, cascade.y, viewDepth ) );
				}
			}
			return shadow;
		}
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	#if defined( SHADOWMAP_TYPE_PCF )
	float getPointShadow( samplerCubeShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 bd3D = normalize( lightToPosition );
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			#ifdef USE_REVERSED_DEPTH_BUFFER
				float dp = ( shadowCameraNear * ( shadowCameraFar - viewSpaceZ ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp -= shadowBias;
			#else
				float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp += shadowBias;
			#endif
			float texelSize = shadowRadius / shadowMapSize.x;
			vec3 absDir = abs( bd3D );
			vec3 tangent = absDir.x > absDir.z ? vec3( 0.0, 1.0, 0.0 ) : vec3( 1.0, 0.0, 0.0 );
			tangent = normalize( cross( bd3D, tangent ) );
			vec3 bitangent = cross( bd3D, tangent );
			float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
			vec2 sample0 = vogelDiskSample( 0, 5, phi );
			vec2 sample1 = vogelDiskSample( 1, 5, phi );
			vec2 sample2 = vogelDiskSample( 2, 5, phi );
			vec2 sample3 = vogelDiskSample( 3, 5, phi );
			vec2 sample4 = vogelDiskSample( 4, 5, phi );
			shadow = (
				texture( shadowMap, vec4( bd3D + ( tangent * sample0.x + bitangent * sample0.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample1.x + bitangent * sample1.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample2.x + bitangent * sample2.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample3.x + bitangent * sample3.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample4.x + bitangent * sample4.y ) * texelSize, dp ) )
			) * 0.2;
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#elif defined( SHADOWMAP_TYPE_BASIC )
	float getPointShadow( samplerCube shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			float depth = textureCube( shadowMap, bd3D ).r;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				depth = 1.0 - depth;
			#endif
			shadow = step( dp, depth );
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#endif
	#endif
#endif`,yT=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
		varying vec4 vSunShadowWorldPosition;
		varying vec3 vSunShadowWorldNormal;
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,bT=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_SUN_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	#ifdef HAS_NORMAL
		vec3 shadowWorldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
	#else
		vec3 shadowWorldNormal = vec3( 0.0 );
	#endif
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_SUN_LIGHT_SHADOWS > 0
		vSunShadowWorldPosition = vec4( worldPosition.xyz, - mvPosition.z );
		vSunShadowWorldNormal = shadowWorldNormal;
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,ET=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
	SunLightShadow sunLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SUN_LIGHT_SHADOWS; i ++ ) {
		sunLight = sunLightShadows[ i ];
		shadow *= receiveShadow ? getSunShadow( sunShadowMap[ i ], sunLight, UNROLLED_LOOP_INDEX ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0 && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,TT=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,AT=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,wT=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,RT=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,CT=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,DT=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,UT=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,LT=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,NT=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseContribution, material.specularColorBlended, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,OT=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,PT=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,zT=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,IT=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,BT=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const FT=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,HT=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,GT=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,VT=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vWorldDirection );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,kT=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,XT=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,WT=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,qT=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,YT=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,ZT=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = vec4( dist, 0.0, 0.0, 1.0 );
}`,KT=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,JT=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,QT=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,jT=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,$T=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,t2=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,e2=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,n2=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,i2=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,a2=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,s2=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,r2=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( normalize( normal ) * 0.5 + 0.5, diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,o2=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,l2=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,c2=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,u2=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_RETROREFLECTION
	uniform float retroreflectivity;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
 
		outgoingLight = outgoingLight + sheenSpecularDirect + sheenSpecularIndirect;
 
 	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,f2=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,h2=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,d2=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,p2=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,m2=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,g2=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,v2=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,_2=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,De={alphahash_fragment:Fb,alphahash_pars_fragment:Hb,alphamap_fragment:Gb,alphamap_pars_fragment:Vb,alphatest_fragment:kb,alphatest_pars_fragment:Xb,aomap_fragment:Wb,aomap_pars_fragment:qb,batching_pars_vertex:Yb,batching_vertex:Zb,begin_vertex:Kb,beginnormal_vertex:Jb,bsdfs:Qb,iridescence_fragment:jb,bumpmap_pars_fragment:$b,clipping_planes_fragment:tE,clipping_planes_pars_fragment:eE,clipping_planes_pars_vertex:nE,clipping_planes_vertex:iE,color_fragment:aE,color_pars_fragment:sE,color_pars_vertex:rE,color_vertex:oE,common:lE,cube_uv_reflection_fragment:cE,defaultnormal_vertex:uE,displacementmap_pars_vertex:fE,displacementmap_vertex:hE,emissivemap_fragment:dE,emissivemap_pars_fragment:pE,colorspace_fragment:mE,colorspace_pars_fragment:gE,envmap_fragment:vE,envmap_common_pars_fragment:_E,envmap_pars_fragment:xE,envmap_pars_vertex:SE,envmap_physical_pars_fragment:UE,envmap_vertex:ME,fog_vertex:yE,fog_pars_vertex:bE,fog_fragment:EE,fog_pars_fragment:TE,gradientmap_pars_fragment:AE,lightmap_pars_fragment:wE,lights_lambert_fragment:RE,lights_lambert_pars_fragment:CE,lights_pars_begin:DE,lights_toon_fragment:LE,lights_toon_pars_fragment:NE,lights_phong_fragment:OE,lights_phong_pars_fragment:PE,lights_physical_fragment:zE,lights_physical_pars_fragment:IE,lights_fragment_begin:BE,lights_fragment_maps:FE,lights_fragment_end:HE,lightprobes_pars_fragment:GE,logdepthbuf_fragment:VE,logdepthbuf_pars_fragment:kE,logdepthbuf_pars_vertex:XE,logdepthbuf_vertex:WE,map_fragment:qE,map_pars_fragment:YE,map_particle_fragment:ZE,map_particle_pars_fragment:KE,metalnessmap_fragment:JE,metalnessmap_pars_fragment:QE,morphinstance_vertex:jE,morphcolor_vertex:$E,morphnormal_vertex:tT,morphtarget_pars_vertex:eT,morphtarget_vertex:nT,normal_fragment_begin:iT,normal_fragment_maps:aT,normal_pars_fragment:sT,normal_pars_vertex:rT,normal_vertex:oT,normalmap_pars_fragment:lT,clearcoat_normal_fragment_begin:cT,clearcoat_normal_fragment_maps:uT,clearcoat_pars_fragment:fT,iridescence_pars_fragment:hT,opaque_fragment:dT,packing:pT,premultiplied_alpha_fragment:mT,project_vertex:gT,dithering_fragment:vT,dithering_pars_fragment:_T,roughnessmap_fragment:xT,roughnessmap_pars_fragment:ST,shadowmap_pars_fragment:MT,shadowmap_pars_vertex:yT,shadowmap_vertex:bT,shadowmask_pars_fragment:ET,skinbase_vertex:TT,skinning_pars_vertex:AT,skinning_vertex:wT,skinnormal_vertex:RT,specularmap_fragment:CT,specularmap_pars_fragment:DT,tonemapping_fragment:UT,tonemapping_pars_fragment:LT,transmission_fragment:NT,transmission_pars_fragment:OT,uv_pars_fragment:PT,uv_pars_vertex:zT,uv_vertex:IT,worldpos_vertex:BT,background_vert:FT,background_frag:HT,backgroundCube_vert:GT,backgroundCube_frag:VT,cube_vert:kT,cube_frag:XT,depth_vert:WT,depth_frag:qT,distance_vert:YT,distance_frag:ZT,equirect_vert:KT,equirect_frag:JT,linedashed_vert:QT,linedashed_frag:jT,meshbasic_vert:$T,meshbasic_frag:t2,meshlambert_vert:e2,meshlambert_frag:n2,meshmatcap_vert:i2,meshmatcap_frag:a2,meshnormal_vert:s2,meshnormal_frag:r2,meshphong_vert:o2,meshphong_frag:l2,meshphysical_vert:c2,meshphysical_frag:u2,meshtoon_vert:f2,meshtoon_frag:h2,points_vert:d2,points_frag:p2,shadow_vert:m2,shadow_frag:g2,sprite_vert:v2,sprite_frag:_2},Jt={common:{diffuse:{value:new ue(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new ye},alphaMap:{value:null},alphaMapTransform:{value:new ye},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new ye}},envmap:{envMap:{value:null},envMapRotation:{value:new ye},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98},dfgLUT:{value:null}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new ye}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new ye}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new ye},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new ye},normalScale:{value:new Lt(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new ye},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new ye}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new ye}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new ye}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new ue(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},sunLights:{value:[],properties:{direction:{},color:{}}},sunLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},sunShadowMatrix:{value:[]},sunShadowCascade:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null},probesSH:{value:null},probesMin:{value:new B},probesMax:{value:new B},probesResolution:{value:new B}},points:{diffuse:{value:new ue(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new ye},alphaTest:{value:0},uvTransform:{value:new ye}},sprite:{diffuse:{value:new ue(16777215)},opacity:{value:1},center:{value:new Lt(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new ye},alphaMap:{value:null},alphaMapTransform:{value:new ye},alphaTest:{value:0}}},oa={basic:{uniforms:ri([Jt.common,Jt.specularmap,Jt.envmap,Jt.aomap,Jt.lightmap,Jt.fog]),vertexShader:De.meshbasic_vert,fragmentShader:De.meshbasic_frag},lambert:{uniforms:ri([Jt.common,Jt.specularmap,Jt.envmap,Jt.aomap,Jt.lightmap,Jt.emissivemap,Jt.bumpmap,Jt.normalmap,Jt.displacementmap,Jt.fog,Jt.lights,{emissive:{value:new ue(0)},envMapIntensity:{value:1}}]),vertexShader:De.meshlambert_vert,fragmentShader:De.meshlambert_frag},phong:{uniforms:ri([Jt.common,Jt.specularmap,Jt.envmap,Jt.aomap,Jt.lightmap,Jt.emissivemap,Jt.bumpmap,Jt.normalmap,Jt.displacementmap,Jt.fog,Jt.lights,{emissive:{value:new ue(0)},specular:{value:new ue(1118481)},shininess:{value:30},envMapIntensity:{value:1}}]),vertexShader:De.meshphong_vert,fragmentShader:De.meshphong_frag},standard:{uniforms:ri([Jt.common,Jt.envmap,Jt.aomap,Jt.lightmap,Jt.emissivemap,Jt.bumpmap,Jt.normalmap,Jt.displacementmap,Jt.roughnessmap,Jt.metalnessmap,Jt.fog,Jt.lights,{emissive:{value:new ue(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:De.meshphysical_vert,fragmentShader:De.meshphysical_frag},toon:{uniforms:ri([Jt.common,Jt.aomap,Jt.lightmap,Jt.emissivemap,Jt.bumpmap,Jt.normalmap,Jt.displacementmap,Jt.gradientmap,Jt.fog,Jt.lights,{emissive:{value:new ue(0)}}]),vertexShader:De.meshtoon_vert,fragmentShader:De.meshtoon_frag},matcap:{uniforms:ri([Jt.common,Jt.bumpmap,Jt.normalmap,Jt.displacementmap,Jt.fog,{matcap:{value:null}}]),vertexShader:De.meshmatcap_vert,fragmentShader:De.meshmatcap_frag},points:{uniforms:ri([Jt.points,Jt.fog]),vertexShader:De.points_vert,fragmentShader:De.points_frag},dashed:{uniforms:ri([Jt.common,Jt.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:De.linedashed_vert,fragmentShader:De.linedashed_frag},depth:{uniforms:ri([Jt.common,Jt.displacementmap]),vertexShader:De.depth_vert,fragmentShader:De.depth_frag},normal:{uniforms:ri([Jt.common,Jt.bumpmap,Jt.normalmap,Jt.displacementmap,{opacity:{value:1}}]),vertexShader:De.meshnormal_vert,fragmentShader:De.meshnormal_frag},sprite:{uniforms:ri([Jt.sprite,Jt.fog]),vertexShader:De.sprite_vert,fragmentShader:De.sprite_frag},background:{uniforms:{uvTransform:{value:new ye},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:De.background_vert,fragmentShader:De.background_frag},backgroundCube:{uniforms:{envMap:{value:null},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new ye}},vertexShader:De.backgroundCube_vert,fragmentShader:De.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:De.cube_vert,fragmentShader:De.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:De.equirect_vert,fragmentShader:De.equirect_frag},distance:{uniforms:ri([Jt.common,Jt.displacementmap,{referencePosition:{value:new B},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:De.distance_vert,fragmentShader:De.distance_frag},shadow:{uniforms:ri([Jt.lights,Jt.fog,{color:{value:new ue(0)},opacity:{value:1}}]),vertexShader:De.shadow_vert,fragmentShader:De.shadow_frag}};oa.physical={uniforms:ri([oa.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new ye},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new ye},clearcoatNormalScale:{value:new Lt(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new ye},dispersion:{value:0},retroreflectivity:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new ye},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new ye},sheen:{value:0},sheenColor:{value:new ue(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new ye},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new ye},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new ye},transmissionSamplerSize:{value:new Lt},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new ye},attenuationDistance:{value:0},attenuationColor:{value:new ue(0)},specularColor:{value:new ue(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new ye},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new ye},anisotropyVector:{value:new Lt},anisotropyMap:{value:null},anisotropyMapTransform:{value:new ye}}]),vertexShader:De.meshphysical_vert,fragmentShader:De.meshphysical_frag};const _u={r:0,b:0,g:0},x2=new an,eS=new ye;eS.set(-1,0,0,0,1,0,0,0,1);function S2(r,t,n,a,o,c){const u=new ue(0);let h=o===!0?0:1,m,p,g=null,_=0,v=null;function x(C){let O=C.isScene===!0?C.background:null;if(O&&O.isTexture){const E=C.backgroundBlurriness>0;O=t.get(O,E)}return O}function b(C){let O=!1;const E=x(C);E===null?M(u,h):E&&E.isColor&&(M(E,1),O=!0);const U=r.xr.getEnvironmentBlendMode();U==="additive"?n.buffers.color.setClear(0,0,0,1,c):U==="alpha-blend"&&n.buffers.color.setClear(0,0,0,0,c),(r.autoClear||O)&&(n.buffers.depth.setTest(!0),n.buffers.depth.setMask(!0),n.buffers.color.setMask(!0),r.clear(r.autoClearColor,r.autoClearDepth,r.autoClearStencil))}function R(C,O){const E=x(O);E&&(E.isCubeTexture||E.mapping===zu)?(p===void 0&&(p=new le(new Wa(1,1,1),new ei({name:"BackgroundCubeMaterial",uniforms:uo(oa.backgroundCube.uniforms),vertexShader:oa.backgroundCube.vertexShader,fragmentShader:oa.backgroundCube.fragmentShader,side:oi,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),p.geometry.deleteAttribute("normal"),p.geometry.deleteAttribute("uv"),p.onBeforeRender=function(U,L,P){this.matrixWorld.copyPosition(P.matrixWorld)},Object.defineProperty(p.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),a.update(p)),p.material.uniforms.envMap.value=E,p.material.uniforms.backgroundBlurriness.value=O.backgroundBlurriness,p.material.uniforms.backgroundIntensity.value=O.backgroundIntensity,p.material.uniforms.backgroundRotation.value.setFromMatrix4(x2.makeRotationFromEuler(O.backgroundRotation)).transpose(),E.isCubeTexture&&E.isRenderTargetTexture===!1&&p.material.uniforms.backgroundRotation.value.premultiply(eS),p.material.toneMapped=Ve.getTransfer(E.colorSpace)!==nn,(g!==E||_!==E.version||v!==r.toneMapping)&&(p.material.needsUpdate=!0,g=E,_=E.version,v=r.toneMapping),p.layers.enableAll(),C.unshift(p,p.geometry,p.material,0,0,null)):E&&E.isTexture&&(m===void 0&&(m=new le(new kn(2,2),new ei({name:"BackgroundMaterial",uniforms:uo(oa.background.uniforms),vertexShader:oa.background.vertexShader,fragmentShader:oa.background.fragmentShader,side:$s,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),m.geometry.deleteAttribute("normal"),Object.defineProperty(m.material,"map",{get:function(){return this.uniforms.t2D.value}}),a.update(m)),m.material.uniforms.t2D.value=E,m.material.uniforms.backgroundIntensity.value=O.backgroundIntensity,m.material.toneMapped=Ve.getTransfer(E.colorSpace)!==nn,E.matrixAutoUpdate===!0&&E.updateMatrix(),m.material.uniforms.uvTransform.value.copy(E.matrix),(g!==E||_!==E.version||v!==r.toneMapping)&&(m.material.needsUpdate=!0,g=E,_=E.version,v=r.toneMapping),m.layers.enableAll(),C.unshift(m,m.geometry,m.material,0,0,null))}function M(C,O){C.getRGB(_u,Qx(r)),n.buffers.color.setClear(_u.r,_u.g,_u.b,O,c)}function S(){p!==void 0&&(p.geometry.dispose(),p.material.dispose(),p=void 0),m!==void 0&&(m.geometry.dispose(),m.material.dispose(),m=void 0)}return{getClearColor:function(){return u},setClearColor:function(C,O=1){u.set(C),h=O,M(u,h)},getClearAlpha:function(){return h},setClearAlpha:function(C){h=C,M(u,h)},render:b,addToRenderList:R,dispose:S}}function M2(r,t){const n=r.getParameter(r.MAX_VERTEX_ATTRIBS),a={},o=v(null);let c=o,u=!1;function h(J,Q,et,k,q){let F=!1;const Z=_(J,k,et,Q);c!==Z&&(c=Z,p(c.object)),F=x(J,k,et,q),F&&b(J,k,et,q),q!==null&&t.update(q,r.ELEMENT_ARRAY_BUFFER),(F||u)&&(u=!1,E(J,Q,et,k),q!==null&&r.bindBuffer(r.ELEMENT_ARRAY_BUFFER,t.get(q).buffer))}function m(){return r.createVertexArray()}function p(J){return r.bindVertexArray(J)}function g(J){return r.deleteVertexArray(J)}function _(J,Q,et,k){const q=k.wireframe===!0;let F=a[Q.id];F===void 0&&(F={},a[Q.id]=F);const Z=J.isInstancedMesh===!0?J.id:0;let ht=F[Z];ht===void 0&&(ht={},F[Z]=ht);let dt=ht[et.id];dt===void 0&&(dt={},ht[et.id]=dt);let pt=dt[q];return pt===void 0&&(pt=v(m()),dt[q]=pt),pt}function v(J){const Q=[],et=[],k=[];for(let q=0;q<n;q++)Q[q]=0,et[q]=0,k[q]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:Q,enabledAttributes:et,attributeDivisors:k,object:J,attributes:{},index:null}}function x(J,Q,et,k){const q=c.attributes,F=Q.attributes;let Z=0;const ht=et.getAttributes();for(const dt in ht)if(ht[dt].location>=0){const I=q[dt];let ct=F[dt];if(ct===void 0&&(dt==="instanceMatrix"&&J.instanceMatrix&&(ct=J.instanceMatrix),dt==="instanceColor"&&J.instanceColor&&(ct=J.instanceColor)),I===void 0||I.attribute!==ct||ct&&I.data!==ct.data)return!0;Z++}return c.attributesNum!==Z||c.index!==k}function b(J,Q,et,k){const q={},F=Q.attributes;let Z=0;const ht=et.getAttributes();for(const dt in ht)if(ht[dt].location>=0){let I=F[dt];I===void 0&&(dt==="instanceMatrix"&&J.instanceMatrix&&(I=J.instanceMatrix),dt==="instanceColor"&&J.instanceColor&&(I=J.instanceColor));const ct={};ct.attribute=I,I&&I.data&&(ct.data=I.data),q[dt]=ct,Z++}c.attributes=q,c.attributesNum=Z,c.index=k}function R(){const J=c.newAttributes;for(let Q=0,et=J.length;Q<et;Q++)J[Q]=0}function M(J){S(J,0)}function S(J,Q){const et=c.newAttributes,k=c.enabledAttributes,q=c.attributeDivisors;et[J]=1,k[J]===0&&(r.enableVertexAttribArray(J),k[J]=1),q[J]!==Q&&(r.vertexAttribDivisor(J,Q),q[J]=Q)}function C(){const J=c.newAttributes,Q=c.enabledAttributes;for(let et=0,k=Q.length;et<k;et++)Q[et]!==J[et]&&(r.disableVertexAttribArray(et),Q[et]=0)}function O(J,Q,et,k,q,F,Z){Z===!0?r.vertexAttribIPointer(J,Q,et,q,F):r.vertexAttribPointer(J,Q,et,k,q,F)}function E(J,Q,et,k){R();const q=k.attributes,F=et.getAttributes(),Z=Q.defaultAttributeValues;for(const ht in F){const dt=F[ht];if(dt.location>=0){let pt=q[ht];if(pt===void 0&&(ht==="instanceMatrix"&&J.instanceMatrix&&(pt=J.instanceMatrix),ht==="instanceColor"&&J.instanceColor&&(pt=J.instanceColor)),pt!==void 0){const I=pt.normalized,ct=pt.itemSize,At=t.get(pt);if(At===void 0)continue;const It=At.buffer,kt=At.type,zt=At.bytesPerElement,ut=kt===r.INT||kt===r.UNSIGNED_INT||pt.gpuType===Ip;if(pt.isInterleavedBufferAttribute){const Tt=pt.data,Ht=Tt.stride,ie=pt.offset;if(Tt.isInstancedInterleavedBuffer){for(let qt=0;qt<dt.locationSize;qt++)S(dt.location+qt,Tt.meshPerAttribute);J.isInstancedMesh!==!0&&k._maxInstanceCount===void 0&&(k._maxInstanceCount=Tt.meshPerAttribute*Tt.count)}else for(let qt=0;qt<dt.locationSize;qt++)M(dt.location+qt);r.bindBuffer(r.ARRAY_BUFFER,It);for(let qt=0;qt<dt.locationSize;qt++)O(dt.location+qt,ct/dt.locationSize,kt,I,Ht*zt,(ie+ct/dt.locationSize*qt)*zt,ut)}else{if(pt.isInstancedBufferAttribute){for(let Tt=0;Tt<dt.locationSize;Tt++)S(dt.location+Tt,pt.meshPerAttribute);J.isInstancedMesh!==!0&&k._maxInstanceCount===void 0&&(k._maxInstanceCount=pt.meshPerAttribute*pt.count)}else for(let Tt=0;Tt<dt.locationSize;Tt++)M(dt.location+Tt);r.bindBuffer(r.ARRAY_BUFFER,It);for(let Tt=0;Tt<dt.locationSize;Tt++)O(dt.location+Tt,ct/dt.locationSize,kt,I,ct*zt,ct/dt.locationSize*Tt*zt,ut)}}else if(Z!==void 0){const I=Z[ht];if(I!==void 0)switch(I.length){case 2:r.vertexAttrib2fv(dt.location,I);break;case 3:r.vertexAttrib3fv(dt.location,I);break;case 4:r.vertexAttrib4fv(dt.location,I);break;default:r.vertexAttrib1fv(dt.location,I)}}}}C()}function U(){z();for(const J in a){const Q=a[J];for(const et in Q){const k=Q[et];for(const q in k){const F=k[q];for(const Z in F)g(F[Z].object),delete F[Z];delete k[q]}}delete a[J]}}function L(J){if(a[J.id]===void 0)return;const Q=a[J.id];for(const et in Q){const k=Q[et];for(const q in k){const F=k[q];for(const Z in F)g(F[Z].object),delete F[Z];delete k[q]}}delete a[J.id]}function P(J){for(const Q in a){const et=a[Q];for(const k in et){const q=et[k];if(q[J.id]===void 0)continue;const F=q[J.id];for(const Z in F)g(F[Z].object),delete F[Z];delete q[J.id]}}}function T(J){for(const Q in a){const et=a[Q],k=J.isInstancedMesh===!0?J.id:0,q=et[k];if(q!==void 0){for(const F in q){const Z=q[F];for(const ht in Z)g(Z[ht].object),delete Z[ht];delete q[F]}delete et[k],Object.keys(et).length===0&&delete a[Q]}}}function z(){W(),u=!0,c!==o&&(c=o,p(c.object))}function W(){o.geometry=null,o.program=null,o.wireframe=!1}return{setup:h,reset:z,resetDefaultState:W,dispose:U,releaseStatesOfGeometry:L,releaseStatesOfObject:T,releaseStatesOfProgram:P,initAttributes:R,enableAttribute:M,disableUnusedAttributes:C}}function y2(r,t,n){let a;function o(m){a=m}function c(m,p){r.drawArrays(a,m,p),n.update(p,a,1)}function u(m,p,g){g!==0&&(r.drawArraysInstanced(a,m,p,g),n.update(p,a,g))}function h(m,p,g){if(g===0)return;t.get("WEBGL_multi_draw").multiDrawArraysWEBGL(a,m,0,p,0,g);let v=0;for(let x=0;x<g;x++)v+=p[x];n.update(v,a,1)}this.setMode=o,this.render=c,this.renderInstances=u,this.renderMultiDraw=h}function b2(r,t,n,a){let o;function c(){if(o!==void 0)return o;if(t.has("EXT_texture_filter_anisotropic")===!0){const P=t.get("EXT_texture_filter_anisotropic");o=r.getParameter(P.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else o=0;return o}function u(P){return!(P!==Qi&&a.convert(P)!==r.getParameter(r.IMPLEMENTATION_COLOR_READ_FORMAT))}function h(P){const T=P===$i&&(t.has("EXT_color_buffer_half_float")||t.has("EXT_color_buffer_float"));return!(P!==Ti&&P!==Ji&&!T&&a.convert(P)!==r.getParameter(r.IMPLEMENTATION_COLOR_READ_TYPE))}function m(P){if(P==="highp"){if(r.getShaderPrecisionFormat(r.VERTEX_SHADER,r.HIGH_FLOAT).precision>0&&r.getShaderPrecisionFormat(r.FRAGMENT_SHADER,r.HIGH_FLOAT).precision>0)return"highp";P="mediump"}return P==="mediump"&&r.getShaderPrecisionFormat(r.VERTEX_SHADER,r.MEDIUM_FLOAT).precision>0&&r.getShaderPrecisionFormat(r.FRAGMENT_SHADER,r.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let p=n.precision!==void 0?n.precision:"highp";const g=m(p);g!==p&&(ve("WebGLRenderer:",p,"not supported, using",g,"instead."),p=g);const _=n.logarithmicDepthBuffer===!0,v=n.reversedDepthBuffer===!0&&t.has("EXT_clip_control");n.reversedDepthBuffer===!0&&v===!1&&ve("WebGLRenderer: Unable to use reversed depth buffer due to missing EXT_clip_control extension. Fallback to default depth buffer.");const x=r.getParameter(r.MAX_TEXTURE_IMAGE_UNITS),b=r.getParameter(r.MAX_VERTEX_TEXTURE_IMAGE_UNITS),R=r.getParameter(r.MAX_TEXTURE_SIZE),M=r.getParameter(r.MAX_CUBE_MAP_TEXTURE_SIZE),S=r.getParameter(r.MAX_VERTEX_ATTRIBS),C=r.getParameter(r.MAX_VERTEX_UNIFORM_VECTORS),O=r.getParameter(r.MAX_VARYING_VECTORS),E=r.getParameter(r.MAX_FRAGMENT_UNIFORM_VECTORS),U=r.getParameter(r.MAX_SAMPLES),L=r.getParameter(r.SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:c,getMaxPrecision:m,textureFormatReadable:u,textureTypeReadable:h,precision:p,logarithmicDepthBuffer:_,reversedDepthBuffer:v,maxTextures:x,maxVertexTextures:b,maxTextureSize:R,maxCubemapSize:M,maxAttributes:S,maxVertexUniforms:C,maxVaryings:O,maxFragmentUniforms:E,maxSamples:U,samples:L}}function E2(r){const t=this;let n=null,a=0,o=!1,c=!1;const u=new Es,h=new ye,m={value:null,needsUpdate:!1};this.uniform=m,this.numPlanes=0,this.numIntersection=0,this.init=function(_,v){const x=_.length!==0||v||a!==0||o;return o=v,a=_.length,x},this.beginShadows=function(){c=!0,g(null)},this.endShadows=function(){c=!1},this.setGlobalState=function(_,v){n=g(_,v,0)},this.setState=function(_,v,x){const b=_.clippingPlanes,R=_.clipIntersection,M=_.clipShadows,S=r.get(_);if(!o||b===null||b.length===0||c&&!M)c?g(null):p();else{const C=c?0:a,O=C*4;let E=S.clippingState||null;m.value=E,E=g(b,v,O,x);for(let U=0;U!==O;++U)E[U]=n[U];S.clippingState=E,this.numIntersection=R?this.numPlanes:0,this.numPlanes+=C}};function p(){m.value!==n&&(m.value=n,m.needsUpdate=a>0),t.numPlanes=a,t.numIntersection=0}function g(_,v,x,b){const R=_!==null?_.length:0;let M=null;if(R!==0){if(M=m.value,b!==!0||M===null){const S=x+R*4,C=v.matrixWorldInverse;h.getNormalMatrix(C),(M===null||M.length<S)&&(M=new Float32Array(S));for(let O=0,E=x;O!==R;++O,E+=4)u.copy(_[O]).applyMatrix4(C,h),u.normal.toArray(M,E),M[E+3]=u.constant}m.value=M,m.needsUpdate=!0}return t.numPlanes=R,t.numIntersection=0,M}}const so=4,T2=6,A2=20,w2=256,hl=new em,k_=new ue;let Ud=null,Ld=0,Nd=0,Od=!1;const R2=new B,Zs=new B;class X_{constructor(t){this._renderer=t,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._sizeLods=[],this._lodMeshes=[],this._backgroundBox=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._blurMaterial=null,this._ggxMaterial=null}fromScene(t,n=0,a=.1,o=100,c={}){const{size:u=256,position:h=R2}=c;Ud=this._renderer.getRenderTarget(),Ld=this._renderer.getActiveCubeFace(),Nd=this._renderer.getActiveMipmapLevel(),Od=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(u);const m=this._allocateTargets();return m.depthBuffer=!0,this._sceneToCubeUV(t,a,o,m,h),n>0&&this._blur(m,0,0,n),this._applyPMREM(m),this._cleanup(m),m}fromEquirectangular(t,n=null){return this._fromTexture(t,n)}fromCubemap(t,n=null){return this._fromTexture(t,n)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=Y_(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=q_(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose(),this._backgroundBox!==null&&(this._backgroundBox.geometry.dispose(),this._backgroundBox.material.dispose())}_setSize(t){this._lodMax=Math.floor(Math.log2(t)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._ggxMaterial!==null&&this._ggxMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let t=0;t<this._lodMeshes.length;t++)this._lodMeshes[t].geometry.dispose()}_cleanup(t){this._renderer.setRenderTarget(Ud,Ld,Nd),this._renderer.xr.enabled=Od,t.scissorTest=!1,eo(t,0,0,t.width,t.height)}_fromTexture(t,n){t.mapping===tr||t.mapping===lo?this._setSize(t.image.length===0?16:t.image[0].width||t.image[0].image.width):this._setSize(t.image.width/4),Ud=this._renderer.getRenderTarget(),Ld=this._renderer.getActiveCubeFace(),Nd=this._renderer.getActiveMipmapLevel(),Od=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;const a=n||this._allocateTargets();return this._textureToCubeUV(t,a),this._applyPMREM(a),this._cleanup(a),a}_allocateTargets(){const t=3*Math.max(this._cubeSize,112),n=4*this._cubeSize,a={magFilter:Xn,minFilter:Xn,generateMipmaps:!1,type:$i,format:Qi,colorSpace:Ru,depthBuffer:!1},o=W_(t,n,a);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==t||this._pingPongRenderTarget.height!==n){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=W_(t,n,a);const{_lodMax:c}=this;({lodMeshes:this._lodMeshes,sizeLods:this._sizeLods}=C2(c)),this._blurMaterial=U2(c,t,n),this._ggxMaterial=D2(c,t,n)}return o}_compileMaterial(t){const n=new le(new Ne,t);this._renderer.compile(n,hl)}_sceneToCubeUV(t,n,a,o,c){const m=new Ei(90,1,n,a),p=[1,-1,1,1,1,1],g=[1,1,1,-1,-1,-1],_=this._renderer,v=_.autoClear,x=_.toneMapping;_.getClearColor(k_),_.toneMapping=ca,_.autoClear=!1,_.state.buffers.depth.getReversed()&&(_.setRenderTarget(o),_.clearDepth(),_.setRenderTarget(null)),this._backgroundBox===null&&(this._backgroundBox=new le(new Wa,new Fa({name:"PMREM.Background",side:oi,depthWrite:!1,depthTest:!1})));const R=this._backgroundBox,M=R.material;let S=!1;const C=t.background;C?C.isColor&&(M.color.copy(C),t.background=null,S=!0):(M.color.copy(k_),S=!0);for(let O=0;O<6;O++){const E=O%3;E===0?(m.up.set(0,p[O],0),m.position.set(c.x,c.y,c.z),m.lookAt(c.x+g[O],c.y,c.z)):E===1?(m.up.set(0,0,p[O]),m.position.set(c.x,c.y,c.z),m.lookAt(c.x,c.y+g[O],c.z)):(m.up.set(0,p[O],0),m.position.set(c.x,c.y,c.z),m.lookAt(c.x,c.y,c.z+g[O]));const U=this._cubeSize;eo(o,E*U,O>2?U:0,U,U),_.setRenderTarget(o),S&&_.render(R,m),_.render(t,m)}_.toneMapping=x,_.autoClear=v,t.background=C}_textureToCubeUV(t,n){const a=this._renderer,o=t.mapping===tr||t.mapping===lo;o?(this._cubemapMaterial===null&&(this._cubemapMaterial=Y_()),this._cubemapMaterial.uniforms.flipEnvMap.value=t.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=q_());const c=o?this._cubemapMaterial:this._equirectMaterial,u=this._lodMeshes[0];u.material=c;const h=c.uniforms;h.envMap.value=t;const m=this._cubeSize;eo(n,0,0,3*m,2*m),a.setRenderTarget(n),a.render(u,hl)}_applyPMREM(t){const n=this._renderer,a=n.autoClear;n.autoClear=!1;const o=this._lodMeshes.length;for(let c=1;c<o;c++)this._applyGGXFilter(t,c-1,c);n.autoClear=a}_applyGGXFilter(t,n,a){const o=this._renderer,c=this._pingPongRenderTarget,u=this._ggxMaterial,h=this._lodMeshes[a];h.material=u;const m=u.uniforms,p=a/(this._lodMeshes.length-1),g=n/(this._lodMeshes.length-1),_=Math.sqrt(p*p-g*g),v=p*1.25,x=_*v,{_lodMax:b}=this,R=this._sizeLods[a],M=3*R*(a>b-so?a-b+so:0),S=4*(this._cubeSize-R);m.envMap.value=t.texture,m.roughness.value=x,m.mipInt.value=b-n,eo(c,M,S,3*R,2*R),o.setRenderTarget(c),o.render(h,hl),m.envMap.value=c.texture,m.roughness.value=0,m.mipInt.value=b-a,eo(t,M,S,3*R,2*R),o.setRenderTarget(t),o.render(h,hl)}_blur(t,n,a,o){const c=this._pingPongRenderTarget,u=Math.min(o,Math.PI)/Math.SQRT2;this._blurPass(t,c,n,a,u),this._blurPass(c,t,a,a,u)}_blurPass(t,n,a,o,c){const u=this._renderer,h=this._blurMaterial,m=this._lodMeshes[o];m.material=h;const p=h.uniforms;p.envMap.value=t.texture,p.sigma.value=c,p.mipInt.value=this._lodMax-a;const g=this._sizeLods[o],_=3*g*(o>this._lodMax-so?o-this._lodMax+so:0),v=4*(this._cubeSize-g);eo(n,_,v,3*g,2*g),u.setRenderTarget(n),u.render(m,hl)}}function C2(r){const t=[],n=[];let a=r;const o=r-so+1+T2;for(let c=0;c<o;c++){const u=Math.pow(2,a);t.push(u);const h=1/(u-2),m=-h,p=1+h,g=[m,m,p,m,p,p,m,m,p,p,m,p],_=6,v=6,x=3,b=new Float32Array(x*v*_),R=new Float32Array(x*v*_);for(let S=0;S<_;S++){const C=S%3*2/3-1,O=S>2?0:-1,E=[C,O,0,C+2/3,O,0,C+2/3,O+1,0,C,O,0,C+2/3,O+1,0,C,O+1,0];b.set(E,x*v*S);for(let U=0;U<v;U++){const L=g[U*2]*2-1,P=g[U*2+1]*2-1;S===0?Zs.set(1,P,L):S===1?Zs.set(-L,1,-P):S===2?Zs.set(-L,P,1):S===3?Zs.set(-1,P,-L):S===4?Zs.set(-L,-1,P):Zs.set(L,P,-1),Zs.toArray(R,(S*v+U)*x)}}const M=new Ne;M.setAttribute("position",new qn(b,x)),M.setAttribute("outputDirection",new qn(R,x)),n.push(new le(M,null)),a>so&&a--}return{lodMeshes:n,sizeLods:t}}function W_(r,t,n){const a=new Hi(r,t,n);return a.texture.mapping=zu,a.texture.name="PMREM.cubeUv",a.scissorTest=!0,a}function eo(r,t,n,a,o){r.viewport.set(t,n,a,o),r.scissor.set(t,n,a,o)}function D2(r,t,n){return new ei({name:"PMREMGGXConvolution",defines:{GGX_SAMPLES:w2,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/n,CUBEUV_MAX_MIP:`${r}.0`},uniforms:{envMap:{value:null},roughness:{value:0},mipInt:{value:0}},vertexShader:ku(),fragmentShader:`

			precision highp float;
			precision highp int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform float roughness;
			uniform float mipInt;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			#define PI 3.14159265359

			// Van der Corput radical inverse
			float radicalInverse_VdC(uint bits) {
				bits = (bits << 16u) | (bits >> 16u);
				bits = ((bits & 0x55555555u) << 1u) | ((bits & 0xAAAAAAAAu) >> 1u);
				bits = ((bits & 0x33333333u) << 2u) | ((bits & 0xCCCCCCCCu) >> 2u);
				bits = ((bits & 0x0F0F0F0Fu) << 4u) | ((bits & 0xF0F0F0F0u) >> 4u);
				bits = ((bits & 0x00FF00FFu) << 8u) | ((bits & 0xFF00FF00u) >> 8u);
				return float(bits) * 2.3283064365386963e-10; // / 0x100000000
			}

			// Hammersley sequence
			vec2 hammersley(uint i, uint N) {
				return vec2(float(i) / float(N), radicalInverse_VdC(i));
			}

			// GGX VNDF importance sampling (Eric Heitz 2018)
			// "Sampling the GGX Distribution of Visible Normals"
			// https://jcgt.org/published/0007/04/01/
			vec3 importanceSampleGGX_VNDF(vec2 Xi, vec3 V, float roughness) {
				float alpha = roughness * roughness;

				// Section 4.1: Orthonormal basis
				vec3 T1 = vec3(1.0, 0.0, 0.0);
				vec3 T2 = cross(V, T1);

				// Section 4.2: Parameterization of projected area
				float r = sqrt(Xi.x);
				float phi = 2.0 * PI * Xi.y;
				float t1 = r * cos(phi);
				float t2 = r * sin(phi);
				float s = 0.5 * (1.0 + V.z);
				t2 = (1.0 - s) * sqrt(1.0 - t1 * t1) + s * t2;

				// Section 4.3: Reprojection onto hemisphere
				vec3 Nh = t1 * T1 + t2 * T2 + sqrt(max(0.0, 1.0 - t1 * t1 - t2 * t2)) * V;

				// Section 3.4: Transform back to ellipsoid configuration
				return normalize(vec3(alpha * Nh.x, alpha * Nh.y, max(0.0, Nh.z)));
			}

			void main() {
				vec3 N = normalize(vOutputDirection);
				vec3 V = N; // Assume view direction equals normal for pre-filtering

				vec3 prefilteredColor = vec3(0.0);
				float totalWeight = 0.0;

				// For very low roughness, just sample the environment directly
				if (roughness < 0.001) {
					gl_FragColor = vec4(bilinearCubeUV(envMap, N, mipInt), 1.0);
					return;
				}

				// Tangent space basis for VNDF sampling
				vec3 up = abs(N.z) < 0.999 ? vec3(0.0, 0.0, 1.0) : vec3(1.0, 0.0, 0.0);
				vec3 tangent = normalize(cross(up, N));
				vec3 bitangent = cross(N, tangent);

				for(uint i = 0u; i < uint(GGX_SAMPLES); i++) {
					vec2 Xi = hammersley(i, uint(GGX_SAMPLES));

					// For PMREM, V = N, so in tangent space V is always (0, 0, 1)
					vec3 H_tangent = importanceSampleGGX_VNDF(Xi, vec3(0.0, 0.0, 1.0), roughness);

					// Transform H back to world space
					vec3 H = normalize(tangent * H_tangent.x + bitangent * H_tangent.y + N * H_tangent.z);
					vec3 L = normalize(2.0 * dot(V, H) * H - V);

					float NdotL = max(dot(N, L), 0.0);

					if(NdotL > 0.0) {
						// Sample environment at fixed mip level
						// VNDF importance sampling handles the distribution filtering
						vec3 sampleColor = bilinearCubeUV(envMap, L, mipInt);

						// Weight by NdotL for the split-sum approximation
						// VNDF PDF naturally accounts for the visible microfacet distribution
						prefilteredColor += sampleColor * NdotL;
						totalWeight += NdotL;
					}
				}

				if (totalWeight > 0.0) {
					prefilteredColor = prefilteredColor / totalWeight;
				}

				gl_FragColor = vec4(prefilteredColor, 1.0);
			}
		`,blending:Ha,depthTest:!1,depthWrite:!1})}function U2(r,t,n){return new ei({name:"SphericalGaussianBlur",defines:{SAMPLES:A2,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/n,CUBEUV_MAX_MIP:`${r}.0`},uniforms:{envMap:{value:null},sigma:{value:0},mipInt:{value:0}},vertexShader:ku(),fragmentShader:`

			precision highp float;
			precision highp int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform float sigma;
			uniform float mipInt;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			#define PI 3.14159265359
			#define GOLDEN_ANGLE 2.39996322973

			void main() {

				if ( sigma == 0.0 ) {

					gl_FragColor = vec4( bilinearCubeUV( envMap, vOutputDirection, mipInt ), 1.0 );
					return;

				}

				vec3 outputDirection = normalize( vOutputDirection );

				vec3 up = abs( outputDirection.z ) < 0.999 ? vec3( 0.0, 0.0, 1.0 ) : vec3( 1.0, 0.0, 0.0 );
				vec3 tangent = normalize( cross( up, outputDirection ) );
				vec3 bitangent = cross( outputDirection, tangent );

				// Truncate the kernel at three standard deviations or at the antipode.
				float thetaMax = min( 3.0 * sigma, PI );
				float truncation = 1.0 - exp( - 0.5 * thetaMax * thetaMax / ( sigma * sigma ) );

				vec3 accumColor = vec3( 0.0 );
				float accumWeight = 0.0;

				for ( int i = 0; i < SAMPLES; i ++ ) {

					// Stratified inverse-CDF sampling of the Gaussian, placed on a golden-angle spiral.
					float stratum = ( float( i ) + 0.5 ) / float( SAMPLES );
					float theta = sigma * sqrt( - 2.0 * log( 1.0 - stratum * truncation ) );
					float phi = float( i ) * GOLDEN_ANGLE;

					vec3 offset = cos( phi ) * tangent + sin( phi ) * bitangent;
					vec3 sampleDirection = cos( theta ) * outputDirection + sin( theta ) * offset;

					// Correct the planar sample density to solid angle.
					float weight = sin( theta ) / theta;

					accumColor += weight * bilinearCubeUV( envMap, sampleDirection, mipInt );
					accumWeight += weight;

				}

				gl_FragColor = vec4( accumColor / accumWeight, 1.0 );

			}
		`,blending:Ha,depthTest:!1,depthWrite:!1})}function q_(){return new ei({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:ku(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:Ha,depthTest:!1,depthWrite:!1})}function Y_(){return new ei({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:ku(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:Ha,depthTest:!1,depthWrite:!1})}function ku(){return`

		precision mediump float;
		precision mediump int;

		attribute vec3 outputDirection;

		varying vec3 vOutputDirection;

		void main() {

			vOutputDirection = outputDirection;
			gl_Position = vec4( position, 1.0 );

		}
	`}class nS extends Hi{constructor(t=1,n={}){super(t,t,n),this.isWebGLCubeRenderTarget=!0;const a={width:t,height:t,depth:1},o=[a,a,a,a,a,a];this.texture=new Hx(o),this._setTextureOptions(n),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(t,n){this.texture.type=n.type,this.texture.colorSpace=n.colorSpace,this.texture.generateMipmaps=n.generateMipmaps,this.texture.minFilter=n.minFilter,this.texture.magFilter=n.magFilter;const a={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},o=new Wa(5,5,5),c=new ei({name:"CubemapFromEquirect",uniforms:uo(a.uniforms),vertexShader:a.vertexShader,fragmentShader:a.fragmentShader,side:oi,blending:Ha});c.uniforms.tEquirect.value=n;const u=new le(o,c),h=n.minFilter;return n.minFilter===Ks&&(n.minFilter=Xn),new Pb(1,10,this).update(t,u),n.minFilter=h,u.geometry.dispose(),u.material.dispose(),this}clear(t,n=!0,a=!0,o=!0){const c=t.getRenderTarget();for(let u=0;u<6;u++)t.setRenderTarget(this,u),t.clear(n,a,o);t.setRenderTarget(c)}}function L2(r){let t=new WeakMap,n=new WeakMap,a=null;function o(v,x=!1){return v==null?null:x?u(v):c(v)}function c(v){if(v&&v.isTexture){const x=v.mapping;if(x===nd||x===id)if(t.has(v)){const b=t.get(v).texture;return h(b,v.mapping)}else{const b=v.image;if(b&&b.height>0){const R=new nS(b.height);return R.fromEquirectangularTexture(r,v),t.set(v,R),v.addEventListener("dispose",p),h(R.texture,v.mapping)}else return null}}return v}function u(v){if(v&&v.isTexture){const x=v.mapping,b=x===nd||x===id,R=x===tr||x===lo;if(b||R){let M=n.get(v);const S=M!==void 0?M.texture.pmremVersion:0;if(v.isRenderTargetTexture&&v.pmremVersion!==S)return a===null&&(a=new X_(r)),M=b?a.fromEquirectangular(v,M):a.fromCubemap(v,M),M.texture.pmremVersion=v.pmremVersion,n.set(v,M),M.texture;if(M!==void 0)return M.texture;{const C=v.image;return b&&C&&C.height>0||R&&C&&m(C)?(a===null&&(a=new X_(r)),M=b?a.fromEquirectangular(v):a.fromCubemap(v),M.texture.pmremVersion=v.pmremVersion,n.set(v,M),v.addEventListener("dispose",g),M.texture):null}}}return v}function h(v,x){return x===nd?v.mapping=tr:x===id&&(v.mapping=lo),v}function m(v){let x=0;const b=6;for(let R=0;R<b;R++)v[R]!==void 0&&x++;return x===b}function p(v){const x=v.target;x.removeEventListener("dispose",p);const b=t.get(x);b!==void 0&&(t.delete(x),b.dispose())}function g(v){const x=v.target;x.removeEventListener("dispose",g);const b=n.get(x);b!==void 0&&(n.delete(x),b.dispose())}function _(){t=new WeakMap,n=new WeakMap,a!==null&&(a.dispose(),a=null)}return{get:o,dispose:_}}function N2(r){const t={};function n(a){if(t[a]!==void 0)return t[a];const o=r.getExtension(a);return t[a]=o,o}return{has:function(a){return n(a)!==null},init:function(){n("EXT_color_buffer_float"),n("WEBGL_clip_cull_distance"),n("OES_texture_float_linear"),n("EXT_color_buffer_half_float"),n("WEBGL_multisampled_render_to_texture"),n("WEBGL_render_shared_exponent")},get:function(a){const o=n(a);return o===null&&ro("WebGLRenderer: "+a+" extension not supported."),o}}}function O2(r,t,n,a){const o={},c=new WeakMap;function u(_){const v=_.target;v.index!==null&&t.remove(v.index);for(const b in v.attributes)t.remove(v.attributes[b]);v.removeEventListener("dispose",u),delete o[v.id];const x=c.get(v);x&&(t.remove(x),c.delete(v)),a.releaseStatesOfGeometry(v),v.isInstancedBufferGeometry===!0&&delete v._maxInstanceCount,n.memory.geometries--}function h(_,v){return o[v.id]===!0||(v.addEventListener("dispose",u),o[v.id]=!0,n.memory.geometries++),v}function m(_){const v=_.attributes;for(const x in v)t.update(v[x],r.ARRAY_BUFFER)}function p(_){const v=[],x=_.index,b=_.attributes.position;let R=0;if(b===void 0)return;if(x!==null){const C=x.array;R=x.version;for(let O=0,E=C.length;O<E;O+=3){const U=C[O+0],L=C[O+1],P=C[O+2];v.push(U,L,L,P,P,U)}}else{const C=b.array;R=b.version;for(let O=0,E=C.length/3-1;O<E;O+=3){const U=O+0,L=O+1,P=O+2;v.push(U,L,L,P,P,U)}}const M=new(b.count>=65535?Ix:zx)(v,1);M.version=R;const S=c.get(_);S&&t.remove(S),c.set(_,M)}function g(_){const v=c.get(_);if(v){const x=_.index;x!==null&&v.version<x.version&&p(_)}else p(_);return c.get(_)}return{get:h,update:m,getWireframeAttribute:g}}function P2(r,t,n){let a;function o(_){a=_}let c,u;function h(_){c=_.type,u=_.bytesPerElement}function m(_,v){r.drawElements(a,v,c,_*u),n.update(v,a,1)}function p(_,v,x){x!==0&&(r.drawElementsInstanced(a,v,c,_*u,x),n.update(v,a,x))}function g(_,v,x){if(x===0)return;t.get("WEBGL_multi_draw").multiDrawElementsWEBGL(a,v,0,c,_,0,x);let R=0;for(let M=0;M<x;M++)R+=v[M];n.update(R,a,1)}this.setMode=o,this.setIndex=h,this.render=m,this.renderInstances=p,this.renderMultiDraw=g}function z2(r){const t={geometries:0,textures:0},n={frame:0,calls:0,triangles:0,points:0,lines:0};function a(c,u,h){switch(n.calls++,u){case r.TRIANGLES:n.triangles+=h*(c/3);break;case r.LINES:n.lines+=h*(c/2);break;case r.LINE_STRIP:n.lines+=h*(c-1);break;case r.LINE_LOOP:n.lines+=h*c;break;case r.POINTS:n.points+=h*c;break;default:We("WebGLInfo: Unknown draw mode:",u);break}}function o(){n.calls=0,n.triangles=0,n.points=0,n.lines=0}return{memory:t,render:n,programs:null,autoReset:!0,reset:o,update:a}}function I2(r,t,n){const a=new WeakMap,o=new xn;function c(u,h,m){const p=u.morphTargetInfluences,g=h.morphAttributes.position||h.morphAttributes.normal||h.morphAttributes.color,_=g!==void 0?g.length:0;let v=a.get(h);if(v===void 0||v.count!==_){let W=function(){T.dispose(),a.delete(h),h.removeEventListener("dispose",W)};var x=W;v!==void 0&&v.texture.dispose();const b=h.morphAttributes.position!==void 0,R=h.morphAttributes.normal!==void 0,M=h.morphAttributes.color!==void 0,S=h.morphAttributes.position||[],C=h.morphAttributes.normal||[],O=h.morphAttributes.color||[];let E=0;b===!0&&(E=1),R===!0&&(E=2),M===!0&&(E=3);let U=h.attributes.position.count*E,L=1;U>t.maxTextureSize&&(L=Math.ceil(U/t.maxTextureSize),U=t.maxTextureSize);const P=new Float32Array(U*L*4*_),T=new Ox(P,U,L,_);T.type=Ji,T.needsUpdate=!0;const z=E*4;for(let J=0;J<_;J++){const Q=S[J],et=C[J],k=O[J],q=U*L*4*J;for(let F=0;F<Q.count;F++){const Z=F*z;b===!0&&(o.fromBufferAttribute(Q,F),P[q+Z+0]=o.x,P[q+Z+1]=o.y,P[q+Z+2]=o.z,P[q+Z+3]=0),R===!0&&(o.fromBufferAttribute(et,F),P[q+Z+4]=o.x,P[q+Z+5]=o.y,P[q+Z+6]=o.z,P[q+Z+7]=0),M===!0&&(o.fromBufferAttribute(k,F),P[q+Z+8]=o.x,P[q+Z+9]=o.y,P[q+Z+10]=o.z,P[q+Z+11]=k.itemSize===4?o.w:1)}}v={count:_,texture:T,size:new Lt(U,L)},a.set(h,v),h.addEventListener("dispose",W)}if(u.isInstancedMesh===!0&&u.morphTexture!==null)m.getUniforms().setValue(r,"morphTexture",u.morphTexture,n);else{let b=0;for(let M=0;M<p.length;M++)b+=p[M];const R=h.morphTargetsRelative?1:1-b;m.getUniforms().setValue(r,"morphTargetBaseInfluence",R),m.getUniforms().setValue(r,"morphTargetInfluences",p)}m.getUniforms().setValue(r,"morphTargetsTexture",v.texture,n),m.getUniforms().setValue(r,"morphTargetsTextureSize",v.size)}return{update:c}}function B2(r,t,n,a,o){let c=new WeakMap;function u(p){const g=o.render.frame,_=p.geometry,v=t.get(p,_);if(c.get(v)!==g&&(t.update(v),c.set(v,g)),p.isInstancedMesh&&(p.hasEventListener("dispose",m)===!1&&p.addEventListener("dispose",m),c.get(p)!==g&&(n.update(p.instanceMatrix,r.ARRAY_BUFFER),p.instanceColor!==null&&n.update(p.instanceColor,r.ARRAY_BUFFER),c.set(p,g))),p.isSkinnedMesh){const x=p.skeleton;c.get(x)!==g&&(x.update(),c.set(x,g))}return v}function h(){c=new WeakMap}function m(p){const g=p.target;g.removeEventListener("dispose",m),a.releaseStatesOfObject(g),n.remove(g.instanceMatrix),g.instanceColor!==null&&n.remove(g.instanceColor)}return{update:u,dispose:h}}const F2={[xx]:"LINEAR_TONE_MAPPING",[Sx]:"REINHARD_TONE_MAPPING",[Mx]:"CINEON_TONE_MAPPING",[zp]:"ACES_FILMIC_TONE_MAPPING",[bx]:"AGX_TONE_MAPPING",[Ex]:"NEUTRAL_TONE_MAPPING",[yx]:"CUSTOM_TONE_MAPPING"};function H2(r,t,n,a,o,c){const u=new Hi(t,n,{type:r,depthBuffer:o,stencilBuffer:c,samples:a?4:0,storeMultisampledDepthBuffer:!1,storeMultisampledStencilBuffer:!1,resolveDepthBuffer:!1,resolveStencilBuffer:!1});let h=null,m=null;const p=new Ne;p.setAttribute("position",new ce([-1,3,0,-1,-1,0,3,-1,0],3)),p.setAttribute("uv",new ce([0,2,0,0,2,0],2));const g=new Db({uniforms:{tDiffuse:{value:null}},vertexShader:`
			precision highp float;

			uniform mat4 modelViewMatrix;
			uniform mat4 projectionMatrix;

			attribute vec3 position;
			attribute vec2 uv;

			varying vec2 vUv;

			void main() {
				vUv = uv;
				gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
			}`,fragmentShader:`
			precision highp float;

			uniform sampler2D tDiffuse;

			varying vec2 vUv;

			#include <tonemapping_pars_fragment>
			#include <colorspace_pars_fragment>

			void main() {
				gl_FragColor = texture2D( tDiffuse, vUv );

				#ifdef LINEAR_TONE_MAPPING
					gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );
				#elif defined( REINHARD_TONE_MAPPING )
					gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );
				#elif defined( CINEON_TONE_MAPPING )
					gl_FragColor.rgb = CineonToneMapping( gl_FragColor.rgb );
				#elif defined( ACES_FILMIC_TONE_MAPPING )
					gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );
				#elif defined( AGX_TONE_MAPPING )
					gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );
				#elif defined( NEUTRAL_TONE_MAPPING )
					gl_FragColor.rgb = NeutralToneMapping( gl_FragColor.rgb );
				#elif defined( CUSTOM_TONE_MAPPING )
					gl_FragColor.rgb = CustomToneMapping( gl_FragColor.rgb );
				#endif

				#ifdef SRGB_TRANSFER
					gl_FragColor = sRGBTransferOETF( gl_FragColor );
				#endif
			}`,depthTest:!1,depthWrite:!1}),_=new le(p,g),v=new em(-1,1,1,-1,0,1);let x=null,b=null,R=!1,M,S=null,C=[],O=!1;this.setSize=function(E,U){u.setSize(E,U),h!==null&&h.setSize(E,U),m!==null&&m.setSize(E,U);for(let L=0;L<C.length;L++){const P=C[L];P.setSize&&P.setSize(E,U)}},this.setEffects=function(E){C=E,O=C.length>0&&C[0].isRenderPass===!0;const U=u.width,L=u.height;C.length>0&&h===null&&(h=new Hi(U,L,{type:$i,depthBuffer:!1,stencilBuffer:!1}),m=new Hi(U,L,{type:$i,depthBuffer:!1,stencilBuffer:!1}));for(let P=0;P<C.length;P++){const T=C[P];T.setSize&&T.setSize(U,L)}},this.begin=function(E,U){if(R||E.toneMapping===ca&&C.length===0)return!1;if(S=U,U!==null){const L=U.width,P=U.height;(u.width!==L||u.height!==P)&&this.setSize(L,P)}return O===!1&&E.setRenderTarget(u),M=E.toneMapping,E.toneMapping=ca,!0},this.hasRenderPass=function(){return O},this.end=function(E,U){E.toneMapping=M,R=!0;let L=u,P=h;for(let T=0;T<C.length;T++){const z=C[T];z.enabled!==!1&&(z.render(E,P,L,U),z.needsSwap!==!1&&(L=P,P=P===h?m:h))}if(x!==E.outputColorSpace||b!==E.toneMapping){x=E.outputColorSpace,b=E.toneMapping,g.defines={},Ve.getTransfer(x)===nn&&(g.defines.SRGB_TRANSFER="");const T=F2[b];T&&(g.defines[T]=""),g.needsUpdate=!0}g.uniforms.tDiffuse.value=L.texture,E.setRenderTarget(S),E.render(_,v),S=null,R=!1},this.isCompositing=function(){return R},this.dispose=function(){u.dispose(),h!==null&&h.dispose(),m!==null&&m.dispose(),p.dispose(),g.dispose()}}const iS=new Wn,Up=new Rl(1,1),aS=new Ox,sS=new C1,rS=new Hx,Z_=[],K_=[],J_=new Float32Array(16),Q_=new Float32Array(9),j_=new Float32Array(4);function po(r,t,n){const a=r[0];if(a<=0||a>0)return r;const o=t*n;let c=Z_[o];if(c===void 0&&(c=new Float32Array(o),Z_[o]=c),t!==0){a.toArray(c,0);for(let u=1,h=0;u!==t;++u)h+=n,r[u].toArray(c,h)}return c}function Bn(r,t){if(r.length!==t.length)return!1;for(let n=0,a=r.length;n<a;n++)if(r[n]!==t[n])return!1;return!0}function Fn(r,t){for(let n=0,a=t.length;n<a;n++)r[n]=t[n]}function Xu(r,t){let n=K_[t];n===void 0&&(n=new Int32Array(t),K_[t]=n);for(let a=0;a!==t;++a)n[a]=r.allocateTextureUnit();return n}function G2(r,t){const n=this.cache;n[0]!==t&&(r.uniform1f(this.addr,t),n[0]=t)}function V2(r,t){const n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y)&&(r.uniform2f(this.addr,t.x,t.y),n[0]=t.x,n[1]=t.y);else{if(Bn(n,t))return;r.uniform2fv(this.addr,t),Fn(n,t)}}function k2(r,t){const n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z)&&(r.uniform3f(this.addr,t.x,t.y,t.z),n[0]=t.x,n[1]=t.y,n[2]=t.z);else if(t.r!==void 0)(n[0]!==t.r||n[1]!==t.g||n[2]!==t.b)&&(r.uniform3f(this.addr,t.r,t.g,t.b),n[0]=t.r,n[1]=t.g,n[2]=t.b);else{if(Bn(n,t))return;r.uniform3fv(this.addr,t),Fn(n,t)}}function X2(r,t){const n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z||n[3]!==t.w)&&(r.uniform4f(this.addr,t.x,t.y,t.z,t.w),n[0]=t.x,n[1]=t.y,n[2]=t.z,n[3]=t.w);else{if(Bn(n,t))return;r.uniform4fv(this.addr,t),Fn(n,t)}}function W2(r,t){const n=this.cache,a=t.elements;if(a===void 0){if(Bn(n,t))return;r.uniformMatrix2fv(this.addr,!1,t),Fn(n,t)}else{if(Bn(n,a))return;j_.set(a),r.uniformMatrix2fv(this.addr,!1,j_),Fn(n,a)}}function q2(r,t){const n=this.cache,a=t.elements;if(a===void 0){if(Bn(n,t))return;r.uniformMatrix3fv(this.addr,!1,t),Fn(n,t)}else{if(Bn(n,a))return;Q_.set(a),r.uniformMatrix3fv(this.addr,!1,Q_),Fn(n,a)}}function Y2(r,t){const n=this.cache,a=t.elements;if(a===void 0){if(Bn(n,t))return;r.uniformMatrix4fv(this.addr,!1,t),Fn(n,t)}else{if(Bn(n,a))return;J_.set(a),r.uniformMatrix4fv(this.addr,!1,J_),Fn(n,a)}}function Z2(r,t){const n=this.cache;n[0]!==t&&(r.uniform1i(this.addr,t),n[0]=t)}function K2(r,t){const n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y)&&(r.uniform2i(this.addr,t.x,t.y),n[0]=t.x,n[1]=t.y);else{if(Bn(n,t))return;r.uniform2iv(this.addr,t),Fn(n,t)}}function J2(r,t){const n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z)&&(r.uniform3i(this.addr,t.x,t.y,t.z),n[0]=t.x,n[1]=t.y,n[2]=t.z);else{if(Bn(n,t))return;r.uniform3iv(this.addr,t),Fn(n,t)}}function Q2(r,t){const n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z||n[3]!==t.w)&&(r.uniform4i(this.addr,t.x,t.y,t.z,t.w),n[0]=t.x,n[1]=t.y,n[2]=t.z,n[3]=t.w);else{if(Bn(n,t))return;r.uniform4iv(this.addr,t),Fn(n,t)}}function j2(r,t){const n=this.cache;n[0]!==t&&(r.uniform1ui(this.addr,t),n[0]=t)}function $2(r,t){const n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y)&&(r.uniform2ui(this.addr,t.x,t.y),n[0]=t.x,n[1]=t.y);else{if(Bn(n,t))return;r.uniform2uiv(this.addr,t),Fn(n,t)}}function tA(r,t){const n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z)&&(r.uniform3ui(this.addr,t.x,t.y,t.z),n[0]=t.x,n[1]=t.y,n[2]=t.z);else{if(Bn(n,t))return;r.uniform3uiv(this.addr,t),Fn(n,t)}}function eA(r,t){const n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z||n[3]!==t.w)&&(r.uniform4ui(this.addr,t.x,t.y,t.z,t.w),n[0]=t.x,n[1]=t.y,n[2]=t.z,n[3]=t.w);else{if(Bn(n,t))return;r.uniform4uiv(this.addr,t),Fn(n,t)}}function nA(r,t,n){const a=this.cache,o=n.allocateTextureUnit();a[0]!==o&&(r.uniform1i(this.addr,o),a[0]=o);let c;this.type===r.SAMPLER_2D_SHADOW?(Up.compareFunction=n.isReversedDepthBuffer()?Wp:Xp,c=Up):c=iS,n.setTexture2D(t||c,o)}function iA(r,t,n){const a=this.cache,o=n.allocateTextureUnit();a[0]!==o&&(r.uniform1i(this.addr,o),a[0]=o),n.setTexture3D(t||sS,o)}function aA(r,t,n){const a=this.cache,o=n.allocateTextureUnit();a[0]!==o&&(r.uniform1i(this.addr,o),a[0]=o),n.setTextureCube(t||rS,o)}function sA(r,t,n){const a=this.cache,o=n.allocateTextureUnit();a[0]!==o&&(r.uniform1i(this.addr,o),a[0]=o),n.setTexture2DArray(t||aS,o)}function rA(r){switch(r){case 5126:return G2;case 35664:return V2;case 35665:return k2;case 35666:return X2;case 35674:return W2;case 35675:return q2;case 35676:return Y2;case 5124:case 35670:return Z2;case 35667:case 35671:return K2;case 35668:case 35672:return J2;case 35669:case 35673:return Q2;case 5125:return j2;case 36294:return $2;case 36295:return tA;case 36296:return eA;case 35678:case 36198:case 36298:case 36306:case 35682:return nA;case 35679:case 36299:case 36307:return iA;case 35680:case 36300:case 36308:case 36293:return aA;case 36289:case 36303:case 36311:case 36292:return sA}}function oA(r,t){r.uniform1fv(this.addr,t)}function lA(r,t){const n=po(t,this.size,2);r.uniform2fv(this.addr,n)}function cA(r,t){const n=po(t,this.size,3);r.uniform3fv(this.addr,n)}function uA(r,t){const n=po(t,this.size,4);r.uniform4fv(this.addr,n)}function fA(r,t){const n=po(t,this.size,4);r.uniformMatrix2fv(this.addr,!1,n)}function hA(r,t){const n=po(t,this.size,9);r.uniformMatrix3fv(this.addr,!1,n)}function dA(r,t){const n=po(t,this.size,16);r.uniformMatrix4fv(this.addr,!1,n)}function pA(r,t){r.uniform1iv(this.addr,t)}function mA(r,t){r.uniform2iv(this.addr,t)}function gA(r,t){r.uniform3iv(this.addr,t)}function vA(r,t){r.uniform4iv(this.addr,t)}function _A(r,t){r.uniform1uiv(this.addr,t)}function xA(r,t){r.uniform2uiv(this.addr,t)}function SA(r,t){r.uniform3uiv(this.addr,t)}function MA(r,t){r.uniform4uiv(this.addr,t)}function yA(r,t,n){const a=this.cache,o=t.length,c=Xu(n,o);Bn(a,c)||(r.uniform1iv(this.addr,c),Fn(a,c));let u;this.type===r.SAMPLER_2D_SHADOW?u=Up:u=iS;for(let h=0;h!==o;++h)n.setTexture2D(t[h]||u,c[h])}function bA(r,t,n){const a=this.cache,o=t.length,c=Xu(n,o);Bn(a,c)||(r.uniform1iv(this.addr,c),Fn(a,c));for(let u=0;u!==o;++u)n.setTexture3D(t[u]||sS,c[u])}function EA(r,t,n){const a=this.cache,o=t.length,c=Xu(n,o);Bn(a,c)||(r.uniform1iv(this.addr,c),Fn(a,c));for(let u=0;u!==o;++u)n.setTextureCube(t[u]||rS,c[u])}function TA(r,t,n){const a=this.cache,o=t.length,c=Xu(n,o);Bn(a,c)||(r.uniform1iv(this.addr,c),Fn(a,c));for(let u=0;u!==o;++u)n.setTexture2DArray(t[u]||aS,c[u])}function AA(r){switch(r){case 5126:return oA;case 35664:return lA;case 35665:return cA;case 35666:return uA;case 35674:return fA;case 35675:return hA;case 35676:return dA;case 5124:case 35670:return pA;case 35667:case 35671:return mA;case 35668:case 35672:return gA;case 35669:case 35673:return vA;case 5125:return _A;case 36294:return xA;case 36295:return SA;case 36296:return MA;case 35678:case 36198:case 36298:case 36306:case 35682:return yA;case 35679:case 36299:case 36307:return bA;case 35680:case 36300:case 36308:case 36293:return EA;case 36289:case 36303:case 36311:case 36292:return TA}}class wA{constructor(t,n,a){this.id=t,this.addr=a,this.cache=[],this.type=n.type,this.setValue=rA(n.type)}}class RA{constructor(t,n,a){this.id=t,this.addr=a,this.cache=[],this.type=n.type,this.size=n.size,this.setValue=AA(n.type)}}class CA{constructor(t){this.id=t,this.seq=[],this.map={}}setValue(t,n,a){const o=this.seq;for(let c=0,u=o.length;c!==u;++c){const h=o[c];h.setValue(t,n[h.id],a)}}}const Pd=/(\w+)(\])?(\[|\.)?/g;function $_(r,t){r.seq.push(t),r.map[t.id]=t}function DA(r,t,n){const a=r.name,o=a.length;for(Pd.lastIndex=0;;){const c=Pd.exec(a),u=Pd.lastIndex;let h=c[1];const m=c[2]==="]",p=c[3];if(m&&(h=h|0),p===void 0||p==="["&&u+2===o){$_(n,p===void 0?new wA(h,r,t):new RA(h,r,t));break}else{let _=n.map[h];_===void 0&&(_=new CA(h),$_(n,_)),n=_}}}class Tu{constructor(t,n){this.seq=[],this.map={};const a=t.getProgramParameter(n,t.ACTIVE_UNIFORMS);for(let u=0;u<a;++u){const h=t.getActiveUniform(n,u),m=t.getUniformLocation(n,h.name);DA(h,m,this)}const o=[],c=[];for(const u of this.seq)u.type===t.SAMPLER_2D_SHADOW||u.type===t.SAMPLER_CUBE_SHADOW||u.type===t.SAMPLER_2D_ARRAY_SHADOW?o.push(u):c.push(u);o.length>0&&(this.seq=o.concat(c))}setValue(t,n,a,o){const c=this.map[n];c!==void 0&&c.setValue(t,a,o)}setOptional(t,n,a){const o=n[a];o!==void 0&&this.setValue(t,a,o)}static upload(t,n,a,o){for(let c=0,u=n.length;c!==u;++c){const h=n[c],m=a[h.id];m.needsUpdate!==!1&&h.setValue(t,m.value,o)}}static seqWithValue(t,n){const a=[];for(let o=0,c=t.length;o!==c;++o){const u=t[o];u.id in n&&a.push(u)}return a}}function tx(r,t,n){const a=r.createShader(t);return r.shaderSource(a,n),r.compileShader(a),a}const UA=37297;let LA=0;function NA(r,t){const n=r.split(`
`),a=[],o=Math.max(t-6,0),c=Math.min(t+6,n.length);for(let u=o;u<c;u++){const h=u+1;a.push(`${h===t?">":" "} ${h}: ${n[u]}`)}return a.join(`
`)}const ex=new ye;function OA(r){Ve._getMatrix(ex,Ve.workingColorSpace,r);const t=`mat3( ${ex.elements.map(n=>n.toFixed(4))} )`;switch(Ve.getTransfer(r)){case Cu:return[t,"LinearTransferOETF"];case nn:return[t,"sRGBTransferOETF"];default:return ve("WebGLProgram: Unsupported color space: ",r),[t,"LinearTransferOETF"]}}function nx(r,t,n){const a=r.getShaderParameter(t,r.COMPILE_STATUS),c=(r.getShaderInfoLog(t)||"").trim();if(a&&c==="")return"";const u=/ERROR: 0:(\d+)/.exec(c);if(u){const h=parseInt(u[1]);return n.toUpperCase()+`

`+c+`

`+NA(r.getShaderSource(t),h)}else return c}function PA(r,t){const n=OA(t);return[`vec4 ${r}( vec4 value ) {`,`	return ${n[1]}( vec4( value.rgb * ${n[0]}, value.a ) );`,"}"].join(`
`)}const zA={[xx]:"Linear",[Sx]:"Reinhard",[Mx]:"Cineon",[zp]:"ACESFilmic",[bx]:"AgX",[Ex]:"Neutral",[yx]:"Custom"};function IA(r,t){const n=zA[t];return n===void 0?(ve("WebGLProgram: Unsupported toneMapping:",t),"vec3 "+r+"( vec3 color ) { return LinearToneMapping( color ); }"):"vec3 "+r+"( vec3 color ) { return "+n+"ToneMapping( color ); }"}const xu=new B;function BA(){Ve.getLuminanceCoefficients(xu);const r=xu.x.toFixed(4),t=xu.y.toFixed(4),n=xu.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${r}, ${t}, ${n} );`,"	return dot( weights, rgb );","}"].join(`
`)}function FA(r){return[r.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",r.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(gl).join(`
`)}function HA(r){const t=[];for(const n in r){const a=r[n];a!==!1&&t.push("#define "+n+" "+a)}return t.join(`
`)}function GA(r,t){const n={},a=r.getProgramParameter(t,r.ACTIVE_ATTRIBUTES);for(let o=0;o<a;o++){const c=r.getActiveAttrib(t,o),u=c.name;let h=1;c.type===r.FLOAT_MAT2&&(h=2),c.type===r.FLOAT_MAT3&&(h=3),c.type===r.FLOAT_MAT4&&(h=4),n[u]={type:c.type,location:r.getAttribLocation(t,u),locationSize:h}}return n}function gl(r){return r!==""}function ix(r,t){const n=t.numSpotLightShadows+t.numSpotLightMaps-t.numSpotLightShadowsWithMaps;return r.replace(/NUM_SUN_LIGHTS/g,t.numSunLights).replace(/NUM_DIR_LIGHTS/g,t.numDirLights).replace(/NUM_SPOT_LIGHTS/g,t.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,t.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,n).replace(/NUM_RECT_AREA_LIGHTS/g,t.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,t.numPointLights).replace(/NUM_HEMI_LIGHTS/g,t.numHemiLights).replace(/NUM_SUN_LIGHT_SHADOWS/g,t.numSunLightShadows).replace(/NUM_DIR_LIGHT_SHADOWS/g,t.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,t.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,t.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,t.numPointLightShadows)}function ax(r,t){return r.replace(/NUM_CLIPPING_PLANES/g,t.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,t.numClippingPlanes-t.numClipIntersection)}const VA=/^[ \t]*#include +<([\w\d./]+)>/gm;function Lp(r){return r.replace(VA,XA)}const kA=new Map;function XA(r,t){let n=De[t];if(n===void 0){const a=kA.get(t);if(a!==void 0)n=De[a],ve('WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',t,a);else throw new Error("THREE.WebGLProgram: Can not resolve #include <"+t+">")}return Lp(n)}const WA=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function sx(r){return r.replace(WA,qA)}function qA(r,t,n,a){let o="";for(let c=parseInt(t);c<parseInt(n);c++)o+=a.replace(/\[\s*i\s*\]/g,"[ "+c+" ]").replace(/UNROLLED_LOOP_INDEX/g,c);return o}function rx(r){let t=`precision ${r.precision} float;
	precision ${r.precision} int;
	precision ${r.precision} sampler2D;
	precision ${r.precision} samplerCube;
	precision ${r.precision} sampler3D;
	precision ${r.precision} sampler2DArray;
	precision ${r.precision} sampler2DShadow;
	precision ${r.precision} samplerCubeShadow;
	precision ${r.precision} sampler2DArrayShadow;
	precision ${r.precision} isampler2D;
	precision ${r.precision} isampler3D;
	precision ${r.precision} isamplerCube;
	precision ${r.precision} isampler2DArray;
	precision ${r.precision} usampler2D;
	precision ${r.precision} usampler3D;
	precision ${r.precision} usamplerCube;
	precision ${r.precision} usampler2DArray;
	`;return r.precision==="highp"?t+=`
#define HIGH_PRECISION`:r.precision==="mediump"?t+=`
#define MEDIUM_PRECISION`:r.precision==="lowp"&&(t+=`
#define LOW_PRECISION`),t}const YA={[Su]:"SHADOWMAP_TYPE_PCF",[pl]:"SHADOWMAP_TYPE_VSM"};function ZA(r){return YA[r.shadowMapType]||"SHADOWMAP_TYPE_BASIC"}const KA={[tr]:"ENVMAP_TYPE_CUBE",[lo]:"ENVMAP_TYPE_CUBE",[zu]:"ENVMAP_TYPE_CUBE_UV"};function JA(r){return r.envMap===!1?"ENVMAP_TYPE_CUBE":KA[r.envMapMode]||"ENVMAP_TYPE_CUBE"}const QA={[lo]:"ENVMAP_MODE_REFRACTION"};function jA(r){return r.envMap===!1?"ENVMAP_MODE_REFLECTION":QA[r.envMapMode]||"ENVMAP_MODE_REFLECTION"}const $A={[_x]:"ENVMAP_BLENDING_MULTIPLY",[qy]:"ENVMAP_BLENDING_MIX",[Yy]:"ENVMAP_BLENDING_ADD"};function t3(r){return r.envMap===!1?"ENVMAP_BLENDING_NONE":$A[r.combine]||"ENVMAP_BLENDING_NONE"}function e3(r){const t=r.envMapCubeUVHeight;if(t===null)return null;const n=Math.log2(t)-2,a=1/t;return{texelWidth:1/(3*Math.max(Math.pow(2,n),112)),texelHeight:a,maxMip:n}}function n3(r,t,n,a){const o=r.getContext(),c=n.defines;let u=n.vertexShader,h=n.fragmentShader;const m=ZA(n),p=JA(n),g=jA(n),_=t3(n),v=e3(n),x=FA(n),b=HA(c),R=o.createProgram();let M,S,C=n.glslVersion?"#version "+n.glslVersion+`
`:"";n.isRawShaderMaterial?(M=["#define SHADER_TYPE "+n.shaderType,"#define SHADER_NAME "+n.shaderName,b].filter(gl).join(`
`),M.length>0&&(M+=`
`),S=["#define SHADER_TYPE "+n.shaderType,"#define SHADER_NAME "+n.shaderName,b].filter(gl).join(`
`),S.length>0&&(S+=`
`)):(M=[rx(n),"#define SHADER_TYPE "+n.shaderType,"#define SHADER_NAME "+n.shaderName,b,n.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",n.batching?"#define USE_BATCHING":"",n.batchingColor?"#define USE_BATCHING_COLOR":"",n.instancing?"#define USE_INSTANCING":"",n.instancingColor?"#define USE_INSTANCING_COLOR":"",n.instancingMorph?"#define USE_INSTANCING_MORPH":"",n.useFog&&n.fog?"#define USE_FOG":"",n.useFog&&n.fogExp2?"#define FOG_EXP2":"",n.map?"#define USE_MAP":"",n.envMap?"#define USE_ENVMAP":"",n.envMap?"#define "+g:"",n.lightMap?"#define USE_LIGHTMAP":"",n.aoMap?"#define USE_AOMAP":"",n.bumpMap?"#define USE_BUMPMAP":"",n.normalMap?"#define USE_NORMALMAP":"",n.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",n.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",n.displacementMap?"#define USE_DISPLACEMENTMAP":"",n.emissiveMap?"#define USE_EMISSIVEMAP":"",n.anisotropy?"#define USE_ANISOTROPY":"",n.anisotropyMap?"#define USE_ANISOTROPYMAP":"",n.clearcoatMap?"#define USE_CLEARCOATMAP":"",n.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",n.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",n.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",n.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",n.specularMap?"#define USE_SPECULARMAP":"",n.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",n.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",n.roughnessMap?"#define USE_ROUGHNESSMAP":"",n.metalnessMap?"#define USE_METALNESSMAP":"",n.alphaMap?"#define USE_ALPHAMAP":"",n.alphaHash?"#define USE_ALPHAHASH":"",n.transmission?"#define USE_TRANSMISSION":"",n.transmissionMap?"#define USE_TRANSMISSIONMAP":"",n.thicknessMap?"#define USE_THICKNESSMAP":"",n.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",n.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",n.mapUv?"#define MAP_UV "+n.mapUv:"",n.alphaMapUv?"#define ALPHAMAP_UV "+n.alphaMapUv:"",n.lightMapUv?"#define LIGHTMAP_UV "+n.lightMapUv:"",n.aoMapUv?"#define AOMAP_UV "+n.aoMapUv:"",n.emissiveMapUv?"#define EMISSIVEMAP_UV "+n.emissiveMapUv:"",n.bumpMapUv?"#define BUMPMAP_UV "+n.bumpMapUv:"",n.normalMapUv?"#define NORMALMAP_UV "+n.normalMapUv:"",n.displacementMapUv?"#define DISPLACEMENTMAP_UV "+n.displacementMapUv:"",n.metalnessMapUv?"#define METALNESSMAP_UV "+n.metalnessMapUv:"",n.roughnessMapUv?"#define ROUGHNESSMAP_UV "+n.roughnessMapUv:"",n.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+n.anisotropyMapUv:"",n.clearcoatMapUv?"#define CLEARCOATMAP_UV "+n.clearcoatMapUv:"",n.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+n.clearcoatNormalMapUv:"",n.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+n.clearcoatRoughnessMapUv:"",n.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+n.iridescenceMapUv:"",n.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+n.iridescenceThicknessMapUv:"",n.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+n.sheenColorMapUv:"",n.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+n.sheenRoughnessMapUv:"",n.specularMapUv?"#define SPECULARMAP_UV "+n.specularMapUv:"",n.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+n.specularColorMapUv:"",n.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+n.specularIntensityMapUv:"",n.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+n.transmissionMapUv:"",n.thicknessMapUv?"#define THICKNESSMAP_UV "+n.thicknessMapUv:"",n.vertexTangents&&n.flatShading===!1?"#define USE_TANGENT":"",n.vertexNormals?"#define HAS_NORMAL":"",n.vertexColors?"#define USE_COLOR":"",n.vertexAlphas?"#define USE_COLOR_ALPHA":"",n.vertexUv1s?"#define USE_UV1":"",n.vertexUv2s?"#define USE_UV2":"",n.vertexUv3s?"#define USE_UV3":"",n.pointsUvs?"#define USE_POINTS_UV":"",n.flatShading?"#define FLAT_SHADED":"",n.skinning?"#define USE_SKINNING":"",n.morphTargets?"#define USE_MORPHTARGETS":"",n.morphNormals&&n.flatShading===!1?"#define USE_MORPHNORMALS":"",n.morphColors?"#define USE_MORPHCOLORS":"",n.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+n.morphTextureStride:"",n.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+n.morphTargetsCount:"",n.doubleSided?"#define DOUBLE_SIDED":"",n.flipSided?"#define FLIP_SIDED":"",n.shadowMapEnabled?"#define USE_SHADOWMAP":"",n.shadowMapEnabled?"#define "+m:"",n.sizeAttenuation?"#define USE_SIZEATTENUATION":"",n.numLightProbes>0?"#define USE_LIGHT_PROBES":"",n.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",n.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(gl).join(`
`),S=[rx(n),"#define SHADER_TYPE "+n.shaderType,"#define SHADER_NAME "+n.shaderName,b,n.useFog&&n.fog?"#define USE_FOG":"",n.useFog&&n.fogExp2?"#define FOG_EXP2":"",n.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",n.map?"#define USE_MAP":"",n.matcap?"#define USE_MATCAP":"",n.envMap?"#define USE_ENVMAP":"",n.envMap?"#define "+p:"",n.envMap?"#define "+g:"",n.envMap?"#define "+_:"",v?"#define CUBEUV_TEXEL_WIDTH "+v.texelWidth:"",v?"#define CUBEUV_TEXEL_HEIGHT "+v.texelHeight:"",v?"#define CUBEUV_MAX_MIP "+v.maxMip+".0":"",n.lightMap?"#define USE_LIGHTMAP":"",n.aoMap?"#define USE_AOMAP":"",n.bumpMap?"#define USE_BUMPMAP":"",n.normalMap?"#define USE_NORMALMAP":"",n.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",n.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",n.packedNormalMap?"#define USE_PACKED_NORMALMAP":"",n.emissiveMap?"#define USE_EMISSIVEMAP":"",n.anisotropy?"#define USE_ANISOTROPY":"",n.anisotropyMap?"#define USE_ANISOTROPYMAP":"",n.clearcoat?"#define USE_CLEARCOAT":"",n.clearcoatMap?"#define USE_CLEARCOATMAP":"",n.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",n.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",n.dispersion?"#define USE_DISPERSION":"",n.retroreflection?"#define USE_RETROREFLECTION":"",n.iridescence?"#define USE_IRIDESCENCE":"",n.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",n.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",n.specularMap?"#define USE_SPECULARMAP":"",n.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",n.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",n.roughnessMap?"#define USE_ROUGHNESSMAP":"",n.metalnessMap?"#define USE_METALNESSMAP":"",n.alphaMap?"#define USE_ALPHAMAP":"",n.alphaTest?"#define USE_ALPHATEST":"",n.alphaHash?"#define USE_ALPHAHASH":"",n.sheen?"#define USE_SHEEN":"",n.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",n.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",n.transmission?"#define USE_TRANSMISSION":"",n.transmissionMap?"#define USE_TRANSMISSIONMAP":"",n.thicknessMap?"#define USE_THICKNESSMAP":"",n.vertexTangents&&n.flatShading===!1?"#define USE_TANGENT":"",n.vertexColors||n.instancingColor?"#define USE_COLOR":"",n.vertexAlphas||n.batchingColor?"#define USE_COLOR_ALPHA":"",n.vertexUv1s?"#define USE_UV1":"",n.vertexUv2s?"#define USE_UV2":"",n.vertexUv3s?"#define USE_UV3":"",n.pointsUvs?"#define USE_POINTS_UV":"",n.gradientMap?"#define USE_GRADIENTMAP":"",n.flatShading?"#define FLAT_SHADED":"",n.doubleSided?"#define DOUBLE_SIDED":"",n.flipSided?"#define FLIP_SIDED":"",n.shadowMapEnabled?"#define USE_SHADOWMAP":"",n.shadowMapEnabled?"#define "+m:"",n.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",n.numLightProbes>0?"#define USE_LIGHT_PROBES":"",n.numLightProbeGrids>0?"#define USE_LIGHT_PROBES_GRID":"",n.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",n.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",n.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",n.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",n.toneMapping!==ca?"#define TONE_MAPPING":"",n.toneMapping!==ca?De.tonemapping_pars_fragment:"",n.toneMapping!==ca?IA("toneMapping",n.toneMapping):"",n.dithering?"#define DITHERING":"",n.opaque?"#define OPAQUE":"",De.colorspace_pars_fragment,PA("linearToOutputTexel",n.outputColorSpace),BA(),n.useDepthPacking?"#define DEPTH_PACKING "+n.depthPacking:"",`
`].filter(gl).join(`
`)),u=Lp(u),u=ix(u,n),u=ax(u,n),h=Lp(h),h=ix(h,n),h=ax(h,n),u=sx(u),h=sx(h),n.isRawShaderMaterial!==!0&&(C=`#version 300 es
`,M=[x,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+M,S=["#define varying in",n.glslVersion===t_?"":"layout(location = 0) out highp vec4 pc_fragColor;",n.glslVersion===t_?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+S);const O=C+M+u,E=C+S+h,U=tx(o,o.VERTEX_SHADER,O),L=tx(o,o.FRAGMENT_SHADER,E);o.attachShader(R,U),o.attachShader(R,L),n.index0AttributeName!==void 0?o.bindAttribLocation(R,0,n.index0AttributeName):n.hasPositionAttribute===!0&&o.bindAttribLocation(R,0,"position"),o.linkProgram(R);function P(J){if(r.debug.checkShaderErrors){const Q=o.getProgramInfoLog(R)||"",et=o.getShaderInfoLog(U)||"",k=o.getShaderInfoLog(L)||"",q=Q.trim(),F=et.trim(),Z=k.trim();let ht=!0,dt=!0;if(o.getProgramParameter(R,o.LINK_STATUS)===!1)if(ht=!1,typeof r.debug.onShaderError=="function")r.debug.onShaderError(o,R,U,L);else{const pt=nx(o,U,"vertex"),I=nx(o,L,"fragment");We("WebGLProgram: Shader Error "+o.getError()+" - VALIDATE_STATUS "+o.getProgramParameter(R,o.VALIDATE_STATUS)+`

Material Name: `+J.name+`
Material Type: `+J.type+`

Program Info Log: `+q+`
`+pt+`
`+I)}else q!==""?ve("WebGLProgram: Program Info Log:",q):(F===""||Z==="")&&(dt=!1);dt&&(J.diagnostics={runnable:ht,programLog:q,vertexShader:{log:F,prefix:M},fragmentShader:{log:Z,prefix:S}})}o.deleteShader(U),o.deleteShader(L),T=new Tu(o,R),z=GA(o,R)}let T;this.getUniforms=function(){return T===void 0&&P(this),T};let z;this.getAttributes=function(){return z===void 0&&P(this),z};let W=n.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return W===!1&&(W=o.getProgramParameter(R,UA)),W},this.destroy=function(){a.releaseStatesOfProgram(this),o.deleteProgram(R),this.program=void 0},this.type=n.shaderType,this.name=n.shaderName,this.id=LA++,this.cacheKey=t,this.usedTimes=1,this.program=R,this.vertexShader=U,this.fragmentShader=L,this}let i3=0;class a3{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(t,n,a){const o=this._getShaderCacheForMaterial(t);return o.has(n)===!1&&(o.add(n),n.usedTimes++),o.has(a)===!1&&(o.add(a),a.usedTimes++),this}remove(t){const n=this.materialCache.get(t);for(const a of n)a.usedTimes--,a.usedTimes===0&&this.shaderCache.delete(a.code);return this.materialCache.delete(t),this}getVertexShaderStage(t){return this._getShaderStage(t.vertexShader)}getFragmentShaderStage(t){return this._getShaderStage(t.fragmentShader)}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(t){const n=this.materialCache;let a=n.get(t);return a===void 0&&(a=new Set,n.set(t,a)),a}_getShaderStage(t){const n=this.shaderCache;let a=n.get(t);return a===void 0&&(a=new s3(t),n.set(t,a)),a}}class s3{constructor(t){this.id=i3++,this.code=t,this.usedTimes=0}}function r3(r){return r===er||r===Au||r===wu}function o3(r,t,n,a,o,c){const u=new Zp,h=new a3,m=new Set,p=[],g=new Map,_=a.logarithmicDepthBuffer;let v=a.precision;const x={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distance",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function b(T){return m.add(T),T===0?"uv":`uv${T}`}function R(T,z,W,J,Q,et){const k=J.fog,q=Q.geometry,F=T.isMeshStandardMaterial||T.isMeshLambertMaterial||T.isMeshPhongMaterial?J.environment:null,Z=T.isMeshStandardMaterial||T.isMeshLambertMaterial&&!T.envMap||T.isMeshPhongMaterial&&!T.envMap,ht=t.get(T.envMap||F,Z),dt=ht&&ht.mapping===zu?ht.image.height:null,pt=x[T.type];T.precision!==null&&(v=a.getMaxPrecision(T.precision),v!==T.precision&&ve("WebGLProgram.getParameters:",T.precision,"not supported, using",v,"instead."));const I=q.morphAttributes.position||q.morphAttributes.normal||q.morphAttributes.color,ct=I!==void 0?I.length:0;let At=0;q.morphAttributes.position!==void 0&&(At=1),q.morphAttributes.normal!==void 0&&(At=2),q.morphAttributes.color!==void 0&&(At=3);let It,kt,zt,ut;if(pt){const lt=oa[pt];It=lt.vertexShader,kt=lt.fragmentShader}else{It=T.vertexShader,kt=T.fragmentShader;const lt=h.getVertexShaderStage(T),Rt=h.getFragmentShaderStage(T);h.update(T,lt,Rt),zt=lt.id,ut=Rt.id}const Tt=r.getRenderTarget(),Ht=r.state.buffers.depth.getReversed(),ie=Q.isInstancedMesh===!0,qt=Q.isBatchedMesh===!0,re=!!T.map,Fe=!!T.matcap,ee=!!ht,de=!!T.aoMap,xe=!!T.lightMap,fe=!!T.bumpMap&&T.wireframe===!1,be=!!T.normalMap,ke=!!T.displacementMap,ze=!!T.emissiveMap,ne=!!T.metalnessMap,Se=!!T.roughnessMap,j=T.anisotropy>0,_e=T.clearcoat>0,Ee=T.dispersion>0,H=T.retroreflectivity>0,A=T.iridescence>0,at=T.sheen>0,mt=T.transmission>0,bt=j&&!!T.anisotropyMap,Bt=_e&&!!T.clearcoatMap,Ft=_e&&!!T.clearcoatNormalMap,Mt=_e&&!!T.clearcoatRoughnessMap,St=A&&!!T.iridescenceMap,Ot=A&&!!T.iridescenceThicknessMap,Xt=at&&!!T.sheenColorMap,Wt=at&&!!T.sheenRoughnessMap,ot=!!T.specularMap,G=!!T.specularColorMap,Y=!!T.specularIntensityMap,nt=mt&&!!T.transmissionMap,w=mt&&!!T.thicknessMap,V=!!T.gradientMap,X=!!T.alphaMap,st=T.alphaTest>0,rt=!!T.alphaHash,it=!!T.extensions;let Ct=ca;T.toneMapped&&(Tt===null||Tt.isXRRenderTarget===!0)&&(Ct=r.toneMapping);const Pt={shaderID:pt,shaderType:T.type,shaderName:T.name,vertexShader:It,fragmentShader:kt,defines:T.defines,customVertexShaderID:zt,customFragmentShaderID:ut,isRawShaderMaterial:T.isRawShaderMaterial===!0,glslVersion:T.glslVersion,precision:v,batching:qt,batchingColor:qt&&Q._colorsTexture!==null,instancing:ie,instancingColor:ie&&Q.instanceColor!==null,instancingMorph:ie&&Q.morphTexture!==null,outputColorSpace:Tt===null?r.outputColorSpace:Tt.isXRRenderTarget===!0?Tt.texture.colorSpace:Ve.workingColorSpace,alphaToCoverage:!!T.alphaToCoverage,map:re,matcap:Fe,envMap:ee,envMapMode:ee&&ht.mapping,envMapCubeUVHeight:dt,aoMap:de,lightMap:xe,bumpMap:fe,normalMap:be,displacementMap:ke,emissiveMap:ze,normalMapObjectSpace:be&&T.normalMapType===Jy,normalMapTangentSpace:be&&T.normalMapType===Ep,packedNormalMap:be&&T.normalMapType===Ep&&r3(T.normalMap.format),metalnessMap:ne,roughnessMap:Se,anisotropy:j,anisotropyMap:bt,clearcoat:_e,clearcoatMap:Bt,clearcoatNormalMap:Ft,clearcoatRoughnessMap:Mt,dispersion:Ee,retroreflection:H,iridescence:A,iridescenceMap:St,iridescenceThicknessMap:Ot,sheen:at,sheenColorMap:Xt,sheenRoughnessMap:Wt,specularMap:ot,specularColorMap:G,specularIntensityMap:Y,transmission:mt,transmissionMap:nt,thicknessMap:w,gradientMap:V,opaque:T.transparent===!1&&T.blending===vl&&T.alphaToCoverage===!1,alphaMap:X,alphaTest:st,alphaHash:rt,combine:T.combine,mapUv:re&&b(T.map.channel),aoMapUv:de&&b(T.aoMap.channel),lightMapUv:xe&&b(T.lightMap.channel),bumpMapUv:fe&&b(T.bumpMap.channel),normalMapUv:be&&b(T.normalMap.channel),displacementMapUv:ke&&b(T.displacementMap.channel),emissiveMapUv:ze&&b(T.emissiveMap.channel),metalnessMapUv:ne&&b(T.metalnessMap.channel),roughnessMapUv:Se&&b(T.roughnessMap.channel),anisotropyMapUv:bt&&b(T.anisotropyMap.channel),clearcoatMapUv:Bt&&b(T.clearcoatMap.channel),clearcoatNormalMapUv:Ft&&b(T.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:Mt&&b(T.clearcoatRoughnessMap.channel),iridescenceMapUv:St&&b(T.iridescenceMap.channel),iridescenceThicknessMapUv:Ot&&b(T.iridescenceThicknessMap.channel),sheenColorMapUv:Xt&&b(T.sheenColorMap.channel),sheenRoughnessMapUv:Wt&&b(T.sheenRoughnessMap.channel),specularMapUv:ot&&b(T.specularMap.channel),specularColorMapUv:G&&b(T.specularColorMap.channel),specularIntensityMapUv:Y&&b(T.specularIntensityMap.channel),transmissionMapUv:nt&&b(T.transmissionMap.channel),thicknessMapUv:w&&b(T.thicknessMap.channel),alphaMapUv:X&&b(T.alphaMap.channel),vertexTangents:!!q.attributes.tangent&&(be||j),vertexNormals:!!q.attributes.normal,vertexColors:T.vertexColors,vertexAlphas:T.vertexColors===!0&&!!q.attributes.color&&q.attributes.color.itemSize===4,pointsUvs:Q.isPoints===!0&&!!q.attributes.uv&&(re||X),fog:!!k,useFog:T.fog===!0,fogExp2:!!k&&k.isFogExp2,flatShading:T.wireframe===!1&&(T.flatShading===!0||q.attributes.normal===void 0&&be===!1&&(T.isMeshLambertMaterial||T.isMeshPhongMaterial||T.isMeshStandardMaterial||T.isMeshPhysicalMaterial)),sizeAttenuation:T.sizeAttenuation===!0,logarithmicDepthBuffer:_,reversedDepthBuffer:Ht,skinning:Q.isSkinnedMesh===!0,hasPositionAttribute:q.attributes.position!==void 0,morphTargets:q.morphAttributes.position!==void 0,morphNormals:q.morphAttributes.normal!==void 0,morphColors:q.morphAttributes.color!==void 0,morphTargetsCount:ct,morphTextureStride:At,numSunLights:z.sun.length,numDirLights:z.directional.length,numPointLights:z.point.length,numSpotLights:z.spot.length,numSpotLightMaps:z.spotLightMap.length,numRectAreaLights:z.rectArea.length,numHemiLights:z.hemi.length,numSunLightShadows:z.sunShadowMap.length,numDirLightShadows:z.directionalShadowMap.length,numPointLightShadows:z.pointShadowMap.length,numSpotLightShadows:z.spotShadowMap.length,numSpotLightShadowsWithMaps:z.numSpotLightShadowsWithMaps,numLightProbes:z.numLightProbes,numLightProbeGrids:et.length,numClippingPlanes:c.numPlanes,numClipIntersection:c.numIntersection,dithering:T.dithering,shadowMapEnabled:r.shadowMap.enabled&&W.length>0,shadowMapType:r.shadowMap.type,toneMapping:Ct,decodeVideoTexture:re&&T.map.isVideoTexture===!0&&Ve.getTransfer(T.map.colorSpace)===nn,decodeVideoTextureEmissive:ze&&T.emissiveMap.isVideoTexture===!0&&Ve.getTransfer(T.emissiveMap.colorSpace)===nn,premultipliedAlpha:T.premultipliedAlpha,doubleSided:T.side===cn,flipSided:T.side===oi,useDepthPacking:T.depthPacking>=0,depthPacking:T.depthPacking||0,index0AttributeName:T.index0AttributeName,extensionClipCullDistance:it&&T.extensions.clipCullDistance===!0&&n.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(it&&T.extensions.multiDraw===!0||qt)&&n.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:n.has("KHR_parallel_shader_compile"),customProgramCacheKey:T.customProgramCacheKey()};return Pt.vertexUv1s=m.has(1),Pt.vertexUv2s=m.has(2),Pt.vertexUv3s=m.has(3),m.clear(),Pt}function M(T){const z=[];if(T.shaderID?z.push(T.shaderID):(z.push(T.customVertexShaderID),z.push(T.customFragmentShaderID)),T.defines!==void 0)for(const W in T.defines)z.push(W),z.push(T.defines[W]);return T.isRawShaderMaterial===!1&&(S(z,T),C(z,T),z.push(r.outputColorSpace)),z.push(T.customProgramCacheKey),z.join()}function S(T,z){T.push(z.precision),T.push(z.outputColorSpace),T.push(z.envMapMode),T.push(z.envMapCubeUVHeight),T.push(z.mapUv),T.push(z.alphaMapUv),T.push(z.lightMapUv),T.push(z.aoMapUv),T.push(z.bumpMapUv),T.push(z.normalMapUv),T.push(z.displacementMapUv),T.push(z.emissiveMapUv),T.push(z.metalnessMapUv),T.push(z.roughnessMapUv),T.push(z.anisotropyMapUv),T.push(z.clearcoatMapUv),T.push(z.clearcoatNormalMapUv),T.push(z.clearcoatRoughnessMapUv),T.push(z.iridescenceMapUv),T.push(z.iridescenceThicknessMapUv),T.push(z.sheenColorMapUv),T.push(z.sheenRoughnessMapUv),T.push(z.specularMapUv),T.push(z.specularColorMapUv),T.push(z.specularIntensityMapUv),T.push(z.transmissionMapUv),T.push(z.thicknessMapUv),T.push(z.combine),T.push(z.fogExp2),T.push(z.sizeAttenuation),T.push(z.morphTargetsCount),T.push(z.morphAttributeCount),T.push(z.numSunLights),T.push(z.numDirLights),T.push(z.numPointLights),T.push(z.numSpotLights),T.push(z.numSpotLightMaps),T.push(z.numHemiLights),T.push(z.numRectAreaLights),T.push(z.numSunLightShadows),T.push(z.numDirLightShadows),T.push(z.numPointLightShadows),T.push(z.numSpotLightShadows),T.push(z.numSpotLightShadowsWithMaps),T.push(z.numLightProbes),T.push(z.shadowMapType),T.push(z.toneMapping),T.push(z.numClippingPlanes),T.push(z.numClipIntersection),T.push(z.depthPacking)}function C(T,z){u.disableAll(),z.instancing&&u.enable(0),z.instancingColor&&u.enable(1),z.instancingMorph&&u.enable(2),z.matcap&&u.enable(3),z.envMap&&u.enable(4),z.normalMapObjectSpace&&u.enable(5),z.normalMapTangentSpace&&u.enable(6),z.clearcoat&&u.enable(7),z.iridescence&&u.enable(8),z.alphaTest&&u.enable(9),z.vertexColors&&u.enable(10),z.vertexAlphas&&u.enable(11),z.vertexUv1s&&u.enable(12),z.vertexUv2s&&u.enable(13),z.vertexUv3s&&u.enable(14),z.vertexTangents&&u.enable(15),z.anisotropy&&u.enable(16),z.alphaHash&&u.enable(17),z.batching&&u.enable(18),z.dispersion&&u.enable(19),z.retroreflection&&u.enable(24),z.batchingColor&&u.enable(20),z.gradientMap&&u.enable(21),z.packedNormalMap&&u.enable(22),z.vertexNormals&&u.enable(23),T.push(u.mask),u.disableAll(),z.fog&&u.enable(0),z.useFog&&u.enable(1),z.flatShading&&u.enable(2),z.logarithmicDepthBuffer&&u.enable(3),z.reversedDepthBuffer&&u.enable(4),z.skinning&&u.enable(5),z.morphTargets&&u.enable(6),z.morphNormals&&u.enable(7),z.morphColors&&u.enable(8),z.premultipliedAlpha&&u.enable(9),z.shadowMapEnabled&&u.enable(10),z.doubleSided&&u.enable(11),z.flipSided&&u.enable(12),z.useDepthPacking&&u.enable(13),z.dithering&&u.enable(14),z.transmission&&u.enable(15),z.sheen&&u.enable(16),z.opaque&&u.enable(17),z.pointsUvs&&u.enable(18),z.decodeVideoTexture&&u.enable(19),z.decodeVideoTextureEmissive&&u.enable(20),z.alphaToCoverage&&u.enable(21),z.numLightProbeGrids>0&&u.enable(22),z.hasPositionAttribute&&u.enable(23),T.push(u.mask)}function O(T){const z=x[T.type];let W;if(z){const J=oa[z];W=wb.clone(J.uniforms)}else W=T.uniforms;return W}function E(T,z){let W=g.get(z);return W!==void 0?++W.usedTimes:(W=new n3(r,z,T,o),p.push(W),g.set(z,W)),W}function U(T){if(--T.usedTimes===0){const z=p.indexOf(T);p[z]=p[p.length-1],p.pop(),g.delete(T.cacheKey),T.destroy()}}function L(T){h.remove(T)}function P(){h.dispose()}return{getParameters:R,getProgramCacheKey:M,getUniforms:O,acquireProgram:E,releaseProgram:U,releaseShaderCache:L,programs:p,dispose:P}}function l3(){let r=new WeakMap;function t(u){return r.has(u)}function n(u){let h=r.get(u);return h===void 0&&(h={},r.set(u,h)),h}function a(u){r.delete(u)}function o(u,h,m){r.get(u)[h]=m}function c(){r=new WeakMap}return{has:t,get:n,remove:a,update:o,dispose:c}}function c3(r,t){return r.groupOrder!==t.groupOrder?r.groupOrder-t.groupOrder:r.renderOrder!==t.renderOrder?r.renderOrder-t.renderOrder:r.material.id!==t.material.id?r.material.id-t.material.id:r.materialVariant!==t.materialVariant?r.materialVariant-t.materialVariant:r.z!==t.z?r.z-t.z:r.id-t.id}function ox(r,t){return r.groupOrder!==t.groupOrder?r.groupOrder-t.groupOrder:r.renderOrder!==t.renderOrder?r.renderOrder-t.renderOrder:r.z!==t.z?t.z-r.z:r.id-t.id}function lx(){const r=[];let t=0;const n=[],a=[],o=[];function c(){t=0,n.length=0,a.length=0,o.length=0}function u(v){let x=0;return v.isInstancedMesh&&(x+=2),v.isSkinnedMesh&&(x+=1),x}function h(v,x,b,R,M,S){let C=r[t];return C===void 0?(C={id:v.id,object:v,geometry:x,material:b,materialVariant:u(v),groupOrder:R,renderOrder:v.renderOrder,z:M,group:S},r[t]=C):(C.id=v.id,C.object=v,C.geometry=x,C.material=b,C.materialVariant=u(v),C.groupOrder=R,C.renderOrder=v.renderOrder,C.z=M,C.group=S),t++,C}function m(v,x,b,R,M,S,C){C.reversedDepth===!0&&(M=-M);const O=h(v,x,b,R,M,S);b.transmission>0?a.push(O):b.transparent===!0?o.push(O):n.push(O)}function p(v,x,b,R,M,S){const C=h(v,x,b,R,M,S);b.transmission>0?a.unshift(C):b.transparent===!0?o.unshift(C):n.unshift(C)}function g(v,x){n.length>1&&n.sort(v||c3),a.length>1&&a.sort(x||ox),o.length>1&&o.sort(x||ox)}function _(){for(let v=t,x=r.length;v<x;v++){const b=r[v];if(b.id===null)break;b.id=null,b.object=null,b.geometry=null,b.material=null,b.group=null}}return{opaque:n,transmissive:a,transparent:o,init:c,push:m,unshift:p,finish:_,sort:g}}function u3(){let r=new WeakMap;function t(a,o){const c=r.get(a);let u;return c===void 0?(u=new lx,r.set(a,[u])):o>=c.length?(u=new lx,c.push(u)):u=c[o],u}function n(){r=new WeakMap}return{get:t,dispose:n}}function f3(){const r={};return{get:function(t){if(r[t.id]!==void 0)return r[t.id];let n;switch(t.type){case"SunLight":case"DirectionalLight":n={direction:new B,color:new ue};break;case"SpotLight":n={position:new B,direction:new B,color:new ue,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":n={position:new B,color:new ue,distance:0,decay:0};break;case"HemisphereLight":n={direction:new B,skyColor:new ue,groundColor:new ue};break;case"RectAreaLight":n={color:new ue,position:new B,halfWidth:new B,halfHeight:new B};break}return r[t.id]=n,n}}}function h3(){const r={};return{get:function(t){if(r[t.id]!==void 0)return r[t.id];let n;switch(t.type){case"SunLight":case"DirectionalLight":n={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Lt};break;case"SpotLight":n={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Lt};break;case"PointLight":n={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Lt,shadowCameraNear:1,shadowCameraFar:1e3};break}return r[t.id]=n,n}}}let d3=0;function p3(r,t){return(t.castShadow?2:0)-(r.castShadow?2:0)+(t.map?1:0)-(r.map?1:0)}function m3(r){const t=new f3,n=h3(),a={version:0,hash:{sunLength:-1,directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numSunShadows:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],sun:[],sunShadow:[],sunShadowMap:[],sunShadowMatrix:[],sunShadowCascade:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let p=0;p<9;p++)a.probe.push(new B);const o=new B,c=new an,u=new an;function h(p){let g=0,_=0,v=0;for(let Q=0;Q<9;Q++)a.probe[Q].set(0,0,0);let x=0,b=0,R=0,M=0,S=0,C=0,O=0,E=0,U=0,L=0,P=0,T=0,z=0,W=0;p.sort(p3);for(let Q=0,et=p.length;Q<et;Q++){const k=p[Q],q=k.color,F=k.intensity,Z=k.distance;let ht=null;if(k.shadow&&k.shadow.map&&(k.shadow.map.texture.format===er?ht=k.shadow.map.texture:ht=k.shadow.map.depthTexture||k.shadow.map.texture),k.isAmbientLight)g+=q.r*F,_+=q.g*F,v+=q.b*F;else if(k.isLightProbe){for(let dt=0;dt<9;dt++)a.probe[dt].addScaledVector(k.sh.coefficients[dt],F);W++}else if(k.isSunLight){const dt=t.get(k);if(dt.color.copy(k.color).multiplyScalar(k.intensity),k.castShadow){const pt=k.shadow,I=n.get(k);I.shadowIntensity=pt.intensity,I.shadowBias=pt.bias,I.shadowNormalBias=pt.normalBias,I.shadowRadius=pt.radius,I.shadowMapSize.copy(pt.mapSize).multiply(pt.getFrameExtents()),a.sunShadow[b]=I,a.sunShadowMap[b]=ht;const ct=pt.getViewportCount();for(let At=0;At<ct;At++)a.sunShadowMatrix[R+At]=pt.getMatrix(At),a.sunShadowCascade[R+At]=pt._cascadeData[At];R+=ct,b++}a.sun[x]=dt,x++}else if(k.isDirectionalLight){const dt=t.get(k);if(dt.color.copy(k.color).multiplyScalar(k.intensity),k.castShadow){const pt=k.shadow,I=n.get(k);I.shadowIntensity=pt.intensity,I.shadowBias=pt.bias,I.shadowNormalBias=pt.normalBias,I.shadowRadius=pt.radius,I.shadowMapSize=pt.mapSize,a.directionalShadow[M]=I,a.directionalShadowMap[M]=ht,a.directionalShadowMatrix[M]=k.shadow.matrix,U++}a.directional[M]=dt,M++}else if(k.isSpotLight){const dt=t.get(k);dt.position.setFromMatrixPosition(k.matrixWorld),dt.color.copy(q).multiplyScalar(F),dt.distance=Z,dt.coneCos=Math.cos(k.angle),dt.penumbraCos=Math.cos(k.angle*(1-k.penumbra)),dt.decay=k.decay,a.spot[C]=dt;const pt=k.shadow;if(k.map&&(a.spotLightMap[T]=k.map,T++,pt.updateMatrices(k),k.castShadow&&z++),a.spotLightMatrix[C]=pt.matrix,k.castShadow){const I=n.get(k);I.shadowIntensity=pt.intensity,I.shadowBias=pt.bias,I.shadowNormalBias=pt.normalBias,I.shadowRadius=pt.radius,I.shadowMapSize=pt.mapSize,a.spotShadow[C]=I,a.spotShadowMap[C]=ht,P++}C++}else if(k.isRectAreaLight){const dt=t.get(k);dt.color.copy(q).multiplyScalar(F),dt.halfWidth.set(k.width*.5,0,0),dt.halfHeight.set(0,k.height*.5,0),a.rectArea[O]=dt,O++}else if(k.isPointLight){const dt=t.get(k);if(dt.color.copy(k.color).multiplyScalar(k.intensity),dt.distance=k.distance,dt.decay=k.decay,k.castShadow){const pt=k.shadow,I=n.get(k);I.shadowIntensity=pt.intensity,I.shadowBias=pt.bias,I.shadowNormalBias=pt.normalBias,I.shadowRadius=pt.radius,I.shadowMapSize=pt.mapSize,I.shadowCameraNear=pt.camera.near,I.shadowCameraFar=pt.camera.far,a.pointShadow[S]=I,a.pointShadowMap[S]=ht,a.pointShadowMatrix[S]=k.shadow.matrix,L++}a.point[S]=dt,S++}else if(k.isHemisphereLight){const dt=t.get(k);dt.skyColor.copy(k.color).multiplyScalar(F),dt.groundColor.copy(k.groundColor).multiplyScalar(F),a.hemi[E]=dt,E++}}O>0&&(r.has("OES_texture_float_linear")===!0?(a.rectAreaLTC1=Jt.LTC_FLOAT_1,a.rectAreaLTC2=Jt.LTC_FLOAT_2):(a.rectAreaLTC1=Jt.LTC_HALF_1,a.rectAreaLTC2=Jt.LTC_HALF_2)),a.ambient[0]=g,a.ambient[1]=_,a.ambient[2]=v;const J=a.hash;(J.sunLength!==x||J.directionalLength!==M||J.pointLength!==S||J.spotLength!==C||J.rectAreaLength!==O||J.hemiLength!==E||J.numSunShadows!==b||J.numDirectionalShadows!==U||J.numPointShadows!==L||J.numSpotShadows!==P||J.numSpotMaps!==T||J.numLightProbes!==W)&&(a.sun.length=x,a.directional.length=M,a.spot.length=C,a.rectArea.length=O,a.point.length=S,a.hemi.length=E,a.sunShadow.length=b,a.sunShadowMap.length=b,a.sunShadowMatrix.length=R,a.sunShadowCascade.length=R,a.directionalShadow.length=U,a.directionalShadowMap.length=U,a.directionalShadowMatrix.length=U,a.pointShadow.length=L,a.pointShadowMap.length=L,a.pointShadowMatrix.length=L,a.spotShadow.length=P,a.spotShadowMap.length=P,a.spotLightMatrix.length=P+T-z,a.spotLightMap.length=T,a.numSpotLightShadowsWithMaps=z,a.numLightProbes=W,J.sunLength=x,J.directionalLength=M,J.pointLength=S,J.spotLength=C,J.rectAreaLength=O,J.hemiLength=E,J.numSunShadows=b,J.numDirectionalShadows=U,J.numPointShadows=L,J.numSpotShadows=P,J.numSpotMaps=T,J.numLightProbes=W,a.version=d3++)}function m(p,g){let _=0,v=0,x=0,b=0,R=0,M=0;const S=g.matrixWorldInverse;for(let C=0,O=p.length;C<O;C++){const E=p[C];if(E.isSunLight){const U=a.sun[_];U.direction.setFromMatrixPosition(E.matrixWorld),U.direction.transformDirection(S),_++}else if(E.isDirectionalLight){const U=a.directional[v];U.direction.setFromMatrixPosition(E.matrixWorld),o.setFromMatrixPosition(E.target.matrixWorld),U.direction.sub(o),U.direction.transformDirection(S),v++}else if(E.isSpotLight){const U=a.spot[b];U.position.setFromMatrixPosition(E.matrixWorld),U.position.applyMatrix4(S),U.direction.setFromMatrixPosition(E.matrixWorld),o.setFromMatrixPosition(E.target.matrixWorld),U.direction.sub(o),U.direction.transformDirection(S),b++}else if(E.isRectAreaLight){const U=a.rectArea[R];U.position.setFromMatrixPosition(E.matrixWorld),U.position.applyMatrix4(S),u.identity(),c.copy(E.matrixWorld),c.premultiply(S),u.extractRotation(c),U.halfWidth.set(E.width*.5,0,0),U.halfHeight.set(0,E.height*.5,0),U.halfWidth.applyMatrix4(u),U.halfHeight.applyMatrix4(u),R++}else if(E.isPointLight){const U=a.point[x];U.position.setFromMatrixPosition(E.matrixWorld),U.position.applyMatrix4(S),x++}else if(E.isHemisphereLight){const U=a.hemi[M];U.direction.setFromMatrixPosition(E.matrixWorld),U.direction.transformDirection(S),M++}}}return{setup:h,setupView:m,state:a}}function cx(r){const t=new m3(r),n=[],a=[],o=[];function c(v){_.camera=v,n.length=0,a.length=0,o.length=0}function u(v){n.push(v)}function h(v){a.push(v)}function m(v){o.push(v)}function p(){t.setup(n)}function g(v){t.setupView(n,v)}const _={lightsArray:n,shadowsArray:a,lightProbeGridArray:o,camera:null,lights:t,transmissionRenderTarget:{},textureUnits:0};return{init:c,state:_,setupLights:p,setupLightsView:g,pushLight:u,pushShadow:h,pushLightProbeGrid:m}}function g3(r){let t=new WeakMap;function n(o,c=0){const u=t.get(o);let h;return u===void 0?(h=new cx(r),t.set(o,[h])):c>=u.length?(h=new cx(r),u.push(h)):h=u[c],h}function a(){t=new WeakMap}return{get:n,dispose:a}}const v3=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,_3=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ).rg;
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ).r;
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( max( 0.0, squared_mean - mean * mean ) );
	gl_FragColor = vec4( mean, std_dev, 0.0, 1.0 );
}`,x3=[new B(1,0,0),new B(-1,0,0),new B(0,1,0),new B(0,-1,0),new B(0,0,1),new B(0,0,-1)],S3=[new B(0,-1,0),new B(0,-1,0),new B(0,0,1),new B(0,0,-1),new B(0,-1,0),new B(0,-1,0)],ux=new an,dl=new B,zd=new B;function M3(r,t,n){let a=new Kp;const o=new Lt,c=new Lt,u=new xn,h=new Ub,m=new Lb,p={},g=n.maxTextureSize,_={[$s]:oi,[oi]:$s,[cn]:cn},v=new ei({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new Lt},radius:{value:4}},vertexShader:v3,fragmentShader:_3}),x=v.clone();x.defines.HORIZONTAL_PASS=1;const b=new Ne;b.setAttribute("position",new qn(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const R=new le(b,v),M=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=Su;let S=this.type;this.render=function(L,P,T){if(M.enabled===!1||M.autoUpdate===!1&&M.needsUpdate===!1||L.length===0)return;this.type===mx&&(ve("WebGLShadowMap: PCFSoftShadowMap has been removed. Using PCFShadowMap instead."),this.type=Su);const z=r.getRenderTarget(),W=r.getActiveCubeFace(),J=r.getActiveMipmapLevel(),Q=r.state;Q.setBlending(Ha),Q.buffers.depth.getReversed()===!0?Q.buffers.color.setClear(0,0,0,0):Q.buffers.color.setClear(1,1,1,1),Q.buffers.depth.setTest(!0),Q.setScissorTest(!1);const et=S!==this.type;et&&P.traverse(function(k){k.material&&(Array.isArray(k.material)?k.material.forEach(q=>q.needsUpdate=!0):k.material.needsUpdate=!0)});for(let k=0,q=L.length;k<q;k++){const F=L[k],Z=F.shadow;if(Z===void 0){ve("WebGLShadowMap:",F,"has no shadow.");continue}if(Z.autoUpdate===!1&&Z.needsUpdate===!1)continue;o.copy(Z.mapSize);const ht=Z.getFrameExtents();o.multiply(ht),c.copy(Z.mapSize),(o.x>g||o.y>g)&&(o.x>g&&(c.x=Math.floor(g/ht.x),o.x=c.x*ht.x,Z.mapSize.x=c.x),o.y>g&&(c.y=Math.floor(g/ht.y),o.y=c.y*ht.y,Z.mapSize.y=c.y));const dt=r.state.buffers.depth.getReversed();if(Z.camera._reversedDepth=dt,Z.map===null||et===!0){if(Z.map!==null&&(Z.map.depthTexture!==null&&(Z.map.depthTexture.dispose(),Z.map.depthTexture=null),Z.map.dispose()),this.type===pl){if(F.isPointLight){ve("WebGLShadowMap: VSM shadow maps are not supported for PointLights. Use PCF or BasicShadowMap instead.");continue}Z.map=new Hi(o.x,o.y,{format:er,type:$i,minFilter:Xn,magFilter:Xn,generateMipmaps:!1}),Z.map.texture.name=F.name+".shadowMap",Z.map.depthTexture=new Rl(o.x,o.y,Ji),Z.map.depthTexture.name=F.name+".shadowMapDepth",Z.map.depthTexture.format=ka,Z.map.depthTexture.compareFunction=null,Z.map.depthTexture.minFilter=Qn,Z.map.depthTexture.magFilter=Qn}else F.isPointLight?(Z.map=new nS(o.x),Z.map.depthTexture=new K1(o.x,ua)):(Z.map=new Hi(o.x,o.y),Z.map.depthTexture=new Rl(o.x,o.y,ua)),Z.map.depthTexture.name=F.name+".shadowMap",Z.map.depthTexture.format=ka,this.type===Su?(Z.map.depthTexture.compareFunction=dt?Wp:Xp,Z.map.depthTexture.minFilter=Xn,Z.map.depthTexture.magFilter=Xn):(Z.map.depthTexture.compareFunction=null,Z.map.depthTexture.minFilter=Qn,Z.map.depthTexture.magFilter=Qn);Z.camera.updateProjectionMatrix()}Z.map.isWebGLCubeRenderTarget!==!0&&(Z.map.width!==o.x||Z.map.height!==o.y)&&Z.map.setSize(o.x,o.y);const pt=Z.map.isWebGLCubeRenderTarget?6:Z.getViewportCount();F.isPointLight!==!0&&Z.updateMatrices(F,T);for(let I=0;I<pt;I++){const ct=Z.getCamera(I);if(F.isPointLight){const At=Z.camera,It=Z.matrix,kt=F.distance||At.far;kt!==At.far&&(At.far=kt,At.updateProjectionMatrix()),dl.setFromMatrixPosition(F.matrixWorld),At.position.copy(dl),zd.copy(At.position),zd.add(x3[I]),At.up.copy(S3[I]),At.lookAt(zd),At.updateMatrixWorld(),It.makeTranslation(-dl.x,-dl.y,-dl.z),ux.multiplyMatrices(At.projectionMatrix,At.matrixWorldInverse),Z._frustum.setFromProjectionMatrix(ux,At.coordinateSystem,At.reversedDepth)}if(Z.map.isWebGLCubeRenderTarget)r.setRenderTarget(Z.map,I),r.clear();else{I===0&&(r.setRenderTarget(Z.map),r.clear());const At=Z.getViewport(I);u.set(c.x*At.x,c.y*At.y,c.x*At.z,c.y*At.w),Q.viewport(u)}a=Z.getFrustum(I),E(P,T,ct,F,this.type)}Z.isPointLightShadow!==!0&&this.type===pl&&C(Z,T),Z.needsUpdate=!1}S=this.type,M.needsUpdate=!1,r.setRenderTarget(z,W,J)};function C(L,P){const T=t.update(R);v.defines.VSM_SAMPLES!==L.blurSamples&&(v.defines.VSM_SAMPLES=L.blurSamples,x.defines.VSM_SAMPLES=L.blurSamples,v.needsUpdate=!0,x.needsUpdate=!0),L.mapPass===null?L.mapPass=new Hi(o.x,o.y,{format:er,type:$i}):(L.mapPass.width!==L.map.width||L.mapPass.height!==L.map.height)&&L.mapPass.setSize(L.map.width,L.map.height),v.uniforms.shadow_pass.value=L.map.depthTexture,v.uniforms.resolution.value.set(L.map.width,L.map.height),v.uniforms.radius.value=L.radius,r.setRenderTarget(L.mapPass),r.clear(),r.renderBufferDirect(P,null,T,v,R,null),x.uniforms.shadow_pass.value=L.mapPass.texture,x.uniforms.resolution.value.set(L.map.width,L.map.height),x.uniforms.radius.value=L.radius,r.setRenderTarget(L.map),r.clear(),r.renderBufferDirect(P,null,T,x,R,null)}function O(L,P,T,z){let W=null;const J=T.isPointLight===!0?L.customDistanceMaterial:L.customDepthMaterial;if(J!==void 0)W=J;else if(W=T.isPointLight===!0?m:h,r.localClippingEnabled&&P.clipShadows===!0&&Array.isArray(P.clippingPlanes)&&P.clippingPlanes.length!==0||P.displacementMap&&P.displacementScale!==0||P.alphaMap&&P.alphaTest>0||P.map&&P.alphaTest>0||P.alphaToCoverage===!0){const Q=W.uuid,et=P.uuid;let k=p[Q];k===void 0&&(k={},p[Q]=k);let q=k[et];q===void 0&&(q=W.clone(),k[et]=q,P.addEventListener("dispose",U)),W=q}if(W.visible=P.visible,W.wireframe=P.wireframe,z===pl?W.side=P.shadowSide!==null?P.shadowSide:P.side:W.side=P.shadowSide!==null?P.shadowSide:_[P.side],W.alphaMap=P.alphaMap,W.alphaTest=P.alphaToCoverage===!0?.5:P.alphaTest,W.map=P.map,W.clipShadows=P.clipShadows,W.clippingPlanes=P.clippingPlanes,W.clipIntersection=P.clipIntersection,W.displacementMap=P.displacementMap,W.displacementScale=P.displacementScale,W.displacementBias=P.displacementBias,W.wireframeLinewidth=P.wireframeLinewidth,W.linewidth=P.linewidth,T.isPointLight===!0&&W.isMeshDistanceMaterial===!0){const Q=r.properties.get(W);Q.light=T}return W}function E(L,P,T,z,W){if(L.visible===!1)return;if(L.layers.test(P.layers)&&(L.isMesh||L.isLine||L.isPoints)&&(L.castShadow||L.receiveShadow&&W===pl)&&(!L.frustumCulled||L.intersectsFrustum(a))){L.modelViewMatrix.multiplyMatrices(T.matrixWorldInverse,L.matrixWorld);const et=t.update(L),k=L.material;if(Array.isArray(k)){const q=et.groups;for(let F=0,Z=q.length;F<Z;F++){const ht=q[F],dt=k[ht.materialIndex];if(dt&&dt.visible){const pt=O(L,dt,z,W);L.onBeforeShadow(r,L,P,T,et,pt,ht),r.renderBufferDirect(T,null,et,pt,L,ht),L.onAfterShadow(r,L,P,T,et,pt,ht)}}}else if(k.visible){const q=O(L,k,z,W);L.onBeforeShadow(r,L,P,T,et,q,null),r.renderBufferDirect(T,null,et,q,L,null),L.onAfterShadow(r,L,P,T,et,q,null)}}const Q=L.children;for(let et=0,k=Q.length;et<k;et++)E(Q[et],P,T,z,W)}function U(L){L.target.removeEventListener("dispose",U);for(const T in p){const z=p[T],W=L.target.uuid;W in z&&(z[W].dispose(),delete z[W])}}}function y3(r,t){function n(){let w=!1;const V=new xn;let X=null;const st=new xn(0,0,0,0);return{setMask:function(rt){X!==rt&&!w&&(r.colorMask(rt,rt,rt,rt),X=rt)},setLocked:function(rt){w=rt},setClear:function(rt,it,Ct,Pt,lt){lt===!0&&(rt*=Pt,it*=Pt,Ct*=Pt),V.set(rt,it,Ct,Pt),st.equals(V)===!1&&(r.clearColor(rt,it,Ct,Pt),st.copy(V))},reset:function(){w=!1,X=null,st.set(-1,0,0,0)}}}function a(){let w=!1,V=!1,X=null,st=null,rt=null;return{setReversed:function(it){if(V!==it){const Ct=t.get("EXT_clip_control");it?Ct.clipControlEXT(Ct.LOWER_LEFT_EXT,Ct.ZERO_TO_ONE_EXT):Ct.clipControlEXT(Ct.LOWER_LEFT_EXT,Ct.NEGATIVE_ONE_TO_ONE_EXT),V=it;const Pt=rt;rt=null,this.setClear(Pt)}},getReversed:function(){return V},setTest:function(it){it?Tt(r.DEPTH_TEST):Ht(r.DEPTH_TEST)},setMask:function(it){X!==it&&!w&&(r.depthMask(it),X=it)},setFunc:function(it){if(V&&(it=o1[it]),st!==it){switch(it){case Hd:r.depthFunc(r.NEVER);break;case Gd:r.depthFunc(r.ALWAYS);break;case Vd:r.depthFunc(r.LESS);break;case bl:r.depthFunc(r.LEQUAL);break;case kd:r.depthFunc(r.EQUAL);break;case Xd:r.depthFunc(r.GEQUAL);break;case Wd:r.depthFunc(r.GREATER);break;case qd:r.depthFunc(r.NOTEQUAL);break;default:r.depthFunc(r.LEQUAL)}st=it}},setLocked:function(it){w=it},setClear:function(it){rt!==it&&(rt=it,V&&(it=1-it),r.clearDepth(it))},reset:function(){w=!1,X=null,st=null,rt=null,V=!1}}}function o(){let w=!1,V=null,X=null,st=null,rt=null,it=null,Ct=null,Pt=null,lt=null;return{setTest:function(Rt){w||(Rt?Tt(r.STENCIL_TEST):Ht(r.STENCIL_TEST))},setMask:function(Rt){V!==Rt&&!w&&(r.stencilMask(Rt),V=Rt)},setFunc:function(Rt,Gt,Vt){(X!==Rt||st!==Gt||rt!==Vt)&&(r.stencilFunc(Rt,Gt,Vt),X=Rt,st=Gt,rt=Vt)},setOp:function(Rt,Gt,Vt){(it!==Rt||Ct!==Gt||Pt!==Vt)&&(r.stencilOp(Rt,Gt,Vt),it=Rt,Ct=Gt,Pt=Vt)},setLocked:function(Rt){w=Rt},setClear:function(Rt){lt!==Rt&&(r.clearStencil(Rt),lt=Rt)},reset:function(){w=!1,V=null,X=null,st=null,rt=null,it=null,Ct=null,Pt=null,lt=null}}}const c=new n,u=new a,h=new o,m=new WeakMap,p=new WeakMap;let g={},_={},v={},x=new WeakMap,b=[],R=null,M=!1,S=null,C=null,O=null,E=null,U=null,L=null,P=null,T=new ue(0,0,0),z=0,W=!1,J=null,Q=null,et=null,k=null,q=null;const F=r.getParameter(r.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let Z=!1,ht=0;const dt=r.getParameter(r.VERSION);dt.indexOf("WebGL")!==-1?(ht=parseFloat(/^WebGL (\d)/.exec(dt)[1]),Z=ht>=1):dt.indexOf("OpenGL ES")!==-1&&(ht=parseFloat(/^OpenGL ES (\d)/.exec(dt)[1]),Z=ht>=2);let pt=null,I={};const ct=r.getParameter(r.SCISSOR_BOX),At=r.getParameter(r.VIEWPORT),It=new xn().fromArray(ct),kt=new xn().fromArray(At);function zt(w,V,X,st){const rt=new Uint8Array(4),it=r.createTexture();r.bindTexture(w,it),r.texParameteri(w,r.TEXTURE_MIN_FILTER,r.NEAREST),r.texParameteri(w,r.TEXTURE_MAG_FILTER,r.NEAREST);for(let Ct=0;Ct<X;Ct++)w===r.TEXTURE_3D||w===r.TEXTURE_2D_ARRAY?r.texImage3D(V,0,r.RGBA,1,1,st,0,r.RGBA,r.UNSIGNED_BYTE,rt):r.texImage2D(V+Ct,0,r.RGBA,1,1,0,r.RGBA,r.UNSIGNED_BYTE,rt);return it}const ut={};ut[r.TEXTURE_2D]=zt(r.TEXTURE_2D,r.TEXTURE_2D,1),ut[r.TEXTURE_CUBE_MAP]=zt(r.TEXTURE_CUBE_MAP,r.TEXTURE_CUBE_MAP_POSITIVE_X,6),ut[r.TEXTURE_2D_ARRAY]=zt(r.TEXTURE_2D_ARRAY,r.TEXTURE_2D_ARRAY,1,1),ut[r.TEXTURE_3D]=zt(r.TEXTURE_3D,r.TEXTURE_3D,1,1),c.setClear(0,0,0,1),u.setClear(1),h.setClear(0),Tt(r.DEPTH_TEST),u.setFunc(bl),fe(!1),be(Jv),Tt(r.CULL_FACE),de(Ha);function Tt(w){g[w]!==!0&&(r.enable(w),g[w]=!0)}function Ht(w){g[w]!==!1&&(r.disable(w),g[w]=!1)}function ie(w,V){return v[w]!==V?(r.bindFramebuffer(w,V),v[w]=V,w===r.DRAW_FRAMEBUFFER&&(v[r.FRAMEBUFFER]=V),w===r.FRAMEBUFFER&&(v[r.DRAW_FRAMEBUFFER]=V),!0):!1}function qt(w,V){let X=b,st=!1;if(w){X=x.get(V),X===void 0&&(X=[],x.set(V,X));const rt=w.textures;if(X.length!==rt.length||X[0]!==r.COLOR_ATTACHMENT0){for(let it=0,Ct=rt.length;it<Ct;it++)X[it]=r.COLOR_ATTACHMENT0+it;X.length=rt.length,st=!0}}else X[0]!==r.BACK&&(X[0]=r.BACK,st=!0);st&&r.drawBuffers(X)}function re(w){return R!==w?(r.useProgram(w),R=w,!0):!1}const Fe={[io]:r.FUNC_ADD,[Cy]:r.FUNC_SUBTRACT,[Dy]:r.FUNC_REVERSE_SUBTRACT};Fe[Uy]=r.MIN,Fe[Ly]=r.MAX;const ee={[Ny]:r.ZERO,[Oy]:r.ONE,[Py]:r.SRC_COLOR,[gx]:r.SRC_ALPHA,[Gy]:r.SRC_ALPHA_SATURATE,[Fy]:r.DST_COLOR,[Iy]:r.DST_ALPHA,[zy]:r.ONE_MINUS_SRC_COLOR,[vx]:r.ONE_MINUS_SRC_ALPHA,[Hy]:r.ONE_MINUS_DST_COLOR,[By]:r.ONE_MINUS_DST_ALPHA,[Vy]:r.CONSTANT_COLOR,[ky]:r.ONE_MINUS_CONSTANT_COLOR,[Xy]:r.CONSTANT_ALPHA,[Wy]:r.ONE_MINUS_CONSTANT_ALPHA};function de(w,V,X,st,rt,it,Ct,Pt,lt,Rt){if(w===Ha){M===!0&&(Ht(r.BLEND),M=!1);return}if(M===!1&&(Tt(r.BLEND),M=!0),w!==Ry){if(w!==S||Rt!==W){if((C!==io||U!==io)&&(r.blendEquation(r.FUNC_ADD),C=io,U=io),Rt)switch(w){case vl:r.blendFuncSeparate(r.ONE,r.ONE_MINUS_SRC_ALPHA,r.ONE,r.ONE_MINUS_SRC_ALPHA);break;case Qv:r.blendFunc(r.ONE,r.ONE);break;case jv:r.blendFuncSeparate(r.ZERO,r.ONE_MINUS_SRC_COLOR,r.ZERO,r.ONE);break;case $v:r.blendFuncSeparate(r.DST_COLOR,r.ONE_MINUS_SRC_ALPHA,r.ZERO,r.ONE);break;default:We("WebGLState: Invalid blending: ",w);break}else switch(w){case vl:r.blendFuncSeparate(r.SRC_ALPHA,r.ONE_MINUS_SRC_ALPHA,r.ONE,r.ONE_MINUS_SRC_ALPHA);break;case Qv:r.blendFuncSeparate(r.SRC_ALPHA,r.ONE,r.ONE,r.ONE);break;case jv:We("WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true");break;case $v:We("WebGLState: MultiplyBlending requires material.premultipliedAlpha = true");break;default:We("WebGLState: Invalid blending: ",w);break}O=null,E=null,L=null,P=null,T.set(0,0,0),z=0,S=w,W=Rt}return}rt=rt||V,it=it||X,Ct=Ct||st,(V!==C||rt!==U)&&(r.blendEquationSeparate(Fe[V],Fe[rt]),C=V,U=rt),(X!==O||st!==E||it!==L||Ct!==P)&&(r.blendFuncSeparate(ee[X],ee[st],ee[it],ee[Ct]),O=X,E=st,L=it,P=Ct),(Pt.equals(T)===!1||lt!==z)&&(r.blendColor(Pt.r,Pt.g,Pt.b,lt),T.copy(Pt),z=lt),S=w,W=!1}function xe(w,V){w.side===cn?Ht(r.CULL_FACE):Tt(r.CULL_FACE);let X=w.side===oi;V&&(X=!X),fe(X),w.blending===vl&&w.transparent===!1?de(Ha):de(w.blending,w.blendEquation,w.blendSrc,w.blendDst,w.blendEquationAlpha,w.blendSrcAlpha,w.blendDstAlpha,w.blendColor,w.blendAlpha,w.premultipliedAlpha),u.setFunc(w.depthFunc),u.setTest(w.depthTest),u.setMask(w.depthWrite),c.setMask(w.colorWrite);const st=w.stencilWrite;h.setTest(st),st&&(h.setMask(w.stencilWriteMask),h.setFunc(w.stencilFunc,w.stencilRef,w.stencilFuncMask),h.setOp(w.stencilFail,w.stencilZFail,w.stencilZPass)),ze(w.polygonOffset,w.polygonOffsetFactor,w.polygonOffsetUnits),w.alphaToCoverage===!0?Tt(r.SAMPLE_ALPHA_TO_COVERAGE):Ht(r.SAMPLE_ALPHA_TO_COVERAGE)}function fe(w){J!==w&&(w?r.frontFace(r.CW):r.frontFace(r.CCW),J=w)}function be(w){w!==Ay?(Tt(r.CULL_FACE),w!==Q&&(w===Jv?r.cullFace(r.BACK):w===wy?r.cullFace(r.FRONT):r.cullFace(r.FRONT_AND_BACK))):Ht(r.CULL_FACE),Q=w}function ke(w){w!==et&&(Z&&r.lineWidth(w),et=w)}function ze(w,V,X){w?(Tt(r.POLYGON_OFFSET_FILL),(k!==V||q!==X)&&(k=V,q=X,u.getReversed()&&(V=-V),r.polygonOffset(V,X))):Ht(r.POLYGON_OFFSET_FILL)}function ne(w){w?Tt(r.SCISSOR_TEST):Ht(r.SCISSOR_TEST)}function Se(w){w===void 0&&(w=r.TEXTURE0+F-1),pt!==w&&(r.activeTexture(w),pt=w)}function j(w,V,X){X===void 0&&(pt===null?X=r.TEXTURE0+F-1:X=pt);let st=I[X];st===void 0&&(st={type:void 0,texture:void 0},I[X]=st),(st.type!==w||st.texture!==V)&&(pt!==X&&(r.activeTexture(X),pt=X),r.bindTexture(w,V||ut[w]),st.type=w,st.texture=V)}function _e(){const w=I[pt];w!==void 0&&w.type!==void 0&&(r.bindTexture(w.type,null),w.type=void 0,w.texture=void 0)}function Ee(){try{r.compressedTexImage2D(...arguments)}catch(w){We("WebGLState:",w)}}function H(){try{r.compressedTexImage3D(...arguments)}catch(w){We("WebGLState:",w)}}function A(){try{r.texSubImage2D(...arguments)}catch(w){We("WebGLState:",w)}}function at(){try{r.texSubImage3D(...arguments)}catch(w){We("WebGLState:",w)}}function mt(){try{r.compressedTexSubImage2D(...arguments)}catch(w){We("WebGLState:",w)}}function bt(){try{r.compressedTexSubImage3D(...arguments)}catch(w){We("WebGLState:",w)}}function Bt(){try{r.texStorage2D(...arguments)}catch(w){We("WebGLState:",w)}}function Ft(){try{r.texStorage3D(...arguments)}catch(w){We("WebGLState:",w)}}function Mt(){try{r.texImage2D(...arguments)}catch(w){We("WebGLState:",w)}}function St(){try{r.texImage3D(...arguments)}catch(w){We("WebGLState:",w)}}function Ot(w){return _[w]!==void 0?_[w]:r.getParameter(w)}function Xt(w,V){_[w]!==V&&(r.pixelStorei(w,V),_[w]=V)}function Wt(w){It.equals(w)===!1&&(r.scissor(w.x,w.y,w.z,w.w),It.copy(w))}function ot(w){kt.equals(w)===!1&&(r.viewport(w.x,w.y,w.z,w.w),kt.copy(w))}function G(w,V){let X=p.get(V);X===void 0&&(X=new WeakMap,p.set(V,X));let st=X.get(w);st===void 0&&(st=r.getUniformBlockIndex(V,w.name),X.set(w,st))}function Y(w,V){const st=p.get(V).get(w);m.get(V)!==st&&(r.uniformBlockBinding(V,st,w.__bindingPointIndex),m.set(V,st))}function nt(){r.disable(r.BLEND),r.disable(r.CULL_FACE),r.disable(r.DEPTH_TEST),r.disable(r.POLYGON_OFFSET_FILL),r.disable(r.SCISSOR_TEST),r.disable(r.STENCIL_TEST),r.disable(r.SAMPLE_ALPHA_TO_COVERAGE),r.blendEquation(r.FUNC_ADD),r.blendFunc(r.ONE,r.ZERO),r.blendFuncSeparate(r.ONE,r.ZERO,r.ONE,r.ZERO),r.blendColor(0,0,0,0),r.colorMask(!0,!0,!0,!0),r.clearColor(0,0,0,0),r.depthMask(!0),r.depthFunc(r.LESS),u.setReversed(!1),r.clearDepth(1),r.stencilMask(4294967295),r.stencilFunc(r.ALWAYS,0,4294967295),r.stencilOp(r.KEEP,r.KEEP,r.KEEP),r.clearStencil(0),r.cullFace(r.BACK),r.frontFace(r.CCW),r.polygonOffset(0,0),r.activeTexture(r.TEXTURE0),r.bindFramebuffer(r.FRAMEBUFFER,null),r.bindFramebuffer(r.DRAW_FRAMEBUFFER,null),r.bindFramebuffer(r.READ_FRAMEBUFFER,null),r.useProgram(null),r.lineWidth(1),r.scissor(0,0,r.canvas.width,r.canvas.height),r.viewport(0,0,r.canvas.width,r.canvas.height),r.pixelStorei(r.PACK_ALIGNMENT,4),r.pixelStorei(r.UNPACK_ALIGNMENT,4),r.pixelStorei(r.UNPACK_FLIP_Y_WEBGL,!1),r.pixelStorei(r.UNPACK_PREMULTIPLY_ALPHA_WEBGL,!1),r.pixelStorei(r.UNPACK_COLORSPACE_CONVERSION_WEBGL,r.BROWSER_DEFAULT_WEBGL),r.pixelStorei(r.PACK_ROW_LENGTH,0),r.pixelStorei(r.PACK_SKIP_PIXELS,0),r.pixelStorei(r.PACK_SKIP_ROWS,0),r.pixelStorei(r.UNPACK_ROW_LENGTH,0),r.pixelStorei(r.UNPACK_IMAGE_HEIGHT,0),r.pixelStorei(r.UNPACK_SKIP_PIXELS,0),r.pixelStorei(r.UNPACK_SKIP_ROWS,0),r.pixelStorei(r.UNPACK_SKIP_IMAGES,0),g={},_={},pt=null,I={},v={},x=new WeakMap,b=[],R=null,M=!1,S=null,C=null,O=null,E=null,U=null,L=null,P=null,T=new ue(0,0,0),z=0,W=!1,J=null,Q=null,et=null,k=null,q=null,It.set(0,0,r.canvas.width,r.canvas.height),kt.set(0,0,r.canvas.width,r.canvas.height),c.reset(),u.reset(),h.reset()}return{buffers:{color:c,depth:u,stencil:h},enable:Tt,disable:Ht,bindFramebuffer:ie,drawBuffers:qt,useProgram:re,setBlending:de,setMaterial:xe,setFlipSided:fe,setCullFace:be,setLineWidth:ke,setPolygonOffset:ze,setScissorTest:ne,activeTexture:Se,bindTexture:j,unbindTexture:_e,compressedTexImage2D:Ee,compressedTexImage3D:H,texImage2D:Mt,texImage3D:St,pixelStorei:Xt,getParameter:Ot,updateUBOMapping:G,uniformBlockBinding:Y,texStorage2D:Bt,texStorage3D:Ft,texSubImage2D:A,texSubImage3D:at,compressedTexSubImage2D:mt,compressedTexSubImage3D:bt,scissor:Wt,viewport:ot,reset:nt}}function b3(r,t,n,a,o,c,u){const h=t.has("WEBGL_multisampled_render_to_texture")?t.get("WEBGL_multisampled_render_to_texture"):null,m=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),p=new Lt,g=new WeakMap,_=new Set;let v;const x=new WeakMap;let b=!1;try{b=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function R(H,A){return b?new OffscreenCanvas(H,A):Du("canvas")}function M(H,A,at){let mt=1;const bt=Ee(H);if((bt.width>at||bt.height>at)&&(mt=at/Math.max(bt.width,bt.height)),mt<1)if(typeof HTMLImageElement<"u"&&H instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&H instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&H instanceof ImageBitmap||typeof VideoFrame<"u"&&H instanceof VideoFrame){const Bt=Math.floor(mt*bt.width),Ft=Math.floor(mt*bt.height);v===void 0&&(v=R(Bt,Ft));const Mt=A?R(Bt,Ft):v;return Mt.width=Bt,Mt.height=Ft,Mt.getContext("2d").drawImage(H,0,0,Bt,Ft),ve("WebGLRenderer: Texture has been resized from ("+bt.width+"x"+bt.height+") to ("+Bt+"x"+Ft+")."),Mt}else return"data"in H&&ve("WebGLRenderer: Image in DataTexture is too big ("+bt.width+"x"+bt.height+")."),H;return H}function S(H){return H.generateMipmaps}function C(H){r.generateMipmap(H)}function O(H){return H.isWebGLCubeRenderTarget?r.TEXTURE_CUBE_MAP:H.isWebGL3DRenderTarget?r.TEXTURE_3D:H.isWebGLArrayRenderTarget||H.isCompressedArrayTexture?r.TEXTURE_2D_ARRAY:r.TEXTURE_2D}function E(H,A,at,mt,bt,Bt=!1){if(H!==null){if(r[H]!==void 0)return r[H];ve("WebGLRenderer: Attempt to use non-existing WebGL internal format '"+H+"'")}let Ft;mt&&(Ft=t.get("EXT_texture_norm16"),Ft||ve("WebGLRenderer: Unable to use normalized textures without EXT_texture_norm16 extension"));let Mt=A;if(A===r.RED&&(at===r.FLOAT&&(Mt=r.R32F),at===r.HALF_FLOAT&&(Mt=r.R16F),at===r.UNSIGNED_BYTE&&(Mt=r.R8),at===r.UNSIGNED_SHORT&&Ft&&(Mt=Ft.R16_EXT),at===r.SHORT&&Ft&&(Mt=Ft.R16_SNORM_EXT)),A===r.RED_INTEGER&&(at===r.UNSIGNED_BYTE&&(Mt=r.R8UI),at===r.UNSIGNED_SHORT&&(Mt=r.R16UI),at===r.UNSIGNED_INT&&(Mt=r.R32UI),at===r.BYTE&&(Mt=r.R8I),at===r.SHORT&&(Mt=r.R16I),at===r.INT&&(Mt=r.R32I)),A===r.RG&&(at===r.FLOAT&&(Mt=r.RG32F),at===r.HALF_FLOAT&&(Mt=r.RG16F),at===r.UNSIGNED_BYTE&&(Mt=r.RG8),at===r.UNSIGNED_SHORT&&Ft&&(Mt=Ft.RG16_EXT),at===r.SHORT&&Ft&&(Mt=Ft.RG16_SNORM_EXT)),A===r.RG_INTEGER&&(at===r.UNSIGNED_BYTE&&(Mt=r.RG8UI),at===r.UNSIGNED_SHORT&&(Mt=r.RG16UI),at===r.UNSIGNED_INT&&(Mt=r.RG32UI),at===r.BYTE&&(Mt=r.RG8I),at===r.SHORT&&(Mt=r.RG16I),at===r.INT&&(Mt=r.RG32I)),A===r.RGB_INTEGER&&(at===r.UNSIGNED_BYTE&&(Mt=r.RGB8UI),at===r.UNSIGNED_SHORT&&(Mt=r.RGB16UI),at===r.UNSIGNED_INT&&(Mt=r.RGB32UI),at===r.BYTE&&(Mt=r.RGB8I),at===r.SHORT&&(Mt=r.RGB16I),at===r.INT&&(Mt=r.RGB32I)),A===r.RGBA_INTEGER&&(at===r.UNSIGNED_BYTE&&(Mt=r.RGBA8UI),at===r.UNSIGNED_SHORT&&(Mt=r.RGBA16UI),at===r.UNSIGNED_INT&&(Mt=r.RGBA32UI),at===r.BYTE&&(Mt=r.RGBA8I),at===r.SHORT&&(Mt=r.RGBA16I),at===r.INT&&(Mt=r.RGBA32I)),A===r.RGB&&(at===r.UNSIGNED_SHORT&&Ft&&(Mt=Ft.RGB16_EXT),at===r.SHORT&&Ft&&(Mt=Ft.RGB16_SNORM_EXT),at===r.UNSIGNED_INT_5_9_9_9_REV&&(Mt=r.RGB9_E5),at===r.UNSIGNED_INT_10F_11F_11F_REV&&(Mt=r.R11F_G11F_B10F)),A===r.RGBA){const St=Bt?Cu:Ve.getTransfer(bt);at===r.FLOAT&&(Mt=r.RGBA32F),at===r.HALF_FLOAT&&(Mt=r.RGBA16F),at===r.UNSIGNED_BYTE&&(Mt=St===nn?r.SRGB8_ALPHA8:r.RGBA8),at===r.UNSIGNED_SHORT&&Ft&&(Mt=Ft.RGBA16_EXT),at===r.SHORT&&Ft&&(Mt=Ft.RGBA16_SNORM_EXT),at===r.UNSIGNED_SHORT_4_4_4_4&&(Mt=r.RGBA4),at===r.UNSIGNED_SHORT_5_5_5_1&&(Mt=r.RGB5_A1)}return(Mt===r.R16F||Mt===r.R32F||Mt===r.RG16F||Mt===r.RG32F||Mt===r.RGBA16F||Mt===r.RGBA32F)&&t.get("EXT_color_buffer_float"),Mt}function U(H,A){let at;return H?A===null||A===ua||A===Tl?at=r.DEPTH24_STENCIL8:A===Ji?at=r.DEPTH32F_STENCIL8:A===El&&(at=r.DEPTH24_STENCIL8,ve("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):A===null||A===ua||A===Tl?at=r.DEPTH_COMPONENT24:A===Ji?at=r.DEPTH_COMPONENT32F:A===El&&(at=r.DEPTH_COMPONENT16),at}function L(H,A){return S(H)===!0||H.isFramebufferTexture&&H.minFilter!==Qn&&H.minFilter!==Xn?Math.log2(Math.max(A.width,A.height))+1:H.mipmaps!==void 0&&H.mipmaps.length>0?H.mipmaps.length:H.isCompressedTexture&&Array.isArray(H.image)?A.mipmaps.length:1}function P(H){const A=H.target;A.removeEventListener("dispose",P),z(A),A.isVideoTexture&&g.delete(A),A.isHTMLTexture&&_.delete(A)}function T(H){const A=H.target;A.removeEventListener("dispose",T),J(A)}function z(H){const A=a.get(H);if(A.__webglInit===void 0)return;const at=H.source,mt=x.get(at);if(mt){const bt=mt[A.__cacheKey];bt.usedTimes--,bt.usedTimes===0&&W(H),Object.keys(mt).length===0&&x.delete(at)}a.remove(H)}function W(H){const A=a.get(H);r.deleteTexture(A.__webglTexture);const at=H.source,mt=x.get(at);delete mt[A.__cacheKey],u.memory.textures--}function J(H){const A=a.get(H);if(H.depthTexture&&(H.depthTexture.dispose(),a.remove(H.depthTexture)),H.isWebGLCubeRenderTarget)for(let mt=0;mt<6;mt++){if(Array.isArray(A.__webglFramebuffer[mt]))for(let bt=0;bt<A.__webglFramebuffer[mt].length;bt++)r.deleteFramebuffer(A.__webglFramebuffer[mt][bt]);else r.deleteFramebuffer(A.__webglFramebuffer[mt]);A.__webglDepthbuffer&&r.deleteRenderbuffer(A.__webglDepthbuffer[mt])}else{if(Array.isArray(A.__webglFramebuffer))for(let mt=0;mt<A.__webglFramebuffer.length;mt++)r.deleteFramebuffer(A.__webglFramebuffer[mt]);else r.deleteFramebuffer(A.__webglFramebuffer);if(A.__webglDepthbuffer&&r.deleteRenderbuffer(A.__webglDepthbuffer),A.__webglMultisampledFramebuffer&&r.deleteFramebuffer(A.__webglMultisampledFramebuffer),A.__webglColorRenderbuffer)for(let mt=0;mt<A.__webglColorRenderbuffer.length;mt++)A.__webglColorRenderbuffer[mt]&&r.deleteRenderbuffer(A.__webglColorRenderbuffer[mt]);A.__webglDepthRenderbuffer&&r.deleteRenderbuffer(A.__webglDepthRenderbuffer)}const at=H.textures;for(let mt=0,bt=at.length;mt<bt;mt++){const Bt=a.get(at[mt]);Bt.__webglTexture&&(r.deleteTexture(Bt.__webglTexture),u.memory.textures--),a.remove(at[mt])}a.remove(H)}let Q=0;function et(){Q=0}function k(){return Q}function q(H){Q=H}function F(){const H=Q;return H>=o.maxTextures&&ve("WebGLTextures: Trying to use "+(H+1)+" texture units while this GPU supports only "+o.maxTextures),Q+=1,H}function Z(H){const A=[];return A.push(H.wrapS),A.push(H.wrapT),A.push(H.wrapR||0),A.push(H.magFilter),A.push(H.minFilter),A.push(H.anisotropy),A.push(H.internalFormat),A.push(H.format),A.push(H.type),A.push(H.generateMipmaps),A.push(H.premultiplyAlpha),A.push(H.flipY),A.push(H.unpackAlignment),A.push(H.colorSpace),A.join()}function ht(H,A){const at=a.get(H);if(H.isVideoTexture&&j(H),H.isRenderTargetTexture===!1&&H.isExternalTexture!==!0&&H.version>0&&at.__version!==H.version){const mt=H.image;if(mt===null)ve("WebGLRenderer: Texture marked for update but no image data found.");else if(mt.complete===!1)ve("WebGLRenderer: Texture marked for update but image is incomplete");else{Ht(at,H,A);return}}else H.isExternalTexture&&(at.__webglTexture=H.sourceTexture?H.sourceTexture:null);n.bindTexture(r.TEXTURE_2D,at.__webglTexture,r.TEXTURE0+A)}function dt(H,A){const at=a.get(H);if(H.isRenderTargetTexture===!1&&H.version>0&&at.__version!==H.version){Ht(at,H,A);return}else H.isExternalTexture&&(at.__webglTexture=H.sourceTexture?H.sourceTexture:null);n.bindTexture(r.TEXTURE_2D_ARRAY,at.__webglTexture,r.TEXTURE0+A)}function pt(H,A){const at=a.get(H);if(H.isRenderTargetTexture===!1&&H.version>0&&at.__version!==H.version){Ht(at,H,A);return}n.bindTexture(r.TEXTURE_3D,at.__webglTexture,r.TEXTURE0+A)}function I(H,A){const at=a.get(H);if(H.isCubeDepthTexture!==!0&&H.version>0&&at.__version!==H.version){ie(at,H,A);return}n.bindTexture(r.TEXTURE_CUBE_MAP,at.__webglTexture,r.TEXTURE0+A)}const ct={[Va]:r.REPEAT,[Ba]:r.CLAMP_TO_EDGE,[Yd]:r.MIRRORED_REPEAT},At={[Qn]:r.NEAREST,[Zy]:r.NEAREST_MIPMAP_NEAREST,[Wc]:r.NEAREST_MIPMAP_LINEAR,[Xn]:r.LINEAR,[ad]:r.LINEAR_MIPMAP_NEAREST,[Ks]:r.LINEAR_MIPMAP_LINEAR},It={[jy]:r.NEVER,[i1]:r.ALWAYS,[$y]:r.LESS,[Xp]:r.LEQUAL,[t1]:r.EQUAL,[Wp]:r.GEQUAL,[e1]:r.GREATER,[n1]:r.NOTEQUAL};function kt(H,A){if(A.type===Ji&&t.has("OES_texture_float_linear")===!1&&(A.magFilter===Xn||A.magFilter===ad||A.magFilter===Wc||A.magFilter===Ks||A.minFilter===Xn||A.minFilter===ad||A.minFilter===Wc||A.minFilter===Ks)&&ve("WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),r.texParameteri(H,r.TEXTURE_WRAP_S,ct[A.wrapS]),r.texParameteri(H,r.TEXTURE_WRAP_T,ct[A.wrapT]),(H===r.TEXTURE_3D||H===r.TEXTURE_2D_ARRAY)&&r.texParameteri(H,r.TEXTURE_WRAP_R,ct[A.wrapR]),r.texParameteri(H,r.TEXTURE_MAG_FILTER,At[A.magFilter]),r.texParameteri(H,r.TEXTURE_MIN_FILTER,At[A.minFilter]),A.compareFunction&&(r.texParameteri(H,r.TEXTURE_COMPARE_MODE,r.COMPARE_REF_TO_TEXTURE),r.texParameteri(H,r.TEXTURE_COMPARE_FUNC,It[A.compareFunction])),t.has("EXT_texture_filter_anisotropic")===!0){if(A.magFilter===Qn||A.minFilter!==Wc&&A.minFilter!==Ks||A.type===Ji&&t.has("OES_texture_float_linear")===!1)return;if(A.anisotropy>1||a.get(A).__currentAnisotropy){const at=t.get("EXT_texture_filter_anisotropic");r.texParameterf(H,at.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(A.anisotropy,o.getMaxAnisotropy())),a.get(A).__currentAnisotropy=A.anisotropy}}}function zt(H,A){let at=!1;H.__webglInit===void 0&&(H.__webglInit=!0,A.addEventListener("dispose",P));const mt=A.source;let bt=x.get(mt);bt===void 0&&(bt={},x.set(mt,bt));const Bt=Z(A);if(Bt!==H.__cacheKey){bt[Bt]===void 0&&(bt[Bt]={texture:r.createTexture(),usedTimes:0},u.memory.textures++,at=!0),bt[Bt].usedTimes++;const Ft=bt[H.__cacheKey];Ft!==void 0&&(bt[H.__cacheKey].usedTimes--,Ft.usedTimes===0&&W(A)),H.__cacheKey=Bt,H.__webglTexture=bt[Bt].texture}return at}function ut(H,A,at){return Math.floor(Math.floor(H/at)/A)}function Tt(H,A,at,mt){const Bt=H.updateRanges;if(Bt.length===0)n.texSubImage2D(r.TEXTURE_2D,0,0,0,A.width,A.height,at,mt,A.data);else{Bt.sort((Xt,Wt)=>Xt.start-Wt.start);let Ft=0;for(let Xt=1;Xt<Bt.length;Xt++){const Wt=Bt[Ft],ot=Bt[Xt],G=Wt.start+Wt.count,Y=ut(ot.start,A.width,4),nt=ut(Wt.start,A.width,4);ot.start<=G+1&&Y===nt&&ut(ot.start+ot.count-1,A.width,4)===Y?Wt.count=Math.max(Wt.count,ot.start+ot.count-Wt.start):(++Ft,Bt[Ft]=ot)}Bt.length=Ft+1;const Mt=n.getParameter(r.UNPACK_ROW_LENGTH),St=n.getParameter(r.UNPACK_SKIP_PIXELS),Ot=n.getParameter(r.UNPACK_SKIP_ROWS);n.pixelStorei(r.UNPACK_ROW_LENGTH,A.width);for(let Xt=0,Wt=Bt.length;Xt<Wt;Xt++){const ot=Bt[Xt],G=Math.floor(ot.start/4),Y=Math.ceil(ot.count/4),nt=G%A.width,w=Math.floor(G/A.width),V=Y,X=1;n.pixelStorei(r.UNPACK_SKIP_PIXELS,nt),n.pixelStorei(r.UNPACK_SKIP_ROWS,w),n.texSubImage2D(r.TEXTURE_2D,0,nt,w,V,X,at,mt,A.data)}H.clearUpdateRanges(),n.pixelStorei(r.UNPACK_ROW_LENGTH,Mt),n.pixelStorei(r.UNPACK_SKIP_PIXELS,St),n.pixelStorei(r.UNPACK_SKIP_ROWS,Ot)}}function Ht(H,A,at){let mt=r.TEXTURE_2D;(A.isDataArrayTexture||A.isCompressedArrayTexture)&&(mt=r.TEXTURE_2D_ARRAY),A.isData3DTexture&&(mt=r.TEXTURE_3D);const bt=zt(H,A),Bt=A.source;n.bindTexture(mt,H.__webglTexture,r.TEXTURE0+at);const Ft=a.get(Bt);if(Bt.version!==Ft.__version||bt===!0){if(n.activeTexture(r.TEXTURE0+at),(typeof ImageBitmap<"u"&&A.image instanceof ImageBitmap)===!1){const X=Ve.getPrimaries(Ve.workingColorSpace),st=A.colorSpace===Ia?null:Ve.getPrimaries(A.colorSpace),rt=A.colorSpace===Ia||X===st?r.NONE:r.BROWSER_DEFAULT_WEBGL;n.pixelStorei(r.UNPACK_FLIP_Y_WEBGL,A.flipY),n.pixelStorei(r.UNPACK_PREMULTIPLY_ALPHA_WEBGL,A.premultiplyAlpha),n.pixelStorei(r.UNPACK_COLORSPACE_CONVERSION_WEBGL,rt)}n.pixelStorei(r.UNPACK_ALIGNMENT,A.unpackAlignment);let St=M(A.image,!1,o.maxTextureSize);St=_e(A,St);const Ot=c.convert(A.format,A.colorSpace),Xt=c.convert(A.type);let Wt=E(A.internalFormat,Ot,Xt,A.normalized,A.colorSpace,A.isVideoTexture);kt(mt,A);let ot;const G=A.mipmaps,Y=A.isVideoTexture!==!0,nt=Ft.__version===void 0||bt===!0,w=Bt.dataReady,V=L(A,St);if(A.isDepthTexture)Wt=U(A.format===Js,A.type),nt&&(Y?n.texStorage2D(r.TEXTURE_2D,1,Wt,St.width,St.height):n.texImage2D(r.TEXTURE_2D,0,Wt,St.width,St.height,0,Ot,Xt,null));else if(A.isDataTexture)if(G.length>0){Y&&nt&&n.texStorage2D(r.TEXTURE_2D,V,Wt,G[0].width,G[0].height);for(let X=0,st=G.length;X<st;X++)ot=G[X],Y?w&&n.texSubImage2D(r.TEXTURE_2D,X,0,0,ot.width,ot.height,Ot,Xt,ot.data):n.texImage2D(r.TEXTURE_2D,X,Wt,ot.width,ot.height,0,Ot,Xt,ot.data);A.generateMipmaps=!1}else Y?(nt&&n.texStorage2D(r.TEXTURE_2D,V,Wt,St.width,St.height),w&&Tt(A,St,Ot,Xt)):n.texImage2D(r.TEXTURE_2D,0,Wt,St.width,St.height,0,Ot,Xt,St.data);else if(A.isCompressedTexture)if(A.isCompressedArrayTexture){Y&&nt&&n.texStorage3D(r.TEXTURE_2D_ARRAY,V,Wt,G[0].width,G[0].height,St.depth);for(let X=0,st=G.length;X<st;X++)if(ot=G[X],A.format!==Qi)if(Ot!==null)if(Y){if(w)if(A.layerUpdates.size>0){const rt=V_(ot.width,ot.height,A.format,A.type);for(const it of A.layerUpdates){const Ct=ot.data.subarray(it*rt/ot.data.BYTES_PER_ELEMENT,(it+1)*rt/ot.data.BYTES_PER_ELEMENT);n.compressedTexSubImage3D(r.TEXTURE_2D_ARRAY,X,0,0,it,ot.width,ot.height,1,Ot,Ct)}}else n.compressedTexSubImage3D(r.TEXTURE_2D_ARRAY,X,0,0,0,ot.width,ot.height,St.depth,Ot,ot.data)}else n.compressedTexImage3D(r.TEXTURE_2D_ARRAY,X,Wt,ot.width,ot.height,St.depth,0,ot.data,0,0);else ve("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else Y?w&&n.texSubImage3D(r.TEXTURE_2D_ARRAY,X,0,0,0,ot.width,ot.height,St.depth,Ot,Xt,ot.data):n.texImage3D(r.TEXTURE_2D_ARRAY,X,Wt,ot.width,ot.height,St.depth,0,Ot,Xt,ot.data);A.layerUpdates.size>0&&A.clearLayerUpdates()}else{Y&&nt&&n.texStorage2D(r.TEXTURE_2D,V,Wt,G[0].width,G[0].height);for(let X=0,st=G.length;X<st;X++)ot=G[X],A.format!==Qi?Ot!==null?Y?w&&n.compressedTexSubImage2D(r.TEXTURE_2D,X,0,0,ot.width,ot.height,Ot,ot.data):n.compressedTexImage2D(r.TEXTURE_2D,X,Wt,ot.width,ot.height,0,ot.data):ve("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):Y?w&&n.texSubImage2D(r.TEXTURE_2D,X,0,0,ot.width,ot.height,Ot,Xt,ot.data):n.texImage2D(r.TEXTURE_2D,X,Wt,ot.width,ot.height,0,Ot,Xt,ot.data)}else if(A.isDataArrayTexture)if(Y){if(nt&&n.texStorage3D(r.TEXTURE_2D_ARRAY,V,Wt,St.width,St.height,St.depth),w)if(A.layerUpdates.size>0){const X=V_(St.width,St.height,A.format,A.type);for(const st of A.layerUpdates){const rt=St.data.subarray(st*X/St.data.BYTES_PER_ELEMENT,(st+1)*X/St.data.BYTES_PER_ELEMENT);n.texSubImage3D(r.TEXTURE_2D_ARRAY,0,0,0,st,St.width,St.height,1,Ot,Xt,rt)}A.clearLayerUpdates()}else n.texSubImage3D(r.TEXTURE_2D_ARRAY,0,0,0,0,St.width,St.height,St.depth,Ot,Xt,St.data)}else n.texImage3D(r.TEXTURE_2D_ARRAY,0,Wt,St.width,St.height,St.depth,0,Ot,Xt,St.data);else if(A.isData3DTexture)Y?(nt&&n.texStorage3D(r.TEXTURE_3D,V,Wt,St.width,St.height,St.depth),w&&n.texSubImage3D(r.TEXTURE_3D,0,0,0,0,St.width,St.height,St.depth,Ot,Xt,St.data)):n.texImage3D(r.TEXTURE_3D,0,Wt,St.width,St.height,St.depth,0,Ot,Xt,St.data);else if(A.isFramebufferTexture){if(nt)if(Y)n.texStorage2D(r.TEXTURE_2D,V,Wt,St.width,St.height);else{let X=St.width,st=St.height;for(let rt=0;rt<V;rt++)n.texImage2D(r.TEXTURE_2D,rt,Wt,X,st,0,Ot,Xt,null),X>>=1,st>>=1}}else if(A.isHTMLTexture){if("texElementImage2D"in r){const X=r.canvas;if(X.hasAttribute("layoutsubtree")||X.setAttribute("layoutsubtree","true"),St.parentNode!==X){X.appendChild(St),_.add(A),X.onpaint=st=>{const rt=st.changedElements;for(const it of _)rt.includes(it.image)&&(it.needsUpdate=!0)},X.requestPaint();return}if(r.texElementImage2D.length===3)r.texElementImage2D(r.TEXTURE_2D,r.RGBA8,St);else{const rt=r.RGBA,it=r.RGBA,Ct=r.UNSIGNED_BYTE;r.texElementImage2D(r.TEXTURE_2D,0,rt,it,Ct,St)}r.texParameteri(r.TEXTURE_2D,r.TEXTURE_MIN_FILTER,r.LINEAR),r.texParameteri(r.TEXTURE_2D,r.TEXTURE_WRAP_S,r.CLAMP_TO_EDGE),r.texParameteri(r.TEXTURE_2D,r.TEXTURE_WRAP_T,r.CLAMP_TO_EDGE)}}else if(G.length>0){if(Y&&nt){const X=Ee(G[0]);n.texStorage2D(r.TEXTURE_2D,V,Wt,X.width,X.height)}for(let X=0,st=G.length;X<st;X++)ot=G[X],Y?w&&n.texSubImage2D(r.TEXTURE_2D,X,0,0,Ot,Xt,ot):n.texImage2D(r.TEXTURE_2D,X,Wt,Ot,Xt,ot);A.generateMipmaps=!1}else if(Y){if(nt){const X=Ee(St);n.texStorage2D(r.TEXTURE_2D,V,Wt,X.width,X.height)}w&&n.texSubImage2D(r.TEXTURE_2D,0,0,0,Ot,Xt,St)}else n.texImage2D(r.TEXTURE_2D,0,Wt,Ot,Xt,St);S(A)&&C(mt),Ft.__version=Bt.version,A.onUpdate&&A.onUpdate(A)}H.__version=A.version}function ie(H,A,at){if(A.image.length!==6)return;const mt=zt(H,A),bt=A.source;n.bindTexture(r.TEXTURE_CUBE_MAP,H.__webglTexture,r.TEXTURE0+at);const Bt=a.get(bt);if(bt.version!==Bt.__version||mt===!0){n.activeTexture(r.TEXTURE0+at);const Ft=Ve.getPrimaries(Ve.workingColorSpace),Mt=A.colorSpace===Ia?null:Ve.getPrimaries(A.colorSpace),St=A.colorSpace===Ia||Ft===Mt?r.NONE:r.BROWSER_DEFAULT_WEBGL;n.pixelStorei(r.UNPACK_FLIP_Y_WEBGL,A.flipY),n.pixelStorei(r.UNPACK_PREMULTIPLY_ALPHA_WEBGL,A.premultiplyAlpha),n.pixelStorei(r.UNPACK_ALIGNMENT,A.unpackAlignment),n.pixelStorei(r.UNPACK_COLORSPACE_CONVERSION_WEBGL,St);const Ot=A.isCompressedTexture||A.image[0].isCompressedTexture,Xt=A.image[0]&&A.image[0].isDataTexture,Wt=[];for(let it=0;it<6;it++)!Ot&&!Xt?Wt[it]=M(A.image[it],!0,o.maxCubemapSize):Wt[it]=Xt?A.image[it].image:A.image[it],Wt[it]=_e(A,Wt[it]);const ot=Wt[0],G=c.convert(A.format,A.colorSpace),Y=c.convert(A.type),nt=E(A.internalFormat,G,Y,A.normalized,A.colorSpace),w=A.isVideoTexture!==!0,V=Bt.__version===void 0||mt===!0,X=bt.dataReady;let st=L(A,ot);kt(r.TEXTURE_CUBE_MAP,A);let rt;if(Ot){w&&V&&n.texStorage2D(r.TEXTURE_CUBE_MAP,st,nt,ot.width,ot.height);for(let it=0;it<6;it++){rt=Wt[it].mipmaps;for(let Ct=0;Ct<rt.length;Ct++){const Pt=rt[Ct];A.format!==Qi?G!==null?w?X&&n.compressedTexSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+it,Ct,0,0,Pt.width,Pt.height,G,Pt.data):n.compressedTexImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+it,Ct,nt,Pt.width,Pt.height,0,Pt.data):ve("WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):w?X&&n.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+it,Ct,0,0,Pt.width,Pt.height,G,Y,Pt.data):n.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+it,Ct,nt,Pt.width,Pt.height,0,G,Y,Pt.data)}}}else{if(rt=A.mipmaps,w&&V){rt.length>0&&st++;const it=Ee(Wt[0]);n.texStorage2D(r.TEXTURE_CUBE_MAP,st,nt,it.width,it.height)}for(let it=0;it<6;it++)if(Xt){w?X&&n.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+it,0,0,0,Wt[it].width,Wt[it].height,G,Y,Wt[it].data):n.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+it,0,nt,Wt[it].width,Wt[it].height,0,G,Y,Wt[it].data);for(let Ct=0;Ct<rt.length;Ct++){const lt=rt[Ct].image[it].image;w?X&&n.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+it,Ct+1,0,0,lt.width,lt.height,G,Y,lt.data):n.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+it,Ct+1,nt,lt.width,lt.height,0,G,Y,lt.data)}}else{w?X&&n.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+it,0,0,0,G,Y,Wt[it]):n.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+it,0,nt,G,Y,Wt[it]);for(let Ct=0;Ct<rt.length;Ct++){const Pt=rt[Ct];w?X&&n.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+it,Ct+1,0,0,G,Y,Pt.image[it]):n.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+it,Ct+1,nt,G,Y,Pt.image[it])}}}S(A)&&C(r.TEXTURE_CUBE_MAP),Bt.__version=bt.version,A.onUpdate&&A.onUpdate(A)}H.__version=A.version}function qt(H,A,at,mt,bt,Bt){const Ft=c.convert(at.format,at.colorSpace),Mt=c.convert(at.type),St=E(at.internalFormat,Ft,Mt,at.normalized,at.colorSpace),Ot=a.get(A),Xt=a.get(at);if(Xt.__renderTarget=A,!Ot.__hasExternalTextures){const Wt=Math.max(1,A.width>>Bt),ot=Math.max(1,A.height>>Bt);bt===r.TEXTURE_3D||bt===r.TEXTURE_2D_ARRAY?n.texImage3D(bt,Bt,St,Wt,ot,A.depth,0,Ft,Mt,null):n.texImage2D(bt,Bt,St,Wt,ot,0,Ft,Mt,null)}n.bindFramebuffer(r.FRAMEBUFFER,H),Se(A)?h.framebufferTexture2DMultisampleEXT(r.FRAMEBUFFER,mt,bt,Xt.__webglTexture,0,ne(A)):(bt===r.TEXTURE_2D||bt>=r.TEXTURE_CUBE_MAP_POSITIVE_X&&bt<=r.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&r.framebufferTexture2D(r.FRAMEBUFFER,mt,bt,Xt.__webglTexture,Bt),n.bindFramebuffer(r.FRAMEBUFFER,null)}function re(H,A,at){if(r.bindRenderbuffer(r.RENDERBUFFER,H),A.depthBuffer){const mt=A.depthTexture,bt=mt&&mt.isDepthTexture?mt.type:null,Bt=U(A.stencilBuffer,bt),Ft=A.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT;Se(A)?h.renderbufferStorageMultisampleEXT(r.RENDERBUFFER,ne(A),Bt,A.width,A.height):at?r.renderbufferStorageMultisample(r.RENDERBUFFER,ne(A),Bt,A.width,A.height):r.renderbufferStorage(r.RENDERBUFFER,Bt,A.width,A.height),r.framebufferRenderbuffer(r.FRAMEBUFFER,Ft,r.RENDERBUFFER,H)}else{const mt=A.textures;for(let bt=0;bt<mt.length;bt++){const Bt=mt[bt],Ft=c.convert(Bt.format,Bt.colorSpace),Mt=c.convert(Bt.type),St=E(Bt.internalFormat,Ft,Mt,Bt.normalized,Bt.colorSpace);Se(A)?h.renderbufferStorageMultisampleEXT(r.RENDERBUFFER,ne(A),St,A.width,A.height):at?r.renderbufferStorageMultisample(r.RENDERBUFFER,ne(A),St,A.width,A.height):r.renderbufferStorage(r.RENDERBUFFER,St,A.width,A.height)}}r.bindRenderbuffer(r.RENDERBUFFER,null)}function Fe(H,A,at){const mt=A.isWebGLCubeRenderTarget===!0;if(n.bindFramebuffer(r.FRAMEBUFFER,H),!(A.depthTexture&&A.depthTexture.isDepthTexture))throw new Error("THREE.WebGLTextures: renderTarget.depthTexture must be an instance of THREE.DepthTexture.");const bt=a.get(A.depthTexture);if(bt.__renderTarget=A,(!bt.__webglTexture||A.depthTexture.image.width!==A.width||A.depthTexture.image.height!==A.height)&&(A.depthTexture.image.width=A.width,A.depthTexture.image.height=A.height,A.depthTexture.needsUpdate=!0),mt){if(bt.__webglInit===void 0&&(bt.__webglInit=!0,A.depthTexture.addEventListener("dispose",P)),bt.__webglTexture===void 0){bt.__webglTexture=r.createTexture(),n.bindTexture(r.TEXTURE_CUBE_MAP,bt.__webglTexture),kt(r.TEXTURE_CUBE_MAP,A.depthTexture);const Ot=c.convert(A.depthTexture.format),Xt=c.convert(A.depthTexture.type);let Wt;A.depthTexture.format===ka?Wt=r.DEPTH_COMPONENT24:A.depthTexture.format===Js&&(Wt=r.DEPTH24_STENCIL8);for(let ot=0;ot<6;ot++)r.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+ot,0,Wt,A.width,A.height,0,Ot,Xt,null)}}else ht(A.depthTexture,0);const Bt=bt.__webglTexture,Ft=ne(A),Mt=mt?r.TEXTURE_CUBE_MAP_POSITIVE_X+at:r.TEXTURE_2D,St=A.depthTexture.format===Js?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT;if(A.depthTexture.format===ka)Se(A)?h.framebufferTexture2DMultisampleEXT(r.FRAMEBUFFER,St,Mt,Bt,0,Ft):r.framebufferTexture2D(r.FRAMEBUFFER,St,Mt,Bt,0);else if(A.depthTexture.format===Js)Se(A)?h.framebufferTexture2DMultisampleEXT(r.FRAMEBUFFER,St,Mt,Bt,0,Ft):r.framebufferTexture2D(r.FRAMEBUFFER,St,Mt,Bt,0);else throw new Error("THREE.WebGLTextures: Unknown depthTexture format.")}function ee(H){const A=a.get(H),at=H.isWebGLCubeRenderTarget===!0;if(A.__boundDepthTexture!==H.depthTexture){const mt=H.depthTexture;if(A.__depthDisposeCallback&&A.__depthDisposeCallback(),mt){const bt=()=>{delete A.__boundDepthTexture,delete A.__depthDisposeCallback,mt.removeEventListener("dispose",bt)};mt.addEventListener("dispose",bt),A.__depthDisposeCallback=bt}A.__boundDepthTexture=mt}if(H.depthTexture&&!A.__autoAllocateDepthBuffer)if(at)for(let mt=0;mt<6;mt++)Fe(A.__webglFramebuffer[mt],H,mt);else{const mt=H.texture.mipmaps;mt&&mt.length>0?Fe(A.__webglFramebuffer[0],H,0):Fe(A.__webglFramebuffer,H,0)}else if(at){A.__webglDepthbuffer=[];for(let mt=0;mt<6;mt++)if(n.bindFramebuffer(r.FRAMEBUFFER,A.__webglFramebuffer[mt]),A.__webglDepthbuffer[mt]===void 0)A.__webglDepthbuffer[mt]=r.createRenderbuffer(),re(A.__webglDepthbuffer[mt],H,!1);else{const bt=H.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT,Bt=A.__webglDepthbuffer[mt];r.bindRenderbuffer(r.RENDERBUFFER,Bt),r.framebufferRenderbuffer(r.FRAMEBUFFER,bt,r.RENDERBUFFER,Bt)}}else{const mt=H.texture.mipmaps;if(mt&&mt.length>0?n.bindFramebuffer(r.FRAMEBUFFER,A.__webglFramebuffer[0]):n.bindFramebuffer(r.FRAMEBUFFER,A.__webglFramebuffer),A.__webglDepthbuffer===void 0)A.__webglDepthbuffer=r.createRenderbuffer(),re(A.__webglDepthbuffer,H,!1);else{const bt=H.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT,Bt=A.__webglDepthbuffer;r.bindRenderbuffer(r.RENDERBUFFER,Bt),r.framebufferRenderbuffer(r.FRAMEBUFFER,bt,r.RENDERBUFFER,Bt)}}n.bindFramebuffer(r.FRAMEBUFFER,null)}function de(H,A,at){const mt=a.get(H);A!==void 0&&qt(mt.__webglFramebuffer,H,H.texture,r.COLOR_ATTACHMENT0,r.TEXTURE_2D,0),at!==void 0&&ee(H)}function xe(H){const A=H.texture,at=a.get(H),mt=a.get(A);H.addEventListener("dispose",T);const bt=H.textures,Bt=H.isWebGLCubeRenderTarget===!0,Ft=bt.length>1;if(Ft||(mt.__webglTexture===void 0&&(mt.__webglTexture=r.createTexture()),mt.__version=A.version,u.memory.textures++),Bt){at.__webglFramebuffer=[];for(let Mt=0;Mt<6;Mt++)if(A.mipmaps&&A.mipmaps.length>0){at.__webglFramebuffer[Mt]=[];for(let St=0;St<A.mipmaps.length;St++)at.__webglFramebuffer[Mt][St]=r.createFramebuffer()}else at.__webglFramebuffer[Mt]=r.createFramebuffer()}else{if(A.mipmaps&&A.mipmaps.length>0){at.__webglFramebuffer=[];for(let Mt=0;Mt<A.mipmaps.length;Mt++)at.__webglFramebuffer[Mt]=r.createFramebuffer()}else at.__webglFramebuffer=r.createFramebuffer();if(Ft)for(let Mt=0,St=bt.length;Mt<St;Mt++){const Ot=a.get(bt[Mt]);Ot.__webglTexture===void 0&&(Ot.__webglTexture=r.createTexture(),u.memory.textures++)}if(H.samples>0&&Se(H)===!1){at.__webglMultisampledFramebuffer=r.createFramebuffer(),at.__webglColorRenderbuffer=[],n.bindFramebuffer(r.FRAMEBUFFER,at.__webglMultisampledFramebuffer);for(let Mt=0;Mt<bt.length;Mt++){const St=bt[Mt];at.__webglColorRenderbuffer[Mt]=r.createRenderbuffer(),r.bindRenderbuffer(r.RENDERBUFFER,at.__webglColorRenderbuffer[Mt]);const Ot=c.convert(St.format,St.colorSpace),Xt=c.convert(St.type),Wt=E(St.internalFormat,Ot,Xt,St.normalized,St.colorSpace,H.isXRRenderTarget===!0),ot=ne(H);r.renderbufferStorageMultisample(r.RENDERBUFFER,ot,Wt,H.width,H.height),r.framebufferRenderbuffer(r.FRAMEBUFFER,r.COLOR_ATTACHMENT0+Mt,r.RENDERBUFFER,at.__webglColorRenderbuffer[Mt])}r.bindRenderbuffer(r.RENDERBUFFER,null),H.depthBuffer&&(at.__webglDepthRenderbuffer=r.createRenderbuffer(),re(at.__webglDepthRenderbuffer,H,!0)),n.bindFramebuffer(r.FRAMEBUFFER,null)}}if(Bt){n.bindTexture(r.TEXTURE_CUBE_MAP,mt.__webglTexture),kt(r.TEXTURE_CUBE_MAP,A);for(let Mt=0;Mt<6;Mt++)if(A.mipmaps&&A.mipmaps.length>0)for(let St=0;St<A.mipmaps.length;St++)qt(at.__webglFramebuffer[Mt][St],H,A,r.COLOR_ATTACHMENT0,r.TEXTURE_CUBE_MAP_POSITIVE_X+Mt,St);else qt(at.__webglFramebuffer[Mt],H,A,r.COLOR_ATTACHMENT0,r.TEXTURE_CUBE_MAP_POSITIVE_X+Mt,0);S(A)&&C(r.TEXTURE_CUBE_MAP),n.unbindTexture()}else if(Ft){for(let Mt=0,St=bt.length;Mt<St;Mt++){const Ot=bt[Mt],Xt=a.get(Ot);let Wt=r.TEXTURE_2D;(H.isWebGL3DRenderTarget||H.isWebGLArrayRenderTarget)&&(Wt=H.isWebGL3DRenderTarget?r.TEXTURE_3D:r.TEXTURE_2D_ARRAY),n.bindTexture(Wt,Xt.__webglTexture),kt(Wt,Ot),qt(at.__webglFramebuffer,H,Ot,r.COLOR_ATTACHMENT0+Mt,Wt,0),S(Ot)&&C(Wt)}n.unbindTexture()}else{let Mt=r.TEXTURE_2D;if((H.isWebGL3DRenderTarget||H.isWebGLArrayRenderTarget)&&(Mt=H.isWebGL3DRenderTarget?r.TEXTURE_3D:r.TEXTURE_2D_ARRAY),n.bindTexture(Mt,mt.__webglTexture),kt(Mt,A),A.mipmaps&&A.mipmaps.length>0)for(let St=0;St<A.mipmaps.length;St++)qt(at.__webglFramebuffer[St],H,A,r.COLOR_ATTACHMENT0,Mt,St);else qt(at.__webglFramebuffer,H,A,r.COLOR_ATTACHMENT0,Mt,0);S(A)&&C(Mt),n.unbindTexture()}H.depthBuffer&&ee(H)}function fe(H){const A=H.textures;for(let at=0,mt=A.length;at<mt;at++){const bt=A[at];if(S(bt)){const Bt=O(H),Ft=a.get(bt).__webglTexture;n.bindTexture(Bt,Ft),C(Bt),n.unbindTexture()}}}const be=[],ke=[];function ze(H){if(H.samples>0){if(Se(H)===!1){const A=H.textures,at=H.width,mt=H.height;let bt=r.COLOR_BUFFER_BIT;const Bt=H.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT,Ft=a.get(H),Mt=A.length>1;if(Mt)for(let Ot=0;Ot<A.length;Ot++)n.bindFramebuffer(r.FRAMEBUFFER,Ft.__webglMultisampledFramebuffer),r.framebufferRenderbuffer(r.FRAMEBUFFER,r.COLOR_ATTACHMENT0+Ot,r.RENDERBUFFER,null),n.bindFramebuffer(r.FRAMEBUFFER,Ft.__webglFramebuffer),r.framebufferTexture2D(r.DRAW_FRAMEBUFFER,r.COLOR_ATTACHMENT0+Ot,r.TEXTURE_2D,null,0);n.bindFramebuffer(r.READ_FRAMEBUFFER,Ft.__webglMultisampledFramebuffer);const St=H.texture.mipmaps;St&&St.length>0?n.bindFramebuffer(r.DRAW_FRAMEBUFFER,Ft.__webglFramebuffer[0]):n.bindFramebuffer(r.DRAW_FRAMEBUFFER,Ft.__webglFramebuffer);for(let Ot=0;Ot<A.length;Ot++){if(H.resolveDepthBuffer&&(H.depthBuffer&&(bt|=r.DEPTH_BUFFER_BIT),H.stencilBuffer&&H.resolveStencilBuffer&&(bt|=r.STENCIL_BUFFER_BIT)),Mt){r.framebufferRenderbuffer(r.READ_FRAMEBUFFER,r.COLOR_ATTACHMENT0,r.RENDERBUFFER,Ft.__webglColorRenderbuffer[Ot]);const Xt=a.get(A[Ot]).__webglTexture;r.framebufferTexture2D(r.DRAW_FRAMEBUFFER,r.COLOR_ATTACHMENT0,r.TEXTURE_2D,Xt,0)}r.blitFramebuffer(0,0,at,mt,0,0,at,mt,bt,r.NEAREST),m===!0&&(be.length=0,ke.length=0,be.push(r.COLOR_ATTACHMENT0+Ot),H.depthBuffer&&H.storeMultisampledDepthBuffer===!1&&(be.push(Bt),ke.push(Bt),r.invalidateFramebuffer(r.DRAW_FRAMEBUFFER,ke)),r.invalidateFramebuffer(r.READ_FRAMEBUFFER,be))}if(n.bindFramebuffer(r.READ_FRAMEBUFFER,null),n.bindFramebuffer(r.DRAW_FRAMEBUFFER,null),Mt)for(let Ot=0;Ot<A.length;Ot++){n.bindFramebuffer(r.FRAMEBUFFER,Ft.__webglMultisampledFramebuffer),r.framebufferRenderbuffer(r.FRAMEBUFFER,r.COLOR_ATTACHMENT0+Ot,r.RENDERBUFFER,Ft.__webglColorRenderbuffer[Ot]);const Xt=a.get(A[Ot]).__webglTexture;n.bindFramebuffer(r.FRAMEBUFFER,Ft.__webglFramebuffer),r.framebufferTexture2D(r.DRAW_FRAMEBUFFER,r.COLOR_ATTACHMENT0+Ot,r.TEXTURE_2D,Xt,0)}n.bindFramebuffer(r.DRAW_FRAMEBUFFER,Ft.__webglMultisampledFramebuffer)}else if(H.depthBuffer&&H.storeMultisampledDepthBuffer===!1&&m){const A=H.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT;r.invalidateFramebuffer(r.DRAW_FRAMEBUFFER,[A])}}}function ne(H){return Math.min(o.maxSamples,H.samples)}function Se(H){const A=a.get(H);return H.samples>0&&t.has("WEBGL_multisampled_render_to_texture")===!0&&A.__useRenderToTexture!==!1}function j(H){const A=u.render.frame;g.get(H)!==A&&(g.set(H,A),H.update())}function _e(H,A){const at=H.colorSpace,mt=H.format,bt=H.type;return H.isCompressedTexture===!0||H.isVideoTexture===!0||at!==Ru&&at!==Ia&&(Ve.getTransfer(at)===nn?(mt!==Qi||bt!==Ti)&&ve("WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):We("WebGLTextures: Unsupported texture color space:",at)),A}function Ee(H){return typeof HTMLImageElement<"u"&&H instanceof HTMLImageElement?(p.width=H.naturalWidth||H.width,p.height=H.naturalHeight||H.height):typeof VideoFrame<"u"&&H instanceof VideoFrame?(p.width=H.displayWidth,p.height=H.displayHeight):(p.width=H.width,p.height=H.height),p}this.allocateTextureUnit=F,this.resetTextureUnits=et,this.getTextureUnits=k,this.setTextureUnits=q,this.setTexture2D=ht,this.setTexture2DArray=dt,this.setTexture3D=pt,this.setTextureCube=I,this.rebindTextures=de,this.setupRenderTarget=xe,this.updateRenderTargetMipmap=fe,this.updateMultisampleRenderTarget=ze,this.setupDepthRenderbuffer=ee,this.setupFrameBufferTexture=qt,this.useMultisampledRTT=Se,this.isReversedDepthBuffer=function(){return n.buffers.depth.getReversed()}}function E3(r,t){function n(a,o=Ia){let c;const u=Ve.getTransfer(o);if(a===Ti)return r.UNSIGNED_BYTE;if(a===Bp)return r.UNSIGNED_SHORT_4_4_4_4;if(a===Fp)return r.UNSIGNED_SHORT_5_5_5_1;if(a===Rx)return r.UNSIGNED_INT_5_9_9_9_REV;if(a===Cx)return r.UNSIGNED_INT_10F_11F_11F_REV;if(a===Ax)return r.BYTE;if(a===wx)return r.SHORT;if(a===El)return r.UNSIGNED_SHORT;if(a===Ip)return r.INT;if(a===ua)return r.UNSIGNED_INT;if(a===Ji)return r.FLOAT;if(a===$i)return r.HALF_FLOAT;if(a===Dx)return r.ALPHA;if(a===Ux)return r.RGB;if(a===Qi)return r.RGBA;if(a===ka)return r.DEPTH_COMPONENT;if(a===Js)return r.DEPTH_STENCIL;if(a===Hp)return r.RED;if(a===Gp)return r.RED_INTEGER;if(a===er)return r.RG;if(a===Vp)return r.RG_INTEGER;if(a===kp)return r.RGBA_INTEGER;if(a===Mu||a===yu||a===bu||a===Eu)if(u===nn)if(c=t.get("WEBGL_compressed_texture_s3tc_srgb"),c!==null){if(a===Mu)return c.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(a===yu)return c.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(a===bu)return c.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(a===Eu)return c.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(c=t.get("WEBGL_compressed_texture_s3tc"),c!==null){if(a===Mu)return c.COMPRESSED_RGB_S3TC_DXT1_EXT;if(a===yu)return c.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(a===bu)return c.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(a===Eu)return c.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(a===Zd||a===Kd||a===Jd||a===Qd)if(c=t.get("WEBGL_compressed_texture_pvrtc"),c!==null){if(a===Zd)return c.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(a===Kd)return c.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(a===Jd)return c.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(a===Qd)return c.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(a===jd||a===$d||a===tp||a===ep||a===np||a===Au||a===ip)if(c=t.get("WEBGL_compressed_texture_etc"),c!==null){if(a===jd||a===$d)return u===nn?c.COMPRESSED_SRGB8_ETC2:c.COMPRESSED_RGB8_ETC2;if(a===tp)return u===nn?c.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:c.COMPRESSED_RGBA8_ETC2_EAC;if(a===ep)return c.COMPRESSED_R11_EAC;if(a===np)return c.COMPRESSED_SIGNED_R11_EAC;if(a===Au)return c.COMPRESSED_RG11_EAC;if(a===ip)return c.COMPRESSED_SIGNED_RG11_EAC}else return null;if(a===ap||a===sp||a===rp||a===op||a===lp||a===cp||a===up||a===fp||a===hp||a===dp||a===pp||a===mp||a===gp||a===vp)if(c=t.get("WEBGL_compressed_texture_astc"),c!==null){if(a===ap)return u===nn?c.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:c.COMPRESSED_RGBA_ASTC_4x4_KHR;if(a===sp)return u===nn?c.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:c.COMPRESSED_RGBA_ASTC_5x4_KHR;if(a===rp)return u===nn?c.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:c.COMPRESSED_RGBA_ASTC_5x5_KHR;if(a===op)return u===nn?c.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:c.COMPRESSED_RGBA_ASTC_6x5_KHR;if(a===lp)return u===nn?c.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:c.COMPRESSED_RGBA_ASTC_6x6_KHR;if(a===cp)return u===nn?c.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:c.COMPRESSED_RGBA_ASTC_8x5_KHR;if(a===up)return u===nn?c.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:c.COMPRESSED_RGBA_ASTC_8x6_KHR;if(a===fp)return u===nn?c.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:c.COMPRESSED_RGBA_ASTC_8x8_KHR;if(a===hp)return u===nn?c.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:c.COMPRESSED_RGBA_ASTC_10x5_KHR;if(a===dp)return u===nn?c.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:c.COMPRESSED_RGBA_ASTC_10x6_KHR;if(a===pp)return u===nn?c.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:c.COMPRESSED_RGBA_ASTC_10x8_KHR;if(a===mp)return u===nn?c.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:c.COMPRESSED_RGBA_ASTC_10x10_KHR;if(a===gp)return u===nn?c.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:c.COMPRESSED_RGBA_ASTC_12x10_KHR;if(a===vp)return u===nn?c.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:c.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(a===_p||a===xp||a===Sp)if(c=t.get("EXT_texture_compression_bptc"),c!==null){if(a===_p)return u===nn?c.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:c.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(a===xp)return c.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(a===Sp)return c.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(a===Mp||a===yp||a===wu||a===bp)if(c=t.get("EXT_texture_compression_rgtc"),c!==null){if(a===Mp)return c.COMPRESSED_RED_RGTC1_EXT;if(a===yp)return c.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(a===wu)return c.COMPRESSED_RED_GREEN_RGTC2_EXT;if(a===bp)return c.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return a===Tl?r.UNSIGNED_INT_24_8:r[a]!==void 0?r[a]:null}return{convert:n}}const T3=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,A3=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class w3{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(t,n){if(this.texture===null){const a=new Gx(t.texture);(t.depthNear!==n.depthNear||t.depthFar!==n.depthFar)&&(this.depthNear=t.depthNear,this.depthFar=t.depthFar),this.texture=a}}getMesh(t){if(this.texture!==null&&this.mesh===null){const n=t.cameras[0].viewport,a=new ei({vertexShader:T3,fragmentShader:A3,uniforms:{depthColor:{value:this.texture},depthWidth:{value:n.z},depthHeight:{value:n.w}}});this.mesh=new le(new kn(20,20),a)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class R3 extends rr{constructor(t,n){super();const a=this;let o=null,c=1,u=null,h="local-floor",m=1,p=null,g=null,_=null,v=null,x=null,b=null;const R=typeof XRWebGLBinding<"u",M=new w3,S={},C=n.getContextAttributes();let O=null,E=null;const U=[],L=[],P=new Lt;let T=null,z=null;const W=new Ei;W.viewport=new xn;const J=new Ei;J.viewport=new xn;const Q=[W,J],et=new zb;let k=null,q=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(ut){let Tt=U[ut];return Tt===void 0&&(Tt=new fd,U[ut]=Tt),Tt.getTargetRaySpace()},this.getControllerGrip=function(ut){let Tt=U[ut];return Tt===void 0&&(Tt=new fd,U[ut]=Tt),Tt.getGripSpace()},this.getHand=function(ut){let Tt=U[ut];return Tt===void 0&&(Tt=new fd,U[ut]=Tt),Tt.getHandSpace()};function F(ut){const Tt=L.indexOf(ut.inputSource);if(Tt===-1)return;const Ht=U[Tt];Ht!==void 0&&(Ht.update(ut.inputSource,ut.frame,p||u),Ht.dispatchEvent({type:ut.type,data:ut.inputSource}))}function Z(){o.removeEventListener("select",F),o.removeEventListener("selectstart",F),o.removeEventListener("selectend",F),o.removeEventListener("squeeze",F),o.removeEventListener("squeezestart",F),o.removeEventListener("squeezeend",F),o.removeEventListener("end",Z),o.removeEventListener("inputsourceschange",ht);for(let ut=0;ut<U.length;ut++){const Tt=L[ut];Tt!==null&&(L[ut]=null,U[ut].disconnect(Tt))}k=null,q=null,M.reset();for(const ut in S)delete S[ut];if(t.setRenderTarget(O),x=null,v=null,_=null,o=null,E=null,zt.stop(),a.isPresenting=!1,t.setPixelRatio(T),t.setSize(P.width,P.height,!1),z!==null){const ut=z.camera;ut.fov=z.fov,ut.zoom=z.zoom,ut.updateProjectionMatrix(),z=null}a.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(ut){c=ut,a.isPresenting===!0&&ve("WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(ut){h=ut,a.isPresenting===!0&&ve("WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return p||u},this.setReferenceSpace=function(ut){p=ut},this.getBaseLayer=function(){return v!==null?v:x},this.getBinding=function(){return _===null&&R&&(_=new XRWebGLBinding(o,n)),_},this.getFrame=function(){return b},this.getSession=function(){return o},this.setSession=async function(ut){if(o=ut,o!==null){if(O=t.getRenderTarget(),o.addEventListener("select",F),o.addEventListener("selectstart",F),o.addEventListener("selectend",F),o.addEventListener("squeeze",F),o.addEventListener("squeezestart",F),o.addEventListener("squeezeend",F),o.addEventListener("end",Z),o.addEventListener("inputsourceschange",ht),C.xrCompatible!==!0&&await n.makeXRCompatible(),T=t.getPixelRatio(),t.getSize(P),R&&"createProjectionLayer"in XRWebGLBinding.prototype){let Ht=null,ie=null,qt=null;C.depth&&(qt=C.stencil?n.DEPTH24_STENCIL8:n.DEPTH_COMPONENT24,Ht=C.stencil?Js:ka,ie=C.stencil?Tl:ua);const re={colorFormat:n.RGBA8,depthFormat:qt,scaleFactor:c};_=this.getBinding(),v=_.createProjectionLayer(re),o.updateRenderState({layers:[v]}),t.setPixelRatio(1),t.setSize(v.textureWidth,v.textureHeight,!1),E=new Hi(v.textureWidth,v.textureHeight,{format:Qi,type:Ti,depthTexture:new Rl(v.textureWidth,v.textureHeight,ie,void 0,void 0,void 0,void 0,void 0,void 0,Ht),stencilBuffer:C.stencil,colorSpace:t.outputColorSpace,samples:C.antialias?4:0,resolveDepthBuffer:v.ignoreDepthValues===!1,resolveStencilBuffer:v.ignoreDepthValues===!1,storeMultisampledDepthBuffer:v.ignoreDepthValues===!1,storeMultisampledStencilBuffer:v.ignoreDepthValues===!1})}else{const Ht={antialias:C.antialias,alpha:!0,depth:C.depth,stencil:C.stencil,framebufferScaleFactor:c};x=new XRWebGLLayer(o,n,Ht),o.updateRenderState({baseLayer:x}),t.setPixelRatio(1),t.setSize(x.framebufferWidth,x.framebufferHeight,!1),E=new Hi(x.framebufferWidth,x.framebufferHeight,{format:Qi,type:Ti,colorSpace:t.outputColorSpace,stencilBuffer:C.stencil,resolveDepthBuffer:x.ignoreDepthValues===!1,resolveStencilBuffer:x.ignoreDepthValues===!1,storeMultisampledDepthBuffer:x.ignoreDepthValues===!1,storeMultisampledStencilBuffer:x.ignoreDepthValues===!1})}E.isXRRenderTarget=!0,this.setFoveation(m),p=null,u=await o.requestReferenceSpace(h),zt.setContext(o),zt.start(),a.isPresenting=!0,a.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(o!==null)return o.environmentBlendMode},this.getDepthTexture=function(){return M.getDepthTexture()};function ht(ut){for(let Tt=0;Tt<ut.removed.length;Tt++){const Ht=ut.removed[Tt],ie=L.indexOf(Ht);ie>=0&&(L[ie]=null,U[ie].disconnect(Ht))}for(let Tt=0;Tt<ut.added.length;Tt++){const Ht=ut.added[Tt];let ie=L.indexOf(Ht);if(ie===-1){for(let re=0;re<U.length;re++)if(re>=L.length){L.push(Ht),ie=re;break}else if(L[re]===null){L[re]=Ht,ie=re;break}if(ie===-1)break}const qt=U[ie];qt&&qt.connect(Ht)}}const dt=new B,pt=new B;function I(ut,Tt,Ht){dt.setFromMatrixPosition(Tt.matrixWorld),pt.setFromMatrixPosition(Ht.matrixWorld);const ie=dt.distanceTo(pt),qt=Tt.projectionMatrix.elements,re=Ht.projectionMatrix.elements,Fe=qt[14]/(qt[10]-1),ee=qt[14]/(qt[10]+1),de=(qt[9]+1)/qt[5],xe=(qt[9]-1)/qt[5],fe=(qt[8]-1)/qt[0],be=(re[8]+1)/re[0],ke=Fe*fe,ze=Fe*be,ne=ie/(-fe+be),Se=ne*-fe;if(Tt.matrixWorld.decompose(ut.position,ut.quaternion,ut.scale),ut.translateX(Se),ut.translateZ(ne),ut.matrixWorld.compose(ut.position,ut.quaternion,ut.scale),ut.matrixWorldInverse.copy(ut.matrixWorld).invert(),qt[10]===-1)ut.projectionMatrix.copy(Tt.projectionMatrix),ut.projectionMatrixInverse.copy(Tt.projectionMatrixInverse);else{const j=Fe+ne,_e=ee+ne,Ee=ke-Se,H=ze+(ie-Se),A=de*ee/_e*j,at=xe*ee/_e*j;ut.projectionMatrix.makePerspective(Ee,H,A,at,j,_e),ut.projectionMatrixInverse.copy(ut.projectionMatrix).invert()}}function ct(ut,Tt){Tt===null?ut.matrixWorld.copy(ut.matrix):ut.matrixWorld.multiplyMatrices(Tt.matrixWorld,ut.matrix),ut.matrixWorldInverse.copy(ut.matrixWorld).invert()}this.updateCamera=function(ut){if(o===null)return;let Tt=ut.near,Ht=ut.far;M.texture!==null&&(M.depthNear>0&&(Tt=M.depthNear),M.depthFar>0&&(Ht=M.depthFar)),et.near=J.near=W.near=Tt,et.far=J.far=W.far=Ht,(k!==et.near||q!==et.far)&&(o.updateRenderState({depthNear:et.near,depthFar:et.far}),k=et.near,q=et.far),et.layers.mask=ut.layers.mask|6,W.layers.mask=et.layers.mask&-5,J.layers.mask=et.layers.mask&-3;const ie=ut.parent,qt=et.cameras;ct(et,ie);for(let re=0;re<qt.length;re++)ct(qt[re],ie);qt.length===2?I(et,W,J):et.projectionMatrix.copy(W.projectionMatrix),z===null&&ut.isPerspectiveCamera&&(z={camera:ut,fov:ut.fov,zoom:ut.zoom}),At(ut,et,ie)};function At(ut,Tt,Ht){Ht===null?ut.matrix.copy(Tt.matrixWorld):(ut.matrix.copy(Ht.matrixWorld),ut.matrix.invert(),ut.matrix.multiply(Tt.matrixWorld)),ut.matrix.decompose(ut.position,ut.quaternion,ut.scale),ut.updateMatrixWorld(!0),ut.projectionMatrix.copy(Tt.projectionMatrix),ut.projectionMatrixInverse.copy(Tt.projectionMatrixInverse),ut.isPerspectiveCamera&&(ut.fov=wl*2*Math.atan(1/ut.projectionMatrix.elements[5]),ut.zoom=1)}this.getCamera=function(){return et},this.getFoveation=function(){if(!(v===null&&x===null))return m},this.setFoveation=function(ut){m=ut,v!==null&&(v.fixedFoveation=ut),x!==null&&x.fixedFoveation!==void 0&&(x.fixedFoveation=ut)},this.hasDepthSensing=function(){return M.texture!==null},this.getDepthSensingMesh=function(){return M.getMesh(et)},this.getCameraTexture=function(ut){return S[ut]};let It=null;function kt(ut,Tt){if(g=Tt.getViewerPose(p||u),b=Tt,g!==null){const Ht=g.views;x!==null&&(t.setRenderTargetFramebuffer(E,x.framebuffer),t.setRenderTarget(E));let ie=!1;Ht.length!==et.cameras.length&&(et.cameras.length=0,ie=!0);for(let ee=0;ee<Ht.length;ee++){const de=Ht[ee];let xe=null;if(x!==null)xe=x.getViewport(de);else{const be=_.getViewSubImage(v,de);xe=be.viewport,ee===0&&(t.setRenderTargetTextures(E,be.colorTexture,be.depthStencilTexture),t.setRenderTarget(E))}let fe=Q[ee];fe===void 0&&(fe=new Ei,fe.layers.enable(ee),fe.viewport=new xn,Q[ee]=fe),fe.matrix.fromArray(de.transform.matrix),fe.matrix.decompose(fe.position,fe.quaternion,fe.scale),fe.projectionMatrix.fromArray(de.projectionMatrix),fe.projectionMatrixInverse.copy(fe.projectionMatrix).invert(),fe.viewport.set(xe.x,xe.y,xe.width,xe.height),ee===0&&(et.matrix.copy(fe.matrix),et.matrix.decompose(et.position,et.quaternion,et.scale)),ie===!0&&et.cameras.push(fe)}const qt=o.enabledFeatures;if(qt&&qt.includes("depth-sensing")&&o.depthUsage=="gpu-optimized"&&R){_=a.getBinding();const ee=_.getDepthInformation(Ht[0]);ee&&ee.isValid&&ee.texture&&M.init(ee,o.renderState)}if(qt&&qt.includes("camera-access")&&R){t.state.unbindTexture(),_=a.getBinding();for(let ee=0;ee<Ht.length;ee++){const de=Ht[ee].camera;if(de){let xe=S[de];xe||(xe=new Gx,S[de]=xe);const fe=_.getCameraImage(de);xe.sourceTexture=fe}}}}for(let Ht=0;Ht<U.length;Ht++){const ie=L[Ht],qt=U[Ht];ie!==null&&qt!==void 0&&qt.update(ie,Tt,p||u)}It&&It(ut,Tt),Tt.detectedPlanes&&a.dispatchEvent({type:"planesdetected",data:Tt}),b=null}const zt=new tS;zt.setAnimationLoop(kt),this.setAnimationLoop=function(ut){It=ut},this.dispose=function(){}}}const C3=new an,oS=new ye;oS.set(-1,0,0,0,1,0,0,0,1);function D3(r,t){function n(M,S){M.matrixAutoUpdate===!0&&M.updateMatrix(),S.value.copy(M.matrix)}function a(M,S){S.color.getRGB(M.fogColor.value,Qx(r)),S.isFog?(M.fogNear.value=S.near,M.fogFar.value=S.far):S.isFogExp2&&(M.fogDensity.value=S.density)}function o(M,S,C,O,E){S.isNodeMaterial?S.uniformsNeedUpdate=!1:S.isMeshBasicMaterial?c(M,S):S.isMeshLambertMaterial?(c(M,S),S.envMap&&(M.envMapIntensity.value=S.envMapIntensity)):S.isMeshToonMaterial?(c(M,S),_(M,S)):S.isMeshPhongMaterial?(c(M,S),g(M,S),S.envMap&&(M.envMapIntensity.value=S.envMapIntensity)):S.isMeshStandardMaterial?(c(M,S),v(M,S),S.isMeshPhysicalMaterial&&x(M,S,E)):S.isMeshMatcapMaterial?(c(M,S),b(M,S)):S.isMeshDepthMaterial?c(M,S):S.isMeshDistanceMaterial?(c(M,S),R(M,S)):S.isMeshNormalMaterial?c(M,S):S.isLineBasicMaterial?(u(M,S),S.isLineDashedMaterial&&h(M,S)):S.isPointsMaterial?m(M,S,C,O):S.isSpriteMaterial?p(M,S):S.isShadowMaterial?(M.color.value.copy(S.color),M.opacity.value=S.opacity):S.isShaderMaterial&&(S.uniformsNeedUpdate=!1)}function c(M,S){M.opacity.value=S.opacity,S.color&&M.diffuse.value.copy(S.color),S.emissive&&M.emissive.value.copy(S.emissive).multiplyScalar(S.emissiveIntensity),S.map&&(M.map.value=S.map,n(S.map,M.mapTransform)),S.alphaMap&&(M.alphaMap.value=S.alphaMap,n(S.alphaMap,M.alphaMapTransform)),S.bumpMap&&(M.bumpMap.value=S.bumpMap,n(S.bumpMap,M.bumpMapTransform),M.bumpScale.value=S.bumpScale,S.side===oi&&(M.bumpScale.value*=-1)),S.normalMap&&(M.normalMap.value=S.normalMap,n(S.normalMap,M.normalMapTransform),M.normalScale.value.copy(S.normalScale),S.side===oi&&M.normalScale.value.negate()),S.displacementMap&&(M.displacementMap.value=S.displacementMap,n(S.displacementMap,M.displacementMapTransform),M.displacementScale.value=S.displacementScale,M.displacementBias.value=S.displacementBias),S.emissiveMap&&(M.emissiveMap.value=S.emissiveMap,n(S.emissiveMap,M.emissiveMapTransform)),S.specularMap&&(M.specularMap.value=S.specularMap,n(S.specularMap,M.specularMapTransform)),S.alphaTest>0&&(M.alphaTest.value=S.alphaTest);const C=t.get(S),O=C.envMap,E=C.envMapRotation;O&&(M.envMap.value=O,M.envMapRotation.value.setFromMatrix4(C3.makeRotationFromEuler(E)).transpose(),O.isCubeTexture&&O.isRenderTargetTexture===!1&&M.envMapRotation.value.premultiply(oS),M.reflectivity.value=S.reflectivity,M.ior.value=S.ior,M.refractionRatio.value=S.refractionRatio),S.lightMap&&(M.lightMap.value=S.lightMap,M.lightMapIntensity.value=S.lightMapIntensity,n(S.lightMap,M.lightMapTransform)),S.aoMap&&(M.aoMap.value=S.aoMap,M.aoMapIntensity.value=S.aoMapIntensity,n(S.aoMap,M.aoMapTransform))}function u(M,S){M.diffuse.value.copy(S.color),M.opacity.value=S.opacity,S.map&&(M.map.value=S.map,n(S.map,M.mapTransform))}function h(M,S){M.dashSize.value=S.dashSize,M.totalSize.value=S.dashSize+S.gapSize,M.scale.value=S.scale}function m(M,S,C,O){M.diffuse.value.copy(S.color),M.opacity.value=S.opacity,M.size.value=S.size*C,M.scale.value=O*.5,S.map&&(M.map.value=S.map,n(S.map,M.uvTransform)),S.alphaMap&&(M.alphaMap.value=S.alphaMap,n(S.alphaMap,M.alphaMapTransform)),S.alphaTest>0&&(M.alphaTest.value=S.alphaTest)}function p(M,S){M.diffuse.value.copy(S.color),M.opacity.value=S.opacity,M.rotation.value=S.rotation,S.map&&(M.map.value=S.map,n(S.map,M.mapTransform)),S.alphaMap&&(M.alphaMap.value=S.alphaMap,n(S.alphaMap,M.alphaMapTransform)),S.alphaTest>0&&(M.alphaTest.value=S.alphaTest)}function g(M,S){M.specular.value.copy(S.specular),M.shininess.value=Math.max(S.shininess,1e-4)}function _(M,S){S.gradientMap&&(M.gradientMap.value=S.gradientMap)}function v(M,S){M.metalness.value=S.metalness,S.metalnessMap&&(M.metalnessMap.value=S.metalnessMap,n(S.metalnessMap,M.metalnessMapTransform)),M.roughness.value=S.roughness,S.roughnessMap&&(M.roughnessMap.value=S.roughnessMap,n(S.roughnessMap,M.roughnessMapTransform)),S.envMap&&(M.envMapIntensity.value=S.envMapIntensity)}function x(M,S,C){M.ior.value=S.ior,S.sheen>0&&(M.sheenColor.value.copy(S.sheenColor).multiplyScalar(S.sheen),M.sheenRoughness.value=S.sheenRoughness,S.sheenColorMap&&(M.sheenColorMap.value=S.sheenColorMap,n(S.sheenColorMap,M.sheenColorMapTransform)),S.sheenRoughnessMap&&(M.sheenRoughnessMap.value=S.sheenRoughnessMap,n(S.sheenRoughnessMap,M.sheenRoughnessMapTransform))),S.clearcoat>0&&(M.clearcoat.value=S.clearcoat,M.clearcoatRoughness.value=S.clearcoatRoughness,S.clearcoatMap&&(M.clearcoatMap.value=S.clearcoatMap,n(S.clearcoatMap,M.clearcoatMapTransform)),S.clearcoatRoughnessMap&&(M.clearcoatRoughnessMap.value=S.clearcoatRoughnessMap,n(S.clearcoatRoughnessMap,M.clearcoatRoughnessMapTransform)),S.clearcoatNormalMap&&(M.clearcoatNormalMap.value=S.clearcoatNormalMap,n(S.clearcoatNormalMap,M.clearcoatNormalMapTransform),M.clearcoatNormalScale.value.copy(S.clearcoatNormalScale),S.side===oi&&M.clearcoatNormalScale.value.negate())),S.dispersion>0&&(M.dispersion.value=S.dispersion),S.retroreflectivity>0&&(M.retroreflectivity.value=S.retroreflectivity),S.iridescence>0&&(M.iridescence.value=S.iridescence,M.iridescenceIOR.value=S.iridescenceIOR,M.iridescenceThicknessMinimum.value=S.iridescenceThicknessRange[0],M.iridescenceThicknessMaximum.value=S.iridescenceThicknessRange[1],S.iridescenceMap&&(M.iridescenceMap.value=S.iridescenceMap,n(S.iridescenceMap,M.iridescenceMapTransform)),S.iridescenceThicknessMap&&(M.iridescenceThicknessMap.value=S.iridescenceThicknessMap,n(S.iridescenceThicknessMap,M.iridescenceThicknessMapTransform))),S.transmission>0&&(M.transmission.value=S.transmission,M.transmissionSamplerMap.value=C.texture,M.transmissionSamplerSize.value.set(C.width,C.height),S.transmissionMap&&(M.transmissionMap.value=S.transmissionMap,n(S.transmissionMap,M.transmissionMapTransform)),M.thickness.value=S.thickness,S.thicknessMap&&(M.thicknessMap.value=S.thicknessMap,n(S.thicknessMap,M.thicknessMapTransform)),M.attenuationDistance.value=S.attenuationDistance,M.attenuationColor.value.copy(S.attenuationColor)),S.anisotropy>0&&(M.anisotropyVector.value.set(S.anisotropy*Math.cos(S.anisotropyRotation),S.anisotropy*Math.sin(S.anisotropyRotation)),S.anisotropyMap&&(M.anisotropyMap.value=S.anisotropyMap,n(S.anisotropyMap,M.anisotropyMapTransform))),M.specularIntensity.value=S.specularIntensity,M.specularColor.value.copy(S.specularColor),S.specularColorMap&&(M.specularColorMap.value=S.specularColorMap,n(S.specularColorMap,M.specularColorMapTransform)),S.specularIntensityMap&&(M.specularIntensityMap.value=S.specularIntensityMap,n(S.specularIntensityMap,M.specularIntensityMapTransform))}function b(M,S){S.matcap&&(M.matcap.value=S.matcap)}function R(M,S){const C=t.get(S).light;M.referencePosition.value.setFromMatrixPosition(C.matrixWorld),M.nearDistance.value=C.shadow.camera.near,M.farDistance.value=C.shadow.camera.far}return{refreshFogUniforms:a,refreshMaterialUniforms:o}}function U3(r,t,n,a){let o={},c={},u=[];const h=r.getParameter(r.MAX_UNIFORM_BUFFER_BINDINGS);function m(E,U){const L=U.program;a.uniformBlockBinding(E,L)}function p(E,U){let L=o[E.id];L===void 0&&(M(E),L=g(E),o[E.id]=L,E.addEventListener("dispose",C));const P=U.program;a.updateUBOMapping(E,P);const T=t.render.frame;c[E.id]!==T&&(v(E),c[E.id]=T)}function g(E){const U=_();E.__bindingPointIndex=U;const L=r.createBuffer(),P=E.__size,T=E.usage;return r.bindBuffer(r.UNIFORM_BUFFER,L),r.bufferData(r.UNIFORM_BUFFER,P,T),r.bindBuffer(r.UNIFORM_BUFFER,null),r.bindBufferBase(r.UNIFORM_BUFFER,U,L),L}function _(){for(let E=0;E<h;E++)if(u.indexOf(E)===-1)return u.push(E),E;return We("WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function v(E){const U=o[E.id],L=E.uniforms,P=E.__cache;r.bindBuffer(r.UNIFORM_BUFFER,U);for(let T=0,z=L.length;T<z;T++){const W=L[T];if(Array.isArray(W))for(let J=0,Q=W.length;J<Q;J++)x(W[J],T,J,P);else x(W,T,0,P)}r.bindBuffer(r.UNIFORM_BUFFER,null)}function x(E,U,L,P){if(R(E,U,L,P)===!0){const T=E.__offset,z=E.value;if(Array.isArray(z)){let W=0;for(let J=0;J<z.length;J++){const Q=z[J],et=S(Q);b(Q,E.__data,W),typeof Q!="number"&&typeof Q!="boolean"&&!Q.isMatrix3&&!ArrayBuffer.isView(Q)&&(W+=et.storage/Float32Array.BYTES_PER_ELEMENT)}}else b(z,E.__data,0);r.bufferSubData(r.UNIFORM_BUFFER,T,E.__data)}}function b(E,U,L){typeof E=="number"||typeof E=="boolean"?U[0]=E:E.isMatrix3?(U[0]=E.elements[0],U[1]=E.elements[1],U[2]=E.elements[2],U[3]=0,U[4]=E.elements[3],U[5]=E.elements[4],U[6]=E.elements[5],U[7]=0,U[8]=E.elements[6],U[9]=E.elements[7],U[10]=E.elements[8],U[11]=0):ArrayBuffer.isView(E)?U.set(new E.constructor(E.buffer,E.byteOffset,U.length)):E.toArray(U,L)}function R(E,U,L,P){const T=E.value,z=U+"_"+L;if(P[z]===void 0)return typeof T=="number"||typeof T=="boolean"?P[z]=T:ArrayBuffer.isView(T)?P[z]=T.slice():P[z]=T.clone(),!0;{const W=P[z];if(typeof T=="number"||typeof T=="boolean"){if(W!==T)return P[z]=T,!0}else{if(ArrayBuffer.isView(T))return!0;if(W.equals(T)===!1)return W.copy(T),!0}}return!1}function M(E){const U=E.uniforms;let L=0;const P=16;for(let z=0,W=U.length;z<W;z++){const J=Array.isArray(U[z])?U[z]:[U[z]];for(let Q=0,et=J.length;Q<et;Q++){const k=J[Q],q=Array.isArray(k.value)?k.value:[k.value];for(let F=0,Z=q.length;F<Z;F++){const ht=q[F],dt=S(ht),pt=L%P,I=pt%dt.boundary,ct=pt+I;L+=I,ct!==0&&P-ct<dt.storage&&(L+=P-ct),k.__data=new Float32Array(dt.storage/Float32Array.BYTES_PER_ELEMENT),k.__offset=L,L+=dt.storage}}}const T=L%P;return T>0&&(L+=P-T),E.__size=L,E.__cache={},this}function S(E){const U={boundary:0,storage:0};return typeof E=="number"||typeof E=="boolean"?(U.boundary=4,U.storage=4):E.isVector2?(U.boundary=8,U.storage=8):E.isVector3||E.isColor?(U.boundary=16,U.storage=12):E.isVector4?(U.boundary=16,U.storage=16):E.isMatrix3?(U.boundary=48,U.storage=48):E.isMatrix4?(U.boundary=64,U.storage=64):E.isTexture?ve("WebGLRenderer: Texture samplers can not be part of an uniforms group."):ArrayBuffer.isView(E)?(U.boundary=16,U.storage=E.byteLength):ve("WebGLRenderer: Unsupported uniform value type.",E),U}function C(E){const U=E.target;U.removeEventListener("dispose",C);const L=u.indexOf(U.__bindingPointIndex);u.splice(L,1),r.deleteBuffer(o[U.id]),delete o[U.id],delete c[U.id]}function O(){for(const E in o)r.deleteBuffer(o[E]);u=[],o={},c={}}return{bind:m,update:p,dispose:O}}const L3=new Uint16Array([12469,15057,12620,14925,13266,14620,13807,14376,14323,13990,14545,13625,14713,13328,14840,12882,14931,12528,14996,12233,15039,11829,15066,11525,15080,11295,15085,10976,15082,10705,15073,10495,13880,14564,13898,14542,13977,14430,14158,14124,14393,13732,14556,13410,14702,12996,14814,12596,14891,12291,14937,11834,14957,11489,14958,11194,14943,10803,14921,10506,14893,10278,14858,9960,14484,14039,14487,14025,14499,13941,14524,13740,14574,13468,14654,13106,14743,12678,14818,12344,14867,11893,14889,11509,14893,11180,14881,10751,14852,10428,14812,10128,14765,9754,14712,9466,14764,13480,14764,13475,14766,13440,14766,13347,14769,13070,14786,12713,14816,12387,14844,11957,14860,11549,14868,11215,14855,10751,14825,10403,14782,10044,14729,9651,14666,9352,14599,9029,14967,12835,14966,12831,14963,12804,14954,12723,14936,12564,14917,12347,14900,11958,14886,11569,14878,11247,14859,10765,14828,10401,14784,10011,14727,9600,14660,9289,14586,8893,14508,8533,15111,12234,15110,12234,15104,12216,15092,12156,15067,12010,15028,11776,14981,11500,14942,11205,14902,10752,14861,10393,14812,9991,14752,9570,14682,9252,14603,8808,14519,8445,14431,8145,15209,11449,15208,11451,15202,11451,15190,11438,15163,11384,15117,11274,15055,10979,14994,10648,14932,10343,14871,9936,14803,9532,14729,9218,14645,8742,14556,8381,14461,8020,14365,7603,15273,10603,15272,10607,15267,10619,15256,10631,15231,10614,15182,10535,15118,10389,15042,10167,14963,9787,14883,9447,14800,9115,14710,8665,14615,8318,14514,7911,14411,7507,14279,7198,15314,9675,15313,9683,15309,9712,15298,9759,15277,9797,15229,9773,15166,9668,15084,9487,14995,9274,14898,8910,14800,8539,14697,8234,14590,7790,14479,7409,14367,7067,14178,6621,15337,8619,15337,8631,15333,8677,15325,8769,15305,8871,15264,8940,15202,8909,15119,8775,15022,8565,14916,8328,14804,8009,14688,7614,14569,7287,14448,6888,14321,6483,14088,6171,15350,7402,15350,7419,15347,7480,15340,7613,15322,7804,15287,7973,15229,8057,15148,8012,15046,7846,14933,7611,14810,7357,14682,7069,14552,6656,14421,6316,14251,5948,14007,5528,15356,5942,15356,5977,15353,6119,15348,6294,15332,6551,15302,6824,15249,7044,15171,7122,15070,7050,14949,6861,14818,6611,14679,6349,14538,6067,14398,5651,14189,5311,13935,4958,15359,4123,15359,4153,15356,4296,15353,4646,15338,5160,15311,5508,15263,5829,15188,6042,15088,6094,14966,6001,14826,5796,14678,5543,14527,5287,14377,4985,14133,4586,13869,4257,15360,1563,15360,1642,15358,2076,15354,2636,15341,3350,15317,4019,15273,4429,15203,4732,15105,4911,14981,4932,14836,4818,14679,4621,14517,4386,14359,4156,14083,3795,13808,3437,15360,122,15360,137,15358,285,15355,636,15344,1274,15322,2177,15281,2765,15215,3223,15120,3451,14995,3569,14846,3567,14681,3466,14511,3305,14344,3121,14037,2800,13753,2467,15360,0,15360,1,15359,21,15355,89,15346,253,15325,479,15287,796,15225,1148,15133,1492,15008,1749,14856,1882,14685,1886,14506,1783,14324,1608,13996,1398,13702,1183]);let ra=null;function N3(){return ra===null&&(ra=new Bx(L3,16,16,er,$i),ra.name="DFG_LUT",ra.minFilter=Xn,ra.magFilter=Xn,ra.wrapS=Ba,ra.wrapT=Ba,ra.generateMipmaps=!1,ra.needsUpdate=!0),ra}class O3{constructor(t={}){const{canvas:n=s1(),context:a=null,depth:o=!0,stencil:c=!1,alpha:u=!1,antialias:h=!1,premultipliedAlpha:m=!0,preserveDrawingBuffer:p=!1,powerPreference:g="default",failIfMajorPerformanceCaveat:_=!1,reversedDepthBuffer:v=!1,outputBufferType:x=Ti}=t;this.isWebGLRenderer=!0;let b;if(a!==null){if(typeof WebGLRenderingContext<"u"&&a instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");b=a.getContextAttributes().alpha}else b=u;const R=x,M=new Set([kp,Vp,Gp]),S=new Set([Ti,ua,El,Tl,Bp,Fp]),C=new Uint32Array(4),O=new Int32Array(4),E=new B;let U=null,L=null;const P=[],T=[];let z=null;this.domElement=n,this.debug={checkShaderErrors:!0,diagnostics:{keywords:!1},onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=ca,this.toneMappingExposure=1,this.transmissionResolutionScale=1;const W=this;let J=!1,Q=null,et=null,k=null,q=null;this._outputColorSpace=In;let F=0,Z=0,ht=null,dt=-1,pt=null;const I=new xn,ct=new xn;let At=null;const It=new ue(0);let kt=0,zt=n.width,ut=n.height,Tt=1,Ht=null,ie=null;const qt=new xn(0,0,zt,ut),re=new xn(0,0,zt,ut);let Fe=!1;const ee=new Kp;let de=!1,xe=!1;const fe=new an,be=new B,ke=new xn,ze={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};let ne=!1;function Se(){return ht===null?Tt:1}let j=a;function _e(D,$){return n.getContext(D,$)}let Ee,H,A,at,mt,bt,Bt,Ft,Mt,St,Ot,Xt,Wt,ot,G,Y,nt,w,V,X,st,rt,it;try{const D={alpha:!0,depth:o,stencil:c,antialias:h,premultipliedAlpha:m,preserveDrawingBuffer:p,powerPreference:g,failIfMajorPerformanceCaveat:_};if("setAttribute"in n&&n.setAttribute("data-engine",`three.js r${Pp}`),n.addEventListener("webglcontextlost",lt,!1),n.addEventListener("webglcontextrestored",Rt,!1),n.addEventListener("webglcontextcreationerror",Gt,!1),j===null){const $="webgl2";if(j=_e($,D),j===null)throw _e($)?new Error("THREE.WebGLRenderer: Error creating WebGL context with your selected attributes."):new Error("THREE.WebGLRenderer: Error creating WebGL context.")}Ct()}catch(D){throw n.removeEventListener("webglcontextlost",lt,!1),n.removeEventListener("webglcontextrestored",Rt,!1),n.removeEventListener("webglcontextcreationerror",Gt,!1),We("WebGLRenderer: "+D.message),D}function Ct(){Ee=new N2(j),Ee.init(),st=new E3(j,Ee),H=new b2(j,Ee,t,st),A=new y3(j,Ee),H.reversedDepthBuffer&&v&&A.buffers.depth.setReversed(!0),et=j.createFramebuffer(),k=j.createFramebuffer(),q=j.createFramebuffer(),at=new z2(j),mt=new l3,bt=new b3(j,Ee,A,mt,H,st,at),Bt=new L2(W),Ft=new Bb(j),rt=new M2(j,Ft),Mt=new O2(j,Ft,at,rt),St=new B2(j,Mt,Ft,rt,at),w=new I2(j,H,bt),G=new E2(mt),Ot=new o3(W,Bt,Ee,H,rt,G),Xt=new D3(W,mt),Wt=new u3,ot=new g3(Ee),nt=new S2(W,Bt,A,St,b,m),Y=new M3(W,St,H),it=new U3(j,at,H,A),V=new y2(j,Ee,at),X=new P2(j,Ee,at),at.programs=Ot.programs,W.capabilities=H,W.extensions=Ee,W.properties=mt,W.renderLists=Wt,W.shadowMap=Y,W.state=A,W.info=at}R!==Ti&&(z=new H2(R,n.width,n.height,h,o,c));const Pt=new R3(W,j);this.xr=Pt,this.getContext=function(){return j},this.getContextAttributes=function(){return j.getContextAttributes()},this.forceContextLoss=function(){const D=Ee.get("WEBGL_lose_context");D&&D.loseContext()},this.forceContextRestore=function(){const D=Ee.get("WEBGL_lose_context");D&&D.restoreContext()},this.getPixelRatio=function(){return Tt},this.setPixelRatio=function(D){D!==void 0&&(Tt=D,this.setSize(zt,ut,!1))},this.getSize=function(D){return D.set(zt,ut)},this.setSize=function(D,$,Et=!0){if(Pt.isPresenting){ve("WebGLRenderer: Can't change size while VR device is presenting.");return}zt=D,ut=$,n.width=Math.floor(D*Tt),n.height=Math.floor($*Tt),Et===!0&&(n.style.width=D+"px",n.style.height=$+"px"),z!==null&&z.setSize(n.width,n.height),this.setViewport(0,0,D,$)},this.getDrawingBufferSize=function(D){return D.set(zt*Tt,ut*Tt).floor()},this.setDrawingBufferSize=function(D,$,Et){zt=D,ut=$,Tt=Et,n.width=Math.floor(D*Et),n.height=Math.floor($*Et),this.setViewport(0,0,D,$)},this.setEffects=function(D){if(R===Ti){We("WebGLRenderer: setEffects() requires outputBufferType set to HalfFloatType or FloatType.");return}if(D){for(let $=0;$<D.length;$++)if(D[$].isOutputPass===!0){ve("WebGLRenderer: OutputPass is not needed in setEffects(). Tone mapping and color space conversion are applied automatically.");break}}z.setEffects(D||[])},this.getCurrentViewport=function(D){return D.copy(I)},this.getViewport=function(D){return D.copy(qt)},this.setViewport=function(D,$,Et,gt){D.isVector4?qt.set(D.x,D.y,D.z,D.w):qt.set(D,$,Et,gt),A.viewport(I.copy(qt).multiplyScalar(Tt).round())},this.getScissor=function(D){return D.copy(re)},this.setScissor=function(D,$,Et,gt){D.isVector4?re.set(D.x,D.y,D.z,D.w):re.set(D,$,Et,gt),A.scissor(ct.copy(re).multiplyScalar(Tt).round())},this.getScissorTest=function(){return Fe},this.setScissorTest=function(D){A.setScissorTest(Fe=D)},this.setOpaqueSort=function(D){Ht=D},this.setTransparentSort=function(D){ie=D},this.getClearColor=function(D){return D.copy(nt.getClearColor())},this.setClearColor=function(){nt.setClearColor(...arguments)},this.getClearAlpha=function(){return nt.getClearAlpha()},this.setClearAlpha=function(){nt.setClearAlpha(...arguments)},this.clear=function(D=!0,$=!0,Et=!0){let gt=0;if(D){let vt=!1;if(ht!==null){const Kt=ht.texture.format;vt=M.has(Kt)}if(vt){const Kt=ht.texture.type,$t=S.has(Kt),Zt=nt.getClearColor(),Qt=nt.getClearAlpha(),jt=Zt.r,Te=Zt.g,Le=Zt.b;$t?(C[0]=jt,C[1]=Te,C[2]=Le,C[3]=Qt,j.clearBufferuiv(j.COLOR,0,C)):(O[0]=jt,O[1]=Te,O[2]=Le,O[3]=Qt,j.clearBufferiv(j.COLOR,0,O))}else gt|=j.COLOR_BUFFER_BIT}$&&(gt|=j.DEPTH_BUFFER_BIT,this.state.buffers.depth.setMask(!0)),Et&&(gt|=j.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),gt!==0&&j.clear(gt)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.setNodesHandler=function(D){D.setRenderer(this),Q=D},this.dispose=function(){n.removeEventListener("webglcontextlost",lt,!1),n.removeEventListener("webglcontextrestored",Rt,!1),n.removeEventListener("webglcontextcreationerror",Gt,!1),nt.dispose(),Wt.dispose(),ot.dispose(),mt.dispose(),Bt.dispose(),St.dispose(),rt.dispose(),it.dispose(),Ot.dispose(),Pt.dispose(),Pt.removeEventListener("sessionstart",He),Pt.removeEventListener("sessionend",qe),Tn.stop()};function lt(D){D.preventDefault(),n_("WebGLRenderer: Context Lost."),J=!0}function Rt(){n_("WebGLRenderer: Context Restored."),J=!1;const D=at.autoReset,$=Y.enabled,Et=Y.autoUpdate,gt=Y.needsUpdate,vt=Y.type;Ct(),at.autoReset=D,Y.enabled=$,Y.autoUpdate=Et,Y.needsUpdate=gt,Y.type=vt}function Gt(D){We("WebGLRenderer: A WebGL context could not be created. Reason: ",D.statusMessage)}function Vt(D){const $=D.target;$.removeEventListener("dispose",Vt),Yt($)}function Yt(D){pe(D),mt.remove(D)}function pe(D){const $=mt.get(D).programs;$!==void 0&&($.forEach(function(Et){Ot.releaseProgram(Et)}),D.isShaderMaterial&&Ot.releaseShaderCache(D))}this.renderBufferDirect=function(D,$,Et,gt,vt,Kt){$===null&&($=ze);const $t=vt.isMesh&&vt.matrixWorld.determinantAffine()<0,Zt=Za(D,$,Et,gt,vt);A.setMaterial(gt,$t);let Qt=Et.index,jt=1;if(gt.wireframe===!0){if(Qt=Mt.getWireframeAttribute(Et),Qt===void 0)return;jt=2}const Te=Et.drawRange,Le=Et.attributes.position;let ae=Te.start*jt,Xe=(Te.start+Te.count)*jt;Kt!==null&&(ae=Math.max(ae,Kt.start*jt),Xe=Math.min(Xe,(Kt.start+Kt.count)*jt)),Qt!==null?(ae=Math.max(ae,0),Xe=Math.min(Xe,Qt.count)):Le!=null&&(ae=Math.max(ae,0),Xe=Math.min(Xe,Le.count));const hn=Xe-ae;if(hn<0||hn===1/0)return;rt.setup(vt,gt,Zt,Et,Qt);let un,Re=V;if(Qt!==null&&(un=Ft.get(Qt),Re=X,Re.setIndex(un)),vt.isMesh)gt.wireframe===!0?(A.setLineWidth(gt.wireframeLinewidth*Se()),Re.setMode(j.LINES)):Re.setMode(j.TRIANGLES);else if(vt.isLine){let Cn=gt.linewidth;Cn===void 0&&(Cn=1),A.setLineWidth(Cn*Se()),vt.isLineSegments?Re.setMode(j.LINES):vt.isLineLoop?Re.setMode(j.LINE_LOOP):Re.setMode(j.LINE_STRIP)}else vt.isPoints?Re.setMode(j.POINTS):vt.isSprite&&Re.setMode(j.TRIANGLES);if(vt.isBatchedMesh)if(Ee.get("WEBGL_multi_draw"))Re.renderMultiDraw(vt._multiDrawStarts,vt._multiDrawCounts,vt._multiDrawCount);else{const Cn=vt._multiDrawStarts,te=vt._multiDrawCounts,Pn=vt._multiDrawCount,Ce=Qt?Ft.get(Qt).bytesPerElement:1,ni=mt.get(gt).currentProgram.getUniforms();for(let pi=0;pi<Pn;pi++)ni.setValue(j,"_gl_DrawID",pi),Re.render(Cn[pi]/Ce,te[pi])}else if(vt.isInstancedMesh)Re.renderInstances(ae,hn,vt.count);else if(Et.isInstancedBufferGeometry){const Cn=Et._maxInstanceCount!==void 0?Et._maxInstanceCount:1/0,te=Math.min(Et.instanceCount,Cn);Re.renderInstances(ae,hn,te)}else Re.render(ae,hn)};function Ke(D,$,Et,gt){Q!==null&&D.isNodeMaterial&&Q.setObject(gt,D),de===!0&&G.setState(D,Et,!1),D.transparent===!0&&D.side===cn&&D.forceSinglePass===!1?(D.side=oi,D.needsUpdate=!0,Ya(D,$,gt),D.side=$s,D.needsUpdate=!0,Ya(D,$,gt),D.side=cn):Ya(D,$,gt)}this.compile=function(D,$,Et=null){Et===null&&(Et=D),Q!==null&&Q.renderStart(D,$,Et),L=ot.get(Et),L.init($),T.push(L),Et.traverseVisible(function(vt){vt.isLight&&vt.layers.test($.layers)&&(L.pushLight(vt),vt.castShadow&&L.pushShadow(vt))}),D!==Et&&D.traverseVisible(function(vt){vt.isLight&&vt.layers.test($.layers)&&(L.pushLight(vt),vt.castShadow&&L.pushShadow(vt))}),L.setupLights(),Q!==null&&Q.updateLights(L.state.lightsArray),xe=this.localClippingEnabled,de=G.init(this.clippingPlanes,xe),de===!0&&G.setGlobalState(this.clippingPlanes,$),Q!==null&&Y.render(L.state.shadowsArray,Et,$);const gt=new Set;return D.traverse(function(vt){if(!(vt.isMesh||vt.isPoints||vt.isLine||vt.isSprite))return;const Kt=vt.material;if(Kt)if(Array.isArray(Kt))for(let $t=0;$t<Kt.length;$t++){const Zt=Kt[$t];Ke(Zt,Et,$,vt),gt.add(Zt)}else Ke(Kt,Et,$,vt),gt.add(Kt)}),L=T.pop(),Q!==null&&Q.renderEnd(),gt},this.compileAsync=function(D,$,Et=null){const gt=this.compile(D,$,Et);return new Promise(vt=>{function Kt(){if(gt.forEach(function($t){const Qt=mt.get($t).currentProgram;(Qt===void 0||Qt.isReady())&&gt.delete($t)}),gt.size===0){vt(D);return}setTimeout(Kt,10)}Ee.get("KHR_parallel_shader_compile")!==null?Kt():setTimeout(Kt,10)})};let gn=null;function $e(D){gn&&gn(D)}function He(){Tn.stop()}function qe(){Tn.start()}const Tn=new tS;Tn.setAnimationLoop($e),typeof self<"u"&&Tn.setContext(self),this.setAnimationLoop=function(D){gn=D,Pt.setAnimationLoop(D),D===null?Tn.stop():Tn.start()},Pt.addEventListener("sessionstart",He),Pt.addEventListener("sessionend",qe),this.render=function(D,$){if($!==void 0&&$.isCamera!==!0){We("WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(J===!0)return;Q!==null&&Q.renderStart(D,$);const Et=Pt.enabled===!0&&Pt.isPresenting===!0,gt=z!==null&&(ht===null||Et)&&z.begin(W,ht);if(D.matrixWorldAutoUpdate===!0&&D.updateMatrixWorld(),$.parent===null&&$.matrixWorldAutoUpdate===!0&&$.updateMatrixWorld(),Pt.enabled===!0&&Pt.isPresenting===!0&&(z===null||z.isCompositing()===!1)&&(Pt.cameraAutoUpdate===!0&&Pt.updateCamera($),$=Pt.getCamera()),D.isScene===!0&&D.onBeforeRender(W,D,$,ht),L=ot.get(D,T.length),L.init($),L.state.textureUnits=bt.getTextureUnits(),T.push(L),fe.multiplyMatrices($.projectionMatrix,$.matrixWorldInverse),ee.setFromProjectionMatrix(fe,la,$.reversedDepth),xe=this.localClippingEnabled,de=G.init(this.clippingPlanes,xe),U=Wt.get(D,P.length),U.init(),P.push(U),Pt.enabled===!0&&Pt.isPresenting===!0){const $t=W.xr.getDepthSensingMesh();$t!==null&&wi($t,$,-1/0,W.sortObjects)}wi(D,$,0,W.sortObjects),U.finish(),Q!==null&&Q.updateLights(L.state.lightsArray),W.sortObjects===!0&&U.sort(Ht,ie),ne=Pt.enabled===!1||Pt.isPresenting===!1||Pt.hasDepthSensing()===!1,ne&&nt.addToRenderList(U,D),this.info.render.frame++,this.info.autoReset===!0&&this.info.reset(),de===!0&&G.beginShadows();const vt=L.state.shadowsArray;if(Y.render(vt,D,$),de===!0&&G.endShadows(),(gt&&z.hasRenderPass())===!1){const $t=U.opaque,Zt=U.transmissive;if(L.setupLights(),$.isArrayCamera){const Qt=$.cameras;if(Zt.length>0)for(let jt=0,Te=Qt.length;jt<Te;jt++){const Le=Qt[jt];Gi($t,Zt,D,Le)}ne&&nt.render(D);for(let jt=0,Te=Qt.length;jt<Te;jt++){const Le=Qt[jt];ha(U,D,Le,Le.viewport)}}else Zt.length>0&&Gi($t,Zt,D,$),ne&&nt.render(D),ha(U,D,$)}ht!==null&&Z===0&&(bt.updateMultisampleRenderTarget(ht),bt.updateRenderTargetMipmap(ht)),gt&&z.end(W),D.isScene===!0&&D.onAfterRender(W,D,$),rt.resetDefaultState(),dt=-1,pt=null,T.pop(),T.length>0?(L=T[T.length-1],bt.setTextureUnits(L.state.textureUnits),de===!0&&G.setGlobalState(W.clippingPlanes,L.state.camera)):L=null,P.pop(),P.length>0?U=P[P.length-1]:U=null,Q!==null&&Q.renderEnd()};function wi(D,$,Et,gt){if(D.visible===!1)return;if(D.layers.test($.layers)){if(D.isGroup)Et=D.renderOrder;else if(D.isLOD)D.autoUpdate===!0&&D.update($);else if(D.isLightProbeGrid)L.pushLightProbeGrid(D);else if(D.isLight)L.pushLight(D),D.castShadow&&L.pushShadow(D);else if(D.isSprite){if(!D.frustumCulled||D.intersectsFrustum(ee)){gt&&ke.setFromMatrixPosition(D.matrixWorld).applyMatrix4(fe);const $t=St.update(D),Zt=D.material;Zt.visible&&U.push(D,$t,Zt,Et,ke.z,null,$)}}else if((D.isMesh||D.isLine||D.isPoints)&&(!D.frustumCulled||D.intersectsFrustum(ee))){const $t=St.update(D),Zt=D.material;if(gt&&(D.boundingSphere!==void 0?(D.boundingSphere===null&&D.computeBoundingSphere(),ke.copy(D.boundingSphere.center)):($t.boundingSphere===null&&$t.computeBoundingSphere(),ke.copy($t.boundingSphere.center)),ke.applyMatrix4(D.matrixWorld).applyMatrix4(fe)),Array.isArray(Zt)){const Qt=$t.groups;for(let jt=0,Te=Qt.length;jt<Te;jt++){const Le=Qt[jt],ae=Zt[Le.materialIndex];ae&&ae.visible&&U.push(D,$t,ae,Et,ke.z,Le,$)}}else Zt.visible&&U.push(D,$t,Zt,Et,ke.z,null,$)}}const Kt=D.children;for(let $t=0,Zt=Kt.length;$t<Zt;$t++)wi(Kt[$t],$,Et,gt)}function ha(D,$,Et,gt){const{opaque:vt,transmissive:Kt,transparent:$t}=D;L.setupLightsView(Et),de===!0&&G.setGlobalState(W.clippingPlanes,Et),gt&&A.viewport(I.copy(gt)),vt.length>0&&As(vt,$,Et),Kt.length>0&&As(Kt,$,Et),$t.length>0&&As($t,$,Et),A.buffers.depth.setTest(!0),A.buffers.depth.setMask(!0),A.buffers.color.setMask(!0),A.setPolygonOffset(!1)}function Gi(D,$,Et,gt){if((Et.isScene===!0?Et.overrideMaterial:null)!==null)return;if(L.state.transmissionRenderTarget[gt.id]===void 0){const ae=Ee.has("EXT_color_buffer_half_float")||Ee.has("EXT_color_buffer_float");L.state.transmissionRenderTarget[gt.id]=new Hi(1,1,{generateMipmaps:!0,type:ae?$i:Ti,minFilter:Ks,samples:Math.max(4,H.samples),stencilBuffer:c,resolveDepthBuffer:!1,resolveStencilBuffer:!1,storeMultisampledDepthBuffer:!1,storeMultisampledStencilBuffer:!1,colorSpace:Ve.workingColorSpace})}const Kt=L.state.transmissionRenderTarget[gt.id],$t=gt.viewport||I;Kt.setSize($t.z*W.transmissionResolutionScale,$t.w*W.transmissionResolutionScale);const Zt=W.getRenderTarget(),Qt=W.getActiveCubeFace(),jt=W.getActiveMipmapLevel();W.setRenderTarget(Kt),W.getClearColor(It),kt=W.getClearAlpha(),kt<1&&W.setClearColor(16777215,.5),W.clear(),ne&&nt.render(Et);const Te=W.toneMapping;W.toneMapping=ca;const Le=gt.viewport;if(gt.viewport!==void 0&&(gt.viewport=void 0),L.setupLightsView(gt),de===!0&&G.setGlobalState(W.clippingPlanes,gt),As(D,Et,gt),bt.updateMultisampleRenderTarget(Kt),bt.updateRenderTargetMipmap(Kt),Ee.has("WEBGL_multisampled_render_to_texture")===!1){let ae=!1;for(let Xe=0,hn=$.length;Xe<hn;Xe++){const un=$[Xe],{object:Re,geometry:Cn,material:te,group:Pn}=un;if(te.side===cn&&Re.layers.test(gt.layers)){const Ce=te.side;te.side=oi,te.needsUpdate=!0,qa(Re,Et,gt,Cn,te,Pn),te.side=Ce,te.needsUpdate=!0,ae=!0}}ae===!0&&(bt.updateMultisampleRenderTarget(Kt),bt.updateRenderTargetMipmap(Kt))}W.setRenderTarget(Zt,Qt,jt),W.setClearColor(It,kt),Le!==void 0&&(gt.viewport=Le),W.toneMapping=Te}function As(D,$,Et){const gt=$.isScene===!0?$.overrideMaterial:null;for(let vt=0,Kt=D.length;vt<Kt;vt++){const $t=D[vt],{object:Zt,geometry:Qt,group:jt}=$t;let Te=$t.material;Te.allowOverride===!0&&gt!==null&&(Te=gt),Zt.layers.test(Et.layers)&&qa(Zt,$,Et,Qt,Te,jt)}}function qa(D,$,Et,gt,vt,Kt){Q!==null&&vt.isNodeMaterial&&Q.setObject(D,vt),D.onBeforeRender(W,$,Et,gt,vt,Kt),D.modelViewMatrix.multiplyMatrices(Et.matrixWorldInverse,D.matrixWorld),D.normalMatrix.getNormalMatrix(D.modelViewMatrix),vt.onBeforeRender(W,$,Et,gt,D,Kt),vt.transparent===!0&&vt.side===cn&&vt.forceSinglePass===!1?(vt.side=oi,vt.needsUpdate=!0,W.renderBufferDirect(Et,$,gt,vt,D,Kt),vt.side=$s,vt.needsUpdate=!0,W.renderBufferDirect(Et,$,gt,vt,D,Kt),vt.side=cn):W.renderBufferDirect(Et,$,gt,vt,D,Kt),D.onAfterRender(W,$,Et,gt,vt,Kt)}function Ya(D,$,Et){$.isScene!==!0&&($=ze);const gt=mt.get(D),vt=L.state.lights,Kt=L.state.shadowsArray,$t=vt.state.version,Zt=Ot.getParameters(D,vt.state,Kt,$,Et,L.state.lightProbeGridArray),Qt=Ot.getProgramCacheKey(Zt);let jt=gt.programs;gt.environment=D.isMeshStandardMaterial||D.isMeshLambertMaterial||D.isMeshPhongMaterial?$.environment:null,gt.fog=$.fog;const Te=D.isMeshStandardMaterial||D.isMeshLambertMaterial&&!D.envMap||D.isMeshPhongMaterial&&!D.envMap;gt.envMap=Bt.get(D.envMap||gt.environment,Te),gt.envMapRotation=gt.environment!==null&&D.envMap===null?$.environmentRotation:D.envMapRotation,jt===void 0&&(D.addEventListener("dispose",Vt),jt=new Map,gt.programs=jt);let Le=jt.get(Qt);if(Le!==void 0){if(gt.currentProgram===Le&&gt.lightsStateVersion===$t)return pa(D,Zt),Le}else Zt.uniforms=Ot.getUniforms(D),Q!==null&&D.isNodeMaterial&&Q.build(D,Et,Zt),D.onBeforeCompile(Zt,W),Le=Ot.acquireProgram(Zt,Qt),jt.set(Qt,Le),gt.uniforms=Zt.uniforms;const ae=gt.uniforms;return(!D.isShaderMaterial&&!D.isRawShaderMaterial||D.clipping===!0)&&(ae.clippingPlanes=G.uniform),pa(D,Zt),gt.needsLights=zl(D),gt.lightsStateVersion=$t,gt.needsLights&&(ae.ambientLightColor.value=vt.state.ambient,ae.lightProbe.value=vt.state.probe,ae.sunLights.value=vt.state.sun,ae.sunLightShadows.value=vt.state.sunShadow,ae.directionalLights.value=vt.state.directional,ae.directionalLightShadows.value=vt.state.directionalShadow,ae.spotLights.value=vt.state.spot,ae.spotLightShadows.value=vt.state.spotShadow,ae.rectAreaLights.value=vt.state.rectArea,ae.ltc_1.value=vt.state.rectAreaLTC1,ae.ltc_2.value=vt.state.rectAreaLTC2,ae.pointLights.value=vt.state.point,ae.pointLightShadows.value=vt.state.pointShadow,ae.hemisphereLights.value=vt.state.hemi,ae.sunShadowMatrix.value=vt.state.sunShadowMatrix,ae.sunShadowCascade.value=vt.state.sunShadowCascade,ae.directionalShadowMatrix.value=vt.state.directionalShadowMatrix,ae.spotLightMatrix.value=vt.state.spotLightMatrix,ae.spotLightMap.value=vt.state.spotLightMap,ae.pointShadowMatrix.value=vt.state.pointShadowMatrix),gt.lightProbeGrid=L.state.lightProbeGridArray.length>0,gt.currentProgram=Le,gt.uniformsList=null,Le}function da(D){if(D.uniformsList===null){const $=D.currentProgram.getUniforms();D.uniformsList=Tu.seqWithValue($.seq,D.uniforms)}return D.uniformsList}function pa(D,$){const Et=mt.get(D);Et.outputColorSpace=$.outputColorSpace,Et.batching=$.batching,Et.batchingColor=$.batchingColor,Et.instancing=$.instancing,Et.instancingColor=$.instancingColor,Et.instancingMorph=$.instancingMorph,Et.skinning=$.skinning,Et.morphTargets=$.morphTargets,Et.morphNormals=$.morphNormals,Et.morphColors=$.morphColors,Et.morphTargetsCount=$.morphTargetsCount,Et.numClippingPlanes=$.numClippingPlanes,Et.numIntersection=$.numClipIntersection,Et.vertexAlphas=$.vertexAlphas,Et.vertexTangents=$.vertexTangents,Et.toneMapping=$.toneMapping}function ws(D,$){if(D.length===0)return null;if(D.length===1)return D[0].texture!==null?D[0]:null;E.setFromMatrixPosition($.matrixWorld);for(let Et=0,gt=D.length;Et<gt;Et++){const vt=D[Et];if(vt.texture!==null&&vt.boundingBox.containsPoint(E))return vt}return null}function Za(D,$,Et,gt,vt){$.isScene!==!0&&($=ze),bt.resetTextureUnits();const Kt=$.fog,$t=gt.isMeshStandardMaterial||gt.isMeshLambertMaterial||gt.isMeshPhongMaterial?$.environment:null,Zt=ht===null?W.outputColorSpace:ht.isXRRenderTarget===!0?ht.texture.colorSpace:Ve.workingColorSpace,Qt=gt.isMeshStandardMaterial||gt.isMeshLambertMaterial&&!gt.envMap||gt.isMeshPhongMaterial&&!gt.envMap,jt=Bt.get(gt.envMap||$t,Qt),Te=gt.vertexColors===!0&&!!Et.attributes.color&&Et.attributes.color.itemSize===4,Le=!!Et.attributes.tangent&&(!!gt.normalMap||gt.anisotropy>0),ae=!!Et.morphAttributes.position,Xe=!!Et.morphAttributes.normal,hn=!!Et.morphAttributes.color;let un=ca;gt.toneMapped&&(ht===null||ht.isXRRenderTarget===!0)&&(un=W.toneMapping);const Re=Et.morphAttributes.position||Et.morphAttributes.normal||Et.morphAttributes.color,Cn=Re!==void 0?Re.length:0,te=mt.get(gt),Pn=L.state.lights;if(de===!0&&(xe===!0||D!==pt)){const sn=D===pt&&gt.id===dt;G.setState(gt,D,sn)}let Ce=!1;gt.version===te.__version?(te.needsLights&&te.lightsStateVersion!==Pn.state.version||te.outputColorSpace!==Zt||vt.isBatchedMesh&&te.batching===!1||!vt.isBatchedMesh&&te.batching===!0||vt.isBatchedMesh&&te.batchingColor===!0&&vt._colorsTexture===null||vt.isBatchedMesh&&te.batchingColor===!1&&vt._colorsTexture!==null||vt.isInstancedMesh&&te.instancing===!1||!vt.isInstancedMesh&&te.instancing===!0||vt.isSkinnedMesh&&te.skinning===!1||!vt.isSkinnedMesh&&te.skinning===!0||vt.isInstancedMesh&&te.instancingColor===!0&&vt.instanceColor===null||vt.isInstancedMesh&&te.instancingColor===!1&&vt.instanceColor!==null||vt.isInstancedMesh&&te.instancingMorph===!0&&vt.morphTexture===null||vt.isInstancedMesh&&te.instancingMorph===!1&&vt.morphTexture!==null||te.envMap!==jt||gt.fog===!0&&te.fog!==Kt||te.numClippingPlanes!==void 0&&(te.numClippingPlanes!==G.numPlanes||te.numIntersection!==G.numIntersection)||te.vertexAlphas!==Te||te.vertexTangents!==Le||te.morphTargets!==ae||te.morphNormals!==Xe||te.morphColors!==hn||te.toneMapping!==un||te.morphTargetsCount!==Cn||!!te.lightProbeGrid!=L.state.lightProbeGridArray.length>0)&&(Ce=!0):(Ce=!0,te.__version=gt.version);let ni=te.currentProgram;Ce===!0&&(ni=Ya(gt,$,vt),Q&&gt.isNodeMaterial&&Q.onUpdateProgram(gt,ni,te));let pi=!1,ii=!1,Ka=!1;const Je=ni.getUniforms(),vn=te.uniforms;if(A.useProgram(ni.program)&&(pi=!0,ii=!0,Ka=!0),gt.id!==dt&&(dt=gt.id,ii=!0),te.needsLights){const sn=ws(L.state.lightProbeGridArray,vt);te.lightProbeGrid!==sn&&(te.lightProbeGrid=sn,ii=!0)}if(pi||pt!==D){A.buffers.depth.getReversed()&&D.reversedDepth!==!0&&(D._reversedDepth=!0,D.updateProjectionMatrix()),Je.setValue(j,"projectionMatrix",D.projectionMatrix),Je.setValue(j,"viewMatrix",D.matrixWorldInverse);const ta=Je.map.cameraPosition;ta!==void 0&&ta.setValue(j,be.setFromMatrixPosition(D.matrixWorld)),H.logarithmicDepthBuffer&&Je.setValue(j,"logDepthBufFC",2/(Math.log(D.far+1)/Math.LN2)),(gt.isMeshPhongMaterial||gt.isMeshToonMaterial||gt.isMeshLambertMaterial||gt.isMeshBasicMaterial||gt.isMeshStandardMaterial||gt.isShaderMaterial)&&Je.setValue(j,"isOrthographic",D.isOrthographicCamera===!0),pt!==D&&(pt=D,ii=!0,Ka=!0)}if(te.needsLights&&(Pn.state.sunShadowMap.length>0&&Je.setValue(j,"sunShadowMap",Pn.state.sunShadowMap,bt),Pn.state.directionalShadowMap.length>0&&Je.setValue(j,"directionalShadowMap",Pn.state.directionalShadowMap,bt),Pn.state.spotShadowMap.length>0&&Je.setValue(j,"spotShadowMap",Pn.state.spotShadowMap,bt),Pn.state.pointShadowMap.length>0&&Je.setValue(j,"pointShadowMap",Pn.state.pointShadowMap,bt)),vt.isSkinnedMesh){Je.setOptional(j,vt,"bindMatrix"),Je.setOptional(j,vt,"bindMatrixInverse");const sn=vt.skeleton;sn&&(sn.boneTexture===null&&sn.computeBoneTexture(),Je.setValue(j,"boneTexture",sn.boneTexture,bt))}vt.isBatchedMesh&&(Je.setOptional(j,vt,"batchingTexture"),Je.setValue(j,"batchingTexture",vt._matricesTexture,bt),Je.setOptional(j,vt,"batchingIdTexture"),Je.setValue(j,"batchingIdTexture",vt._indirectTexture,bt),Je.setOptional(j,vt,"batchingColorTexture"),vt._colorsTexture!==null&&Je.setValue(j,"batchingColorTexture",vt._colorsTexture,bt));const Ri=Et.morphAttributes;if((Ri.position!==void 0||Ri.normal!==void 0||Ri.color!==void 0)&&w.update(vt,Et,ni),(ii||te.receiveShadow!==vt.receiveShadow)&&(te.receiveShadow=vt.receiveShadow,Je.setValue(j,"receiveShadow",vt.receiveShadow)),(gt.isMeshStandardMaterial||gt.isMeshLambertMaterial||gt.isMeshPhongMaterial)&&gt.envMap===null&&$.environment!==null&&(vn.envMapIntensity.value=$.environmentIntensity),vn.dfgLUT!==void 0&&(vn.dfgLUT.value=N3()),ii){if(Je.setValue(j,"toneMappingExposure",W.toneMappingExposure),te.needsLights&&Rn(vn,Ka),Kt&&gt.fog===!0&&Xt.refreshFogUniforms(vn,Kt),Xt.refreshMaterialUniforms(vn,gt,Tt,ut,L.state.transmissionRenderTarget[D.id]),te.needsLights&&te.lightProbeGrid){const sn=te.lightProbeGrid;vn.probesSH.value=sn.texture,vn.probesMin.value.copy(sn.boundingBox.min),vn.probesMax.value.copy(sn.boundingBox.max),vn.probesResolution.value.copy(sn.resolution)}Tu.upload(j,da(te),vn,bt)}if(gt.isShaderMaterial&&gt.uniformsNeedUpdate===!0&&(Tu.upload(j,da(te),vn,bt),gt.uniformsNeedUpdate=!1),gt.isSpriteMaterial&&Je.setValue(j,"center",vt.center),Je.setValue(j,"modelViewMatrix",vt.modelViewMatrix),Je.setValue(j,"normalMatrix",vt.normalMatrix),Je.setValue(j,"modelMatrix",vt.matrixWorld),gt.uniformsGroups!==void 0){const sn=gt.uniformsGroups;for(let ta=0,Vi=sn.length;ta<Vi;ta++){const Ci=sn[ta];it.update(Ci,ni),it.bind(Ci,ni)}}return ni}function Rn(D,$){D.ambientLightColor.needsUpdate=$,D.lightProbe.needsUpdate=$,D.sunLights.needsUpdate=$,D.sunLightShadows.needsUpdate=$,D.directionalLights.needsUpdate=$,D.directionalLightShadows.needsUpdate=$,D.pointLights.needsUpdate=$,D.pointLightShadows.needsUpdate=$,D.spotLights.needsUpdate=$,D.spotLightShadows.needsUpdate=$,D.rectAreaLights.needsUpdate=$,D.hemisphereLights.needsUpdate=$}function zl(D){return D.isMeshLambertMaterial||D.isMeshToonMaterial||D.isMeshPhongMaterial||D.isMeshStandardMaterial||D.isShadowMaterial||D.isShaderMaterial&&D.lights===!0}this.getActiveCubeFace=function(){return F},this.getActiveMipmapLevel=function(){return Z},this.getRenderTarget=function(){return ht},this.setRenderTargetTextures=function(D,$,Et){const gt=mt.get(D);gt.__autoAllocateDepthBuffer=D.resolveDepthBuffer===!1,gt.__autoAllocateDepthBuffer===!1&&(gt.__useRenderToTexture=!1),mt.get(D.texture).__webglTexture=$,mt.get(D.depthTexture).__webglTexture=gt.__autoAllocateDepthBuffer?void 0:Et,gt.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(D,$){const Et=mt.get(D);Et.__webglFramebuffer=$,Et.__useDefaultFramebuffer=$===void 0},this.setRenderTarget=function(D,$=0,Et=0){ht=D,F=$,Z=Et;let gt=null,vt=!1,Kt=!1;if(D){const Zt=mt.get(D);if(Zt.__useDefaultFramebuffer!==void 0){A.bindFramebuffer(j.FRAMEBUFFER,Zt.__webglFramebuffer),I.copy(D.viewport),ct.copy(D.scissor),At=D.scissorTest,A.viewport(I),A.scissor(ct),A.setScissorTest(At),dt=-1;return}else if(Zt.__webglFramebuffer===void 0)bt.setupRenderTarget(D);else if(Zt.__hasExternalTextures)bt.rebindTextures(D,mt.get(D.texture).__webglTexture,mt.get(D.depthTexture).__webglTexture);else if(D.depthBuffer){const Te=D.depthTexture;if(Zt.__boundDepthTexture!==Te){if(Te!==null&&mt.has(Te)&&(D.width!==Te.image.width||D.height!==Te.image.height))throw new Error("THREE.WebGLRenderer: Attached DepthTexture is initialized to the incorrect size.");bt.setupDepthRenderbuffer(D)}}const Qt=D.texture;(Qt.isData3DTexture||Qt.isDataArrayTexture||Qt.isCompressedArrayTexture)&&(Kt=!0);const jt=mt.get(D).__webglFramebuffer;D.isWebGLCubeRenderTarget?(Array.isArray(jt[$])?gt=jt[$][Et]:gt=jt[$],vt=!0):D.samples>0&&bt.useMultisampledRTT(D)===!1?gt=mt.get(D).__webglMultisampledFramebuffer:Array.isArray(jt)?gt=jt[Et]:gt=jt,I.copy(D.viewport),ct.copy(D.scissor),At=D.scissorTest}else I.copy(qt).multiplyScalar(Tt).floor(),ct.copy(re).multiplyScalar(Tt).floor(),At=Fe;if(Et!==0&&(gt=et),A.bindFramebuffer(j.FRAMEBUFFER,gt)&&A.drawBuffers(D,gt),A.viewport(I),A.scissor(ct),A.setScissorTest(At),vt){const Zt=mt.get(D.texture);j.framebufferTexture2D(j.FRAMEBUFFER,j.COLOR_ATTACHMENT0,j.TEXTURE_CUBE_MAP_POSITIVE_X+$,Zt.__webglTexture,Et)}else if(Kt){const Zt=$;for(let Qt=0;Qt<D.textures.length;Qt++){const jt=mt.get(D.textures[Qt]);j.framebufferTextureLayer(j.FRAMEBUFFER,j.COLOR_ATTACHMENT0+Qt,jt.__webglTexture,Et,Zt)}}else if(D!==null&&Et!==0){const Zt=mt.get(D.texture);j.framebufferTexture2D(j.FRAMEBUFFER,j.COLOR_ATTACHMENT0,j.TEXTURE_2D,Zt.__webglTexture,Et)}dt=-1};function mo(D){const $=mt.get(D);return($.__readFormat!==D.format||$.__readType!==D.type)&&($.__readFormat=D.format,$.__readType=D.type,$.__formatReadable=H.textureFormatReadable(D.format),$.__typeReadable=H.textureTypeReadable(D.type)),$}this.readRenderTargetPixels=function(D,$,Et,gt,vt,Kt,$t,Zt=0){if(!(D&&D.isWebGLRenderTarget)){We("WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let Qt=mt.get(D).__webglFramebuffer;if(D.isWebGLCubeRenderTarget&&$t!==void 0&&(Qt=Qt[$t]),Qt){A.bindFramebuffer(j.FRAMEBUFFER,Qt);try{const jt=D.textures[Zt],Te=jt.format,Le=jt.type;D.textures.length>1&&j.readBuffer(j.COLOR_ATTACHMENT0+Zt);const ae=mo(jt);if(ae.__formatReadable===!1){We("WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(ae.__typeReadable===!1){We("WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}$>=0&&$<=D.width-gt&&Et>=0&&Et<=D.height-vt&&j.readPixels($,Et,gt,vt,st.convert(Te),st.convert(Le),Kt)}finally{const jt=ht!==null?mt.get(ht).__webglFramebuffer:null;A.bindFramebuffer(j.FRAMEBUFFER,jt)}}},this.readRenderTargetPixelsAsync=async function(D,$,Et,gt,vt,Kt,$t,Zt=0){if(!(D&&D.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let Qt=mt.get(D).__webglFramebuffer;if(D.isWebGLCubeRenderTarget&&$t!==void 0&&(Qt=Qt[$t]),Qt)if($>=0&&$<=D.width-gt&&Et>=0&&Et<=D.height-vt){A.bindFramebuffer(j.FRAMEBUFFER,Qt);const jt=D.textures[Zt],Te=jt.format,Le=jt.type;D.textures.length>1&&j.readBuffer(j.COLOR_ATTACHMENT0+Zt);const ae=mo(jt);if(ae.__formatReadable===!1)throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(ae.__typeReadable===!1)throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");const Xe=j.createBuffer();j.bindBuffer(j.PIXEL_PACK_BUFFER,Xe),j.bufferData(j.PIXEL_PACK_BUFFER,Kt.byteLength,j.STREAM_READ),j.readPixels($,Et,gt,vt,st.convert(Te),st.convert(Le),0),j.bindBuffer(j.PIXEL_PACK_BUFFER,null);const hn=ht!==null?mt.get(ht).__webglFramebuffer:null;A.bindFramebuffer(j.FRAMEBUFFER,hn);const un=j.fenceSync(j.SYNC_GPU_COMMANDS_COMPLETE,0);return j.flush(),await r1(j,un,4),j.bindBuffer(j.PIXEL_PACK_BUFFER,Xe),j.getBufferSubData(j.PIXEL_PACK_BUFFER,0,Kt),j.bindBuffer(j.PIXEL_PACK_BUFFER,null),j.deleteBuffer(Xe),j.deleteSync(un),Kt}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")},this.copyFramebufferToTexture=function(D,$=null,Et=0){const gt=Math.pow(2,-Et),vt=Math.floor(D.image.width*gt),Kt=Math.floor(D.image.height*gt),$t=$!==null?$.x:0,Zt=$!==null?$.y:0;bt.setTexture2D(D,0),j.copyTexSubImage2D(j.TEXTURE_2D,Et,0,0,$t,Zt,vt,Kt),A.unbindTexture()},this.copyTextureToTexture=function(D,$,Et=null,gt=null,vt=0,Kt=0){let $t,Zt,Qt,jt,Te,Le,ae,Xe,hn;const un=D.isCompressedTexture?D.mipmaps[Kt]:D.image;if(Et!==null)$t=Et.max.x-Et.min.x,Zt=Et.max.y-Et.min.y,Qt=Et.isBox3?Et.max.z-Et.min.z:1,jt=Et.min.x,Te=Et.min.y,Le=Et.isBox3?Et.min.z:0;else{const vn=Math.pow(2,-vt);$t=Math.floor(un.width*vn),Zt=Math.floor(un.height*vn),D.isDataArrayTexture?Qt=un.depth:D.isData3DTexture?Qt=Math.floor(un.depth*vn):Qt=1,jt=0,Te=0,Le=0}gt!==null?(ae=gt.x,Xe=gt.y,hn=gt.z):(ae=0,Xe=0,hn=0);const Re=st.convert($.format),Cn=st.convert($.type);let te;$.isData3DTexture?(bt.setTexture3D($,0),te=j.TEXTURE_3D):$.isDataArrayTexture||$.isCompressedArrayTexture?(bt.setTexture2DArray($,0),te=j.TEXTURE_2D_ARRAY):(bt.setTexture2D($,0),te=j.TEXTURE_2D),A.activeTexture(j.TEXTURE0),A.pixelStorei(j.UNPACK_FLIP_Y_WEBGL,$.flipY),A.pixelStorei(j.UNPACK_PREMULTIPLY_ALPHA_WEBGL,$.premultiplyAlpha),A.pixelStorei(j.UNPACK_ALIGNMENT,$.unpackAlignment);const Pn=A.getParameter(j.UNPACK_ROW_LENGTH),Ce=A.getParameter(j.UNPACK_IMAGE_HEIGHT),ni=A.getParameter(j.UNPACK_SKIP_PIXELS),pi=A.getParameter(j.UNPACK_SKIP_ROWS),ii=A.getParameter(j.UNPACK_SKIP_IMAGES);A.pixelStorei(j.UNPACK_ROW_LENGTH,un.width),A.pixelStorei(j.UNPACK_IMAGE_HEIGHT,un.height),A.pixelStorei(j.UNPACK_SKIP_PIXELS,jt),A.pixelStorei(j.UNPACK_SKIP_ROWS,Te),A.pixelStorei(j.UNPACK_SKIP_IMAGES,Le);const Ka=D.isDataArrayTexture||D.isData3DTexture,Je=$.isDataArrayTexture||$.isData3DTexture;if(D.isDepthTexture){const vn=mt.get(D),Ri=mt.get($),sn=mt.get(vn.__renderTarget),ta=mt.get(Ri.__renderTarget);A.bindFramebuffer(j.READ_FRAMEBUFFER,sn.__webglFramebuffer),A.bindFramebuffer(j.DRAW_FRAMEBUFFER,ta.__webglFramebuffer);for(let Vi=0;Vi<Qt;Vi++)Ka&&(j.framebufferTextureLayer(j.READ_FRAMEBUFFER,j.COLOR_ATTACHMENT0,mt.get(D).__webglTexture,vt,Le+Vi),j.framebufferTextureLayer(j.DRAW_FRAMEBUFFER,j.COLOR_ATTACHMENT0,mt.get($).__webglTexture,Kt,hn+Vi)),j.blitFramebuffer(jt,Te,$t,Zt,ae,Xe,$t,Zt,j.DEPTH_BUFFER_BIT,j.NEAREST);A.bindFramebuffer(j.READ_FRAMEBUFFER,null),A.bindFramebuffer(j.DRAW_FRAMEBUFFER,null)}else if(vt!==0||D.isRenderTargetTexture||mt.has(D)){const vn=mt.get(D),Ri=mt.get($);A.bindFramebuffer(j.READ_FRAMEBUFFER,k),A.bindFramebuffer(j.DRAW_FRAMEBUFFER,q);for(let sn=0;sn<Qt;sn++)Ka?j.framebufferTextureLayer(j.READ_FRAMEBUFFER,j.COLOR_ATTACHMENT0,vn.__webglTexture,vt,Le+sn):j.framebufferTexture2D(j.READ_FRAMEBUFFER,j.COLOR_ATTACHMENT0,j.TEXTURE_2D,vn.__webglTexture,vt),Je?j.framebufferTextureLayer(j.DRAW_FRAMEBUFFER,j.COLOR_ATTACHMENT0,Ri.__webglTexture,Kt,hn+sn):j.framebufferTexture2D(j.DRAW_FRAMEBUFFER,j.COLOR_ATTACHMENT0,j.TEXTURE_2D,Ri.__webglTexture,Kt),vt!==0?j.blitFramebuffer(jt,Te,$t,Zt,ae,Xe,$t,Zt,j.COLOR_BUFFER_BIT,j.NEAREST):Je?j.copyTexSubImage3D(te,Kt,ae,Xe,hn+sn,jt,Te,$t,Zt):j.copyTexSubImage2D(te,Kt,ae,Xe,jt,Te,$t,Zt);A.bindFramebuffer(j.READ_FRAMEBUFFER,null),A.bindFramebuffer(j.DRAW_FRAMEBUFFER,null)}else Je?D.isDataTexture||D.isData3DTexture?j.texSubImage3D(te,Kt,ae,Xe,hn,$t,Zt,Qt,Re,Cn,un.data):$.isCompressedArrayTexture?j.compressedTexSubImage3D(te,Kt,ae,Xe,hn,$t,Zt,Qt,Re,un.data):j.texSubImage3D(te,Kt,ae,Xe,hn,$t,Zt,Qt,Re,Cn,un):D.isDataTexture?j.texSubImage2D(j.TEXTURE_2D,Kt,ae,Xe,$t,Zt,Re,Cn,un.data):D.isCompressedTexture?j.compressedTexSubImage2D(j.TEXTURE_2D,Kt,ae,Xe,un.width,un.height,Re,un.data):j.texSubImage2D(j.TEXTURE_2D,Kt,ae,Xe,$t,Zt,Re,Cn,un);A.pixelStorei(j.UNPACK_ROW_LENGTH,Pn),A.pixelStorei(j.UNPACK_IMAGE_HEIGHT,Ce),A.pixelStorei(j.UNPACK_SKIP_PIXELS,ni),A.pixelStorei(j.UNPACK_SKIP_ROWS,pi),A.pixelStorei(j.UNPACK_SKIP_IMAGES,ii),Kt===0&&$.generateMipmaps&&j.generateMipmap(te),A.unbindTexture()},this.initRenderTarget=function(D){mt.get(D).__webglFramebuffer===void 0&&bt.setupRenderTarget(D)},this.initTexture=function(D){D.isCubeTexture?bt.setTextureCube(D,0):D.isData3DTexture?bt.setTexture3D(D,0):D.isDataArrayTexture||D.isCompressedArrayTexture?bt.setTexture2DArray(D,0):bt.setTexture2D(D,0),A.unbindTexture()},this.resetState=function(){F=0,Z=0,ht=null,A.reset(),rt.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return la}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(t){this._outputColorSpace=t;const n=this.getContext();n.drawingBufferColorSpace=Ve._getDrawingBufferColorSpace(t),n.unpackColorSpace=Ve._getUnpackColorSpace()}}class P3{constructor(t,n,a,o){this.canvas=t,this.kind=n,this.builder=a,this.scene=new I1,this.camera=new Ei(56,1,.055,240),this.recipe=null,this.raf=0,this.running=!1,this.disposed=!1,this.width=1,this.height=1,this.elapsed=0,this.frame=0,this.previous=0,this.baseRotation=new Ai,this.targetLook=new Lt,this.look=new Lt,this.lookRotation=new Ai,this.euler=new Xa(0,0,0,"YXZ"),this.renderer=new O3({canvas:t,antialias:!0,alpha:!1,powerPreference:"high-performance"}),this.renderer.outputColorSpace=In,this.renderer.toneMapping=zp,this.renderer.toneMappingExposure=1.1,this.renderer.shadowMap.enabled=!0,this.renderer.shadowMap.type=mx,this.contextLost=c=>{c.preventDefault(),o()},t.addEventListener("webglcontextlost",this.contextLost),t.dataset.world=n}async init(){this.recipe=this.builder({scene:this.scene,camera:this.camera,renderer:this.renderer}),this.applyComposition()}setSize(t,n,a){this.width=Math.max(1,t),this.height=Math.max(1,n),this.renderer.setPixelRatio(Math.min(2,Math.max(1,a))),this.renderer.setSize(this.width,this.height,!1),this.applyComposition()}applyComposition(){var t;this.camera.aspect=this.width/this.height,(t=this.recipe)==null||t.resize(this.camera.aspect),this.camera.updateProjectionMatrix(),this.baseRotation.copy(this.camera.quaternion)}renderFrame(t){if(this.disposed||!this.recipe)return;const n=Math.max(0,Math.min(t,.06));this.elapsed+=n,this.look.lerp(this.targetLook,n===0?1:1-Math.exp(-n*7)),this.euler.set(this.look.y,this.look.x,0),this.lookRotation.setFromEuler(this.euler),this.camera.quaternion.copy(this.baseRotation).multiply(this.lookRotation),this.camera.updateMatrixWorld(),this.recipe.update(this.elapsed,n),this.renderer.setRenderTarget(null),this.renderer.render(this.scene,this.camera),this.canvas.dataset.frame=String(++this.frame),this.canvas.dataset.time=this.elapsed.toFixed(4),this.canvas.dataset.drawCalls=String(this.renderer.info.render.calls),this.canvas.dataset.triangles=String(this.renderer.info.render.triangles),this.canvas.dataset.geometries=String(this.renderer.info.memory.geometries),this.canvas.dataset.textures=String(this.renderer.info.memory.textures)}start(){if(this.running||this.disposed)return;this.running=!0,this.previous=performance.now();const t=n=>{if(!this.running||this.disposed)return;const a=(n-this.previous)/1e3;this.previous=n,this.renderFrame(a),this.raf=requestAnimationFrame(t)};this.raf=requestAnimationFrame(t)}stop(){this.running=!1,cancelAnimationFrame(this.raf),this.raf=0,this.targetLook.set(0,0)}drag(t,n){this.targetLook.set(Qs.clamp(-t*.24,-.15,.15),Qs.clamp(-n*.18,-.09,.09))}releaseDrag(){this.targetLook.set(0,0)}interact(t,n,a=!1){var c;const o=(c=this.recipe)==null?void 0:c.interact(t,n,a,!this.running);return o?(this.renderFrame(0),{world:this.kind,action:o.action,value:Qs.clamp(o.value,0,1)}):null}dispose(){var o,c;if(this.disposed)return;this.disposed=!0,this.stop(),this.canvas.removeEventListener("webglcontextlost",this.contextLost),(c=(o=this.recipe)==null?void 0:o.dispose)==null||c.call(o);const t=new Set,n=new Set,a=new Set;this.scene.traverse(u=>{var g;const h=u;h.geometry&&t.add(h.geometry);const m=h.material?Array.isArray(h.material)?h.material:[h.material]:[];for(const _ of m){n.add(_);for(const v of Object.values(_))v instanceof Wn&&a.add(v);if(_ instanceof ei)for(const v of Object.values(_.uniforms))v.value instanceof Wn&&a.add(v.value)}(g=u.shadow)==null||g.dispose()});for(const u of a)u.dispose();for(const u of n)u.dispose();for(const u of t)u.dispose();this.scene.clear(),this.renderer.dispose(),this.renderer.forceContextLoss(),this.recipe=null}}class z3 extends Ey{constructor(){super(...arguments),this.gestureCancellers=new Map}registerGesture(t,n){return this.gestureCancellers.set(t,n),()=>{this.gestureCancellers.delete(t)}}acquire(t){this.gestureCancellers.forEach(a=>a());const n=super.acquire(t);return()=>{this.gestureCancellers.forEach(a=>a()),n()}}owns(t){return this.top===t}interact(t,n,a,o=!1){var c;return this.top===t?((c=this.engine)==null?void 0:c.interact(n,a,o))??null:null}}const fx=new Map;function I3(r,t){let n=fx.get(r);return n||(n=new z3({canvasClass:"rain-shelter-canvas",isSupported:()=>typeof WebGL2RenderingContext<"u",create:(a,o)=>new P3(a,r,t,o)}),fx.set(r,n)),n}const Id={tent:["텐트 속 빗소리","텐트 입구 조절"],window:["비 오는 창가","유리에 빗방울 길 내기"],porch:["장마철 처마","돌확 물결 만들기"],storm:["여름 뇌우","차양 열림 조절"]};function Wu({active:r,onInteraction:t,static3D:n=!1,kind:a,builder:o}){const c=Vn.useRef(null),u=Vn.useRef(null),h=Vn.useRef(null),m=Vn.useRef(t);m.current=t;const[p,g]=Vn.useState("loading"),[_,v]=Vn.useState(null),b=Ty(r)&&!n,R=I3(a,o);Vn.useEffect(()=>{if(!u.current)return;const C={mount:u.current,running:!1,onStatus:g};h.current=C;const O=R.acquire(C);return()=>{h.current=null,O()}},[R]),Vn.useEffect(()=>{h.current&&R.setRunning(h.current,b)},[R,b,p]);const M=(C,O,E=!1)=>{var P;const U=h.current;if(!U||!r||p!=="ready")return;const L=R.interact(U,C,O,E);L&&(v(L.value),(P=m.current)==null||P.call(m,L))},S=Vn.useRef(M);return S.current=M,Vn.useEffect(()=>{const C=c.current,O=h.current;if(!C||!O||!r||p!=="ready")return;const E=C.closest("[data-scene-surface]")??C,U='button, input, select, textarea, a[href], summary, label, [contenteditable]:not([contenteditable="false"]), [role="button"], [role="link"], [role="slider"], [role="switch"], [role="checkbox"], [role="radio"], [tabindex]:not([tabindex="-1"]), [data-scene-control], [data-scene-no-drag], [inert]';let L=null;const P=k=>{if(!L||k.pointerId!==L.id)return;if(!R.owns(O)){W();return}const q=k.clientX-L.x,F=k.clientY-L.y;if(Math.hypot(q,F)>8&&(L.moved=!0),L.moved&&b){C.dataset.look="drag";const Z=Math.max(1,Math.min(C.clientWidth,C.clientHeight));R.drag(O,q/Z,F/Z)}},T=(k,q=!0)=>{if(!L||k&&k.pointerId!==L.id)return;const F=L;L=null,delete C.dataset.look,R.releaseDrag(O),window.removeEventListener("pointermove",P),window.removeEventListener("pointerup",z),window.removeEventListener("pointercancel",W);const Z=(k==null?void 0:k.target)instanceof Element?k.target:null;if(!q&&k&&R.owns(O)&&!(Z!=null&&Z.closest(U))&&!F.moved&&Math.hypot(k.clientX-F.x,k.clientY-F.y)<=8){const ht=C.getBoundingClientRect();k.clientX>=ht.left&&k.clientX<=ht.right&&k.clientY>=ht.top&&k.clientY<=ht.bottom&&S.current((k.clientX-ht.left)/ht.width*2-1,1-(k.clientY-ht.top)/ht.height*2)}},z=k=>T(k,!1),W=k=>T(k,!0),J=k=>{if(L||!R.owns(O)||!k.isPrimary||k.button!==0)return;const q=k.target instanceof Element?k.target:null;if(!q||q.closest(U)||!E.contains(q)||E!==C&&q.closest("[data-scene-surface]")!==E||!C.contains(q)&&!q.hasAttribute("data-scene-drag"))return;const F=C.getBoundingClientRect();k.clientX<F.left||k.clientX>F.right||k.clientY<F.top||k.clientY>F.bottom||(k.pointerType==="mouse"&&k.preventDefault(),L={id:k.pointerId,x:k.clientX,y:k.clientY,moved:!1},window.addEventListener("pointermove",P),window.addEventListener("pointerup",z),window.addEventListener("pointercancel",W))},Q=()=>W(),et=R.registerGesture(O,Q);return E.addEventListener("pointerdown",J),window.addEventListener("blur",Q),()=>{et(),E.removeEventListener("pointerdown",J),window.removeEventListener("blur",Q),W()}},[r,R,b,p]),je.jsxs("div",{ref:c,className:`rain-shelter rain-shelter-${a}`,"data-world":a,"data-state":p,"data-motion":b?"running":"paused","data-interaction-value":_??"",role:"group","aria-label":`${Id[a][0]} 3D 풍경`,children:[je.jsx("div",{ref:u,className:"rain-shelter-mount"}),p==="ready"&&je.jsxs("button",{className:"rain-shelter-action","aria-label":Id[a][1],disabled:!r,onClick:()=>M(0,0,!0),children:[Id[a][1],je.jsx("span",{"aria-hidden":"true",children:" ↗"})]}),p==="loading"&&je.jsx("span",{className:"rain-shelter-status",role:"status",children:"쉼터를 준비하고 있어요"}),p==="failed"&&je.jsx("span",{className:"rain-shelter-status",role:"status",children:"이 환경에서 3D 풍경을 표시할 수 없습니다."})]})}function B3(r,t=!1){const n=r[0].index!==null,a=new Set(Object.keys(r[0].attributes)),o=new Set(Object.keys(r[0].morphAttributes)),c={},u={},h=r[0].morphTargetsRelative,m=new Ne;let p=0;for(let g=0;g<r.length;++g){const _=r[g];let v=0;if(n!==(_.index!==null))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+g+". All geometries must have compatible attributes; make sure index attribute exists among all geometries, or in none of them."),null;for(const x in _.attributes){if(!a.has(x))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+g+'. All geometries must have compatible attributes; make sure "'+x+'" attribute exists among all geometries, or in none of them.'),null;c[x]===void 0&&(c[x]=[]),c[x].push(_.attributes[x]),v++}if(v!==a.size)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+g+". Make sure all geometries have the same number of attributes."),null;if(h!==_.morphTargetsRelative)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+g+". .morphTargetsRelative must be consistent throughout all geometries."),null;for(const x in _.morphAttributes){if(!o.has(x))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+g+".  .morphAttributes must be consistent throughout all geometries."),null;u[x]===void 0&&(u[x]=[]),u[x].push(_.morphAttributes[x])}if(t){let x;if(n)x=_.index.count;else if(_.attributes.position!==void 0)x=_.attributes.position.count;else return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+g+". The geometry must have either an index or a position attribute"),null;m.addGroup(p,x,g),p+=x}}if(n){let g=0;const _=[];for(let v=0;v<r.length;++v){const x=r[v].index;for(let b=0;b<x.count;++b)_.push(x.getX(b)+g);g+=r[v].attributes.position.count}m.setIndex(_)}for(const g in c){const _=hx(c[g]);if(!_)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+g+" attribute."),null;m.setAttribute(g,_)}for(const g in u){const _=u[g][0].length;if(_!==0){m.morphAttributes=m.morphAttributes||{},m.morphAttributes[g]=[];for(let v=0;v<_;++v){const x=[];for(let R=0;R<u[g].length;++R)x.push(u[g][R][v]);const b=hx(x);if(!b)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+g+" morphAttribute."),null;m.morphAttributes[g].push(b)}}}return m}function hx(r){let t,n,a,o=-1,c=0;for(let p=0;p<r.length;++p){const g=r[p];if(t===void 0&&(t=g.array.constructor),t!==g.array.constructor)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.array must be of consistent array types across matching attributes."),null;if(n===void 0&&(n=g.itemSize),n!==g.itemSize)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.itemSize must be consistent across matching attributes."),null;if(a===void 0&&(a=g.normalized),a!==g.normalized)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.normalized must be consistent across matching attributes."),null;if(o===-1&&(o=g.gpuType),o!==g.gpuType)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.gpuType must be consistent across matching attributes."),null;c+=g.count*n}const u=new t(c),h=new qn(u,n,a);let m=0;for(let p=0;p<r.length;++p){const g=r[p];if(g.isInterleavedBufferAttribute){const _=m/n;for(let v=0,x=g.count;v<x;v++)for(let b=0;b<n;b++){const R=g.getComponent(v,b);h.setComponent(v+_,b,R)}}else u.set(g.array,m);m+=g.count*n}return o!==void 0&&(h.gpuType=o),h}function F3(r,t=1e-4){t=Math.max(t,Number.EPSILON);const n={},a=r.getIndex(),o=r.getAttribute("position"),c=a?a.count:o.count;let u=0;const h=Object.keys(r.attributes),m={},p={},g=[],_=["getX","getY","getZ","getW"],v=["setX","setY","setZ","setW"];for(let C=0,O=h.length;C<O;C++){const E=h[C],U=r.attributes[E];m[E]=new U.constructor(new U.array.constructor(U.count*U.itemSize),U.itemSize,U.normalized);const L=r.morphAttributes[E];L&&(p[E]||(p[E]=[]),L.forEach((P,T)=>{const z=new P.array.constructor(P.count*P.itemSize);p[E][T]=new P.constructor(z,P.itemSize,P.normalized)}))}const x=t*.5,b=Math.log10(1/t),R=Math.pow(10,b),M=x*R;for(let C=0;C<c;C++){const O=a?a.getX(C):C;let E="";for(let U=0,L=h.length;U<L;U++){const P=h[U],T=r.getAttribute(P),z=T.itemSize;for(let W=0;W<z;W++)E+=`${Math.trunc(T[_[W]](O)*R+M)},`}if(E in n)g.push(n[E]);else{for(let U=0,L=h.length;U<L;U++){const P=h[U],T=r.getAttribute(P),z=r.morphAttributes[P],W=T.itemSize,J=m[P],Q=p[P];for(let et=0;et<W;et++){const k=_[et],q=v[et];if(J[q](u,T[k](O)),z)for(let F=0,Z=z.length;F<Z;F++)Q[F][q](u,z[F][k](O))}}n[E]=u,g.push(u),u++}}const S=r.clone();for(const C in r.attributes){const O=m[C];if(S.setAttribute(C,new O.constructor(O.array.slice(0,u*O.itemSize),O.itemSize,O.normalized)),C in p)for(let E=0;E<p[C].length;E++){const U=p[C][E];S.morphAttributes[C][E]=new U.constructor(U.array.slice(0,u*U.itemSize),U.itemSize,U.normalized)}}return S.setIndex(g),S}function nm(r){return()=>{r|=0,r=r+1831565813|0;let t=Math.imul(r^r>>>15,1|r);return t=t+Math.imul(t^t>>>7,61|t)^t,((t^t>>>14)>>>0)/4294967296}}function za(r,t,n=.78){const a=document.createElement("canvas");a.width=a.height=512;const o=a.getContext("2d"),c=nm(r.charCodeAt(0)*67),u=o.createImageData(512,512);for(let p=0;p<512;p++)for(let g=0;g<512;g++){let _=220;if(r==="wood"){const x=4*Math.sin(p*.018)+1.7*Math.sin(p*.062);_+=Math.sin((g+x)*.28)*13+Math.sin((g+x)*1.19)*5+(c()-.5)*22}else r==="fabric"?_+=(g%4<2?9:-12)+(p%4<2?8:-10)+(c()-.5)*13:r==="leaf"?_+=Math.cos(g*.044)*9+(c()-.5)*10:_+=(c()-.5)*38+Math.sin(g*.063+Math.sin(p*.027)*3)*7+Math.cos(p*.071)*5;const v=(p*512+g)*4;u.data[v]=u.data[v+1]=u.data[v+2]=_,u.data[v+3]=255}if(o.putImageData(u,0,0),r==="wood")for(let p=0;p<34;p++){const g=c()*512;o.beginPath(),o.moveTo(g,0);for(let _=0;_<=512;_+=8)o.lineTo(g+3*Math.sin(_*.025+p),_);o.strokeStyle=`rgba(48,30,17,${.035+c()*.1})`,o.lineWidth=.5+c(),o.stroke()}const h=new ar(a);h.colorSpace=In,h.wrapS=h.wrapT=Va,h.anisotropy=4;const m=h.clone();return m.colorSpace=Ia,new me({color:t,map:h,bumpMap:m,bumpScale:r==="stone"?.028:r==="fabric"?.012:.017,roughness:n,metalness:0})}function H3(r,t={}){const{count:n=900,width:a=18,height:o=13,depth:c=22,z:u=-12,speed:h=7.5,color:m="#c8dadd",opacity:p=.25}=t,g=nm(711),_=new Float32Array(n*6),v=new Float32Array(n*2);for(let M=0;M<n;M++){const S=(g()-.5)*a,C=g()*o,O=u+(g()-.5)*c;for(let E=0;E<2;E++){const U=M*6+E*3;_[U]=S,_[U+1]=C,_[U+2]=O,v[M*2+E]=E}}const x=new Ne;x.setAttribute("position",new qn(_,3)),x.setAttribute("aEnd",new qn(v,1));const b=new ei({transparent:!0,depthWrite:!1,uniforms:{uTime:{value:0},uColor:{value:new ue(m)},uOpacity:{value:p}},vertexShader:`attribute float aEnd; uniform float uTime; varying float vDepth; void main(){vec3 p=position;p.y=mod(p.y-uTime*${h.toFixed(3)}+10000.,${o.toFixed(3)})-.2;p.y+=aEnd*.18;p.x+=aEnd*.045;vec4 mv=modelViewMatrix*vec4(p,1.);vDepth=-mv.z;gl_Position=projectionMatrix*mv;}`,fragmentShader:`uniform vec3 uColor; uniform float uOpacity; varying float vDepth; void main(){gl_FragColor=vec4(uColor,uOpacity*clamp(1.-vDepth/70.,.1,1.)); #include <tonemapping_fragment>
 #include <colorspace_fragment>
}`.replace("; #include",`;
#include`)}),R=new ir(x,b);return R.frustumCulled=!1,R.name="outside-rain",r.add(R),{update(M){b.uniforms.uTime.value=M},mesh:R}}const G3=({scene:r,camera:t})=>{var Wt,ot;const n=nm(190719);r.background=new ue("#586d69"),r.fog=new fo("#677e78",.052),r.add(new Hu("#b7d3d3","#343b2b",1.15));const a=new Gu("#c5e0df",1.8);a.position.set(-6,12,-10),r.add(a);const o=new Ol("#efd9b3",1.4,7,2);o.position.set(0,1.3,2),r.add(o);const c=(G,Y=512)=>{const nt=document.createElement("canvas");nt.width=nt.height=Y;const w=nt.getContext("2d");G(w);const V=new ar(nt);return V.wrapS=V.wrapT=Va,V.colorSpace=In,V.anisotropy=4,V},u=c(G=>{G.fillStyle="#bbb59f",G.fillRect(0,0,512,512);for(let Y=0;Y<512;Y+=2)G.strokeStyle=Y%4?"rgba(55,43,28,.08)":"rgba(247,228,177,.13)",G.beginPath(),G.moveTo(Y,0),G.lineTo(Y,512),G.stroke(),G.beginPath(),G.moveTo(0,Y),G.lineTo(512,Y),G.stroke();for(let Y=0;Y<5500;Y++)G.fillStyle=`rgba(32,29,21,${n()*.06})`,G.fillRect(n()*512,n()*512,1,1);for(let Y=0;Y<7;Y++){const nt=n()*512,w=G.createLinearGradient(nt-12,0,nt+12,0);w.addColorStop(0,"rgba(50,41,28,0)"),w.addColorStop(.5,"rgba(50,41,28,.055)"),w.addColorStop(1,"rgba(240,226,179,0)"),G.fillStyle=w,G.fillRect(nt-12,0,24,512)}});u.repeat.set(6,12);const h=new me({map:u,color:"#d5d2b7",roughness:.94,side:cn,bumpMap:u,bumpScale:.006}),m=za("fabric","#796444",.97),p=new me({color:"#3e4947",metalness:.7,roughness:.38}),g=new me({color:"#d3bd8c",roughness:.94}),_=(G,Y,nt=0,w=0,V=0,X=r)=>{const st=new le(G,Y);return st.position.set(nt,w,V),X.add(st),st},v=(G,Y,nt,w=r,V=32)=>_(new Ll(new Nu(G),V,Y,6,!1),nt,0,0,0,w),x=new Ne,b=[],R=[],M=[],S=72,C=44,O=(G,Y)=>{const nt=G*Math.PI,w=-1.72+Y*6.1,V=.052*Math.sin(Y*Math.PI)*Math.sin(nt*19+Y*7)+.025*Math.sin(nt*31+Y*17)*Math.sin(nt);return new B(Math.cos(nt)*(2.08+V),.025+Math.sin(nt)*(2.12+V),w)};for(let G=0;G<=C;G++)for(let Y=0;Y<=S;Y++){const nt=O(Y/S,G/C);b.push(nt.x,nt.y,nt.z),R.push(Y/S,G/C)}for(let G=0;G<C;G++)for(let Y=0;Y<S;Y++){const nt=G*(S+1)+Y,w=nt+S+1;M.push(nt,w,nt+1,w,w+1,nt+1)}x.setAttribute("position",new ce(b,3)),x.setAttribute("uv",new ce(R,2)),x.setIndex(M),x.computeVertexNormals(),_(x,h);for(const G of[0,.43,.88]){const Y=Array.from({length:45},(nt,w)=>O(w/44,G));v(Y,.027,p),v(Y.map(nt=>nt.clone().add(new B(0,-.024,.034))),.017,m)}for(const G of[.16,.36,.65,.84])v(Array.from({length:26},(Y,nt)=>O(G,nt/25).multiply(new B(.993,.994,1))),.008,m);const E=_(new kn(4.17,6.35,10,18),za("fabric","#514c38",.99),0,.018,1.27);E.rotation.x=-Math.PI/2;for(const G of[-1.85,1.85])v([new B(G,.055,-1.65),new B(G,.055,1),new B(G,.07,4.15)],.019,m);const U=new ji;r.add(U);const L=[];for(const G of[-1,1]){const Y=new Ne,nt=[],w=[],V=[],X=36,st=20;for(let Gt=0;Gt<=X;Gt++)for(let Vt=0;Vt<=st;Vt++){const Yt=Gt/X,pe=Vt/st,Ke=.035+Yt*2.085,gn=2.09*Math.sqrt(Math.max(0,1-Yt*Yt)),$e=.96*Math.pow(1-Yt,.58)+.02,He=G*Qs.lerp($e,Math.max($e,gn),pe),qe=.085*Math.sin(pe*8*Math.PI+Yt*5)*Math.sin(Math.PI*pe);nt.push(He,Ke,-1.65+qe+.05*Math.sin(Yt*13)),w.push(pe,Yt)}for(let Gt=0;Gt<X;Gt++)for(let Vt=0;Vt<st;Vt++){const Yt=Gt*(st+1)+Vt,pe=Yt+st+1;V.push(Yt,pe,Yt+1,pe,pe+1,Yt+1)}Y.setAttribute("position",new ce(nt,3)),Y.setAttribute("uv",new ce(w,2)),Y.setIndex(V),Y.computeVertexNormals();const rt=_(Y,h,0,0,0,U);L.push(rt);const it=Array.from({length:40},(Gt,Vt)=>{const Yt=Vt/39;return new B(G*(.96*Math.pow(1-Yt,.58)+.02),.035+Yt*2.085,-1.585+.05*Math.sin(Yt*13))}),Ct=v(it,.014,m,rt),Pt=new Ne,lt=[];for(let Gt=1;Gt<it.length-1;Gt++){const Vt=it[Gt];lt.push(Vt.x-.01,Vt.y,Vt.z+.02,Vt.x+.01,Vt.y+.007,Vt.z+.02)}Pt.setAttribute("position",new ce(lt,3)),Ct.add(new ir(Pt,new nr({color:"#dbc697",transparent:!0,opacity:.8})));const Rt=_(new js(.045,.011,6,18),g,G*1.09,.65,-1.48,rt);Rt.rotation.y=.3}for(const G of[-1,1])v([new B(G*1.95,.25,-1.72),new B(G*2.85,.04,-3.7)],.01,g),_(new mn(.017,.022,.24,5),p,G*2.85,.03,-3.7).rotation.z=G*.25;const P=new wp;P.moveTo(-1.22,.03),P.lineTo(1.22,.03),P.quadraticCurveTo(.77,1.32,0,2.1),P.quadraticCurveTo(-.77,1.32,-1.22,.03);const T=_(new Ou(P),new Fa({colorWrite:!1,depthWrite:!1,side:cn}),0,0,-1.57);T.name="tent-entrance-interaction";const z=za("fabric","#294c50",.94);(Wt=z.map)==null||Wt.repeat.set(2,2),(ot=z.bumpMap)==null||ot.repeat.set(2,2),z.bumpScale=.004;const W=new Ne,J=[],Q=[],et=[],k=52,q=100,F=(G,Y,nt=!1)=>{const w=-.78+Y*4,V=.54+.28*Math.sin(Y*Math.PI*.69),X=(G*2-1)*V,st=Math.pow(Math.max(0,1-Math.pow(G*2-1,2)),.65),rt=nt?-.004:.044*Math.pow(Math.sin(Y*Math.PI*13),2),it=.013*Math.sin(G*31+Y*17)*(1-st);return new B(X-.03,.04+st*(.245+.08*Y+rt)+it,w)};for(let G=0;G<=q;G++)for(let Y=0;Y<=k;Y++){const nt=F(Y/k,G/q);J.push(nt.x,nt.y,nt.z),Q.push(Y/k*2,G/q*5)}for(let G=0;G<q;G++)for(let Y=0;Y<k;Y++){const nt=G*(k+1)+Y,w=nt+k+1;et.push(nt,w,nt+1,w,w+1,nt+1)}W.setAttribute("position",new ce(J,3)),W.setAttribute("uv",new ce(Q,2)),W.setIndex(et),W.computeVertexNormals(),_(W,z);const Z=new me({color:"#819590",roughness:1});for(let G=1;G<13;G++)v(Array.from({length:40},(Y,nt)=>F(nt/39,G/13,!0).add(new B(0,.004,0))),.0035,Z,r,39);v(Array.from({length:40},(G,Y)=>F(.975,Y/39).add(new B(.007,.008,0))),.012,m);const ht=_(new kn(.85,.62,30,20),za("fabric","#998363",1),-.49,.2,1.63),dt=ht.geometry.attributes.position;for(let G=0;G<dt.count;G++)dt.setZ(G,.025*Math.sin(dt.getX(G)*35)+.02*Math.cos(dt.getY(G)*14));ht.geometry.computeVertexNormals(),ht.rotation.set(-Math.PI/2,.05,-.26);const pt=new ji;pt.position.set(-.88,.027,.4),r.add(pt);const I=new me({color:"#554b32",metalness:.78,roughness:.32}),ct=new me({color:"#ffd48a",emissive:"#ffbd64",emissiveIntensity:1.9,roughness:.5}),At=new Nl({color:"#faecd1",transparent:!0,opacity:.15,roughness:.12,metalness:.08,side:cn,depthWrite:!1});_(new mn(.12,.155,.075,24),I,0,.055,0,pt),_(new mn(.104,.11,.245,24,1,!0),At,0,.215,0,pt),_(new mn(.047,.06,.175,20),ct,0,.19,0,pt),_(new mn(.15,.13,.035,24),I,0,.352,0,pt),_(new Bu(.12,.075,24),I,0,.4,0,pt),_(new mn(.038,.038,.028,16),I,0,.446,0,pt);for(let G=0;G<6;G++){const Y=G*Math.PI/3;v([new B(Math.cos(Y)*.125,.075,Math.sin(Y)*.125),new B(Math.cos(Y)*.132,.22,Math.sin(Y)*.132),new B(Math.cos(Y)*.121,.355,Math.sin(Y)*.121)],.009,I,pt,12)}v(Array.from({length:22},(G,Y)=>{const nt=Y/21*Math.PI;return new B(Math.cos(nt)*.13,.385+Math.sin(nt)*.16,0)}),.009,I,pt,22);const It=new Ol("#ffce86",5.2,4.8,2);It.position.set(-.88,.26,.4),r.add(It);const kt=c(G=>{const Y=G.createRadialGradient(256,256,15,256,256,250);Y.addColorStop(0,"rgba(0,0,0,.65)"),Y.addColorStop(.48,"rgba(0,0,0,.2)"),Y.addColorStop(1,"rgba(0,0,0,0)"),G.fillStyle=Y,G.fillRect(0,0,512,512)}),zt=new Fa({map:kt,transparent:!0,depthWrite:!1}),ut=_(new kn(.8,.75),zt,-.88,.031,.4);ut.rotation.x=-Math.PI/2;const Tt=new kn(46,48,68,68),Ht=Tt.attributes.position;for(let G=0;G<Ht.count;G++){const Y=Ht.getX(G),nt=Ht.getY(G);Ht.setZ(G,.09*Math.sin(Y*.47)*Math.cos(nt*.39)+.025*Math.sin(Y*2.4+nt))}Tt.computeVertexNormals();const ie=_(Tt,za("earth","#353c2b",.91),0,-.115,-19);ie.rotation.x=-Math.PI/2;const qt=new me({color:"#638379",roughness:.2,metalness:.33,transparent:!0,opacity:.64});for(let G=0;G<9;G++){const Y=new wp,nt=.32+n()*.9,w=.25+n()*.8;for(let X=0;X<=30;X++){const st=X/30*Math.PI*2,rt=1+.13*Math.sin(st*3)+.1*Math.cos(st*5),it=Math.cos(st)*nt*rt,Ct=Math.sin(st)*w*rt;X?Y.lineTo(it,Ct):Y.moveTo(it,Ct)}const V=_(new Ou(Y),qt,(n()-.5)*8,-.007,-3.1-n()*9);V.rotation.x=-Math.PI/2}const re=za("wood","#343d31",.99),Fe=za("wood","#485244",.96),ee=new ji;r.add(ee);const de=za("leaf","#385644",.94);de.side=cn;const xe=new Ne,fe=[],be=[],ke=[];for(let G=0;G<=8;G++)for(let Y=0;Y<3;Y++){const nt=G/8,w=Y-1;fe.push(w*Math.sin(nt*Math.PI)*.23,nt-.5,Math.sin(nt*Math.PI)*(.06-Math.abs(w)*.04)),be.push(Y/2,nt)}for(let G=0;G<8;G++)for(let Y=0;Y<2;Y++){const nt=G*3+Y;ke.push(nt,nt+1,nt+3,nt+1,nt+4,nt+3)}xe.setAttribute("position",new ce(fe,3)),xe.setAttribute("uv",new ce(be,2)),xe.setIndex(ke),xe.computeVertexNormals();const ze=new En(xe,de,8e3);ze.instanceMatrix.setUsage(Lx),ee.add(ze);const ne=new Mn;let Se=0;const j=(G,Y,nt,w,V,X)=>{Se>=8e3||(ne.position.set(G,Y,nt),ne.rotation.set(.8+n()*1.1,n()*Math.PI*2,X),ne.scale.set(w,V,1),ne.updateMatrix(),ze.setMatrixAt(Se++,ne.matrix))};for(let G=0;G<38;G++){let Y=(n()-.5)*34,nt=-4.3-n()*29;G<5&&(Y=[-3.1,3.7,-1.7,1.4,-.45][G],nt=[-5.5,-7.2,-10,-12,-20][G]);const w=7+n()*9,V=.13+n()*.26,X=_(new mn(V*.38,V,w,13,12),G%3?re:Fe,Y,w/2-.1,nt,ee),st=X.geometry.attributes.position;for(let rt=0;rt<st.count;rt++){const it=st.getY(rt),Ct=Math.atan2(st.getZ(rt),st.getX(rt)),Pt=1+.08*Math.sin(Ct*5+Math.sin(it*.8));st.setX(rt,st.getX(rt)*Pt+.055*Math.sin(it*1.2+G)),st.setZ(rt,st.getZ(rt)*Pt)}X.geometry.computeVertexNormals(),X.rotation.z=(n()-.5)*.09;for(let rt=0;rt<4;rt++){const it=n()*Math.PI*2;v([new B(Y,.23,nt),new B(Y+Math.cos(it)*V*1.7,.025,nt+Math.sin(it)*V*1.7),new B(Y+Math.cos(it)*V*3,-.04,nt+Math.sin(it)*V*3)],V*.18,re,ee,10)}for(let rt=0;rt<5;rt++){const it=n()*Math.PI*2,Ct=3.6+rt*w*.105,Pt=1.3+n()*1.6,lt=new B(Y+Math.cos(it)*Pt,Ct+.38,nt+Math.sin(it)*Pt);v([new B(Y,Ct,nt),new B((Y+lt.x)/2,Ct+.1,(nt+lt.z)/2),lt],V*.17,re,ee,10);for(let Rt=0;Rt<25;Rt++){const Gt=.12+n()*.93;j(Qs.lerp(Y,lt.x,Gt)+(n()-.5)*.8,Ct+.4*Gt+(n()-.5)*.45,Qs.lerp(nt,lt.z,Gt)+(n()-.5)*.8,.3+n()*.38,.34+n()*.45,it)}}}ee.updateMatrixWorld(!0);for(const G of[re,Fe]){const Y=ee.children.filter(V=>V instanceof le&&!(V instanceof En)&&V.material===G),nt=Y.map(V=>V.geometry.clone().applyMatrix4(V.matrix)),w=B3(nt,!1);w&&_(w,G,0,0,0,ee);for(const V of Y)ee.remove(V),V.geometry.dispose();for(const V of nt)V.dispose()}const _e=[];for(let G=0;G<28;G++){const Y=(n()-.5)*13,nt=-2.8-n()*12;if(!(Math.abs(Y)<.55&&nt>-5))for(let w=0;w<7;w++){const V=w/7*Math.PI*2+n()*.25,X=.6+n()*.65,st=rt=>new B(Y+Math.cos(V)*X*rt,.025+Math.sin(rt*Math.PI*.85)*X*.68,nt+Math.sin(V)*X*rt);for(let rt=1;rt<10;rt++){const it=st(rt/10),Ct=st((rt-1)/10);_e.push(it.x,it.y,it.z,Ct.x,Ct.y,Ct.z);for(const Pt of[-1,1]){const lt=.15*Math.sin(rt/10*Math.PI)+.045;if(Se<8e3){const Rt=new B(Math.cos(V+Pt*1.25),.25,Math.sin(V+Pt*1.25)).normalize();ne.position.set(it.x+Rt.x*lt*.5,it.y,it.z+Rt.z*lt*.5),ne.quaternion.setFromUnitVectors(new B(0,1,0),Rt),ne.scale.set(lt*.85,lt*1.6,1),ne.updateMatrix(),ze.setMatrixAt(Se++,ne.matrix)}}}}}ze.count=Se,ze.instanceMatrix.needsUpdate=!0;const Ee=new Ne;Ee.setAttribute("position",new ce(_e,3)),ee.add(new ir(Ee,new nr({color:"#526b40"})));const H=za("stone","#454d42",.83),A=new En(new ho(1,1),H,60);r.add(A);for(let G=0;G<60;G++){ne.position.set((n()-.5)*18,-.08,-2.4-n()*18),ne.rotation.set(n(),n()*6.2,n());const Y=.06+n()*.22;ne.scale.set(Y*1.6,Y*.55,Y),ne.updateMatrix(),A.setMatrixAt(G,ne.matrix)}const at=_(new mn(.18,.22,3.8,10),re,-2.3,.18,-5.5);at.rotation.set(0,-.32,Math.PI/2);const mt=c(G=>{G.fillStyle="#948063",G.fillRect(0,0,512,512);for(let Y=0;Y<32;Y++)G.beginPath(),G.ellipse(249,265,6+Y*8.3,5+Y*7.7,.12,0,Math.PI*2),G.strokeStyle=`rgba(53,42,29,${.1+n()*.2})`,G.lineWidth=1+n()*2.5,G.stroke();G.strokeStyle="#443f30",G.lineWidth=3;for(let Y=0;Y<5;Y++){const nt=n()*6.28;G.beginPath(),G.moveTo(256+Math.cos(nt)*245,256+Math.sin(nt)*245),G.lineTo(256+Math.cos(nt+.1)*100,256+Math.sin(nt+.1)*100),G.stroke()}}),bt=_(new Ts(.216,20),new me({map:mt,color:"#aaa18b",roughness:.92}),0,-1.905,0,at);bt.rotation.x=Math.PI/2;const Bt=H3(r,{count:1400,width:29,height:17,depth:27,z:-16,speed:8.5,color:"#d0e1de",opacity:.29}),Ft=new Nl({color:"#c1ded4",metalness:.05,roughness:.06,transparent:!0,opacity:.63}),Mt=new En(new Fu(1,6,5),Ft,47);r.add(Mt);for(let G=0;G<47;G++){const Y=.09+G/46*(Math.PI-.18),nt=.01+n()*.012;ne.position.set(Math.cos(Y)*2.09,Math.sin(Y)*2.12,-1.75),ne.rotation.set(0,0,0),ne.scale.set(nt,nt*1.4,nt),ne.updateMatrix(),Mt.setMatrixAt(G,ne.matrix)}for(let G=0;G<2;G++){const Y=G?1:-1,nt=new En(Mt.geometry,Ft,24);L[G].add(nt);for(let w=0;w<24;w++){const V=.08+n()*.86,X=.007+n()*.006;ne.position.set(Y*(.96*Math.pow(1-V,.58)+.03+n()*.05),.035+V*2.085,-1.54+.05*Math.sin(V*13)),ne.rotation.set(0,0,0),ne.scale.set(X,X*1.7,X*.65),ne.updateMatrix(),nt.setMatrixAt(w,ne.matrix)}}let St=.68,Ot=.68;const Xt=new Vu;return{update(G,Y){St=Qs.damp(St,Ot,2.1,Y);const nt=.8+St*.38;L[0].scale.x=nt,L[1].scale.x=nt,L[0].position.x=-.1*St,L[1].position.x=.1*St,It.intensity=5.2+Math.sin(G*.71)*.055,Bt.update(G)},resize(G){const Y=G<.82;pt.position.set(Y?-.62:-.88,.027,Y?-.52:.4),It.position.set(pt.position.x,.26,pt.position.z),ut.position.set(pt.position.x,.031,pt.position.z),t.fov=Y?69:62,t.position.set(Y?0:.1,Y?.75:.78,Y?1.77:2.05),t.lookAt(Y?0:.02,Y?.84:.83,-6),t.updateProjectionMatrix()},interact(G,Y,nt=!1,w=!1){return!nt&&(Xt.setFromCamera(new Lt(G,Y),t),!Xt.intersectObjects([...L,T],!1)[0])?null:(Ot=Ot>.5?.2:.95,w&&(St=Ot),{action:"opening",value:Ot})}}};function V3(r){return je.jsx(Wu,{...r,kind:"tent",builder:G3})}const lS=r=>()=>(r=r*1664525+1013904223>>>0,r/4294967296);function k3(r,t,n){const a=document.createElement("canvas");a.width=a.height=512;const o=a.getContext("2d"),c=lS(n);o.fillStyle=r,o.fillRect(0,0,512,512);for(let h=0;h<(t==="wood"?1600:2e4);h++){const m=c()*512,p=c()*512;o.fillStyle=`rgba(${c()<.5?"255,238,205":"24,31,20"},${c()*.16})`,t==="wood"?(o.beginPath(),o.ellipse(m,p,.12+c()*.55,18+c()*240,.015*Math.sin(m),0,Math.PI*2),o.fill()):o.fillRect(m,p,1+c()*4,1+c()*5)}if(t==="wood")for(let h=0;h<3;h++){const m=60+c()*370,p=c()*512;for(let g=3;g<25;g+=2)o.strokeStyle=`rgba(41,26,14,${.09-g*.002})`,o.beginPath(),o.ellipse(m,p,g*.32,g,-.06,0,Math.PI*2),o.stroke()}const u=new ar(a);return u.wrapS=u.wrapT=Va,u.colorSpace=In,u.anisotropy=4,u}function X3(){const r=[],t=[],n=[];for(let c=0;c<=14;c++){const u=c/14,h=Math.pow(Math.sin(u*Math.PI),.75)*.45*(c%2?.87:1);for(let m=0;m<3;m++){const p=m-1;r.push(p*h,u,(p?-.055:.028)*Math.sin(u*Math.PI)+.12*u*u),t.push(m/2,u)}}for(let c=0;c<14;c++)for(let u=0;u<2;u++){const h=c*3+u,m=h+3;n.push(h,m,h+1,h+1,m,m+1)}const o=new Ne;return o.setAttribute("position",new ce(r,3)),o.setAttribute("uv",new ce(t,2)),o.setIndex(n),o.computeVertexNormals(),o}function dx(){const r=[],t=[],n=[];for(let u=0;u<=7;u++){const h=u/7,m=Math.pow(Math.max(0,Math.sin(Math.PI*h)),.52)*(.44+h*.2);for(let p=0;p<=7;p++){const g=p/7*2-1;r.push(g*m,h,.055*Math.sin(h*Math.PI)+.065*g*g*h-.055*h*h),t.push(p/7,h)}}for(let u=0;u<7;u++)for(let h=0;h<7;h++){const m=u*8+h,p=m+7+1;n.push(m,p,m+1,p,p+1,m+1)}const c=new Ne;return c.setAttribute("position",new ce(r,3)),c.setAttribute("uv",new ce(t,2)),c.setIndex(n),c.computeVertexNormals(),c}const W3=({scene:r,camera:t,renderer:n})=>{const a=lS(83059);r.background=new ue("#a6bab6"),r.fog=new fo("#b4c5bf",.021);const o=new ji;r.add(o);const c=[],u=(ot,G,Y)=>{const nt=k3(ot,G,Y);return c.push(nt),nt},h=u("#82745e","wood",13),m=new me({map:h,color:"#c7c4b3",roughness:.68,bumpMap:h,bumpScale:.018}),p=h.clone();p.center.set(.5,.5),p.rotation=Math.PI/2,p.repeat.set(1,3),c.push(p);const g=new me({map:p,color:"#c7c4b3",roughness:.65,bumpMap:p,bumpScale:.008}),_=new me({map:h,color:"#67543c",roughness:.74,bumpMap:h,bumpScale:.012}),v=u("#434c33","earth",32);v.repeat.set(8,8);const x=new me({map:v,roughness:.98,bumpMap:v,bumpScale:.07}),b=u("#78817a","stone",55),R=new me({map:b,color:"#b5b6a7",roughness:.72,bumpMap:b,bumpScale:.042}),M=new me({color:"#655b41",roughness:.42,metalness:.62}),S=new me({color:"#c2cbb0",roughness:.7,side:cn});S.onBeforeCompile=ot=>{ot.fragmentShader=ot.fragmentShader.replace("#include <color_fragment>",`#include <color_fragment>
      float midrib = 1.0 - smoothstep(0.014, 0.029, abs(vUv.x - 0.5));
      float veins = pow(max(0.0, cos((vUv.y + abs(vUv.x-0.5)*0.63)*85.0)), 20.0);
      diffuseColor.rgb *= 0.84 + 0.12*sin(vUv.y*3.14159);
      diffuseColor.rgb += vec3(0.08,0.09,0.025) * (midrib*0.65+veins*0.24);`)},S.defines={USE_UV:""};const C=new me({color:"#ffffff",roughness:.8,side:cn});C.onBeforeCompile=ot=>{ot.fragmentShader=ot.fragmentShader.replace("#include <color_fragment>",`#include <color_fragment>
      float vein=pow(max(0.0,cos((vUv.x-0.5)*(11.0+vUv.y*18.0))),14.0);
      diffuseColor.rgb *= 0.88+0.12*vUv.y+0.04*vein;
      diffuseColor.rgb = mix(diffuseColor.rgb,vec3(0.57,0.67,0.51),pow(1.0-vUv.y,5.0)*0.32);`)},C.defines={USE_UV:""};const O=[],E=(ot,G,Y,nt,w,V,X,st=r)=>{const rt=new le(new Wa(ot,G,Y),X);return rt.position.set(nt,w,V),rt.castShadow=rt.receiveShadow=!0,st.add(rt),st===r&&O.push(rt),rt},U=(ot,G,Y,nt,w=o)=>{const V=new le(new mn(Y*.72,Y,ot.distanceTo(G),7),nt);return V.position.copy(ot).add(G).multiplyScalar(.5),V.quaternion.setFromUnitVectors(new B(0,1,0),G.clone().sub(ot).normalize()),w.add(V),V},L=new Hu("#d8edf0","#748052",1.5);r.add(L);const P=new Gu("#e7f4f4",1.8);P.position.set(-3,7,2),P.castShadow=!0,P.shadow.mapSize.set(1024,1024),P.shadow.camera.left=-8,P.shadow.camera.right=8,P.shadow.camera.top=7,P.shadow.camera.bottom=-4,P.shadow.bias=-.002,P.shadow.normalBias=.035,P.shadow.radius=3,r.add(P);const T=new Ol("#ffdaa4",2.7,7,2);T.position.set(1.7,2.5,2.7),r.add(T),E(6.9,.18,.66,0,.57,.12,_),E(6.8,.11,1.15,0,.67,.44,g).geometry.translate(0,0,0),E(.26,3.9,.3,-3.02,2,.02,m),E(.26,3.9,.3,3.02,2,.02,m),E(6.3,.28,.35,0,3.67,.02,m),E(.13,2.82,.17,-.63,2.16,.08,m),E(5.8,.075,.15,0,2.93,.08,m);for(const ot of[-2.85,2.85])E(.035,2.94,.06,ot,2.14,.17,_);for(const ot of[.8,3.5])E(5.7,.035,.06,0,ot,.17,_);for(const ot of[-3.03,3.03,-.63])for(const G of[.88,3.35]){const Y=new le(new mn(.022,.022,.006,10),_);Y.rotation.x=Math.PI/2,Y.position.set(ot,G,.183),r.add(Y)}E(.06,.19,.02,-.625,1.63,.18,M),E(.13,.025,.037,-.57,1.64,.205,M);const W=new me({color:"#c9bfac",roughness:.96});E(2.5,5,.2,-4.4,2,.05,W),E(2.5,5,.2,4.4,2,.05,W),E(9,1.3,.2,0,-.11,.07,W);const J=[new Lt(.035,0),new Lt(.16,.016),new Lt(.24,.085),new Lt(.254,.13),new Lt(.24,.137),new Lt(.222,.09),new Lt(.148,.036),new Lt(.04,.025)],Q=new me({color:"#92a8a0",roughness:.29,metalness:.05}),et=new le(new Pl(J,40),Q);et.position.set(.38,.733,.44),et.receiveShadow=et.castShadow=!0,r.add(et);const k=new le(new Ts(.197,40),new Nl({color:"#627f79",roughness:.08,metalness:.25,clearcoat:1,transparent:!0,opacity:.85}));k.rotation.x=-Math.PI/2,k.position.set(.38,.82,.44),r.add(k);for(let ot=0;ot<3;ot++){const G=new le(dx(),new me({color:ot===1?"#a4a1d2":"#8da6d0",side:cn,roughness:.72}));G.rotation.set(-Math.PI/2,0,a()*6.28),G.scale.setScalar(.075),G.position.set(.31+a()*.13,.822,.38+a()*.13),r.add(G)}const q=new le(new kn(25,26,48,48),x),F=q.geometry.attributes.position;for(let ot=0;ot<F.count;ot++){const G=F.getX(ot),Y=F.getY(ot);F.setZ(ot,Math.sin(G*1.2)*Math.cos(Y*.55)*.1+Math.sin(G*2.8+Y)*.025)}q.geometry.computeVertexNormals(),q.rotation.x=-Math.PI/2,q.position.set(0,-.1,-10),q.receiveShadow=!0,o.add(q);for(let ot=0;ot<10;ot++){const G=-1.3-ot*.91,Y=-.18+Math.sin(ot*.63)*1.12,nt=new mn(.46+a()*.13,.5+a()*.12,.09+a()*.04,7),w=new le(nt,R);w.position.set(Y,-.012,G),w.rotation.y=a()*5,w.scale.z=.65+a()*.21,w.castShadow=w.receiveShadow=!0,o.add(w)}const Z=new me({color:"#536746",roughness:.94}),ht=X3(),dt=dx(),pt=[],I=[],ct=new B(0,1.6,3.2);[[-1.36,-2.6,1.87,.535],[-3.6,-4,1.4,.61],[-1.8,-5.4,1.13,.56],[1.42,-2.7,1.44,.62],[3.2,-3.6,1.57,.555],[2.6,-5.8,1.16,.59]].forEach(([ot,G,Y,nt],w)=>{for(let V=0;V<7;V++){const X=V*2.39996+w,st=.26+a()*.6,rt=new B(ot+Math.cos(X)*st,Y*(.63+a()*.38),G+Math.sin(X)*st*.72),it=new B(ot+(a()-.5)*.28,-.05,G+(a()-.5)*.3);U(it,rt,.017+a()*.009,Z);for(let Gt=0;Gt<11;Gt++){const Vt=.17+Gt*.068,Yt=it.clone().lerp(rt,Vt),pe=new B(Math.cos(X+Gt*2.4)*.65,.2+a()*.38,Math.sin(X+Gt*2.4)*.5),Ke=.34+a()*.32,gn=new Ai().setFromUnitVectors(new B(0,1,0),pe.normalize());gn.multiply(new Ai().setFromAxisAngle(new B(0,1,0),a()*1.8-.9)),pt.push({pos:Yt,q:gn,scale:new B(Ke*.82,Ke,Ke),color:new ue().setHSL(.23+a()*.07,.28+a()*.16,.18+a()*.13)})}const Ct=.2+a()*.11,Pt=ct.clone().sub(rt).normalize().lerp(new B(0,1,0),.35).normalize(),lt=new Ai().setFromUnitVectors(new B(0,0,1),Pt),Rt=w===0||w===3?45:32;for(let Gt=0;Gt<Rt;Gt++){const Vt=Math.acos(1-(Gt+.5)/(Rt+2)),Yt=Gt*2.39996,pe=new B(Math.sin(Vt)*Math.cos(Yt),Math.sin(Vt)*Math.sin(Yt),Math.cos(Vt)),Ke=pe.clone().multiplyScalar(Ct*(.88+a()*.25)).applyQuaternion(lt).add(rt),gn=new Ai().setFromUnitVectors(new B(0,0,1),pe.clone().applyQuaternion(lt)),$e=a()*Math.PI*2,He=.065+a()*.027,qe=new ue().setHSL(nt+.05+a()*.035,.4+a()*.22,.45+a()*.16);for(let Tn=0;Tn<4;Tn++){const wi=gn.clone().multiply(new Ai().setFromAxisAngle(new B(0,0,1),$e+Tn*Math.PI/2));I.push({pos:Ke,q:wi,scale:new B(He,He,He),color:qe})}}}});const It=new En(ht,S,pt.length),kt=new En(dt,C,I.length),zt=new Mn;for(const[ot,G]of[[It,pt],[kt,I]])G.forEach((Y,nt)=>{zt.position.copy(Y.pos),zt.quaternion.copy(Y.q),zt.scale.copy(Y.scale),zt.updateMatrix(),ot.setMatrixAt(nt,zt.matrix),ot.setColorAt(nt,Y.color)}),ot.castShadow=!0,ot.receiveShadow=!0,o.add(ot);const ut=u("#a8b2a1","stone",18);ut.repeat.set(5,1);const Tt=new me({map:ut,color:"#c4c8b7",roughness:.97,bumpMap:ut,bumpScale:.016});E(24,1.5,.23,0,.58,-11.5,Tt,o);const Ht=E(24.3,.12,.64,0,1.37,-11.5,new me({color:"#59675e",roughness:.88}),o);Ht.rotation.z=.002;const ie=new me({color:"#7f9266",roughness:.76}),qt=[];for(let ot=0;ot<29;ot++){const G=-11+ot*.79+a()*.25,Y=3.8+a()*3.8,nt=-12.8-a()*3.4,w=new B(G,0,nt),V=new B(G+(a()-.5)*1.1,Y,nt+a()*.8);U(w,V,.045+a()*.018,ie);for(let X=0;X<7;X++){const st=w.clone().lerp(V,.42+X*.077),rt=X%2?1:-1,it=st.clone().add(new B(rt*(.9+a()),.1+a()*.4,a()-.5));U(st,it,.009,Z);for(let Ct=0;Ct<9;Ct++)zt.position.copy(st).lerp(it,(Ct+1)/10),zt.quaternion.setFromUnitVectors(new B(0,1,0),new B(rt*(Ct%2?.2:.9),-.12-a()*.7,.4).normalize()),zt.scale.set(.09,.48+a()*.23,.3),zt.updateMatrix(),qt.push(zt.matrix.clone())}}const re=new En(ht,new me({color:"#4f7355",roughness:.95,side:cn}),qt.length);qt.forEach((ot,G)=>re.setMatrixAt(G,ot)),o.add(re);const Fe=[],ee=[],de=new me({map:h,color:"#58624c",roughness:.97,bumpMap:h,bumpScale:.025});for(const[ot,G,Y]of[[-9,-13,6.7],[-3.5,-13.8,7.4],[3.4,-14.3,7.2],[9.2,-12,7]]){const nt=new B(ot,0,G),w=new B(ot+.45,Y*.65,G-.25);U(nt,w,.17,de);for(let V=0;V<9;V++){const X=V*2.4,st=1.1+a()*1.5,rt=nt.clone().lerp(w,.5+a()*.43),it=new B(ot+Math.cos(X)*st,Y*(.57+a()*.43),G+Math.sin(X)*st*.7);U(rt,it,.047,de);for(let Ct=0;Ct<76;Ct++){const Pt=rt.clone().lerp(it,.42+a()*.71);Pt.x+=(a()-.5)*1.75,Pt.y+=(a()-.5)*.95,Pt.z+=(a()-.5)*1.45,zt.position.copy(Pt),zt.rotation.set(a()*1.7-.85,a()*2.2-1.1,a()*6.28);const lt=.45+a()*.4;zt.scale.set(lt*.7,lt,lt),zt.updateMatrix(),Fe.push(zt.matrix.clone()),ee.push(new ue().setHSL(.25+a()*.05,.26+a()*.2,.15+a()*.12))}}}const xe=new En(ht,new me({color:"#e5ebd5",roughness:.88,side:cn}),Fe.length);Fe.forEach((ot,G)=>{xe.setMatrixAt(G,ot),xe.setColorAt(G,ee[G])}),xe.receiveShadow=!0,o.add(xe);const fe=[];for(let ot=0;ot<26;ot++){const G=-1.6-a()*8,nt=-.18+Math.sin((-G-1.3)/.91*.63)*1.12+(ot%2?1:-1)*(.71+a()*1);for(let w=0;w<6;w++){const V=w*1.047+ot,X=new B(Math.cos(V),0,Math.sin(V));for(let st=1;st<=7;st++)for(const rt of[-1,1]){const it=st/8,Ct=.17*Math.sin(it*Math.PI);zt.position.set(nt+X.x*it*.46,.02+Math.sin(it*Math.PI*.7)*.35,G+X.z*it*.46);const Pt=new B(X.z*rt,.1,-X.x*rt);zt.quaternion.setFromUnitVectors(new B(0,1,0),Pt.normalize()),zt.scale.set(Ct*.62,Ct,Ct),zt.updateMatrix(),fe.push(zt.matrix.clone())}}}const be=new En(ht,new me({color:"#657b43",side:cn,roughness:.83}),fe.length);fe.forEach((ot,G)=>be.setMatrixAt(G,ot)),be.receiveShadow=!0,o.add(be);const ke=new ho(1,1),ze=[];for(let ot=0;ot<110;ot++){const G=-1.35-a()*9,Y=-.18+Math.sin((-G-1.3)/.91*.63)*1.12;zt.position.set(Y+(a()-.5)*1.65,-.015,G),zt.rotation.set(a(),a()*6,a());const nt=.025+a()*.055;zt.scale.set(nt*1.3,nt*.55,nt),zt.updateMatrix(),ze.push(zt.matrix.clone())}const ne=new En(ke,R,ze.length);ze.forEach((ot,G)=>ne.setMatrixAt(G,ot)),ne.receiveShadow=!0,o.add(ne);const Se=1e3,j=new Float32Array(Se*6),_e=new Float32Array(Se*3);for(let ot=0;ot<Se;ot++)_e[ot*3]=a()*19-9.5,_e[ot*3+1]=a()*7,_e[ot*3+2]=-.8-a()*13;const Ee=new Ne;Ee.setAttribute("position",new qn(j,3));const H=new ir(Ee,new nr({color:"#d8e8e3",transparent:!0,opacity:.28,depthWrite:!1}));o.add(H);const A=new Hi(1,1,{minFilter:Xn,magFilter:Xn,depthBuffer:!0,type:$i}),at={uScene:{value:A.texture},uResolution:{value:new Lt(1,1)},uTime:{value:0},uTouch:{value:new Lt(-2,-2)},uTouchStrength:{value:0}},mt=new ei({uniforms:at,transparent:!1,depthWrite:!0,toneMapped:!0,vertexShader:"varying vec2 vUv; void main(){ vUv=uv; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0); }",fragmentShader:`
      uniform sampler2D uScene; uniform vec2 uResolution; uniform float uTime; uniform vec2 uTouch; uniform float uTouchStrength; varying vec2 vUv;
      float h(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
      vec3 drops(vec2 uv, vec2 density, float layer){
        vec2 p=uv*density; vec2 cell=floor(p); float seed=h(cell+layer);
        vec2 q=fract(p)-vec2(0.18+seed*0.60,0.24+h(cell+2.2)*0.5);
        float r=0.058+0.12*h(cell+1.7); q.y*=0.68+seed*0.28;
        float d=length(q)/r; float mask=(1.0-smoothstep(0.72,1.0,d))*step(0.13,seed);
        return vec3(q*mask/r,mask);
      }
      void main(){
        vec2 screenUv=gl_FragCoord.xy/uResolution;
        vec3 a=drops(vUv,vec2(38.0,22.0),0.0), b=drops(vUv,vec2(19.0,11.0),8.1);
        vec2 refractNormal=a.xy*0.0038+b.xy*0.007; float dropMask=max(a.z,b.z);
        float stream=0.0; vec2 streamN=vec2(0.0);
        for(int i=0;i<7;i++){
          float fi=float(i); float seed=fract(sin(fi*72.13+9.8)*199.73);
          float head=1.1-fract(uTime*(0.027+seed*0.016)+seed)*1.3;
          float x=0.06+fi*0.147+sin(vUv.y*17.0+fi)*0.003;
          float dx=vUv.x-x; float tail=smoothstep(head-0.018,head+0.025,vUv.y)*(1.0-smoothstep(head+0.23,head+0.58,vUv.y));
          float s=exp(-pow(dx/0.0015,2.0))*tail;
          stream=max(stream,s); streamN.x+=sign(dx)*s*0.006;
          vec2 qp=(vUv-vec2(x,head))*vec2(1.0,0.66); float dd=length(qp)/0.009;
          float bead=1.0-smoothstep(0.72,1.0,dd); refractNormal+=qp*bead*1.4; dropMask=max(dropMask,bead);
        }
        vec2 traceDelta=(vUv-uTouch)*vec2(1.5,1.0);
        float clear=exp(-dot(traceDelta,traceDelta)*135.0)*uTouchStrength;
        refractNormal=(refractNormal+streamN)*(1.0-clear*0.88);
        vec3 bg=texture2D(uScene,clamp(screenUv+refractNormal,vec2(0.002),vec2(0.998))).rgb;
        float edgeLight=(a.x+a.y*0.8)*a.z*0.033+(b.x+b.y)*b.z*0.048+stream*0.035;
        float mist=(0.012+pow(1.0-vUv.y,3.0)*0.018)*(1.0-clear);
        bg=mix(bg,vec3(0.64,0.73,0.70),mist)+edgeLight*(1.0-clear);
        gl_FragColor=vec4(bg,1.0);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }`}),bt=new le(new kn(5.72,2.69),mt);bt.position.set(0,2.15,-.012),r.add(bt);const Bt=new Vu,Ft=new Lt;let Mt=100,St=0,Ot=0,Xt=0;return{resize:ot=>{t.fov=ot<.85?51:49,t.position.set(ot<.85?-.08:.12,ot<.85?1.42:1.47,ot<.85?3.15:3.05),t.lookAt(ot<.85?-.07:0,ot<.85?1.45:1.38,-3.5),t.updateProjectionMatrix()},update(ot,G){St=ot,Mt+=G,at.uTime.value=ot,at.uTouchStrength.value=Math.max(0,1-Mt/8),o.rotation.y=Math.sin(ot*.19)*45e-5,re.rotation.z=Math.sin(ot*.28)*.0025,xe.rotation.z=Math.sin(ot*.16)*9e-4,It.rotation.z=Math.sin(ot*.37)*.0017,kt.rotation.z=Math.sin(ot*.37)*.0017;for(let nt=0;nt<Se;nt++){const w=nt*6,V=nt*3,X=((_e[V+1]-ot*4.7)%7+7)%7;j[w]=_e[V]+X*.042,j[w+1]=X,j[w+2]=_e[V+2],j[w+3]=j[w]+.009,j[w+4]=X+.14,j[w+5]=j[w+2]}Ee.attributes.position.needsUpdate=!0,n.getDrawingBufferSize(Ft),(Ft.x!==Ot||Ft.y!==Xt)&&(Ot=Math.max(1,Ft.x),Xt=Math.max(1,Ft.y),A.setSize(Ot,Xt),at.uResolution.value.copy(Ft));const Y=n.getRenderTarget();bt.visible=!1,n.setRenderTarget(A),n.clear(),n.render(r,t),n.setRenderTarget(Y),bt.visible=!0},interact(ot,G,Y){if(Y)at.uTouch.value.set(.52,.43);else{Bt.setFromCamera(new Lt(ot,G),t);const nt=Bt.intersectObjects([bt,...O],!1)[0];if(!(nt!=null&&nt.uv)||nt.object!==bt)return null;at.uTouch.value.copy(nt.uv)}return Mt=0,{action:"glass-trace",value:.65+Math.sin(St)*.1}},dispose(){A.dispose(),c.forEach(ot=>ot.dispose())}}};function q3(r){return je.jsx(Wu,{...r,kind:"window",builder:W3})}const Y3=({scene:r,camera:t,renderer:n})=>{let a=520731;const o=()=>(a=a*1664525+1013904223>>>0,a/4294967296),c=(w,V)=>w+o()*(V-w);r.background=new ue("#8faaa8"),r.fog=new fo("#839b94",.036),t.position.set(0,1.49,3.7),t.lookAt(.08,.92,-5),t.near=.035,t.far=90;const u=w=>{const V=document.createElement("canvas");V.width=512,V.height=512;const X=V.getContext("2d"),st=X.createImageData(512,512);for(let it=0;it<512;it++)for(let Ct=0;Ct<512;Ct++){const Pt=w==="wood"?174+Math.sin(it*.71+Math.sin(Ct*.009)*1.3+Math.sin(it*.027)*2)*7+Math.sin(it*2.1+Ct*.002)*3+c(-5,5):153+Math.sin(Ct*.042+Math.sin(it*.029)*3)*12+Math.sin(it*.052-Ct*.027)*9+c(-19,19),lt=(it*512+Ct)*4;st.data[lt]=Pt,st.data[lt+1]=Pt,st.data[lt+2]=Pt,st.data[lt+3]=255}if(X.putImageData(st,0,0),w==="wood")for(let it=0;it<70;it++){const Ct=c(0,512);X.strokeStyle=`rgba(34,24,17,${c(.07,.19)})`,X.lineWidth=c(.4,1.3),X.beginPath(),X.moveTo(c(-90,180),Ct),X.bezierCurveTo(180,Ct-2,310,Ct+3,c(400,600),Ct+1),X.stroke()}const rt=new ar(V);return rt.wrapS=rt.wrapT=Va,rt.colorSpace=In,rt.anisotropy=Math.min(8,n.capabilities.getMaxAnisotropy()),rt},h=u("wood"),m=u("stone"),p=u("soil");h.center.set(.5,.5),h.rotation=Math.PI/2;const g=new me({color:"#8f7b5e",map:h,bumpMap:h,bumpScale:.014,roughness:.74}),_=new me({color:"#5d4530",map:h,bumpMap:h,bumpScale:.028,roughness:.82}),v=new me({color:"#a08561",map:h,roughness:.92}),x=new me({color:"#a6afa6",map:m,bumpMap:m,bumpScale:.028,roughness:.88}),b=new me({color:"#838e80",map:m,bumpMap:m,bumpScale:.024,roughness:.46}),R=new me({color:"#596b3a",map:p,bumpMap:p,bumpScale:.09,roughness:1}),M=new me({color:"#737e60",map:p,bumpMap:p,bumpScale:.07,roughness:.9}),S=new me({color:"#353d30",roughness:1}),C=new me({color:"#526337",roughness:.9}),O=new me({color:"#655b46",map:h,bumpMap:h,bumpScale:.085,roughness:.9}),E=new Fa({color:"#0c1b17",transparent:!0,opacity:.13,depthWrite:!1});r.add(new Hu("#d4e2de","#777057",2.05));const U=new Gu("#e8e1c8",1.7);U.position.set(-8,13,-7),U.castShadow=!0,U.shadow.mapSize.set(1024,1024),U.shadow.camera.left=-12,U.shadow.camera.right=12,U.shadow.camera.top=12,U.shadow.camera.bottom=-12,U.shadow.camera.near=1,U.shadow.camera.far=40,U.shadow.bias=-.001,U.shadow.normalBias=.035,U.shadow.radius=3,r.add(U);const L=new Ol("#edcba0",5.5,9,2);L.position.set(-2.3,2.1,3.2),r.add(L);const P=(w,V,X,st,rt,it,Ct)=>{const Pt=new le(new Wa(w,V,X),st);return Pt.position.set(rt,it,Ct),Pt.castShadow=Pt.receiveShadow=!0,r.add(Pt),Pt},T=(w,V,X,st,rt=X*.7,it=9)=>{const Ct=new le(new mn(rt,X,w.distanceTo(V),it),st);return Ct.position.copy(w).add(V).multiplyScalar(.5),Ct.quaternion.setFromUnitVectors(new B(0,1,0),V.clone().sub(w).normalize()),Ct.castShadow=Ct.receiveShadow=!0,r.add(Ct),Ct},z=new kn(70,60,42,42);z.rotateX(-Math.PI/2);const W=z.attributes.position;for(let w=0;w<W.count;w++){const V=W.getX(w),X=W.getZ(w);W.setY(w,-.23+Math.sin(V*.41)*Math.sin(X*.3)*.13)}z.computeVertexNormals();const J=new le(z,M);J.position.z=-20,J.receiveShadow=!0,r.add(J),P(14,.28,5.5,_,0,-.13,3);for(let w=0;w<31;w++){const V=P(.442,.12,5.45,w%6===0?v:g,-6.91+w*.462,.065+c(-.004,.004),3);V.rotation.z=c(-.001,.001)}P(14.3,.18,.18,_,0,.015,.26),P(14.1,.12,.31,g,0,-.055,.16),P(14.25,.14,.29,_,0,-.16,-.08);for(const w of[-4.5,1.35]){P(.34,3.03,.35,_,w,1.455,.54),P(.41,.1,.43,v,w,.16,.54),P(.48,.2,.48,x,w,-.015,.54),P(.64,.18,.46,g,w,2.53,.54);const V=P(.15,1.1,.19,g,w+(w<0?.32:-.32),2.27,.54);V.rotation.z=w<0?-.64:.64,P(.47,.1,.41,_,w,2.04,.54)}P(14.3,.3,.32,_,0,2.77,.54),P(14.6,.16,4.7,_,0,3.18,2.25);for(let w=0;w<17;w++){const V=P(.13,.18,5.8,w%3?g:v,-7.1+w*.9,2.93,1.9);V.rotation.x=-.065}const Q=new me({color:"#565951",roughness:.9,map:m,bumpMap:m,bumpScale:.025}),et=new mn(.17,.17,.55,10,1,!0,0,Math.PI);et.rotateX(Math.PI/2);const k=new En(et,Q,53),q=new Mn;for(let w=0;w<53;w++)q.position.set(-7.2+w*.275,2.99+Math.pow((w-26)/26,2)*.16,-.22),q.rotation.set(0,0,0),q.updateMatrix(),k.setMatrixAt(w,q.matrix);k.castShadow=!0,r.add(k);const F=F3(new ho(1,3)),Z=F.attributes.position;for(let w=0;w<Z.count;w++){const V=Z.getX(w),X=Z.getY(w),st=Z.getZ(w),rt=1+Math.sin(V*8+st*4)*.08+Math.sin(X*13-V*3)*.035;Z.setXYZ(w,V*rt,X*rt,st*rt)}F.computeVertexNormals();const ht=new En(F,b,63);for(let w=0;w<63;w++){const V=w<11?-.8+Math.sin(w*.74)*1.1-w*.06:c(-12,12),X=w<11?-1.5-w*.77:c(-3,-19);q.position.set(V,-.095+(w<11?0:c(-.07,.08)),X),q.scale.set(w<11?c(.37,.56):c(.15,.61),w<11?c(.07,.12):c(.1,.27),w<11?c(.3,.48):c(.17,.7)),q.rotation.set(c(-.2,.2),c(0,6.28),c(-.1,.1)),q.updateMatrix(),ht.setMatrixAt(w,q.matrix),ht.setColorAt(w,new ue().setHSL(c(.12,.18),c(.05,.16),c(.46,.67)))}ht.castShadow=ht.receiveShadow=!0,r.add(ht);const dt=new En(F,x,19),pt=new En(F,R,19);for(let w=0;w<19;w++){const V=w<7?-3.7+w*1.12:c(-13,13),X=w<7?-7.7-Math.sin(w)*1.7:c(-9,-24),st=c(.35,.9);q.position.set(V,st*.21-.12,X),q.scale.set(c(.65,1.3),st,c(.5,1.05)),q.rotation.set(c(-.25,.25),c(0,6.28),c(-.2,.2)),q.updateMatrix(),dt.setMatrixAt(w,q.matrix),q.position.y+=st*.16,q.scale.multiply(new B(.89,.86,.89)),q.updateMatrix(),pt.setMatrixAt(w,q.matrix)}dt.castShadow=dt.receiveShadow=!0,pt.castShadow=pt.receiveShadow=!0,r.add(dt,pt);const I=new En(F,x,94);for(let w=0;w<94;w++){const V=Math.floor(w/31);q.position.set(-15+w%31*1.03+V*.31,V*.35-.03,-16.2+Math.sin(w%31)*.13),q.scale.set(c(.49,.61),c(.21,.26),c(.39,.53)),q.rotation.set(c(-.04,.04),c(-.25,.25),c(-.08,.08)),q.updateMatrix(),I.setMatrixAt(w,q.matrix)}I.receiveShadow=!0,r.add(I);const ct=new Ne,At=[],It=[],kt=[];for(let w=0;w<=8;w++){const V=w/8,X=Math.sin(Math.PI*V)*(.16+.055*V);for(const st of[-1,0,1])At.push(st*X,V,Math.sin(V*Math.PI)*.1+(st===0?.025:0)),It.push((st+1)*.5,V)}for(let w=0;w<8;w++)for(let V=0;V<2;V++){const X=w*3+V;kt.push(X,X+1,X+3,X+1,X+4,X+3)}ct.setAttribute("position",new ce(At,3)),ct.setAttribute("uv",new ce(It,2)),ct.setIndex(kt),ct.computeVertexNormals();const zt=new me({color:"#7f9c55",roughness:.72,side:cn}),ut=new En(ct,zt,2280);let Tt=0;const Ht=[[-2.1,-1.15,1.25],[2.15,-1.25,1.2],[-3.2,-2.6,1.45],[2.7,-3.4,1.3],[3.5,-5.9,1.4],[-4.5,-4.9,1.3],[-2.9,-8.2,1.1],[4.8,-9,1.6],[-5.5,-10,1.4],[6.5,-5,1.2],[1.9,-10,1],[-7.1,-7.2,1.4]];for(const[w,V,X]of Ht)for(let st=0;st<7;st++){const rt=st/7*Math.PI*2+c(-.24,.24),it=X*c(.7,1.1),Ct=[];for(let Rt=0;Rt<5;Rt++){const Gt=Rt/4;Ct.push(new B(w+Math.cos(rt)*Gt*it,-.1+Math.sin(Gt*Math.PI*.8)*it*.67,V+Math.sin(rt)*Gt*it))}const Pt=new Nu(Ct),lt=new le(new Ll(Pt,10,.008,3,!1),C);r.add(lt);for(let Rt=1;Rt<=12;Rt++){const Gt=Rt/13,Vt=Pt.getPoint(Gt),Yt=Math.sin(Gt*Math.PI)*it*.36;for(const pe of[-1,1]){const Ke=new B(Math.cos(rt)*.2+Math.sin(rt)*pe,.12,Math.sin(rt)*.2-Math.cos(rt)*pe).normalize();q.position.copy(Vt),q.quaternion.setFromUnitVectors(new B(0,1,0),Ke),q.scale.set(.22*X,Yt,.8),q.updateMatrix(),ut.setMatrixAt(Tt,q.matrix),ut.setColorAt(Tt++,new ue().setHSL(c(.2,.27),c(.25,.49),c(.29,.61)))}}}ut.count=Tt,ut.receiveShadow=!0,r.add(ut);const ie=new En(ct,zt,7800);let qt=0;for(let w=0;w<17;w++){const V=w<2?w?5.4:-5.6:c(-18,18),X=w<2?-8.8:c(-16,-30),st=c(3.8,9.3),rt=c(-.8,.8),it=c(-.55,.55),Ct=new B(V,-.25,X),Pt=new B(V+rt*.32,st*.43,X+it*.3),lt=new B(V+rt,st*.86,X+it);T(Ct,Pt,c(.14,.26),O,.105,11),T(Pt,lt,.105,O,.031,9);for(let Rt=0;Rt<6;Rt++){const Gt=Rt*2.39+w*.8,Vt=st*c(.38,.78),Yt=c(1.1,2.9),pe=new B(V+rt*Vt/st,Vt,X+it*Vt/st),Ke=new B(V+Math.cos(Gt)*Yt*.6,Vt+c(.12,.55),X+Math.sin(Gt)*Yt*.6),gn=new B(V+Math.cos(Gt)*Yt,Vt+c(.5,1.5),X+Math.sin(Gt)*Yt);T(pe,Ke,.055,O,.034,8),T(Ke,gn,.034,O,.008,6);for(let $e=0;$e<64;$e++){const He=Math.sqrt(o())*1.32,qe=c(0,Math.PI*2);q.position.copy(gn).add(new B(Math.cos(qe)*He,c(-.44,.66),Math.sin(qe)*He)),q.rotation.set(c(.5,2.4),c(0,Math.PI*2),c(0,Math.PI*2)),q.scale.set(c(.5,.9),c(.3,.61),1),q.updateMatrix(),ie.setMatrixAt(qt,q.matrix),ie.setColorAt(qt++,new ue().setHSL(c(.22,.31),c(.17,.31),c(.32,.58)))}}}for(let w=0;w<18;w++){const V=c(-16,16),X=c(-13,-24),st=c(.8,2.5);T(new B(V,-.15,X),new B(V+.11,st,X-.09),.034,O,.008,6);for(let rt=0;rt<64;rt++){const it=c(0,Math.PI*2),Ct=Math.sqrt(o())*c(.45,1.15);q.position.set(V+Math.cos(it)*Ct,st*.53+c(-.3,.7),X+Math.sin(it)*Ct),q.rotation.set(c(.7,2.2),c(0,6.28),c(0,6.28)),q.scale.set(.7,c(.3,.63),1),q.updateMatrix(),ie.setMatrixAt(qt,q.matrix),ie.setColorAt(qt++,new ue().setHSL(c(.22,.29),c(.23,.37),c(.3,.51)))}}ie.count=qt,ie.receiveShadow=!0,r.add(ie);for(let w=0;w<3;w++){const V=new kn(95,34,58,22);V.rotateX(-Math.PI/2);const X=V.attributes.position;for(let rt=0;rt<X.count;rt++){const it=X.getX(rt),Ct=X.getZ(rt),Pt=4.3+w*1.1+Math.sin(it*.073+w*1.7)*1.6+Math.sin(it*.19+w)*.64,lt=Math.max(0,Math.sin((Ct+17)/34*Math.PI));X.setY(rt,-.7+lt*Pt+Math.sin(it*.37+Ct*.19)*.16)}V.computeVertexNormals();const st=new le(V,new me({color:w===0?"#66795b":w===1?"#78927f":"#92a79a",roughness:1}));st.position.z=-35-w*16,r.add(st)}const re=new ji;re.position.set(.64,-.13,-.03),r.add(re);const Fe=[new Lt(.09,0),new Lt(.37,.025),new Lt(.55,.11),new Lt(.65,.25),new Lt(.715,.49),new Lt(.7,.63),new Lt(.665,.67),new Lt(.588,.665),new Lt(.55,.6),new Lt(.51,.37),new Lt(.39,.23),new Lt(.1,.19),new Lt(0,.19)],ee=new Pl(Fe,72),de=ee.attributes.position;for(let w=0;w<de.count;w++){const V=de.getX(w),X=de.getY(w),st=de.getZ(w),rt=Math.atan2(V,st),it=Math.sin(rt*7+.4)*.012+Math.sin(rt*13-.7)*.004;de.setXYZ(w,V*(1+it),X+Math.sin(rt*5)*.008*Math.min(X,1),st*(1+it))}ee.computeVertexNormals();const xe=new le(ee,x);xe.castShadow=xe.receiveShadow=!0,re.add(xe);const fe=new le(F,b);fe.position.set(.64,-.2,-.03),fe.scale.set(.65,.13,.54),r.add(fe);const be=new le(new Ts(.85,48),E);be.rotation.x=-Math.PI/2,be.position.set(.64,-.201,-.03),r.add(be);const ke=new me({color:"#9a9166",map:h,roughness:.73});T(new B(1.26,-.13,-.4),new B(1.26,.89,-.4),.036,ke,.034,12);const ze=new B(1.48,.9,-.33),ne=new B(.91,.81,-.12);T(ze,ne,.054,ke,.057,14);const Se=new le(new Ts(.042,20),S);Se.position.copy(ne),Se.quaternion.setFromUnitVectors(new B(0,0,1),ne.clone().sub(ze).normalize()),r.add(Se);const j=new me({color:"#464330",roughness:1});for(let w=0;w<3;w++){const V=new le(new js(.059,.007,5,16),j);V.position.set(1.24-w*.015,.867-w*.002,-.242+w*.005),V.rotation.set(0,1.22,1.73),r.add(V)}const _e={uTime:{value:0},uTouch:{value:new Lt(.12,-.05)},uTouchTime:{value:-100}},Ee=new ei({uniforms:_e,side:cn,vertexShader:`
      uniform float uTime; uniform vec2 uTouch; uniform float uTouchTime;
      varying vec2 vP; varying vec3 vWorld; varying vec3 vNormal;
      float ripple(vec2 p,vec2 o,float age,float amp){float d=length(p-o);return sin(d*56.-age*11.)*exp(-pow((d-age*.27)*9.,2.))*exp(-age*.65)*amp;}
      float surface(vec2 p){float h=sin(p.x*14.+uTime*.58)*sin(p.y*13.-uTime*.65)*.00025;
        for(int i=0;i<7;i++){float f=float(i);float age=mod(uTime*.87+f*.471,3.6);vec2 c=vec2(sin(f*12.4),cos(f*8.7))*.39;h+=ripple(p,c,age,.0004);}
        h+=ripple(p,vec2(.27,-.09),mod(uTime*1.5,2.5),.00065);
        float age=uTime-uTouchTime;if(age>=0.&&age<8.)h+=ripple(p,uTouch,age,.0045);
        return h;}
      void main(){vP=position.xy;float h=surface(position.xy);vec3 p=position+vec3(0.,0.,h);vec4 w=modelMatrix*vec4(p,1.);vWorld=w.xyz;
        float e=.004;float dx=surface(position.xy+vec2(e,0.))-surface(position.xy-vec2(e,0.));float dy=surface(position.xy+vec2(0.,e))-surface(position.xy-vec2(0.,e));
        vNormal=normalize(mat3(modelMatrix)*normalize(vec3(-dx/(2.*e),-dy/(2.*e),1.)));gl_Position=projectionMatrix*viewMatrix*w;}
    `,fragmentShader:`
      varying vec2 vP; varying vec3 vWorld; varying vec3 vNormal;
      void main(){vec3 n=normalize(vNormal);vec3 v=normalize(cameraPosition-vWorld);vec3 r=reflect(-v,n);float f=.04+.72*pow(1.-max(dot(n,v),0.),4.);
        vec3 deep=vec3(.012,.035,.026);vec3 sky=mix(vec3(.035,.06,.044),vec3(.18,.22,.19),smoothstep(-.05,.6,r.y));
        float branch=sin(r.x*8.+r.z*2.)*sin(r.z*7.-r.x*3.);sky*=mix(.83,1.,smoothstep(-.1,.2,branch+r.y*.6));
        vec3 c=mix(deep,sky,.12+f*.5);float glint=pow(max(dot(reflect(normalize(vec3(-.4,-1.,.3)),n),v),0.),65.);c+=vec3(.63,.68,.60)*glint*.06;
        float edge=smoothstep(.39,.558,length(vP));c*=1.-edge*.18;gl_FragColor=vec4(c,1.);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }
    `}),H=new le(new Ts(.562,96),Ee);H.rotation.x=-Math.PI/2,H.position.y=.581,re.add(H);const A=new kn(1.124,1.124,64,64),at=[],mt=A.attributes.position,bt=A.index;for(let w=0;w<bt.count;w+=3){const V=bt.getX(w),X=bt.getX(w+1),st=bt.getX(w+2);[V,X,st].every(rt=>Math.hypot(mt.getX(rt),mt.getY(rt))<.557)&&at.push(V,X,st)}A.setIndex(at),H.geometry.dispose(),H.geometry=A;const Bt=new Nl({color:"#b4d1cc",transparent:!0,opacity:.34,roughness:.14,metalness:.08,depthWrite:!1});for(const[w,V,X]of[[-3.5,-.33,.015],[-1.74,-.3,.012],[2.5,-.34,.018],[4.4,-.35,.019],[.91,-.12,.009]]){const st=w===.91?.8:2.96,rt=w===.91?.46:-.13,it=new Nu([new B(w,st,V),new B(w+.012,st*.67,V+.015),new B(w+.025,(st+rt)*.37,V+.036),new B(w+.012,rt,V+.045)]),Ct=new Ll(it,18,X,5,!1);r.add(new le(Ct,Bt))}const Ft=1550,Mt=new Float32Array(Ft*6),St=[];for(let w=0;w<Ft;w++)St.push(c(-17,17),c(0,9),c(-24,-.45),c(.7,1.35));const Ot=new Ne;Ot.setAttribute("position",new qn(Mt,3));const Xt=new ir(Ot,new nr({color:"#c3d4d0",transparent:!0,opacity:.26,depthWrite:!1}));Xt.frustumCulled=!1,r.add(Xt);const Wt=new Ne,ot=new Float32Array(165);Wt.setAttribute("position",new qn(ot,3));const G=new Z1(Wt,new Fx({color:"#cbdfd5",size:.018,transparent:!0,opacity:.51,depthWrite:!1}));G.frustumCulled=!1,r.add(G);const Y=new Vu;let nt=0;return{resize(w){t.fov=w<.8?61:52,t.position.set(w<.8?.68:0,w<.8?1.42:1.49,w<.8?3.3:3.7),t.lookAt(w<.8?.56:.08,w<.8?1:.92,-5),t.updateProjectionMatrix()},update(w){nt=w,_e.uTime.value=w;for(let V=0;V<Ft;V++){const X=V*4,st=V*6,rt=((St[X+1]-w*4.9*St[X+3])%9+9)%9-.25,it=St[X]+Math.sin(w*.16+St[X+2])*.02;Mt[st]=it,Mt[st+1]=rt,Mt[st+2]=St[X+2],Mt[st+3]=it+.023,Mt[st+4]=rt+.16*St[X+3],Mt[st+5]=St[X+2]-.008}Ot.attributes.position.needsUpdate=!0;for(let V=0;V<55;V++){const X=(w*.9+V*.371)%1,st=[-3.5,-1.74,2.5,4.4,.91][V%5],rt=V*2.4;ot[V*3]=st+Math.cos(rt)*X*.095,ot[V*3+1]=(V%5===4?.459:-.12)+Math.sin(X*Math.PI)*.045,ot[V*3+2]=(V%5===4?-.12:-.3)+Math.sin(rt)*X*.07}Wt.attributes.position.needsUpdate=!0,ie.rotation.z=Math.sin(w*.22)*.0016,ut.rotation.y=Math.sin(w*.31)*.0014,Bt.opacity=.34+Math.sin(w*1.3)*.025},interact(w,V,X=!1){Y.setFromCamera(new Lt(w,V),t),r.updateMatrixWorld(!0);const st=X?null:Y.intersectObject(H,!1)[0];if(!X&&!st)return null;if(st){const rt=H.worldToLocal(st.point.clone());_e.uTouch.value.set(rt.x,rt.y)}else _e.uTouch.value.set(-.08,.06);return _e.uTouchTime.value=nt,{action:"basin-ripple",value:.55}}}};function Z3(r){return je.jsx(Wu,{...r,kind:"porch",builder:Y3})}const cS=r=>()=>(r=Math.imul(r,1664525)+1013904223|0,(r>>>0)/4294967296);function no(r,t,n=.85){const a=cS(9187+r.length),o=document.createElement("canvas");o.width=o.height=256;const c=o.getContext("2d");c.fillStyle="#bcb9b0",c.fillRect(0,0,256,256);const u=c.getImageData(0,0,256,256);for(let m=0;m<256;m++)for(let p=0;p<256;p++){const g=r==="timber"?Math.sin(m*.39+Math.sin(p*.019)*3)*12+Math.sin(m*1.8)*5:r==="canvas"?(p%3===0?9:0)+(m%3===0?-11:0):Math.sin(p*.055)*Math.sin(m*.091)*6,_=174+a()*43+g,v=(m*256+p)*4;u.data[v]=_,u.data[v+1]=_-2,u.data[v+2]=_-6,u.data[v+3]=255}if(c.putImageData(u,0,0),r==="timber"){for(let m=0;m<65;m++){c.strokeStyle=`rgba(52,38,24,${.06+a()*.1})`,c.lineWidth=.4+a()*1.1,c.beginPath();const p=a()*256;c.moveTo(0,p),c.bezierCurveTo(80,p-5,150,p+5,256,p+a()*9-4),c.stroke()}for(let m=0;m<4;m++){const p=a()*256,g=a()*256;for(let _=0;_<7;_++)c.strokeStyle=`rgba(43,29,21,${.13-_*.013})`,c.beginPath(),c.ellipse(p,g,5+_*4,1.8+_*1.25,0,0,Math.PI*2),c.stroke()}}const h=new ar(o);return h.colorSpace=In,h.wrapS=h.wrapT=Va,h.repeat.set(r==="timber"?2:3,r==="timber"?1:3),new me({color:t,map:h,bumpMap:h,bumpScale:r==="timber"?.022:.009,roughness:n})}const K3=`varying vec3 vWorld;
void main(){vWorld=(modelMatrix*vec4(position,1.)).xyz;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}`,uS=`
float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453123);}
float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash(i),hash(i+vec2(1,0)),f.x),mix(hash(i+vec2(0,1)),hash(i+vec2(1,1)),f.x),f.y);}
float fbm(vec2 p){float n=0.,a=.5;mat2 m=mat2(.80,-.60,.60,.80);for(int i=0;i<5;i++){n+=a*noise(p);p=m*p*2.03+13.7;a*=.5;}return n;}
`,J3=`uniform float uTime;varying vec3 vWorld;
${uS}
void main(){
 vec3 d=normalize(vWorld-cameraPosition);float h=max(d.y,0.);
 vec3 sky=mix(vec3(.57,.65,.65),vec3(.24,.32,.37),pow(h,.47));
 vec2 p=d.xz/max(d.y+.35,.13);p=p*1.18+vec2(uTime*.002,0.);
 float broad=fbm(p*.61+vec2(4.1,13.));
 float fold=fbm(p*2.1+vec2(broad*2.,-uTime*.003));
 float billow=fbm(p*4.8+fold*2.);
 float cover=smoothstep(.25,.72,broad*.57+fold*.35+billow*.08);
 vec3 cloud=mix(vec3(.15,.205,.24),vec3(.44,.50,.52),smoothstep(.3,.75,fold));
 float side=clamp(-d.x*.50+.40,0.,1.);
 cloud+=vec3(.085,.09,.078)*side*smoothstep(.52,.70,fold);
 sky=mix(sky,cloud,cover*.97*smoothstep(-.20,.085,d.y));
 float underside=smoothstep(.50,.70,fbm(p*.83+vec2(19.,5.)))*smoothstep(-.15,.16,d.y);
 sky=mix(sky,vec3(.17,.235,.275),underside*.45);
 float haze=1.-smoothstep(.0,.16,abs(d.y));
 sky=mix(sky,vec3(.60,.68,.66),haze*.19);
 gl_FragColor=vec4(sky,1.);
 #include <tonemapping_fragment>
 #include <colorspace_fragment>
}`;function Fi(r,t,n,a){const o=new le(new Wa(...t),a);return o.position.set(...n),o.castShadow=!0,o.receiveShadow=!0,r.add(o),o}function px(r,t,n,a,o,c=a){const u=new le(new mn(c,a,t.distanceTo(n),9),o);return u.position.copy(t).lerp(n,.5),u.quaternion.setFromUnitVectors(new B(0,1,0),n.clone().sub(t).normalize()),r.add(u),u}const Q3=({scene:r,camera:t})=>{const n=cS(564932);r.background=new ue("#718687"),r.fog=new fo("#869e9a",.0085);const a=new ei({vertexShader:K3,fragmentShader:J3,uniforms:{uTime:{value:0}},side:oi,depthWrite:!1}),o=new le(new Fu(240,48,24),a);o.renderOrder=-10,r.add(o);const c=new Hu("#cbdcda","#6f6b51",2.55);r.add(c);const u=new Gu("#e4eadc",1.9);u.position.set(-30,35,12),r.add(u);const h=new Ol("#ffbe79",5.5,7,2);h.position.set(-1.55,1.42,1.7),r.add(h);const m=no("timber",7693134,.85),p=no("timber",6510405,.43),g=no("timber",8746587,.79),_=no("clay",9854528,.74);no("stone",7368545,.89);const v=new me({color:6639931,metalness:.72,roughness:.42}),x=no("canvas",9143145,.94);x.side=cn;const b=new me({color:6582378,metalness:.58,roughness:.59}),R=new kn(230,215,90,76);R.rotateX(-Math.PI/2);const M=R.attributes.position,S=[],C=(lt,Rt)=>-.5+Math.sin(lt*.035+.5)*Math.sin(Rt*.019)*2.8+Math.sin(lt*.072-Rt*.038)*1.1;for(let lt=0;lt<M.count;lt++){const Rt=M.getX(lt),Gt=M.getZ(lt)-83;M.setY(lt,C(Rt,Gt)),M.setZ(lt,Gt);const Vt=.5+.5*Math.sin(Rt*.097+Gt*.18+Math.sin(Rt*.11)),Yt=new ue().lerpColors(new ue("#56674a"),new ue("#81916a"),Vt*.58),pe=Math.pow(.5+.5*Math.cos(Gt*.67+Rt*.026),14)*.048;Yt.offsetHSL(0,0,-pe),S.push(Yt.r,Yt.g,Yt.b)}R.setAttribute("color",new ce(S,3)),R.computeVertexNormals();const O=new le(R,new me({vertexColors:!0,roughness:1}));O.receiveShadow=!0,r.add(O);for(let lt=0;lt<3;lt++){const Rt=-88-lt*25,Gt=[],Vt=[];for(let pe=0;pe<=80;pe++){const Ke=-190+pe*4.75,gn=4.2+Math.sin(pe*.13+lt*2)*3.5+Math.sin(pe*.35+lt)*1.25+lt*1.4;if(Gt.push(Ke,gn,Rt,Ke,-9,Rt),pe<80){const $e=pe*2;Vt.push($e,$e+1,$e+2,$e+1,$e+3,$e+2)}}const Yt=new Ne;Yt.setAttribute("position",new ce(Gt,3)),Yt.setIndex(Vt),Yt.computeVertexNormals(),r.add(new le(Yt,new me({color:[4940368,6584170,7966082][lt],roughness:1,side:cn})))}const E=document.createElement("canvas");E.width=E.height=256;const U=E.getContext("2d");U.fillStyle="#bdc3a9",U.fillRect(0,0,256,256);for(let lt=0;lt<6e3;lt++){const Rt=.025+n()*.11;U.fillStyle=n()<.58?`rgba(49,65,32,${Rt})`:`rgba(230,225,165,${Rt})`,U.beginPath(),U.ellipse(n()*256,n()*256,1+n()*8,1+n()*3,n()*3,0,Math.PI*2),U.fill()}const L=new ar(E);L.colorSpace=In,L.wrapS=L.wrapT=Va,L.repeat.set(30,26),O.material.map=L,O.material.bumpMap=L,O.material.bumpScale=.045;const P=new Ne,T=[],z=[];for(let lt=0;lt<12;lt++){const Rt=n()*Math.PI*2,Gt=n()*.19,Vt=.06+n()*.18,Yt=Math.cos(Rt)*Gt,pe=Math.sin(Rt)*Gt,Ke=.26+n()*.37,gn=.015+n()*.015,$e=T.length/3;for(let He=0;He<4;He++){const qe=He/3,Tn=Yt+Math.cos(Rt)*qe*qe*Vt,wi=pe+Math.sin(Rt)*qe*qe*Vt,ha=gn*(1-qe*.92);if(T.push(Tn-Math.cos(Rt+1.57)*ha,qe*Ke,wi-Math.sin(Rt+1.57)*ha,Tn+Math.cos(Rt+1.57)*ha,qe*Ke,wi+Math.sin(Rt+1.57)*ha),He<3){const Gi=$e+He*2;z.push(Gi,Gi+1,Gi+2,Gi+1,Gi+3,Gi+2)}}}P.setAttribute("position",new ce(T,3)),P.setIndex(z),P.computeVertexNormals();const W=new me({color:16777215,roughness:.97,side:cn}),J={value:0};W.onBeforeCompile=lt=>{lt.uniforms.uGrassTime=J,lt.vertexShader=`uniform float uGrassTime;
`+lt.vertexShader,lt.vertexShader=lt.vertexShader.replace("#include <begin_vertex>",`#include <begin_vertex>
      float bx = instanceMatrix[3].x; float bz=instanceMatrix[3].z;
      transformed.x += sin(uGrassTime*.65+bx*.15+bz*.11)*pow(max(position.y,0.),2.)*.19;
      transformed.z += sin(uGrassTime*.49+bz*.16)*pow(max(position.y,0.),2.)*.09;`)};const Q=new En(P,W,4200),et=new Mn,k=new ue;for(let lt=0;lt<4200;lt++){const Rt=(n()-.5)*80,Gt=-3-Math.pow(n(),1.9)*69;et.position.set(Rt,C(Rt,Gt)+.08,Gt),et.rotation.set(0,n()*Math.PI*2,0),et.scale.setScalar(.6+n()*1.1),et.updateMatrix(),Q.setMatrixAt(lt,et.matrix),k.setHSL(.19+n()*.05,.2+n()*.18,.24+n()*.12),Q.setColorAt(lt,k)}Q.frustumCulled=!1,r.add(Q);const q=new ho(1,3),F=q.attributes.position;for(let lt=0;lt<F.count;lt++){const Rt=F.getX(lt),Gt=F.getY(lt),Vt=F.getZ(lt),Yt=1+Math.sin(Rt*8+Vt*6)*.072+Math.sin(Gt*11+Rt*5)*.068+Math.cos(Vt*14-Gt*9)*.053;F.setXYZ(lt,Rt*Yt,Gt*Yt,Vt*Yt)}const Z=q.attributes.normal;for(let lt=0;lt<F.count;lt++){const Rt=new B(F.getX(lt),F.getY(lt),F.getZ(lt)).normalize();Z.setXYZ(lt,Rt.x,Rt.y,Rt.z)}const ht=new En(q,new me({color:8230258,roughness:1}),165),dt=new En(new mn(.1,.18,1,5),new me({color:5132609}),55);for(let lt=0;lt<55;lt++){const Rt=-87+lt*3.4+n()*2,Gt=-62+Math.sin(lt*.33)*7,Vt=2.2+n()*2.7;et.position.set(Rt,C(Rt,Gt)+Vt*.35,Gt),et.rotation.set(0,0,0),et.scale.set(1,Vt*.7,1),et.updateMatrix(),dt.setMatrixAt(lt,et.matrix);for(let Yt=0;Yt<3;Yt++)et.position.set(Rt+(Yt-1)*Vt*.25,C(Rt,Gt)+Vt*(.68+n()*.16),Gt+(n()-.5)*2),et.rotation.set(n(),n(),n()),et.scale.set(Vt*(.37+n()*.1),Vt*(.35+n()*.22),Vt*.4),et.updateMatrix(),ht.setMatrixAt(lt*3+Yt,et.matrix),k.setHSL(.25,.21,.22+n()*.08),ht.setColorAt(lt*3+Yt,k)}r.add(ht,dt),Fi(r,[6.8,.24,6.8],[0,-.19,1.55],m);for(let lt=0;lt<19;lt++){const Rt=Fi(r,[.346,.1,6.8],[-3.22+lt*.357,-.025+n()*.006,1.55],lt%4===0?g:p);Rt.rotation.y=(n()-.5)*.002}Fi(r,[6.9,.24,.2],[0,-.04,-1.88],g);const pt=[[-2.85,-1.13],[2.85,-1.13],[-2.85,4.2],[2.85,4.2]];for(const[lt,Rt]of pt){Fi(r,[.21,3.38,.23],[lt,1.59,Rt],m),Fi(r,[.25,.18,.27],[lt,.15,Rt],g);const Gt=Fi(r,[.13,1,.13],[lt-Math.sign(lt)*.26,2.75,Rt],g);Gt.rotation.z=Math.sign(lt)*-.54;for(const Vt of[.56,2.45]){const Yt=new le(new mn(.018,.018,.01,9),v);Yt.rotation.x=Math.PI/2,Yt.position.set(lt,Vt,Rt+.124),r.add(Yt)}}Fi(r,[6.15,.25,.27],[0,3.19,-1.13],m),Fi(r,[6.15,.25,.27],[0,3.57,4.2],m);for(let lt=0;lt<7;lt++){const Rt=Fi(r,[.14,.18,6.15],[-2.75+lt*.916,3.42,1.4],g);Rt.rotation.x=.063}const I=new kn(6.6,6.4,120,1);I.rotateX(-Math.PI/2);const ct=I.attributes.position;for(let lt=0;lt<ct.count;lt++)ct.setY(lt,Math.sin(ct.getX(lt)*31)*.032+ct.getZ(lt)*.064);I.computeVertexNormals();const At=new le(I,b);At.material.side=cn,At.position.set(0,3.58,1.35),r.add(At);const It=new le(new mn(.095,.095,6.55,14,1,!0,0,Math.PI),b);It.rotation.z=Math.PI/2,It.position.set(0,3.12,-1.87),r.add(It);const kt=new kn(5.66,1,64,14),zt=kt.attributes.position;for(let lt=0;lt<zt.count;lt++)zt.setZ(lt,Math.sin(zt.getX(lt)*12.5)*.016+.035*Math.sin((zt.getY(lt)+.5)*Math.PI));kt.computeVertexNormals();const ut=new le(kt,x);ut.position.set(0,2.85,-1.32),r.add(ut);const Tt=Fi(r,[5.74,.055,.06],[0,2.6,-1.32],g),Ht=new le(new mn(.11,.11,5.72,20),x);Ht.rotation.z=Math.PI/2,Ht.position.set(0,3.03,-1.32),r.add(Ht);const ie=new me({color:10917752,roughness:1}),qt=px(r,new B(.84,3.04,-1.24),new B(.84,1.64,-1.24),.012,ie),re=new le(new js(.06,.012,6,24),ie);re.scale.y=1.75,re.position.set(.84,1.58,-1.24),r.add(re);const Fe=new le(new Wa(.5,1.8,.4),new Fa({visible:!1}));Fe.position.set(.84,2.15,-1.24),r.add(Fe);let ee=.82,de=.82;const xe=[new Lt(.21,0),new Lt(.28,.08),new Lt(.4,.4),new Lt(.42,.62),new Lt(.34,.84),new Lt(.29,.89),new Lt(.3,.96),new Lt(.34,.99),new Lt(.35,1.03),new Lt(.3,1.06),new Lt(.26,1.01),new Lt(.255,.9),new Lt(.3,.77)],fe=new le(new Pl(xe,56),_);fe.position.set(1.11,.025,.25),fe.castShadow=!0,fe.receiveShadow=!0,r.add(fe);const be=new le(new Ts(.29,40),new me({color:3419171,roughness:.9}));be.rotation.x=-Math.PI/2,be.position.set(1.11,.79,.25),r.add(be);const ke=[];for(const lt of[.13,.75,.94]){const Rt=new le(new js(lt===.75?.368:lt===.94?.292:.3,.007,4,56),_);Rt.rotation.x=Math.PI/2,Rt.position.set(1.11,lt+.025,.25),r.add(Rt),ke.push(Rt)}const ze=new le(new mn(.52,.46,.07,40),_);ze.position.set(1.11,.067,.25),r.add(ze);const ne=new ji;ne.position.set(-1.6,.06,1.35),Fi(ne,[.66,.08,.45],[0,.53,0],g);for(const lt of[-.23,.23])for(const Rt of[-.13,.13]){const Gt=Fi(ne,[.07,.51,.08],[lt,.27,Rt],m);Gt.rotation.z=-Math.sign(lt)*.11}r.add(ne);const Se=new ji;Se.position.set(-1.6,.65,1.35);const j=new le(new mn(.16,.18,.08,32),v);Se.add(j);const _e=new le(new mn(.12,.135,.27,32,1,!0),new Nl({color:15326650,roughness:.1,transparent:!0,opacity:.2,side:cn,metalness:.12}));_e.position.y=.17,Se.add(_e);const Ee=new le(new mn(.032,.042,.19,12),new Fa({color:16766365}));Ee.position.y=.13,Se.add(Ee);const H=new le(new Bu(.19,.13,32),v);H.position.y=.38,Se.add(H);for(let lt=0;lt<4;lt++){const Rt=lt*Math.PI/2;px(Se,new B(Math.cos(Rt)*.145,.04,Math.sin(Rt)*.145),new B(Math.cos(Rt)*.145,.33,Math.sin(Rt)*.145),.014,v)}const A=new le(new js(.115,.009,5,24,Math.PI),v);A.position.y=.46,Se.add(A),r.add(Se);const at=[];for(const[lt,Rt,Gt,Vt]of[[-32,-69,31,.28],[20,-95,54,.28],[-1,-45,19,.12],[48,-56,24,.26],[-58,-112,44,.33]]){const Yt=new ei({transparent:!0,depthWrite:!1,side:cn,uniforms:{uTime:{value:0},uOpacity:{value:Vt}},vertexShader:"varying vec2 vUv;void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}",fragmentShader:`varying vec2 vUv;uniform float uTime;uniform float uOpacity;${uS}
      void main(){float x=vUv.x+vUv.y*.17;float streak=fbm(vec2(x*19.,vUv.y*.8-uTime*.022));float edge=smoothstep(0.,.2,vUv.x)*smoothstep(1.,.79,vUv.x);float base=smoothstep(0.,.07,vUv.y)*smoothstep(1.,.48,vUv.y);float a=(.3+streak*.7)*edge*base*uOpacity;gl_FragColor=vec4(.70,.78,.78,a);#include <colorspace_fragment>}`.replace(";#include",`;
#include`)}),pe=new le(new kn(Gt,30),Yt);pe.position.set(lt,13.1,Rt),pe.renderOrder=2,r.add(pe),at.push(Yt)}const mt=1350,bt=new Ne,Bt=new Float32Array(mt*6),Ft=[];for(let lt=0;lt<mt;lt++)Ft.push((n()-.5)*64,n()*16,-2.35-n()*54,.3+n()*.38);bt.setAttribute("position",new qn(Bt,3));const Mt=new ir(bt,new nr({color:13360346,transparent:!0,opacity:.23,depthWrite:!1}));Mt.frustumCulled=!1,Mt.renderOrder=3,r.add(Mt);const St=new Ne,Ot=new Float32Array(276),Xt=[];for(let lt=0;lt<46;lt++)Xt.push((n()-.5)*6.45,n()*3.1,.06+n()*.13);St.setAttribute("position",new qn(Ot,3));const Wt=new ir(St,new nr({color:13359302,transparent:!0,opacity:.39,depthWrite:!1}));Wt.frustumCulled=!1,r.add(Wt);const ot=new $p(.017,.031,14),G=new Fa({color:11781560,transparent:!0,opacity:.065,depthWrite:!1,side:cn}),Y=new En(ot,G,36);r.add(Y);const nt=document.createElement("canvas");nt.width=nt.height=128;const w=nt.getContext("2d"),V=w.createRadialGradient(64,64,7,64,64,64);V.addColorStop(0,"rgba(19,22,18,0.52)"),V.addColorStop(.45,"rgba(19,22,18,0.29)"),V.addColorStop(1,"rgba(19,22,18,0)"),w.fillStyle=V,w.fillRect(0,0,128,128);const X=new ar(nt),st=new Fa({map:X,transparent:!0,depthWrite:!1,polygonOffset:!0,polygonOffsetFactor:-1}),rt=[];for(const[lt,Rt,Gt,Vt]of[[1.11,.25,1.4,1.2],[-1.6,1.35,1.1,.86],[-2.85,-1.13,.74,.7],[2.85,-1.13,.74,.7]]){const Yt=new le(new kn(Gt,Vt),st);Yt.rotation.x=-Math.PI/2,Yt.position.set(lt,.033,Rt),r.add(Yt),rt.push(Yt)}const it=new Vu;function Ct(lt,Rt){a.uniforms.uTime.value=lt,J.value=lt;for(const Vt of at)Vt.uniforms.uTime.value=lt;ee+=(de-ee)*Math.min(1,Rt*2);const Gt=.18+(1-ee)*.86;ut.scale.y=Gt,ut.position.y=3.02-Gt*.5,Tt.position.y=3.02-Gt,ut.rotation.y=Math.sin(lt*.31)*.003;for(let Vt=0;Vt<mt;Vt++){const Yt=Vt*4,pe=Vt*6,Ke=(Ft[Yt+1]-lt*6.4)%16,gn=Ke<0?Ke+16:Ke,$e=Ft[Yt]+gn*.078;Bt[pe]=$e,Bt[pe+1]=gn-.8,Bt[pe+2]=Ft[Yt+2],Bt[pe+3]=$e+.031,Bt[pe+4]=gn+Ft[Yt+3]-.8,Bt[pe+5]=Ft[Yt+2]+.018}bt.attributes.position.needsUpdate=!0;for(let Vt=0;Vt<46;Vt++){const Yt=Vt*3,pe=Vt*6,Ke=((Xt[Yt+1]-lt*3.35)%3.1+3.1)%3.1;Ot[pe]=Xt[Yt],Ot[pe+1]=Ke,Ot[pe+2]=-1.91,Ot[pe+3]=Xt[Yt]+.003,Ot[pe+4]=Ke+Xt[Yt+2],Ot[pe+5]=-1.92}St.attributes.position.needsUpdate=!0;for(let Vt=0;Vt<36;Vt++){const Yt=(lt*.41+Vt*.317)%1;et.position.set(Xt[Vt*3],.033,-1.66-Vt*.618%1*.16),et.rotation.set(-Math.PI/2,0,0),et.scale.setScalar(.25+Yt*1.1),et.updateMatrix(),Y.setMatrixAt(Vt,et.matrix)}Y.instanceMatrix.needsUpdate=!0}function Pt(lt){t.position.set(lt<.8?.12:0,1.48,2.45);const Rt=lt<.8,Gt=Rt?.61:1.11,Vt=Rt?-.28:.25;fe.position.set(Gt,.025,Vt),be.position.set(Gt,.79,Vt),ze.position.set(Gt,.067,Vt);for(const Yt of ke)Yt.position.x=Gt,Yt.position.z=Vt;ne.position.set(Rt?-.39:-1.6,.06,Rt?-.05:1.35),Se.position.set(Rt?-.39:-1.6,.65,Rt?-.05:1.35),rt[0].position.set(Gt,.033,Vt),rt[1].position.set(Rt?-.39:-1.6,.033,Rt?-.05:1.35),h.position.set(Rt?-.39:-1.55,1.2,Rt?-.05:1.7),t.fov=lt<.8?62:56,t.near=.08,t.far=420,t.lookAt(lt<.8?-.1:0,lt<.8?1.78:1.9,-27),t.updateProjectionMatrix()}return Ct(0,0),Pt(t.aspect),{update:Ct,resize:Pt,interact(lt,Rt,Gt=!1,Vt=!1){return it.setFromCamera(new Lt(lt,Rt),t),!Gt&&it.intersectObjects([Fe,ut,Tt,qt,re],!1).length===0?null:(de=de>.6?.26:.9,Vt&&(ee=de),{action:"awning",value:de})}}};function j3(r){return je.jsx(Wu,{...r,kind:"storm",builder:Q3})}const fS={tent:V3,window:q3,porch:Z3,storm:j3},Np=new URLSearchParams(window.location.search),Bd=Np.get("world"),Fd=Bd&&Bd in fS?Bd:"tent";function $3(){const[r,t]=Vn.useState(Np.get("paused")!=="1"),[n,a]=Vn.useState(!0),[o,c]=Vn.useState(!1),[u,h]=Vn.useState(Np.get("static3D")==="1"),[m,p]=Vn.useState([]),[g,_]=Vn.useState(0),v=R=>p(M=>[...M.slice(-49),R]),x=fS[Fd],b=je.jsx(je.Fragment,{children:je.jsx("div",{className:"qa-drag-overlay","data-scene-drag":!0,"aria-label":"QA transparent player drag surface",children:je.jsxs("div",{className:"qa-player-chrome","aria-label":"QA player chrome",children:[je.jsx("button",{"data-qa-chrome-button":!0,onClick:()=>_(R=>R+1),children:"Player chrome"}),je.jsx("input",{"data-qa-chrome-input":!0,type:"range","aria-label":"QA player volume",min:"0",max:"100",defaultValue:"50"})]})})});return je.jsxs(je.Fragment,{children:[je.jsxs("main",{id:"qa-stage","data-world":Fd,"data-mounted":n,"data-active":r,"data-static":u,children:[n&&je.jsxs("div",{id:"qa-primary-holder",className:"qa-holder","data-scene-surface":!0,children:[je.jsx(x,{active:r,static3D:u,onInteraction:v}),b]}),n&&o&&je.jsxs("div",{id:"qa-second-holder",className:"qa-holder qa-second","data-scene-surface":!0,"aria-label":"QA second holder",children:[je.jsx(x,{active:r,static3D:u,onInteraction:v}),b]})]}),je.jsxs("aside",{id:"qa-controls","aria-label":"Isolated QA controls",children:[je.jsx("strong",{children:Fd}),je.jsx("button",{id:"qa-active",onClick:()=>t(R=>!R),children:r?"Pause":"Resume"}),je.jsx("button",{id:"qa-mounted",onClick:()=>{a(R=>!R),c(!1)},children:n?"Unmount":"Mount"}),je.jsx("button",{id:"qa-second",disabled:!n,onClick:()=>c(R=>!R),children:o?"Close second holder":"Open second holder"}),je.jsxs("button",{id:"qa-static",onClick:()=>h(R=>!R),children:["Static ",u?"on":"off"]}),je.jsxs("output",{id:"qa-events","data-count":m.length,"data-chrome-clicks":g,"data-events":JSON.stringify(m),children:[m.length," interactions"]})]})]})}by.createRoot(document.getElementById("root")).render(je.jsx($3,{}));
